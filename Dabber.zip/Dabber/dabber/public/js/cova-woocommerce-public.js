(function ( $ ) {
    'use strict';

    $(document).ready(
        function () {
            $('body').on(
                'change', '.single_variation_wrap #select_location', function (e) {
                    // console.log('location changed');
                }
            );
        }
    );

})(jQuery);
