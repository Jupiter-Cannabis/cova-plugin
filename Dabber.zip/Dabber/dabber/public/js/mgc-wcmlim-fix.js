(function ($) {
    /**
     * mgc_wcmlim declared in cova-woocommerce-public.js 
     */
    let mgc_wcmlim_data = {};

    function mgc_wcmlim_get_selected_location_id()
    {
        let selected_location_index = mgc_wcmlim.current_location;

        if ($('select#wcmlim-change-lc-select').length > 0) {
            selected_location_index = $('select#wcmlim-change-lc-select').val();
        }

        return mgc_wcmlim.location_terms[selected_location_index]['term_id'];
    }

    function mgc_wcmlim_initialize_price_data()
    {
        let options = $('select#pa_brand');

        if (options.length < 1) { return; }

        mgc_wcmlim_data['selected_variation']    = options.val();
        mgc_wcmlim_data['selected_location']    = mgc_wcmlim_get_selected_location_id();
        
        let regular_price = mgc_wcmlim.single_product_price[mgc_wcmlim_data.selected_variation][mgc_wcmlim_data.selected_location]['regular'];
        let sale_price       = mgc_wcmlim.single_product_price[mgc_wcmlim_data.selected_variation][mgc_wcmlim_data.selected_location]['sale'];

        mgc_wcmlim_data['regular_price'] = (regular_price !== '')? parseFloat(regular_price).toFixed(2) : 0;
        mgc_wcmlim_data['sale_price']     = (sale_price !== '')? parseFloat(sale_price).toFixed(2) : 0;
    }

    function mgc_wcmlim_is_location_request(data)
    {
        let components = JSON.parse('{"' + decodeURI(data).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"') + '"}');

        if (!components.hasOwnProperty('action')) {
            return false;
        }

        if (components.action !== 'wcmlim_display_location') {
            return false;
        }

        return true;
    }

    function mgc_wcmlim_get_location_price_html(xhr, options)
    {        
        let data = $.parseJSON(xhr.responseText);
        let is_loc_request = mgc_wcmlim_is_location_request(options.data);
        
        if (!is_loc_request) { return; }

        let prices = data[mgc_wcmlim.current_location_index];
        let price_html = 'test';

        if (prices.hasOwnProperty('sale_price')) {
            let fragment_price_html = '<del>'+ prices.regular_price +'</del>';
            fragment_price_html += '<ins>'+ prices.sale_price +'</ins>';

            console.log('fragment_price_html', fragment_price_html);
            price_html = fragment_price_html;
            // $('body.single-product .summary .price').html(price_html);
        } else {
            console.log('prices.regular_price', prices.regular_price);
            price_html = prices.regular_price;
            // $('body.single-product .summary .price').html(prices.regular_price);
        }    
        console.log(xhr.responseText);
        console.log('is_loc_request', is_loc_request);
        console.log('price_html', price_html);
        console.log('prices', prices);
        console.log('data', data);

        $('body.single-product .summary .price').each(
            function () {
                $(this).html(price_html);
            }
        );

        let final_price_html = $('body.single-product .summary .price').prop('outerHTML');

        if ($('.summary .single_variation_wrap .sticky-bar-action').length > 0) {
            if ($('.summary .single_variation_wrap .sticky-bar-action .price').length < 1) {
                $('.summary .single_variation_wrap .sticky-bar-action').prepend(final_price_html);
            }            
        }
    }

    function mgc_wcmlim_on_variation_change()
    {
        $('select#pa_brand').on(
            'change', function (e) {
                $('body.single-product .summary .price').html(mgc_vars.loader_html);
            }
        );
    }

    $(document).ready(
        function () {
            mgc_wcmlim_initialize_price_data();
            mgc_wcmlim_on_variation_change();
        }
    );


    $(document).ajaxComplete(
        function (event, xhr, options) {
            mgc_wcmlim_get_location_price_html(xhr, options);
        }
    );

})(jQuery);