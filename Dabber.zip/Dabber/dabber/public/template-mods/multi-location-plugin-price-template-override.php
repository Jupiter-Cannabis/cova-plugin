<?php

if (! defined('ABSPATH') ) {
    exit; // Exit if accessed directly
}

global $product;

$price =  $product->get_price_html(); 

?>

<p class="<?php echo esc_attr(apply_filters('woocommerce_product_price_class', 'price')); ?>">
    <?php if($price !== '' && is_product()) : ?>
        <span class="mgc-loader-wrap"><span class="mgc-loader">Loading...</span></span>
    <?php else : ?>
        <?php echo $product->get_price_html(); ?>
    <?php endif; ?>
</p>
