<?php

add_action(
    'plugins_loaded', function () {
        /**
         * Remove out of stock duplicate in product archive items
         */
        cova_remove_filters_with_method_name('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_stock', 10);

        add_filter('woocommerce_post_class', 'mgc_add_product_list_class', 10, 2);
    }, 9999
);

/**
 * @reference https://wordpress.stackexchange.com/questions/304859/remove-action-from-a-plugin-class
 */
function cova_remove_filters_with_method_name( $hook_name = '', $method_name = '', $priority = 0 )
{
    global $wp_filter;
    // Take only filters on right hook name and priority
    if (! isset($wp_filter[ $hook_name ][ $priority ]) || ! is_array($wp_filter[ $hook_name ][ $priority ]) ) {
        return false;
    }
    // Loop on filters registered
    foreach ( (array) $wp_filter[ $hook_name ][ $priority ] as $unique_id => $filter_array ) {
        // Test if filter is an array ! (always for class/method)
        if (isset($filter_array['function']) && is_array($filter_array['function']) ) {
            // Test if object is a class and method is equal to param !
            if (is_object($filter_array['function'][0]) && get_class($filter_array['function'][0]) && $filter_array['function'][1] == $method_name ) {
                // Test for WordPress >= 4.7 WP_Hook class (https://make.wordpress.org/core/2016/09/08/wp_hook-next-generation-actions-and-filters/)
                if (is_a($wp_filter[ $hook_name ], 'WP_Hook') ) {
                    unset($wp_filter[ $hook_name ]->callbacks[ $priority ][ $unique_id ]);
                } else {
                    unset($wp_filter[ $hook_name ][ $priority ][ $unique_id ]);
                }
            }
        }
    }
    return false;
}

function mgc_add_product_list_class($classes, $product)
{
    $current_location_stock = mgc_get_product_location_stock_quantity($product->get_id());

    if ($current_location_stock > 0) {
        $classes[] = 'current-location-has-stock';
    }    

    return $classes;
}

/**
 * Show potency
 */
//function dabber_woocommerce_shop_loop_potency()
//{
//    global $product;
//
//    $mgCategories = ['edibles', 'beverages', 'topicals', 'tinctures'];
//
//    // Get top level category
//    $mainCategory = null;
//    $categories = get_the_terms($product->get_id(), 'product_cat');
//
//    foreach ($categories as $category) {
//        if ($category->parent == 0) {
//           $mainCategory = $category;
//        }
//    }
//
//    // Get unit
//    $unit = in_array($mainCategory->slug, $mgCategories) ? 'mg' : '%';
//
//    $max_thc  = get_field('maximum_thc_content_percent', $product->get_id());
//    $min_thc  = get_field('minimum_thc_content_percent', $product->get_id());
//    $max_cbd  = get_field('maximum_cbd_content_percent', $product->get_id());
//
//    $potency = [];
//
//    if ($max_thc) {
//        $potency['thc'] = '<span>THC:</span> ' . $max_thc . $unit;
//    }
//
//    if ($min_thc && $min_thc != $max_thc) {
//        $potency['thc'] = '<span>THC:</span> ' . $min_thc . $unit . ' - ' . $max_thc . $unit;
//    }
//
//    if ($max_cbd) {
//        $potency['cbd'] = '<span>CBD:</span> ' . $max_cbd . $unit;
//    }
//
//    echo '<div class="product-potency">' . (count($potency) ? implode(' | ', $potency) : '&nbsp;') . '</div>';
//}
//add_action( 'woocommerce_shop_loop_item_title', 'dabber_woocommerce_shop_loop_potency', 10);
