<?php

add_filter('woocommerce_add_to_cart_redirect', 'add_to_cart_redirect_to_shop');

/**
 * Redirect users after add to cart.
 */
function add_to_cart_redirect_to_shop()
{
    // Get product ID
    if (isset($_REQUEST['add-to-cart'])) {
        $product_id = (int) apply_filters('woocommerce_add_to_cart_product_id', $_REQUEST['add-to-cart']);

        // Redirect back to product page
        return get_permalink($product_id);

        // Get top level category
        $mainCategory = null;
        $categories = get_the_terms($product_id, 'product_cat');

        foreach ($categories as $category) {
            if ($category->parent == 0) {
                $mainCategory = $category;
            }
        }

        if ($mainCategory) {
            // Redirect to main category page
            return get_term_link($mainCategory, 'product_cat');
        }
    }

    // Redirect to shop page
    return get_permalink(wc_get_page_id('shop'));
}

add_action('wp_footer', 'dabber_open_cart_after_added_to_cart');

/**
 * Open side cart after product has been added into it
 */
function dabber_open_cart_after_added_to_cart()
{
    ?>
    <script type="text/javascript">
        jQuery(function() {
            jQuery( document.body ).on('added_to_cart', function() {
                if (!jQuery('body').hasClass('single-product')) {
                    jQuery('.dropdown-toggle').click();
                }
            });
        });
    </script>
    <?php
}

function dabber_product_stock_hooks()
{
    add_filter('woocommerce_product_get_stock_quantity', 'dabber_override_product_stock_quantity', 11, 2);
    add_filter('woocommerce_product_get_stock_status', 'dabber_override_product_stock_status', 11, 2);
}
add_action('wp', 'dabber_product_stock_hooks');

function dabber_override_product_stock_quantity($value, $product)
{
    if (is_admin()) {
        return $value;
    }    
    $current_location = cova_get_current_location();
    $location_quantity = dabber_get_product_location_stock_quantity($product->get_id(), $current_location); 

    return $location_quantity;
}

function dabber_override_product_stock_status($value, $product)
{
    global $dabber_current_location_data;

    if (is_admin()) {
        return $value;
    }

    $current_location  = cova_get_current_location();
    $location_quantity = dabber_get_product_location_stock_quantity($product->get_id(), $current_location); 
    //$stock_threshold   = (int) get_option('woocommerce_notify_no_stock_amount');
    $stock_threshold = $dabber_current_location_data['oos_threshold'];

    if ($location_quantity > $stock_threshold) {
        return 'instock';
    }

    return 'outofstock';
}
