<?php

/**
 * Remove selected variation title in product cart item title (cart slider)
 */
add_filter('woocommerce_product_variation_title_include_attributes', 'cova_custom_product_variation_title', 999, 2);
function cova_custom_product_variation_title($should_include_attributes, $product)
{
    return false;
}

/**
 * Remove selected variation title in product cart item title (cart page)
 */
add_filter('woocommerce_cart_item_name', 'cova_modify_cart_page_item_title', 99999, 3);
function cova_modify_cart_page_item_title($title, $cart_item, $cart_item_key)
{
    $product_link = get_the_permalink($cart_item['data']->get_id());
    $location = $cart_item['select_location']['location_name'];
    $title = $cart_item['data']->get_name();

    return '<a href="'. $product_link .'"><span>'. $title .'<p>Location: '. $location .'</p></span></a>';
}

/**
 * Remove Uncategorized category in product loop category list
 */
add_filter('term_links-product_cat', 'mgc_remove_uncategorized_from_list');
function mgc_remove_uncategorized_from_list($links)
{
    foreach ($links as $key => $link) {
        if (stripos($link, 'uncategorized') !== false) {
            unset($links[$key]);
        }
    }

    return $links;
}

add_action('wp_head', 'mgc_wcmlim_add_inline_styling');
function mgc_wcmlim_add_inline_styling()
{
    $display_preferred = get_option("wcmlim_display_preferred_loc");
    ?>
    <style type="text/css">
        <?php if($display_preferred === 'on') : ?>
            .Wcmlim_sloc_label {
                display: none !important;
            }
        <?php endif; ?>
        .summary span.sku_wrapper {
            display: none;
        }        
    </style>
    <?php
}

/**
 * If the product has featured_image meta, use it instead of the image ID
 * The returned value will be used later on for wp_get_attachment_image and wp_get_attachment_image_src
 *
 * @param  $value
 * @param  $object
 * @return mixed
 */
function cova_modify_product_get_image_id($value, $object)
{
    $cova_image = $object->get_meta('featured_image');

    if (empty($cova_image)) {
        return $value;
    }

    return $cova_image;
}
add_filter('woocommerce_product_get_image_id', 'cova_modify_product_get_image_id', 20, 2);

function cova_modify_gallery_image_ids($value, $object)
{
    $cova_images = $object->get_meta('images');

    if (empty($cova_images)) {
        return $value;
    }

    return $cova_images;
}
add_filter('woocommerce_product_get_gallery_image_ids', 'cova_modify_gallery_image_ids', 20, 2);

function cova_modify_get_attachment_image_src($image, $attachment_id, $size, $icon)
{
    if (is_int($attachment_id)) {
        return $image;
    }

    $size = (is_array($size))? [$size[0], $size[1]] : $size;
    $img_data = cova_get_product_image_url($attachment_id, $size);

    if (!is_array($img_data)) {
        $img_data = [
            'url' => $img_data,
            'size' => [1500, 1500],
        ];
    }

    return [
        $img_data['url'],
        $img_data['size'][0],
        $img_data['size'][1],
        true
    ];
}
add_filter('wp_get_attachment_image_src', 'cova_modify_get_attachment_image_src', 20, 4);

function cova_set_product_is_on_sale($on_sale, $product)
{
    $current_location = cova_get_current_location();

    $regular_price = cova_get_product_location_regular_price($product->get_id(), $current_location);
    $sale_price = cova_get_product_location_sale_price($product->get_id(), $current_location);

    if (!$sale_price || $sale_price == '0') {
        return false;
    }

    if ($sale_price > 0 & $sale_price < $regular_price) {
        return true;
    }

    return $on_sale;
}
add_filter('woocommerce_product_is_on_sale', 'cova_set_product_is_on_sale', 9999, 2);

function cova_override_price_html($price, $product)
{
    if ($product->is_type('simple')) {
        $current_location = cova_get_current_location();
        $sale_price       = cova_get_product_location_sale_price($product->get_id(), $current_location);
        $regular_price    = cova_get_product_location_regular_price($product->get_id(), $current_location);

        if ($sale_price > 0 && $sale_price < $regular_price) {
            $price = '<del aria-hidden="true">' . ( is_numeric($regular_price) ? wc_price($regular_price) : $regular_price ) . '</del> <ins>' . ( is_numeric($sale_price) ? wc_price($sale_price) : $sale_price ) . '</ins>';

        } else {
            $price = '<span class="woocommerce-Price-amount amount">'. ( is_numeric($regular_price) ? wc_price($regular_price) : $regular_price ) .'</span>';
        }
    }
    
    return $price;
}
add_filter('woocommerce_get_price_html', 'cova_override_price_html', 100, 2);


function dabber_override_product_regular_price($value, $product)
{
    $current_location = cova_get_current_location();
    $location_price   = cova_get_product_location_regular_price($product->get_id(), $current_location);

    return $location_price;
}
add_filter('woocommerce_product_get_regular_price', 'dabber_override_product_regular_price', 11, 2);

function dabber_override_product_sale_price($value, $product)
{
    $current_location = cova_get_current_location();
    $location_price   = cova_get_product_location_sale_price($product->get_id(), $current_location);

    return $location_price;
}
add_filter('woocommerce_product_get_sale_price', 'dabber_override_product_sale_price', 11, 2);

add_filter('woocommerce_get_product_terms', 'dabber_modify_variation_dropdown_term_sorting', 100, 4);
function dabber_modify_variation_dropdown_term_sorting($terms, $product_id, $taxonomy, $args)
{
    uasort(
        $terms, function ($a, $b) {
            return $a->term_id <=> $b->term_id;
        }
    );

    return $terms;
}

//add_filter('wc_price', 'dabber_hide_product_with_default_price', 100, 2);
function dabber_hide_product_with_default_price($return, $price)
{
    if ($price === '1,000.00' || $price === '1000') {
        return '';
    }

    return $return;
}

add_filter('woocommerce_is_purchasable', 'dabber_set_product_with_default_price_purchasable', 9999, 2);
function dabber_set_product_with_default_price_purchasable($is_purchasable, $product)
{
    if ($product->get_regular_price() == '1000') {
        return false;
    }

    return $is_purchasable;
}

add_filter('woocommerce_loop_add_to_cart_link', 'dabber_hide_add_to_cart_with_default_price', 9999, 2);
function dabber_hide_add_to_cart_with_default_price($button, $product)
{
    if ($product->get_regular_price() == '1000') {
        return '';
    }
    return $button;
}
