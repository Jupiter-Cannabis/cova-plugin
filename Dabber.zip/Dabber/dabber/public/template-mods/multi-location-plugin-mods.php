<?php

/**
 * This file is for Woocommerce-Multi-Locations-Inventory-Management bug fixes.
 */
add_action(
    'plugins_loaded', function () {
        if (!class_exists('Wcmlim')) { return; 
        }

        // add_action('wp_enqueue_scripts', 'mgc_wcmlim_load_scripts', 99999);
        // add_filter('wc_get_template', 'mgc_wcmlim_modify_single_product_price_template_path', 50, 10);
        // add_filter('wc_get_template', 'mgc_wcmlim_modify_loop_price_template_path', 50, 10);
        add_action('init', 'mgc_wcmlim_set_current_location_by_parameter', 0);
    }, 9999
);

function mgc_wcmlim_load_scripts()
{
    if (is_product()) {

        global $post;

        wp_enqueue_style('cova-wcmlim-fix-css', MGC_PLUGIN_URI .'public/css/mgc-wcmlim-fix.css', [], null);
        wp_enqueue_script('cova-wcmlim-fix-js', MGC_PLUGIN_URI .'public/js/mgc-wcmlim-fix.js', [], strtotime(date('Y-m-d h:i:s')), true);

        $currency_symbol = get_woocommerce_currency_symbol();
        $currency_symbol = ($currency_symbol)? $currency_symbol : '$';

        wp_add_inline_script(
            'cova-wcmlim-fix-js', 'mgc_wcmlim = '. json_encode(
                [
                'currency_symbol'         => $currency_symbol,
                'current_location'          => $_COOKIE['mcgyver_selected_location_term_id'],
                'current_location_index' => $_COOKIE['wcmlim_selected_location'],
                'location_terms'          => mgc_wcmlim_get_location_terms(),
                'single_product_price'      => mgc_wcmlim_get_product_initial_price($post->ID)
                ]
            ), 'before'
        );
    }    
}

function mgc_wcmlim_set_current_location_by_parameter()
{    
    if (isset($_POST['wcmlim_change_lc_to'])) {
        return;
    }
    if (!isset($_GET['store-location'])) {
        return;
    }
    if ($_GET['store-location'] === '') {
        return;
    }

    $selected_location = $_GET['store-location'];

    $cookieTimeOption = get_option("wcmlim_set_location_cookie_time");
    $shold = get_option("wcmlim_show_location_selection");
    $cookieTime = intval($cookieTimeOption) ? $cookieTimeOption : 1;
    if ($shold == "on") {
        if (is_user_logged_in()) {
            $current_user_id = get_current_user_id();
            $specificLocation = get_user_meta($current_user_id, 'wcmlim_user_specific_location', true);    
            setcookie("wcmlim_selected_location", $specificLocation, time() + 36000, '/');
        }
    } else {

        if (isset($selected_location)) {
            setcookie("wcmlim_selected_location", $selected_location, time() + ($cookieTime * 24 * 60 * 60), '/');
            $_COOKIE['wcmlim_selected_location'] = $selected_location;
        } else {
            // unset cookies
            setcookie('wcmlim_selected_location', -1, -1, '/');
            unset($_COOKIE['wcmlim_selected_location']);
        }
    }
}

function mgc_wcmlim_get_location_terms()
{
    $terms = get_terms(
        [
        'hide_empty' => false,
        'taxonomy' => 'locations'
        ]
    );

    $new_terms = [];

    foreach ($terms as $key => $term) {
        $new_terms[] = [
        'term_id' => $term->term_id,
        'name' => $term->name
        ];
    }

    return $new_terms;
}

function mgc_wcmlim_get_product_initial_price($product_id)
{
    $product = wc_get_product($product_id);
    $prices = false;

    if ($product->is_type('variable')) {
        $prices = mgc_wcmlim_get_product_variation_prices($product);
    }

    return $prices;
}

function mgc_wcmlim_get_product_variation_prices($product)
{
    $variations = $product->get_children();

    if (empty($variations)) {
        return;
    }

    $locations = get_terms(
        [
        'taxonomy'      => 'locations',
        'hide_empty' => false,
        'fields'      => 'ids'
        ]
    );

    $prices = [];

    foreach ($variations as $variation_key) {
        $variation_slug = get_post_meta($variation_key, 'attribute_pa_brand', true);
        foreach ($locations as $location_id) {
            $prices[$variation_slug][$location_id] = [
            'regular' => get_post_meta($variation_key, 'wcmlim_regular_price_at_'. $location_id, true),
            'sale' => get_post_meta($variation_key, 'wcmlim_sale_price_at_'. $location_id, true)
            ];
        }
    }

    return (!empty($prices))? $prices : false;
}

/**
 * Override single product price template path.
 * Change the price html to add a loading effect and only render the price once the correct price is loaded.
 * Issue: wcmlim does not render the price correctly on page load.
 */
function mgc_wcmlim_modify_single_product_price_template_path($template, $template_name, $args, $template_path, $default_path)
{
    if ($template_name !== 'single-product/price.php') {
        return $template;
    }

    return MGC_PLUGIN_DIR .'public/template-mods/multi-location-plugin-price-template-override.php';
}

/**
 * Override loop product price template path.
 * Change the price html class from .price to something to avoid wcmlim from overriding the incorrect price.
 * Issue: wcmlim overrides the loop price with the current price in single product page.
 */
function mgc_wcmlim_modify_loop_price_template_path($template, $template_name, $args, $template_path, $default_path)
{
    if ($template_name !== 'loop/price.php') {
        return $template;
    }

    return MGC_PLUGIN_DIR .'public/template-mods/multi-location-plugin-loop-price-template-override.php';    
}
