<?php

/**
 * Override wcmlim output in checkout page location details in order review.
 * Issue: wcmlim is printing duplicate locations.
 */
add_action(
    'plugins_loaded', function () {
        remove_action('woocommerce_review_order_after_shipping', 'wcmlim_location_row_layout');
    }, 9999
);

function cova_wcmlim_location_row_layout()
{
    if (is_wcmlim_chosen_shipping_method()) {
        // load the contents of the cart into an array.
        global $woocommerce;
        $cart_message = [];
        $cart = $woocommerce->cart->cart_contents;

        if (get_option('wcmlim_allow_local_pickup') == 'on' && get_option('wcmlim_allow_only_backend') != 'on') {
            // loop through the array looking for the tag you set. Switch to true if the tag is     found.
            foreach ($cart as $array_item) {
                if (isset($array_item['select_location']['location_name'])) {
                    $terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));
                    foreach ($terms as $term) {

                        if ($term->name == $array_item['select_location']['location_name']) {
                            $term_id = $term->term_id;
                            $streetNumber = get_term_meta($term_id, 'wcmlim_street_number', true);
                            $route = get_term_meta($term_id, 'wcmlim_route', true);
                            $locality = get_term_meta($term_id, 'wcmlim_locality', true);
                            $state = get_term_meta($term_id, 'wcmlim_administrative_area_level_1', true);
                            $postal_code = get_term_meta($term_id, 'wcmlim_postal_code', true);
                            $country = get_term_meta($term_id, 'wcmlim_country', true);

                            $cart_message[] = "Pickup Address : " . $streetNumber . " , " . $route . " , " . $locality . " , "  . $state . " , " . $postal_code . " , " . $country . "<br/>";
                        }
                    }
                }
            }

            if (!empty($cart_message)) {

                $cart_message = array_unique($cart_message);
                ?>
        <tr class="shipping-pickup-store">
          <td colspan="2">
            <p class="message"><?php echo implode('', $cart_message) ?></p>
          </td>
        </tr>
                <?php
            }
        } elseif (get_option('wcmlim_allow_only_backend') == 'on') {
            ?>
      <tr class="shipping-pickup-store">

        <th><strong><?php echo "Pickup Location"; ?></strong></th>
        <td>
          <select name="wcmlim_pickup" id="wcmlim_pickup" class="wcmlim_pickup" style="width: fit-content;">
            <?php
            // Loop over $cart items
            if (!empty(WC()->cart->get_cart())) {
                $terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));
                foreach ($terms as $key => $term) {

                    ?>
                <option data-termid="<?php esc_html_e($term->term_id); ?>" value="<?php esc_html_e($term->name); ?>"><?php echo $term->name; ?></option>
                    <?php


                }
            }

            ?>
          </select>
        </td>
      </tr>
            <?php
        }
    }
}
// add_action('woocommerce_review_order_after_shipping', 'cova_wcmlim_location_row_layout');
