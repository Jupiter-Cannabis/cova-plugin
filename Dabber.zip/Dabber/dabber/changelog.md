# Changelog

All notable changes to this project will be documented in this file.

## 3.1.66 - 2023-10-25

### Added

- Added customer address create and update API calls
- Added functionality to create/update customer shipping address during order creation

## 3.1.65 - 2023-10-23

### Changed

- Remove cova_update_products_v2 and dabber_cron_update_pricing_and_location_global_data outdated cron.

## 3.1.64 - 2023-09-07

### Added

- Added inventory sync CRON to run every 3 minutes.

### Changed

- "Update Last Modified Products" in the admin synchronization will always update products that have changes from 7 days ago to current date.
- Import products CRON is now set to run twice daily.
- Update product sync CRON is set to run every 30 minutes.
- Removed Woocommerce visibility dependency to show products in frontend.

### Fixed

- Fixed add to cart button missing in single product page.

## 3.1.63 - 2023-08-31

### Added

- Added a feature to sync product in single product page. The sync button is located above the product title and will only be available in logged-in admin users.

### Fixed

- Fixed insufficient stock orders
- Fixed add to cart quantity field to limit to the actual available stock to be added.

## 3.1.62 - 2023-08-25

### Added

- Implemented manual purchase limits

### Changed

- Updated display position labels in product fields mapping in admin panel

## 3.1.61 - 2023-08-24

### Changed

- Removed 1999-01-01 as default sync "date as of" value and changed to previous 7 days.

### Fixed

- Fixed "Categorized Out of Stock" reindexing to update \_stock_status and WC product visibility.

## 3.1.60 - 2023-08-19

### Fixed

- Fixed product stock status and visibility on inventory sync.

## 3.1.59 - 2023-08-18

### Added

- Added additional endpoint request "get*detailed_products_by_catalog_ids" to be able to get the total stock amount from all batches and save in wcmlim_stock_at*<location_id> metadata

### Fixed

- Fixed stock quantity total value to be saved in database,

## [3.1.58] - 2023-08-14

### Changed

- Improve performance by separating inventory count update background process from product details background synchronization process
