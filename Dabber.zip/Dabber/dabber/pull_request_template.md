# Checklist:

- [ ] Update version number in `cova-woocommerce.php` file
- [ ] Document the changes in change log file with the format below

```markdown
## [VERSION_NUMBER] - DATE

### Added

-

### Changed

-

### Fixed

-
```
