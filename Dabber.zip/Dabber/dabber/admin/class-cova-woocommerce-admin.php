<?php


/**
 * The admin-specific functionality of the plugin.
 *
 * @link  http://example.com
 * @since 1.0.0
 *
 * @package    Cova_woocommerce
 * @subpackage Cova_woocommerce/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Cova_woocommerce
 * @subpackage Cova_woocommerce/admin
 * @author     Your Name <email@example.com>
 */
class Cova_woocommerce_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since  1.0.0
     * @access private
     * @var    string    $Cova_woocommerce    The ID of this plugin.
     */
    private $Cova_woocommerce;

    /**
     * The version of this plugin.
     *
     * @since  1.0.0
     * @access private
     * @var    string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since 1.0.0
     * @param string $Cova_woocommerce The name of this plugin.
     * @param string $version          The version of this plugin.
     */
    public function __construct( $Cova_woocommerce, $version )
    {

        $this->Cova_woocommerce = $Cova_woocommerce;
        $this->version = $version;

        include_once plugin_dir_path(dirname(__FILE__)) . 'admin/AdminUI.php';
        include_once plugin_dir_path(dirname(__FILE__)) . 'admin/advanced-settings.php';
        include_once plugin_dir_path(dirname(__FILE__)) . 'admin/cova-sync-console.php';
        include_once plugin_dir_path(dirname(__FILE__)) . 'admin/general-settings.php';
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since 1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cova_woocommerce_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Cova_woocommerce_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style('cova-datatable-css', 'https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css', array(), $this->version, 'all');

        wp_enqueue_style('cova-datatable-buttons-css', 'https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css', array(), $this->version, 'all');

        wp_enqueue_style($this->Cova_woocommerce, plugin_dir_url(__FILE__) . 'css/cova-woocommerce-admin.css', array(), rand(9, 499), 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since 1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cova_woocommerce_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Cova_woocommerce_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script('cova-moment', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js', array( 'jquery' ), $this->version, false);

        wp_enqueue_script('cova-datatable', 'https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js', array( 'jquery' ), rand(9, 499), false);

        wp_enqueue_script('cova-datatable-buttons', 'https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.js', array( 'jquery' ), rand(9, 499), false);

        wp_enqueue_script('cova-datatable-jszip', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js', array( 'jquery' ), rand(9, 499), false);
        wp_enqueue_script('cova-datatable-pdfmake', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array( 'jquery' ), rand(9, 499), false);
        wp_enqueue_script('cova-datatable-vfs_fonts', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array( 'jquery' ), rand(9, 499), false);

        wp_enqueue_script('cova-datatable-buttons-html5', 'https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js', array( 'jquery' ), rand(9, 499), false);

        wp_enqueue_script($this->Cova_woocommerce, plugin_dir_url(__FILE__) . 'js/cova-woocommerce-admin.js', array( 'jquery' ), rand(9, 499), false);


        // Pass ajax_url to script.js
        wp_localize_script($this->Cova_woocommerce, 'plugin_ajax_object', array( 'ajax_url' => admin_url('admin-ajax.php') ));

    }

    

}
