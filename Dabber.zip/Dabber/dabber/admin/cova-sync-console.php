<?php

add_action(
    'plugins_loaded', function () {
        add_filter('dabber_admin_module_nav_items', 'dabber_module_add_cova_sync_tab', 0);
        add_filter('dabber_admin_module_sub_nav_items_synchronization', 'dabber_add_product_sync_sub_tab');
        add_action('dabber_render_module_admin_page_synchronization_product_sync', 'dabber_render_cova_sync_tab_content');

        //    add_action('dabber_register_module_hooks_synchronization_product_sync', 'dabber_register_product_sync_hooks');
    }, 9
);

add_action('admin_enqueue_scripts', 'dabber_enqueue_product_sync_scripts');

//function dabber_register_product_sync_hooks()
//{
//    add_action('admin_enqueue_scripts', 'dabber_enqueue_product_sync_scripts');
//}

function dabber_enqueue_product_sync_scripts()
{
    $ajax_url = admin_url('admin-ajax.php');
    $plugin_dir = plugin_dir_url(__FILE__);

    wp_enqueue_script('cova-sync-func', $plugin_dir .'js/functions.js', [], null, true);
    wp_add_inline_script(
        'cova-sync-func', 'let cova_sync = '. json_encode(
            [
            'ajax_url' => $ajax_url
            ]
        ), 'before'
    );

    wp_enqueue_script('cova-locations-sync', $plugin_dir .'js/locations-sync.js', [], null, true);
    wp_enqueue_script('cova-promotions-sync', $plugin_dir .'js/promotions-sync.js', [], null, true);
    wp_enqueue_script('cova-import-products-sync', $plugin_dir .'js/import-products.js', [], null, true);
    wp_enqueue_script('cova-update-products-sync', $plugin_dir .'js/update-products.js', [], null, true);
//    wp_enqueue_script('cova-inventory-sync', $plugin_dir .'js/inventory-sync.js', [], null, true);
    wp_enqueue_script('dabber-product-pricing-sync', $plugin_dir .'js/pricing-sync.js', [], null, true);
}

function dabber_module_add_cova_sync_tab($tabs)
{
    $tabs['synchronization'] = __('Synchronization', 'dabber');

    return $tabs;
}

function dabber_add_product_sync_sub_tab($sub_tabs)
{
    $sub_tabs['product_sync'] = __('Product Sync', 'dabber');
    return $sub_tabs;
}

function dabber_render_cova_sync_tab_content()
{
    load_template(plugin_dir_path(__FILE__) .'partials/cova-sync-console.php', true, []);
}
