<?php

namespace Dabber\Admin;

/**
 * @todo move remaining module UI from old admin UI
 */
class AdminUI
{
    private $admin_page_key = 'dabber_integration';
    private $current_page;

    /**
     * @filter dabber_admin_module_nav_items                    - Insert new tab
     * @filter dabber_admin_module_sub_nav_items_{tab name}     - Insert sub tab
     *
     * Use to render module admin tab content
     * @action dabber_render_module_admin_page_before_{tab name}
     * @action dabber_render_module_admin_page_{tab name}
     * @action dabber_render_module_admin_page_after_{tab name}
     *
     * Use to render module admin sub tab content
     * @action dabber_render_module_admin_page_before_{tab name}_{section name}
     * @action dabber_render_module_admin_page_{tab name}_{section name}
     * @action dabber_render_module_admin_page_after_{tab name}_{section name}
     *
     * Use to render module admin tab section
     * @action dabber_render_module_admin_section_before_{tab name}
     * @action dabber_render_module_admin_section_{tab name}
     * @action dabber_render_module_admin_section_after_{tab name}
     *
     * Use to render module admin sub tab section
     * @action dabber_render_module_admin_section_before_{tab name}_{section name}
     * @action dabber_render_module_admin_section_{tab name}_{section name}
     * @action dabber_render_module_admin_section_after_{tab name}_{section name}
     *
     * Register admin ui module specific hooks.
     * Warning: Do not use this hook if the code block needs to be executed globally.
     * @action dabber_register_module_hooks_{tab name}
     * @action dabber_register_module_hooks_{tab name}_{section name}
     *
     * Enqueue module specific hooks.
     * @action dabber_admin_enqueue_scripts_{tab name}
     * @action dabber_admin_enqueue_scripts_{tab name}_{section name}
     *
     * Tab or sub-tab specific action used for saving settings
     * @action dabber_admin_module_before_save_settings_{tab name}
     * @action dabber_admin_module_save_settings_{tab name}
     * @action dabber_admin_module_after_save_settings_{tab name}
     *
     * @action dabber_admin_module_before_save_settings_{tab name}_{section name}
     * @action dabber_admin_module_save_settings_{tab name}_{section name}
     * @action dabber_admin_module_after_save_settings_{tab name}_{section name}
     */
    public function __construct()
    {
        $this->current_page = $this->get_current_page();

        add_action('admin_menu', [$this, 'register_admin_menu']);

        add_action('plugins_loaded', [$this, 'save_module_admin_settings'], 10);
        add_action('plugins_loaded', [$this, 'register_module_specific_hooks']);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);

        add_action('dabber_render_module_tabs', [$this, 'render_page_tabs']);
        add_action('dabber_render_module_sub_tabs', [$this, 'render_page_sub_tabs']);
        add_action('dabber_render_module_page_content', [$this, 'render_page_content']);

        add_action('dabber_render_module_admin_page_'. $this->current_page['tab'], [$this, 'render_page_tab_content']);
        add_action('dabber_render_module_admin_page_'. $this->current_page['tab'] .'_'. $this->current_page['section'], [$this, 'render_page_section_content']);

        //        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
    }

    public function enqueue_admin_scripts()
    {
        do_action('dabber_admin_enqueue_scripts_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
        do_action('dabber_admin_enqueue_scripts_'. $this->current_page['tab']);
    }

    //    public function enqueue_admin_scripts()
    //    {
    //        $ajax_url = admin_url( 'admin-ajax.php' );
    //
    //        wp_register_script('cova-sync-func', plugin_dir_url(__FILE__) .'js/functions.js', [], null, true);
    //        wp_add_inline_script('cova-sync-func', 'let cova_sync = '. json_encode([
    //            'ajax_url' => $ajax_url
    //        ]), 'before');
    //    }

    public function save_module_admin_settings()
    {
        if ($this->current_page['tab'] === '') {
            return;
        }

        if (isset($_POST['dabber_admin_module_save_settings_'. $this->current_page['tab']])) {
            do_action('dabber_admin_module_before_save_settings_'. $this->current_page['tab'], $_POST);
            do_action('dabber_admin_module_save_settings_'. $this->current_page['tab'], $_POST);
            do_action('dabber_admin_module_after_save_settings_'. $this->current_page['tab'], $_POST);
        }
        if (isset($_POST['dabber_admin_module_save_settings_'. $this->current_page['tab'] .'_'. $this->current_page['section']])) {
            do_action('dabber_admin_module_before_save_settings_'. $this->current_page['tab'] .'_'. $this->current_page['section'], $_POST);
            do_action('dabber_admin_module_save_settings_'. $this->current_page['tab'] .'_'. $this->current_page['section'], $_POST);
            do_action('dabber_admin_module_after_save_settings_'. $this->current_page['tab'] .'_'. $this->current_page['section'], $_POST);
        }
    }

    public function register_module_specific_hooks()
    {
        if ($this->current_page['tab'] !== '') {
            do_action('dabber_register_module_hooks_'. $this->current_page['tab']);
        }

        if ($this->current_page['section'] !== '') {
            do_action('dabber_register_module_hooks_' . $this->current_page['tab'] . '_' . $this->current_page['section']);
        }
    }

    public function register_admin_menu()
    {
        add_menu_page('Cova E-Commerce Integration', 'Cova Integration', 'manage_options', 'dabber_integration', [$this, 'page_callback']);
    }

    public function page_callback()
    {
        echo '<div class="wrap">';

            do_action('dabber_render_module_tabs');
            do_action('dabber_render_module_sub_tabs');

            $tab_class = ($this->current_page['tab'] !== '')? $this->current_page['tab'] : '';
            $section_class = ($this->current_page['section'] !== '')? $this->current_page['section'] : '';

            echo '<div class="dabber-admin-tab-content-wrap '. $tab_class .' '. $section_class .'">';
                do_action('dabber_render_module_page_content');
            echo '</div>';

        echo '</div>';
    }

    public function render_page_tabs()
    {
        $tabs = apply_filters(
            'dabber_admin_module_nav_items', [
            'general_settings' => __('General Settings'),
            ]
        );

        echo '<h1>Cova E-Commerce Integration</h1>';

        echo '<nav class="nav-tab-wrapper cova-nav-tab-wrapper">';
        foreach ($tabs as $tab_key => $name) {
            $is_active = ($tab_key === $this->current_page['tab'])? 'nav-tab-active' : '';
            $sub_tabs = apply_filters('dabber_admin_module_sub_nav_items_'. $tab_key, []);
            $section = (empty($sub_tabs))? '' : array_key_first($sub_tabs);
            echo '<a href="'. $this->get_admin_url($tab_key, $section) .'" class="nav-tab '. $is_active .'">'. $name .'</a>';
        }
        echo '</nav>';
    }

    public function render_page_sub_tabs()
    {
        $sub_tabs = apply_filters('dabber_admin_module_sub_nav_items_'. $this->current_page['tab'], []);

        if (empty($sub_tabs)) {
            return;
        }

        echo '<div class="dabber-sub-navs">';
            echo '<ul>';
        foreach ($sub_tabs as $key => $name) {
            $is_active = ($this->current_page['section'] === $key)? 'active' : '';
            echo '<li class="'. $is_active .'"><a href="'. get_admin_url() .'admin.php?page='. $this->admin_page_key .'&tab='. $this->current_page['tab'] .'&section='. $key .'">'. $name .'</a></li>';
        }
            echo '</ul>';
        echo '</div>';
    }

    public function render_page_content()
    {
        if ($this->current_page['section'] === '') {
            do_action('dabber_render_module_admin_page_before_'. $this->current_page['tab']);
            do_action('dabber_render_module_admin_page_'. $this->current_page['tab']);
            do_action('dabber_render_module_admin_page_after_'. $this->current_page['tab']);
        } else {
            do_action('dabber_render_module_admin_page_before_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
            do_action('dabber_render_module_admin_page_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
            do_action('dabber_render_module_admin_page_after_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
        }
    }

    public function render_page_tab_content()
    {
        echo '<form action="" method="post">';
            do_action('dabber_render_module_admin_section_before_'. $this->current_page['tab']);
            do_action('dabber_render_module_admin_section_'. $this->current_page['tab']);
            do_action('dabber_render_module_admin_section_after_'. $this->current_page['tab']);
            echo '<input type="hidden" name="dabber_admin_module_save_settings_'. $this->current_page['tab'] .'" value="1">';
        echo '</form>';
    }

    public function render_page_section_content()
    {
        echo '<form action="" method="post">';
            do_action('dabber_render_module_admin_section_before_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
            do_action('dabber_render_module_admin_section_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
            do_action('dabber_render_module_admin_section_after_'. $this->current_page['tab'] .'_'. $this->current_page['section']);
            echo '<input type="hidden" name="dabber_admin_module_save_settings_'. $this->current_page['tab'] .'_'. $this->current_page['section'] .'" value="1">';
        echo '</form>';
    }

    public function get_current_page()
    {
        if (!isset($_GET['page']) || $_GET['page'] !== $this->admin_page_key) {
            return [
                'tab' => '',
                'section' => ''
            ];
        }

        return [
            'tab' => (isset($_GET['tab']) && $_GET['tab'] !== '')? $_GET['tab'] : 'general_settings',
            'section' => (isset($_GET['section']) && $_GET['section'] !== '')? $_GET['section'] : ''
        ];
    }

    public function get_admin_url($tab = '', $section = '')
    {
        $base_url = get_admin_url() .'admin.php?';

        $page_args = [
            'page' => $this->admin_page_key,
        ];

        if ($tab === '') {
            return $base_url . http_build_query($page_args);
        }

        $page_args['tab'] = $tab;

        if ($section === '') {
            return $base_url . http_build_query($page_args);
        }

        $page_args['section'] = $section;

        return $base_url . http_build_query($page_args);
    }

}

new AdminUI();
