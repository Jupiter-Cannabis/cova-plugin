<?php

add_action(
    'plugins_loaded', function () {
        add_action('dabber_admin_module_save_settings_general_settings', 'dabber_save_general_settings');
        add_action('dabber_render_module_admin_section_general_settings', 'dabber_render_cova_sales_order_settings', 10);
        add_action('dabber_render_module_admin_section_after_general_settings', 'dabber_general_settings_save_button', 9999);
    }, 9
);

function dabber_render_cova_sales_order_settings()
{
    load_template(
        plugin_dir_path(__FILE__) .'partials/sales-order-settings.php', true, [
        'dabber_site_status' => get_option('dabber_site_status'),
        'enable_push_order'  => get_option('cova_enable_push_order')
        ]
    );
}

function dabber_save_general_settings($post_data)
{
    $site_status = isset($_POST['site-status']) ? $_POST['site-status'] : 'live';
    update_option('dabber_site_status', sanitize_text_field($site_status));

    $enable_push_order = (isset($_POST['cova-enable-push-order']))? 'yes' : 'no';
    update_option('cova_enable_push_order', sanitize_text_field($enable_push_order));
}

function dabber_general_settings_save_button()
{
    echo '<input type="submit" id="submit" class="button button-primary" value="Save Changes">';
}
