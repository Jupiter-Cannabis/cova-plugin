function cova_print_log_message(message, data = '')
{
    console.log(message);
    jQuery('.product-sync-log ul').append('<li>'+ message +'</li>');

    if (data !== '') {
        console.log(data);
    }
}

function cova_parse_form_data(data) 
{
    const json = {};

    jQuery.each(
        data, function () {
            json[this.name] = this.value || "";
        }
    );

    return json;
}

(function ($) {
    let total_items_synced = 0;

    function initiate_product_sync(form_data)
    {
        form_data = cova_parse_form_data(form_data);

        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_initiate_product_sync',
                    form_data: form_data
                },
                beforeSend: function () {
                    $('.product-sync-log').show();
                    cova_print_log_message('Initializing sync process...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    if (res.status !== 'ok') {
                        cova_print_log_message(res.message);
                        return;
                    }
                    $('.total-items').html(res.data.products_found);
                    cova_print_log_message(res.message, res.data);

                    store_catalog_data();
                },
                error: function () {}
            }
        );
    }

    function store_catalog_data()
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_store_catalog_data',
                },
                beforeSend: function () {
                    cova_print_log_message('Storing catalog data...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {
                        return;
                    }                

                    store_locations_data();
                },
                error: function () {}
            }
        );
    }

    function store_locations_data()
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_store_locations_data',
                },
                beforeSend: function () {
                    cova_print_log_message('Storing locations data...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {
                        return;
                    }                

                    store_pricing_data();
                },
                error: function () {}
            }
        );
    }

    function store_pricing_data(page_num = 0)
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_store_pricing_data',
                    page_num: page_num
                },
                beforeSend: function () {
                    cova_print_log_message('Storing pricing data...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {
                        return;
                    }

                    if (res.page !== 'complete') {
                        store_pricing_data(res.page);
                        return;
                    }

                    store_inventory_data();
                },
                error: function () {}
            }
        );        
    }

    function store_inventory_data()
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_store_inventory_data',
                },
                beforeSend: function () {
                    cova_print_log_message('Storing inventory data...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {
                        return;
                    }                

                    prepare_product_sync();
                },
                error: function () {}
            }
        );                
    }

    function prepare_product_sync()
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_prepare_product_sync',
                },
                beforeSend: function () {
                    cova_print_log_message('Preparing product sync.');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {                    
                        return;
                    }

                    sync_product(res.data);
                },
                error: function () {}
            }
        );
    }

    function sync_product(sync_data = false)
    {
        $.ajax(
            {
                url: cova_product_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_sync_product'
                },
                beforeSend: function () {
                    cova_print_log_message('Syncing item: '+ sync_data.next_sync_item);
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    if (res.status !== 'ok') {
                        cova_print_log_message(res.message);
                        return;
                    }

                    total_items_synced += 1;
                    res.data.total_items_synced = total_items_synced;

                    $('.total-synced').html(total_items_synced);
                    cova_print_log_message(res.message, res.data);
                
                    if (res.data.next_sync_item === 'complete') {                    
                        total_items_synced = 0;
                        $('.general-sync-status').html('Sync Complete');
                        cova_print_log_message('Sync Complete.');
                        return;
                    }

                    sync_product(res.data);
                },
                error: function () {}
            }
        );
    }

    $(document).ready(
        function () {
            $(document.body).on(
                'submit', '#cova-import-products', function (e) {
                    e.preventDefault();
                    initiate_product_sync($(this).serializeArray());
                }
            );        
        }
    );

})(jQuery);