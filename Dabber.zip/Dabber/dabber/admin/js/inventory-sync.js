(function ($) {
    let total_synced = 0;
    let total_update = null;

    function cova_initialize_product_import(clear_log_files)
    {
        sync_ajax(
            'inventory_sync', 'update_inventory', {
                data: {
                    clear_log_files: clear_log_files
                },
                beforeSend: function () {                
                },
                success: function (response) {

                    cova_print_log_message(response);

                    total_synced += response.data.total_synced;

                    if (total_update === null) {
                        total_update = response.data.total_update;
                    }

                    if (response.data.total_synced > 0) {
                        //                     cova_sync_set_progress_number(total_synced, total_update);
                    }                

                    if (response.data.status === 'complete') {
                        cova_sync_set_operation_status('complete');
                        return;
                    }

                    cova_initialize_product_import('no');
                }
            }
        );
    }

    $(document.body).on(
        'dabber_sync_inventory', function (e) {
            cova_clear_console();
            cova_print_log_message('Syncing inventory...');
            cova_sync_set_operation_name('sync-inventory');
            cova_sync_set_operation_status('processing');


            cova_initialize_product_import('yes');
        }
    );

    // $(document.body).on('submit', '#cova-inventory-sync', function(e)
    // {
    //     e.preventDefault();

    //     cova_clear_console();
    //     cova_print_log_message('Syncing inventory...');
    //     cova_sync_set_operation_name('sync-inventory');
    //     cova_sync_set_operation_status('processing');

    //     cova_initialize_product_import();
    // });

})(jQuery);