(function ($) {
    let total_synced = 0;
    let total_import = null;

    function cova_initialize_product_import()
    {
        sync_ajax(
            'import_sync', 'import_products', {
                beforeSend: function () {                
                },
                success: function (response) {

                    cova_print_log_message(response);

                    total_synced += response.data.total_synced;

                    if (total_import === null) {
                        total_import = response.data.total_import;
                    }

                    if (response.data.total_synced > 0) {
                        cova_sync_set_progress_number(total_synced, total_import);
                    }                

                    if (response.data.status === 'complete') {
                        total_import = null;
                        total_synced = 0;
                        cova_sync_set_operation_status('complete');
                        return;
                    }

                    cova_initialize_product_import();
                }
            }
        );
    }

    $(document.body).on(
        'dabber_import_products', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Importing products...');
            cova_sync_set_operation_name('import-products');
            cova_sync_set_operation_status('processing');

            cova_initialize_product_import();
        }
    );
})(jQuery);