(function ($) {
    "use strict";

    $(document).ready(
        function () {
            $(document.body).on(
                'click', '.add-category-limit', function (e) {
                    e.preventDefault();
                    let field = $(this);
            
            
                }
            );
        }
    );


    /**
     * All of the code for your admin-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */

    setTimeout(
        function () {
            // jQuery(".js-add-new-sync-button").on("click", function () {
            //   jQuery(this).attr("disabled", "disabled");
            //   var progressContainer = jQuery(".js-cova-sync-progress");
            //   progressContainer.html("Importing new products...<br />");
            //   runCovaSync(0, 0, "true");
            // });

            jQuery(".js-cova-get-data-button").on(
                "click", function () {
                    jQuery(this).attr("disabled", "disabled");
                    var progressContainer = jQuery(".js-cova-get-data-progress");
                    progressContainer.html("Getting data from cova api...<br />");
                    runCovaGetData();
                }
            );

            jQuery(".js-cova-generate-product-object-button").on(
                "click", function () {
                    jQuery(this).attr("disabled", "disabled");
                    var progressContainer = jQuery(
                        ".js-cova-generate-product-object-progress"
                    );
                    progressContainer.html("Generating products object...<br />");
                    runCovaGenerateProductObject();
                }
            );

            jQuery(".js-cova-import-product-images-button").on(
                "click", function () {
                    jQuery(this).attr("disabled", "disabled");
                    var progressContainer = jQuery(".js-cova-import-product-images-progress");
                    progressContainer.html("Importing product images...<br />");
                    runCovaImportProductImages(0);
                }
            );

            jQuery(".js-cova-sync-information-button").on(
                "click", function (e) {
                    jQuery(this).attr("disabled", "disabled");
                    var progressContainer = jQuery(".js-cova-sync-information-progress");
                    progressContainer.html("Updating products information...<br />");
                    runCovaInformationSync(0);
                    e.preventDefault();
                }
            );
        }, 200
    );
})(jQuery);

function millisecondsToHours(ms)
{
    return Math.round((ms / 1000 / 60 / 60) * 100) / 100;
}

function runCovaImportProductImages(batch)
{
    if (jQuery("body").hasClass("woocommerce_page_register_cova_sync")) {
        // AJAX url
        var ajax_url = plugin_ajax_object.ajax_url;

        // Fetch All records (AJAX request without parameter)
        var data = {
            action: "import_product_images",
            batch: batch,
        };

        jQuery.ajax(
            {
                url: ajax_url,
                type: "post",
                data: data,
                cache: false,
                dataType: "json",
                success: function (response) {
                    console.log(response);

                    if (response.batch <= response.batch_length) {
                        setTimeout(runCovaImportProductImages(parseInt(response.batch)), 5);
                    }

                    var progressContainer = jQuery(
                        ".js-cova-import-product-images-progress"
                    );
                    progressContainer
                      .html("<p>" + response.message + "</p>")
                      .addClass("updated notice");
                    jQuery(".js-cova-import-product-images-button").removeAttr("disabled");
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(jqXHR, textStatus, error);

                    var progressContainer = jQuery(
                        ".js-cova-import-product-images-progress"
                    );
                    progressContainer
                    .html("<p>Importing failed!</p>")
                    .addClass("error notice");

                    jQuery(".js-cova-import-product-images-button").removeAttr("disabled");
                },
            }
        );
    }
}

function runCovaGenerateProductObject()
{
    if (jQuery("body").hasClass("woocommerce_page_register_cova_sync")) {
        // AJAX url
        var ajax_url = plugin_ajax_object.ajax_url;

        // Fetch All records (AJAX request without parameter)
        var data = {
            action: "generate_product_object",
        };

        var ajaxTime = new Date().getTime();

        jQuery.ajax(
            {
                url: ajax_url,
                type: "post",
                data: data,
                cache: false,
                dataType: "json",
                success: function (response) {
                    console.log(response);

                    if (response.productsInTrash 
                        && parseInt(response.productsInTrash_count) > 0
                    ) {
                        var progressContainer = jQuery(
                            ".js-cova-generate-product-object-progress"
                        );
                        progressContainer
                        .html("<p>" + response.message + "</p>")
                        .addClass("error notice");
                        jQuery(".js-cova-generate-product-object-button").removeAttr(
                            "disabled"
                        );
                    } else if (!response.cova_unsync_products) {
                        var progressContainer = jQuery(
                            ".js-cova-generate-product-object-progress"
                        );
                        progressContainer
                        .html("<p>" + response.message + "</p>")
                        .addClass("error notice");
                        jQuery(".js-cova-generate-product-object-button").removeAttr(
                            "disabled"
                        );
                    } else {
                        if (response.catalog_length > 0) {
                            var progressContainer = jQuery(
                                ".js-cova-generate-product-object-progress"
                            );
                            var totalTime = new Date().getTime() - ajaxTime;
                            var estimatedTimeTpl =
                            "<br />Estimated Time To Complete: " +
                            getEstimateTime(totalTime * response.batch_length);

                            progressContainer.html(response.message + estimatedTimeTpl);
                        } else {
                            var progressContainer = jQuery(
                                ".js-cova-generate-product-object-progress"
                            );
                            progressContainer
                            .html("<p>" + response.message + "</p>")
                            .addClass("updated notice");
                            jQuery(".js-cova-generate-product-object-button").removeAttr(
                                "disabled"
                            );
                        }
                    }
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(jqXHR, textStatus, error);

                    var progressContainer = jQuery(
                        ".js-cova-generate-product-object-progress"
                    );
                    progressContainer
                    .html("<p>Syncing has error!</p>")
                    .addClass("error notice");

                    jQuery(".js-cova-generate-product-object-button").removeAttr(
                        "disabled"
                    );
                },
            }
        );
    }
}

function runCovaGetData()
{
    if (jQuery("body").hasClass("woocommerce_page_register_cova_sync")) {
        // AJAX url
        var ajax_url = plugin_ajax_object.ajax_url;

        // Fetch All records (AJAX request without parameter)
        var data = {
            action: "get_cova_data",
        };

        var ajaxTime = new Date().getTime();

        jQuery.ajax(
            {
                url: ajax_url,
                type: "post",
                data: data,
                cache: false,
                dataType: "json",
                success: function (response) {
                    console.log(response);

                    if (response.catalog_length > 0) {
                        var progressContainer = jQuery(".js-cova-get-data-progress");
                        var totalTime = new Date().getTime() - ajaxTime;
                        var estimatedTimeTpl =
                        "<br />Estimated Time To Complete: " +
                        getEstimateTime(totalTime * response.batch_length);

                        progressContainer
                        .html(response.message + estimatedTimeTpl)
                        .addClass("updated notice");
                    } else {
                        var progressContainer = jQuery(".js-cova-get-data-progress");
                        progressContainer.html("Syncing is Done!").addClass("updated notice");
                        jQuery(".js-cova-get-data-button").removeAttr("disabled");
                    }
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(jqXHR, textStatus, error);

                    var progressContainer = jQuery(".js-cova-get-data-progress");
                    progressContainer.html("Syncing has error!");

                    jQuery(".js-cova-get-data-button").removeAttr("disabled");
                },
            }
        );
    }
}

function runCovaSync(batchCounter, createdCounter, newSync)
{
    if (jQuery("body").hasClass("woocommerce_page_register_cova_sync")) {
        // AJAX url
        var ajax_url = plugin_ajax_object.ajax_url;

        // Fetch All records (AJAX request without parameter)
        var data = {
            action: "ajax_add_new_products",
            batch: batchCounter,
            created: createdCounter,
            from: jQuery("#from").val(),
            to: jQuery("#to").val(),
            for_import: jQuery("#for_import").val(),
            new_sync: newSync,
        };

        var ajaxTime = new Date().getTime();

        jQuery.ajax(
            {
                url: ajax_url,
                type: "post",
                data: data,
                cache: false,
                dataType: "json",
                success: function (response) {
                    console.log(response);

                    if (response !== null && response.catalog_length > 0) {
                        var progressContainer = jQuery(".js-cova-sync-progress");
                        var totalTime = new Date().getTime() - ajaxTime;
                        var estimatedTimeTpl =
                        "<br />Estimated Time To Complete: " +
                        getEstimateTime(totalTime * response.batch_length);

                        if (response.run > 0) {
                            progressContainer.html(response.message + estimatedTimeTpl);
                            setTimeout(
                                runCovaSync(parseInt(response.batch), response.created, "false"),
                                5
                            );
                        } else {
                            progressContainer.html(response.message).addClass("updated notice");
                            jQuery(".js-add-new-sync-button").removeAttr("disabled");
                        }
                    } else {
                        var progressContainer = jQuery(".js-cova-sync-progress");
                        progressContainer.html("Syncing has error! Please try again.");
                        jQuery(".js-add-new-sync-button").removeAttr("disabled");
                    }
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(jqXHR, textStatus, error);

                    var progressContainer = jQuery(".js-cova-sync-progress");
                    progressContainer.html("Syncing has error!");

                    jQuery(".js-add-new-sync-button").removeAttr("disabled");
                },
            }
        );
    }
}

function getEstimateTime(value)
{
    var now = moment();
    var seconds = moment.duration(value).seconds();
    var minutes = moment.duration(value).minutes();
    var hours = Math.trunc(moment.duration(value).asHours());

    return hours + " hour and " + minutes + " minutes";
}

function runCovaInformationSync(batchCounter)
{
    if (jQuery("body").hasClass("woocommerce_page_register_cova_sync")) {
        // AJAX url
        var ajax_url = plugin_ajax_object.ajax_url;

        // Fetch All records (AJAX request without parameter)
        var data = {
            action: "cova_information_sync",
            batch: batchCounter,
        };

        var ajaxTime = new Date().getTime();

        jQuery.ajax(
            {
                url: ajax_url,
                type: "post",
                data: data,
                cache: false,
                dataType: "json",
                success: function (response) {
                    console.log(response);

                    if (response.batch !== response.batch_count) {
                        var progressContainer = jQuery(".js-cova-sync-information-progress");
                        var totalTime = new Date().getTime() - ajaxTime;
                        var estimatedTimeTpl =
                        "<br />Estimated Time To Complete: " +
                        getEstimateTime(totalTime * response.batch_count);

                        progressContainer.html(response.batch + estimatedTimeTpl);

                        setTimeout(runCovaInformationSync(parseInt(response.batch)), 5);
                    } else {
                        var progressContainer = jQuery(".js-cova-sync-information-progress");
                        progressContainer.html("Syncing is Done!");
                        jQuery(".js-cova-sync-information-button").removeAttr("disabled");
                    }
                },
                error: function (jqXHR, textStatus, error) {
                    console.error(jqXHR, textStatus, error);
                    var progressContainer = jQuery(".js-cova-sync-information-progress");
                    progressContainer.html(jqXHR.statusText);
                    jQuery(".js-cova-sync-information-button").removeAttr("disabled");
                },
            }
        );
    }
}
