(function ($) {
    function dabber_initialize_product_update(sync_action)
    {
        sync_ajax(
            'update_sync', sync_action, {
                beforeSend: function () {
                },
                success: function (response) {

                    cova_print_log_message(response);

                    if (response.data.status === 'complete') {
                        cova_sync_set_operation_status('complete');
                        return;
                    }

                    dabber_initialize_product_update(sync_action);
                }
            }
        );
    }

    $(document.body).on(
        'dabber_sync_product_details', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Updating products...');
            cova_sync_set_operation_name('update-products');
            cova_sync_set_operation_status('processing');
            console.log('sync products by last modified');

            dabber_initialize_product_update('update_products');
        }
    );

    $(document.body).on(
        'dabber_sync_all_products', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Updating products...');
            cova_sync_set_operation_name('update-products');
            cova_sync_set_operation_status('processing');
            console.log('sync all products');

            dabber_initialize_product_update('update_all_products');
        }
    );

    $(document.body).on(
        'dabber_sync_inventory', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Updating product inventory...');
            cova_sync_set_operation_name('update-products');
            cova_sync_set_operation_status('processing');
            console.log('sync inventory');

            dabber_initialize_product_update('update_inventory');
        }
    );

})(jQuery);