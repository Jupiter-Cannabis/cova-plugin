(function ($) {
    function initialize_location_sync()
    {
        sync_ajax(
            'location_sync', 'initialize_sync_locations', {
                beforeSend: function () {
                      cova_clear_console();
                      cova_sync_set_operation_name('sync-locations');
                      cova_sync_set_operation_status('processing');

                      cova_print_log_message('Syncing cova locations...');
                },
                success: function (response) {
                    cova_print_log_message(response);
                    cova_sync_set_operation_status('complete');
                }
            }
        );
    }

    $(document.body).on(
        'dabber_sync_locations', function (e) {
            e.preventDefault();

            // let message = 'Warning! You will need to resync all the products after syncing the locations. Are you sure you want to resync the locations?';
            //
            // if (confirm(message) === true) {
            initialize_location_sync();
            // }
        }
    );

})(jQuery);