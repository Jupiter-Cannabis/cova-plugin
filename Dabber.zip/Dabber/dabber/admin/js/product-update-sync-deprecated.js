(function ($) {
    let total_items_updated = 0;

    function initiate_product_sync_update(form_data)
    {
        form_data = cova_parse_form_data(form_data);

        $.ajax(
            {
                url: cova_product_update_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_initiate_product_update_sync',
                    form_data: form_data
                },
                beforeSend: function () {
                    $('.product-sync-log').show();
                    cova_print_log_message('Initializing sync process...');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    if (res.status !== 'ok') {
                        cova_print_log_message(res.message);
                        return;
                    }
                    $('.total-items').html(res.data.products_found);
                    cova_print_log_message(res.message, res.data);

                    prepare_product_update_sync();
                },
                error: function () {}
            }
        );
    }

    function prepare_product_update_sync()
    {
        $.ajax(
            {
                url: cova_product_update_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_prepare_product_update_sync',
                },
                beforeSend: function () {
                    cova_print_log_message('Preparing product sync.');
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    cova_print_log_message(res.message);

                    if (res.status !== 'ok') {                    
                        return;
                    }

                    update_product(res.data);
                },
                error: function () {}
            }
        );        
    }

    function update_product(sync_data = false)
    {
        $.ajax(
            {
                url: cova_product_update_sync_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'cova_update_product_sync'
                },
                beforeSend: function () {
                    if (sync_data.next_sync_item !== false) {
                        cova_print_log_message('Syncing item: '+ sync_data.next_sync_item);
                    }                
                },
                success: function ( response ) {
                    var res = JSON.parse(response);

                    if (res.status === 'complete') {                    
                        total_items_updated = 0;
                        $('.general-sync-status').html('Sync Complete');
                        cova_print_log_message(res.message);
                        return;
                    }

                    if (res.status !== 'ok') {
                        cova_print_log_message(res.message);
                        return;
                    }

                    total_items_updated += 1;
                    res.data.total_items_updated = total_items_updated;

                    $('.total-synced').html(total_items_updated);
                    cova_print_log_message(res.message, res.data);
                
                    update_product(res.data);
                },
                error: function () {}
            }
        );
    }
    
    $(document).ready(
        function () {
            $(document.body).on(
                'submit', '#cova-update-products', function (e) {
                    e.preventDefault();

                    initiate_product_sync_update($(this).serializeArray());
                }
            );
        }
    );

})(jQuery);