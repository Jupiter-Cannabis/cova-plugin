<?php

if (!empty($args['available_modules'])) : ?>

    <h2>Enable/Disable Modules</h2>
    <table class="form-table">
        <tbody>
        <?php
        foreach($args['available_modules'] as $module) :
            $readonly = '';

            if ($module['must_use'] === true) {
                $readonly = 'readonly=readonly disabled=disabled';
                $checked = 'checked="checked"';
            } else {
                $checked = checked(1, in_array($module['class'], $args['enabled_modules']), false);
            }
            ?>
            <tr>
                <th><?php echo $module['name'] ?></th>
                <td><input type="checkbox" <?php echo $readonly .' '. $checked ?> name="dabber_enabled_modules[]" value="<?php echo $module['class'] ?>"></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
