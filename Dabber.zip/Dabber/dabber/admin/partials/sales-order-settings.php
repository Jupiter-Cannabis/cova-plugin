<h2><?php _e('Site Launching Settings', 'cova') ?></h2>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row"><?php _e('Site status', 'cova') ?></th>
        <td>
            <fieldset>
                <label for="site-status-live">
                    <input name="site-status" <?php echo ((!$args['dabber_site_status'] || $args['dabber_site_status'] === 'live')? 'checked="checked"' : '') ?> type="radio" id="site-status-live" value="live">
                    Live
                </label>
                <br>
                <label for="site-status-coming-soon">
                    <input name="site-status" <?php echo (($args['dabber_site_status'] === 'coming-soon')? 'checked="checked"' : '') ?> type="radio" id="site-status-coming-soon" value="coming-soon">
                    Coming soon
                </label>
                <br>
                <label for="site-status-maintenance">
                    <input name="site-status" <?php echo (($args['dabber_site_status'] === 'maintenance')? 'checked="checked"' : '') ?> type="radio" id="site-status-maintenance" value="maintenance">
                    Maintenance
                </label>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
<hr>
<h2><?php _e('Cova Sales Order Settings', 'cova') ?></h2>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row"><?php _e('Enable push order to cova', 'cova') ?></th>
        <td>
            <fieldset>
                <label for="cova-enable-push-order">
                    <input name="cova-enable-push-order" <?php echo (($args['enable_push_order'] === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="cova-enable-push-order" value="1">
                </label>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
