<div class="cova-sync-controls">
    <div>
        <form id="dabber-sync" class="" method="post" action="">
            <h3>Choose Sync Action</h3>
            <select id="sync-action" name="sync-action" required="required">
                <option value="">-- Choose action --</option>
                <option value="sync-inventory">Update Product Inventory</option>
                <option value="sync-details">Update Last Modified Products</option>
                <option value="full-sync-details">Update All Products</option>
                <option value="import">Import Products</option>
                <option value="sync-promotions">Sync Promotions</option>
                <option value="sync-locations">Sync Locations</option>
            </select>
            <input type="submit" name="cova-import-products" class="button button-primary cova-sync-btn button-large" value="Submit" />
        </form>
    </div>
</div>
<div class="cova-sync-console">
    <div class="cova-sync-console-head">
        <span class="sync-process"></span>
        <span class="sync-status"></span>
    </div>
    <div class="sync-console-body">
        <ul></ul>
    </div>
    <div class="cova-sync-console-command">
        <form id="sync-command" method="post" action="">
            <input type="text" data-lpignore="true" spellcheck="false" name="cmd">
        </form>
    </div>
</div>