<?php

add_action(
    'plugins_loaded', function () {
        add_filter('dabber_admin_module_nav_items', 'dabber_module_add_advanced_tab', 200);
        add_filter('dabber_admin_module_sub_nav_items_advanced', 'dabber_add_advanced_sub_tab', 1);
        add_action('dabber_render_module_admin_section_advanced_manage_modules', 'dabber_render_advanced_tab_content');
        add_action('dabber_admin_module_save_settings_advanced_manage_modules', 'dabber_save_module_advanced_settings');
        add_action('dabber_admin_module_after_save_settings_advanced_manage_modules', 'dabber_reload_page_after_module_save');
    }, 9
);

function dabber_module_add_advanced_tab($tabs)
{
    $tabs['advanced'] = __('Advanced');

    return $tabs;
}

function dabber_add_advanced_sub_tab($tabs)
{
    $tabs['manage_modules'] = __('Manage Modules');

    return $tabs;
}

function dabber_render_advanced_tab_content()
{
    global $dabber_available_modules, $dabber_enabled_modules;

    load_template(
        plugin_dir_path(__FILE__) .'partials/modules.php', true, [
        'available_modules' => $dabber_available_modules,
        'enabled_modules'   => $dabber_enabled_modules
        ]
    );

    echo '<hr>';
    echo '<input type="submit" id="submit" class="button button-primary" value="Save Changes">';
}

function dabber_save_module_advanced_settings($post_data)
{
    cova_debugger($post_data);
    $enabled_modules = (isset($post_data['dabber_enabled_modules']))? $post_data['dabber_enabled_modules'] : [];
    update_option('dabber_enabled_modules', $enabled_modules);
}

function dabber_reload_page_after_module_save()
{
    wp_redirect(get_admin_url(). 'admin.php?page=dabber_integration&tab=advanced&section=manage_modules');
    exit;
}
