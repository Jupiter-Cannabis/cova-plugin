<?php
require_once __DIR__ . '/vendor/autoload.php';

session_start();
/**
 * Dabber
 *
 * This plugin integrates with COVA ERP to woocommerce plugin
 *
 * @link    covasoftware.com
 * @since   1.0.0
 * @package Cova_Integration
 *
 * @cova-woocommerce
 * Plugin Name:       Cova Integration 
 * Plugin URI:        www.covasoftware.com
 * Description:       This plugin integrates with COVA ERP to woocommerce plugin
 * Version:           3.1.66
 * Author:            Cova Software
 * Author URI:        www.covasoftware.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cova
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('COVA_PLUGIN_URI', plugin_dir_url(__FILE__));
define('COVA_PLUGIN_DIR', plugin_dir_path(__FILE__));

define('MGC_PLUGIN_URI', plugin_dir_url(__FILE__));
define('MGC_PLUGIN_DIR', plugin_dir_path(__FILE__));

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('Cova_woocommerce_VERSION', '3.1.66');

/**
 * The properties used by the 011Y and logging functions
 * Typically these will be set in the wp-config.php file, but could be set here too.
 */
define( 'STATSD_HOST', '' );
define('STATSD_PORT', 8125);
define( 'STATSD_APIKEY_NAMESPACEPREPEND', '' );
define( 'STATSD_ENVIRONMENT', 'prod' );
define( 'LOGGING_LEVEL', \Monolog\Logger::INFO );
define( 'LOGGLY_API_KEY', '');
define('LOGGLY_TAGS', 'cova-ecommerce-' . STATSD_ENVIRONMENT);

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-cova-woocommerce-activator.php
 */
function activate_Cova_woocommerce()
{
    include_once plugin_dir_path(__FILE__) . 'includes/class-cova-woocommerce-activator.php';
    Cova_woocommerce_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-cova-woocommerce-deactivator.php
 */
function deactivate_Cova_woocommerce()
{
    include_once plugin_dir_path(__FILE__) . 'includes/class-cova-woocommerce-deactivator.php';
    Cova_woocommerce_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_cova_woocommerce');
register_deactivation_hook(__FILE__, 'deactivate_cova_woocommerce');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-cova-woocommerce.php';

/**
 * Init plugin modules
 */
require plugin_dir_path(__FILE__) . 'modules/init.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since 1.0.0
 */

function run_Cova_woocommerce()
{

    $plugin = new Cova_woocommerce();
    $plugin->run();
}
run_Cova_woocommerce();

add_filter('woocommerce_product_backorders_allowed', '__return_false');

/**
 * Disable out of stock variations @ WooCommerce Single
 */
add_filter('woocommerce_variation_is_active', 'dabber_disable_variations_out_of_stock', 10, 2);
function dabber_disable_variations_out_of_stock($is_active, $variation)
{

    if (!$variation->is_in_stock()) {
        return false;
    }

    return $is_active;
}

// function that runs when shortcode is called
function cova_product_filter_override()
{
    // Output needs to be return
    return do_shortcode('[prdctfltr_sc_products use_filter="false"  instock_products="in" ]');
}
// register shortcode
add_shortcode('cova_product_filter_override', 'cova_product_filter_override');

/**
 * Redirect all pages based on site status
 */
add_action('template_redirect', 'redirect_by_site_status');
function redirect_by_site_status()
{

    $dabber_site_status = get_option('dabber_site_status');

    if (!$dabber_site_status || $dabber_site_status === 'live' || is_null(get_page_by_path($dabber_site_status))) {
        return;
    }

    if (!is_page($dabber_site_status) && !is_user_logged_in() && !wp_doing_ajax()) {
        wp_redirect(site_url($dabber_site_status));
        exit();
    }
}
