<?php

namespace Dabber\Modules\BulkProducts;

use Cova_Integration\Cova_Data_Manager;
use Cova_Integration\WC_Simple_Product_Updater;

class SimpleProductHandler
{

}
