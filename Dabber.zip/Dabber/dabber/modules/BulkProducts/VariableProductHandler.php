<?php

namespace Dabber\Modules\BulkProducts;

use Cova_Integration\Cova_Data_Manager;
use Cova_Integration\WC_Variation_Product_Creator;

class VariableProductHandler
{
    public $measurement_types = [
        'SingleUnit' => 'pcs',
        'Mass' => 'g'
    ];

    public function run()
    {
        add_filter('dabber_order_item_catalog_id', [$this, 'modify_order_item_catalog_id'], 100, 2);
        add_filter('dabber_set_product_total_stock', [$this, 'modify_product_total_stock'], 100, 3);
        add_filter('dabber_sync_variable_product_details', [$this, 'add_custom_details']);
        add_filter('dabber_sync_variable_product_attribute_term', [$this, 'set_variation_term'], 100, 2);
        add_filter('dabber_sync_variable_is_create_variation', [$this, 'disable_default_variation_creation'], 100, 2);

        add_action('dabber_sync_variable_product_after_create', [$this, 'create_tiered_price_variations'], 110, 2);
        add_action('dabber_sync_variable_product_after_update', [$this, 'add_additional_variable_details'], 100);
        add_action('dabber_sync_variable_product_after_update', [$this, 'save_variable_meta'], 100);

        add_filter('dabber_sync_variation_product_details', [$this, 'modify_variation_details'], 100);
        add_filter('dabber_sync_variation_product_update_metadata', [$this, 'modify_save_variation_meta_items']);
        //        add_filter('dabber_sync_before_product_update', [$this, 'update_variation_products'], 100, 3);
        add_action('dabber_sync_variation_product_after_update', [$this, 'save_variation_meta'], 100);

        add_filter('woocommerce_order_item_quantity', [$this, 'modify_order_quantity'], 100, 3);
        add_action('woocommerce_variation_set_stock', [$this, 'adjust_variations_stock'], 100);
        add_action('cova_sync_after_inventory_update', [$this, 'adjust_variations_stock_on_inventory_sync'], 100, 3);
        add_action('woocommerce_add_to_cart_validation', [$this, 'validate_product_page_add_to_cart'], 100, 5);
        add_action('woocommerce_update_cart_validation', [$this, 'validate_cart_page_add_to_cart'], 100, 4);

        //@tests
        //        add_filter('dabber_import_process_catalog_ids', [$this, 'test_import']);
        //        add_filter('dabber_inventory_sync_process_update_items', [$this, 'test_inventory_sync']);
        //        add_filter('dabber_sync_product_update_process_catalog_ids', [$this, 'test_update_process']);
    }

    public function test_import($catalog_ids)
    {
        $catalog_ids = ['ecadcaf5-3c1e-4918-8fed-85963e13df22'];

        return $catalog_ids;
    }

    public function test_inventory_sync($items)
    {
        $items = [
            [
                [
                    'catalog_id' => 'ecadcaf5-3c1e-4918-8fed-85963e13df22',
                    'location_id' => '297775',
                    'quantity' => 50,
                    'update_key' => '1669267113-297775-ecadcaf5-3c1e-4918-8fed-85963e13df22'
                ]
            ]
        ];
        return $items;
    }

    public function test_update_process($items)
    {
        return [
            ['ecadcaf5-3c1e-4918-8fed-85963e13df22']
        ];
    }

    public function validate_cart_page_add_to_cart($passed,  $cart_item_key,  $values,  $quantity)
    {
        $validation = $this->validate_cart_quantity_availability($values['variation_id'], $quantity);

        if (empty($validation)) {
            return $passed;
        }

        cova_add_wc_notice($validation['message'], 'error');
        return false;
    }

    public function validate_product_page_add_to_cart($passed, $product_id, $quantity, $variation_id = '', $variations = '')
    {
        $validation = $this->validate_cart_quantity_availability($variation_id, $quantity);

        if (empty($validation)) {
            return $passed;
        }

        cova_add_wc_notice($validation['message'], 'error');
        return false;
    }

    public function validate_cart_quantity_availability($variation_id, $quantity)
    {
        global $dabber_current_location, $dabber_current_location_data;

        if (!is_numeric($variation_id) || $variation_id === 0) {
            return [];
        }

        $variation = wc_get_product($variation_id);
        $is_tiered_variation = $variation->get_meta('dabber_is_price_tiered_variation');

        if ($is_tiered_variation !== 'yes') {
            return [];
        }

        $location_stock     = (float) $variation->get_meta('wcmlim_stock_at_'. $dabber_current_location);
        //$available_quantity = (float) ($location_stock - (int) get_option('woocommerce_notify_no_stock_amount'));
        $available_quantity = (float) ($location_stock - (int) $dabber_current_location_data['oos_threshold']);
        $purchase_quantity  = (float) $quantity * $variation->get_weight();

        if ($available_quantity < $purchase_quantity) {
            return [
                'message' => __('Sorry, we do not have enough <strong>'. $variation->get_name() .'</strong> in stock to fulfill your order ('. $available_quantity .' available). We apologize for any inconvenience caused', "woocommerce")
            ];
        }

        return [];
    }

    public function add_additional_variable_details($object)
    {
        if (!$this->is_tiered_variable($object->data)) {
            return;
        }

        do_action('dabber_map_product_fields', $object->product, $object);
    }

    public function adjust_variations_stock_on_inventory_sync($product, $item, $obj)
    {
        if ($product->get_meta('dabber_is_tiered_variable') !== 'yes') {
            return;
        }

        $new_quantity = $item['quantity'];
        $wc_location = cova_get_wc_location_by_cova_location_id($item['location_id']);
        $total_stock = $this->get_bulk_total_stock($product->get_meta('cova_catalog_id'));

        foreach ($product->get_available_variations('objects') as $variation) {

            $variation->update_meta_data('wcmlim_stock_at_'. $wc_location->term_id, $new_quantity);
            $variation->set_stock_quantity($total_stock);

            if ($new_quantity < 0) {
                $variation->set_stock_status('outofstock');
            } else {
                $variation->set_stock_status('instock');
            }

            $variation->save();

            dabber_hack_product_visibility($variation);
        }
    }

    public function get_bulk_total_stock($catalog_id)
    {
        $inventory = Cova_Data_Manager::get_global_data('inventory');
        $stocks = [];

        foreach ($inventory as $location_id => $items) {
            foreach ($items as $catlg_id => $item) {
                if ($catlg_id !== $catalog_id) {
                    continue;
                }
                $stocks[$location_id] = $item['Quantity'];
            }
        }

        return array_sum($stocks);
    }

    public function modify_order_item_catalog_id($catalog_id, $product)
    {
        if ($product->get_meta('dabber_is_price_tiered_variation') !== 'yes') {
            return $catalog_id;
        }

        $parent = wc_get_product($product->get_parent_id());

        return $parent->get_meta('cova_catalog_id');
    }

    public function modify_product_total_stock($total_stock, $product, $item)
    {
        if ($product->get_meta('dabber_is_tiered_variable') !== 'yes') {
            return $total_stock;
        }

        return $this->get_bulk_total_stock($product->get_meta('cova_catalog_id'));
    }

    public function modify_order_quantity($quantity, $order, $item)
    {
        $product = $item->get_product();

        if ($product->get_meta('dabber_is_price_tiered_variation') !== 'yes') {
            return $quantity;
        }

        $weight = (float) $product->get_weight();

        if ($weight < 0) {
            return $quantity;
        }

        return (float) $quantity * $weight;
    }

    /**
     * @desc   Adjust sibling variation stock after a successful purchase.
     * @param  $current_product
     * @return void
     */
    public function adjust_variations_stock($current_product)
    {
        global $dabber_current_location;

        //        error_log(print_r([
        //            'adjust_variations_stock' => [
        //                'new_stock_at_'. $dabber_current_location => $current_product->get_meta('wcmlim_stock_at_'. $dabber_current_location),
        //                'current_total_stock' => $current_product->get_stock_quantity(),
        //                'variation' => $current_product->get_name()
        //            ]
        //        ], true));


        if ($current_product->get_meta('dabber_is_price_tiered_variation') !== 'yes') {
            return;
        }

        $new_quantity = $current_product->get_meta('wcmlim_stock_at_'. $dabber_current_location);
        $current_product_total_stock = $current_product->get_stock_quantity();
        $parent = wc_get_product($current_product->get_parent_id());

        foreach ($parent->get_available_variations('objects') as $item) {
            if ($item->get_id() === $current_product->get_id()) {
                continue;
            }

            $item->update_meta_data('wcmlim_stock_at_'. $dabber_current_location, $new_quantity);
            $item->set_stock_quantity($current_product_total_stock);

            if ($current_product_total_stock < 0) {
                $item->set_stock_status('outofstock');
            } else {
                $item->set_stock_status('instock');
            }

            $item->save();

            dabber_hack_product_visibility($item);
        }

        $parent->set_stock_quantity($current_product_total_stock);

        if ($current_product_total_stock < 0) {
            $parent->set_stock_status('outofstock');
        } else {
            $parent->set_stock_status('instock');
        }

        $parent->save();

        dabber_hack_product_visibility($parent);
    }

    public function create_tiered_price_variations($data, $parent_id)
    {
        global $cova_api;

        if (!$this->is_tiered_variable($data)) {
            return;
        }

        $attributes = get_post_meta($parent_id, 'cova_attributes', true);
        $attributes_prices = $this->get_tier_prices($data);

        if (empty($attributes['Quantity'])) {
            return;
        }

        $global_data = Cova_Data_Manager::generate_global_data();
        $locations   = Cova_Data_Manager::get_stored_data('locations');

        sort($attributes['Quantity']);

        foreach ($attributes['Quantity'] as $attr_name) {
            $variation_creator = new WC_Variation_Product_Creator($cova_api);

            $default_pricing = 99999;
            $tiered_price_id = false;

            $sku = $data['Id'] .'-'. filter_var(str_replace('-', '', $attr_name), FILTER_SANITIZE_NUMBER_INT);

            $data['parent_id'] = $parent_id;
            $data['bulk_data_overrides']['sku'] = $sku;

            foreach ($locations as $location_id => $loc_data) {
                $data['bulk_data_overrides']['pricing']['location_pricing'][$location_id] = [
                    'RegularPrice' => $attributes_prices[$attr_name][$location_id]['RegularPrice'],
                    'OverridePrice' => $attributes_prices[$attr_name][$location_id]['OverridePrice']
                ];

                if ($default_pricing === 99999) {
                    // set default dummy pricing. Dummy price is overridden by the actual price.
                    $default_pricing = $attributes_prices[$attr_name][$location_id]['RegularPrice'];
                }
                if ($tiered_price_id === false) {
                    $tiered_price_id = $attributes_prices[$attr_name][$location_id]['PricingTierId'];
                }
            }

            $data['bulk_data_overrides']['pricing']['default_pricing'] = $default_pricing;
            $data['bulk_data_overrides']['title'] = $attr_name;
            $data['tiered_price_id']  = $tiered_price_id;
            $data['tiered_variation'] = true;

            $variation_creator->set_data($data);
            $variation_creator->set_cova_global_data($global_data);

            //@test
            $variation = $variation_creator->create();
        }
    }

    public function save_variable_meta($object)
    {
        if (!$this->is_tiered_variable($object->data)) {
            return;
        }

        update_post_meta($object->product->get_id(), 'dabber_is_tiered_variable', 'yes');
        update_post_meta($object->product->get_id(), 'cova_attributes', $object->data['attributes']);
        update_post_meta($object->product->get_id(), 'cova_catalog_id', $object->data['catalog_id']);
        update_post_meta($object->product->get_id(), 'measurement_type', $object->data['cova_data']['MeasurementType']);
    }

    public function update_variation_products($update, $cova_product, $parent_product)
    {
        global $cova_api;

        $is_tiered = $parent_product->get_meta('dabber_is_tiered_variable');

        if ($is_tiered !== 'yes') {
            return $update;
        }

        $cova_product['product_type'] = 'tiered_variable';

        dabber_update_variable_product($cova_product, $parent_product);

        $variations = $parent_product->get_available_variations('object');
        $tiered_prices = $this->get_latest_tiered_prices();

        //        $existing_variations = [];

        foreach ($variations as $variation) {
            $variation_tiered_id = $variation->get_meta('dabber_tier_price_id');

            if ($variation_tiered_id === '-1' || array_key_exists($variation_tiered_id, $tiered_prices)) {
                //                $existing_variations[] = $variation_tiered_id;

                $this->update_tiered_price_variation(
                    [
                    'MeasurementType' => $parent_product->get_meta('measurement_type'),
                    'catalog_id' => $cova_product['catalog_id'],
                    'variation' => $variation
                    ], $tiered_prices
                );


            } else {
                wp_delete_post($variation->get_id(), true); // delete non-existing tiered variation
            }
        }

        // -update master product
        // -delete non existing variations
        // update existing variations
        // add new variations

        //        !d($variations);
        //        !d($existing_variations);


        return 'test';
    }

    public function update_tiered_price_variation($data, $tiered_prices)
    {
        $attributes_prices = $this->get_tier_prices($data);
        $tier_quantity = $data['variation']->get_meta('dabber_tier_quantity');
        $price_measure_unit = $this->measurement_types[$data['MeasurementType']];
        $variation_key  = $tier_quantity .' '. (($price_measure_unit == 'pcs')? 'pc': $price_measure_unit);

        if (!empty($attributes_prices[$variation_key])) {
            foreach ($attributes_prices[$variation_key] as $location_id => $prices) {
                !d($prices, $data['variation']->get_id());
                cova_update_product_location_regular_price($data['variation']->get_id(), $location_id, $prices['RegularPrice']);
                cova_update_product_location_sale_price($data['variation']->get_id(), $location_id, $prices['OverridePrice']);
            }
        }

        // update default price
        // get parent weight
        // update variation weight $parent_weight * $tier_quantity
        // update inventory quantity
        !d($attributes_prices[$variation_key]);
        !d($data);
    }

    public function update_tiered_variation_prices()
    {
        //        cova_update_product_location_regular_price
    }

    public function get_latest_tiered_prices()
    {
        global $cova_api;

        $tiered_prices = Cova_Data_Manager::get_stored_data('pricing_tiers');

        if (empty($tiered_prices)) {
            $tiered_prices = $cova_api['pricing']->get_price_tiers();
            Cova_Data_Manager::store_data('pricing_tiers', $tiered_prices, true);
        }

        return $tiered_prices;
    }

    public function save_variation_meta($object)
    {
        if (!$this->is_tiered_variation($object->data)) {
            return;
        }

        $tiered_price_id = (!$object->data['tier_price_id'])? -1 : $object->data['tier_price_id'];

        update_post_meta($object->product->get_id(), 'dabber_is_price_tiered_variation', $object->data['is_price_tiered_variation']);
        update_post_meta($object->product->get_id(), 'dabber_tier_quantity', $object->data['tier_quantity']);
        update_post_meta($object->product->get_id(), 'dabber_tier_price_id', $tiered_price_id);
    }

    /**
     * @desc   Do not create standard variations. We need to create a different set of variation data for tiered price.
     * @param  $is_create
     * @param  $product_id
     * @return false|mixed
     */
    public function disable_default_variation_creation($is_create, $product_id)
    {
        $is_tiered_variable = get_post_meta($product_id, 'dabber_is_tiered_variable', true);

        if ($is_tiered_variable !== 'yes') {
            return $is_create;
        }

        return false;
    }

    public function modify_variation_details($details)
    {
        if (empty($details['cova_data']['bulk_data_overrides'])) {
            return $details;
        }

        $price_tiers = Cova_Data_Manager::get_stored_data('pricing_tiers');
        $tier_quantity = 1;

        if ($details['cova_data']['tiered_price_id']) {
            $details['weights']['equivalency']['value'] = (float) $details['weights']['equivalency']['value'] * $price_tiers[$details['cova_data']['tiered_price_id']]['QuantityLowerBound'];
            $tier_quantity = $price_tiers[$details['cova_data']['tiered_price_id']]['QuantityLowerBound'];
        }

        $details['is_price_tiered_variation']  = 'yes';
        $details['tier_quantity'] = $tier_quantity;
        $details['tier_price_id'] = $details['cova_data']['tiered_price_id'];

        return array_merge($details, $details['cova_data']['bulk_data_overrides']);
    }

    public function modify_save_variation_meta_items($meta_items)
    {
        unset($meta_items['cova_catalog_id']);

        return $meta_items;
    }

    public function add_custom_details($details)
    {
        if (!$this->is_tiered_variable($details)) {
            return $details;
        }

        $price_tiers = Cova_Data_Manager::get_stored_data('pricing_tiers');

        $price_measure_unit = $this->measurement_types[$details['cova_data']['MeasurementType']];
        $default_tier_name  = '1 '. (($price_measure_unit == 'pcs')? 'pc': $price_measure_unit);
        $attributes = [$default_tier_name];

        foreach ($price_tiers as $item) {
            $attr_name = $item['QuantityLowerBound'] .' '. $price_measure_unit;
            $attributes[] = $attr_name;
        }

        $details['attributes']['Quantity'] = $attributes;

        // Use Quantity attribute instead of Brand for bulk products
        if (isset($details['attributes']['Brand'])) {
            unset($details['attributes']['Brand']);
        }

        $details['cova_specifications'] = $details['cova_data']['Specifications'];

        return $details;
    }

    public function is_tiered_variable($data)
    {
        return (isset($data['product_type']) && $data['product_type'] === 'tiered_variable');
    }

    public function is_tiered_variation($data)
    {
        return isset($data['is_price_tiered_variation']);
    }

    public function set_variation_term($term, $data)
    {
        if (!$this->is_tiered_variable($data['cova_data'])) {
            return $term;
        }

        return 'quantity';
    }

    public function get_tier_prices($details, $price_tiers = [])
    {
        $price_tiers = (!empty($price_tiers))? $price_tiers : Cova_Data_Manager::get_stored_data('pricing_tiers');
        $locations   = Cova_Data_Manager::get_stored_data('locations');

        $price_measure_unit = $this->measurement_types[$details['MeasurementType']];
        $default_tier_name  = '1 '. (($price_measure_unit == 'pcs')? 'pc': $price_measure_unit);

        $prices = [];

        foreach ($locations as $location_id => $loc_data) {
            $location_prices = Cova_Data_Manager::get_global_data('pricing-'. $location_id);

            if (!isset($location_prices[$location_id][$details['catalog_id']])) {
                continue;
            }

            foreach ($location_prices[$location_id][$details['catalog_id']] as $item) {
                if ($item['PricingTierId'] !== null) {
                    $tier_data  = $price_tiers[$item['PricingTierId']];
                    $price_name = $tier_data['QuantityLowerBound'] .' '. $price_measure_unit;
                    $item['RegularPrice']  = (float) $item['RegularPrice'] * $tier_data['QuantityLowerBound'];
                    $item['OverridePrice'] = (float) $item['OverridePrice'] * $tier_data['QuantityLowerBound'];
                } else {
                    $price_name = $default_tier_name;
                }

                $prices[$price_name][$location_id] = $item;
            }
        }

        return $prices;
    }
}
