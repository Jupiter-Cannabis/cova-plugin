<h2><?php _e('Bulk Product Settings', 'cova') ?></h2>
<form action="" method="post">
    <table class="form-table">
        <tbody>
            <tr>
                <th scope="row"><label for="convert-tiered-variable"><?php _e('Convert Tiered Prices to Variable Product', 'dabber') ?></label></th>
                <td>
                    <input name="convert-tiered" <?php echo (($args['convert_to'] === 'variable')? 'checked="checked"' : '') ?> type="radio" id="convert-tiered-variable" value="variable">
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="convert-tiered-simple"><?php _e('Convert Tiered Prices to Simple Product', 'dabber') ?></label></th>
                <td>
                    <input name="convert-tiered" <?php echo (($args['convert_to'] === 'simple')? 'checked="checked"' : '') ?> type="radio" id="convert-tiered-simple" value="simple">
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="do-not-convert"><?php _e('Do not convert', 'dabber') ?></label></th>
                <td>
                    <input name="convert-tiered" <?php echo (($args['convert_to'] === 'none')? 'checked="checked"' : '') ?> type="radio" id="do-not-convert" value="none">
                </td>
            </tr>
        </tbody>
    </table>
    <input type="submit" id="submit" name="dabber-save-bulk-product-settings" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">
</form>
