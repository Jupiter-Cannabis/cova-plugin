<?php

namespace Dabber\Modules\BulkProducts;

use Cova_Integration\Cova_Data_Manager;
use Cova_Integration\WC_Simple_Product_Updater;

class BulkProducts
{
    private $settings;

    //    public static $module_info = [
    //        'name' => 'Bulk Products',
    //        'description' => ''
    //    ];

    public function run()
    {
        add_action('init', [$this, 'save_settings']);
        add_action('init', [$this, 'load_settings']);

        add_filter('dabber_admin_module_sub_nav_items_synchronization', [$this, 'add_sync_settings_sub_tab'], 20);
        add_action('dabber_render_module_admin_page_after_synchronization_product_sync_settings', [$this, 'render_product_sync_settings']);

        add_filter('dabber_import_product_type_identifier', [$this, 'set_product_type_identifier'], 100, 2);
        add_action('dabber_before_product_import_process', [$this, 'create_tiered_prices_log']);

        (new VariableProductHandler())->run();

        /**
         * @todo review functionalities for simple product handler
         */
        //        if ($this->settings === 'testonly') {
        //            add_filter('cova_sync_product_details', [$this, 'customize_product_details'], 100, 2);
        //            add_filter('cova_sync_product_update_metadata', [$this, 'add_update_metadata'], 100, 4);
        //            add_filter('cova_get_product_by_catalog_id', [$this, 'get_product_by_catalog_id'], 100);
        //            add_filter('cova_sync_product_update_product_props', [$this, 'modify_product_props'], 100, 4);
        //            add_filter('cova_update_product_location_stock_quantity', [$this, 'modify_product_location_stock_quantity_update'], 100, 3);
        //            add_action('cova_after_simple_product_update', [$this, 'update_bulk_products'], 100, 2);
        //
        //            add_filter('woocommerce_order_item_quantity', [$this, 'modify_product_order_quantity'], 100, 3);
        //            add_action('woocommerce_product_set_stock', [$this, 'adjust_sibling_products_stock_single'], 100);
        //            add_action('woocommerce_product_set_stock', [$this, 'adjust_sibling_products_stock_on_product_update'], 100);
        //            add_action('woocommerce_product_set_stock', [$this, 'adjust_sibling_products_stock_on_inventory_update'], 100);
        //        }
    }

    public function set_product_type_identifier($type, $cova_product)
    {
        if (!$this->is_tiered_product($cova_product['catalog_id']) || $this->settings['convert_bulk_to'] === 'none') {
            return $type;
        }

        return ($this->settings['convert_bulk_to'] === 'variable')? 'tiered_variable' : $this->settings['convert_bulk_to'];
    }

    public function is_tiered_product($catalog_id)
    {
        $locations = Cova_Data_Manager::get_stored_data('locations');

        foreach ($locations as $location_id => $loc_data) {
            $pricing = Cova_Data_Manager::get_global_data('pricing-'. $location_id);
            if (!isset($pricing[$location_id][$catalog_id]) || count($pricing[$location_id][$catalog_id]) <= 1) {
                return false;
            }
            return true; // no need to loop through all locations since tiered prices are applied to all locations.
        }

        return false;
    }

    public function create_tiered_prices_log()
    {
        global $cova_api;

        $is_data_exists = Cova_Data_Manager::is_stored_file_exists('pricing_tiers');

        if ($is_data_exists) {
            return;
        }

        $price_tiers = $cova_api['pricing']->get_price_tiers();

        if (empty($price_tiers)) {
            return;
        }

        Cova_Data_Manager::store_data('pricing_tiers', $price_tiers, true);
    }

    public function load_settings()
    {
        $convert_bulk_to = get_option('dabber_bulk_product_convert_to');

        $this->settings = [
            'convert_bulk_to' => (!$convert_bulk_to)? 'variable' : $convert_bulk_to
        ];
    }

    public function add_sync_settings_sub_tab($sub_tabs)
    {
        $sub_tabs['product_sync_settings'] = __('Product Sync Settings', 'dabber');

        return $sub_tabs;
    }

    public function render_product_sync_settings()
    {
        load_template(
            plugin_dir_path(__FILE__) . 'templates/sync-settings.php', true, [
            'convert_to' => $this->settings['convert_bulk_to']
            ]
        );
    }

    public function save_settings()
    {
        if (!isset($_POST['dabber-save-bulk-product-settings'])) {
            return;
        }

        update_option('dabber_bulk_product_convert_to', sanitize_text_field($_POST['convert-tiered']));
    }

    public function adjust_sibling_products_stock_single($current_product)
    {
        global $cova_current_sync_running, $cova_is_single_set_stock;

        if (isset($cova_current_sync_running) || $cova_is_single_set_stock === true) {
            return;
        }

        $this->adjust_sibling_products_stock_quantity($current_product);
    }

    public function adjust_sibling_products_stock_on_product_update($current_product)
    {
        global $cova_current_sync_running, $cova_is_single_set_stock;

        if ($cova_current_sync_running !== 'product_update' || $cova_is_single_set_stock === true) {
            return;
        }

        $base_bulk_product = $this->get_base_bulk_product($current_product->get_meta('cova_catalog_id'));

        if (!$base_bulk_product) {
            $this->adjust_sibling_products_stock_quantity($current_product);
            return;
        }

        $this->adjust_sibling_products_stock_quantity($base_bulk_product);
    }

    public function adjust_sibling_products_stock_on_inventory_update($current_product)
    {
        global $cova_current_sync_running, $cova_is_single_set_stock;

        if ($cova_current_sync_running !== 'inventory_update' || $cova_is_single_set_stock === true) {
            return;
        }

        $base_bulk_product = $this->get_base_bulk_product($current_product->get_meta('cova_catalog_id'));

        if (!$base_bulk_product) {
            $this->adjust_sibling_products_stock_quantity($current_product);
            return;
        }

        $this->adjust_sibling_products_stock_quantity($base_bulk_product);
    }

    public function adjust_sibling_products_stock_quantity($current_product)
    {
        global $cova_is_single_set_stock;

        $cova_is_single_set_stock = true;
        $is_bulk_product = $current_product->get_meta('is_bulk_product');

        if ($is_bulk_product !== 'yes') {
            return;
        }

        $current_location = cova_get_current_location();
        $new_quantity = $current_product->get_meta('wcmlim_stock_at_'. $current_location);
        $catalog_id = $current_product->get_meta('cova_catalog_id');

        $products = dabber_get_bulk_products_by_catalog_id($catalog_id);
        $current_product_total_stock = $current_product->get_stock_quantity();

        foreach ($products as $product) {

            if ($product->ID === $current_product->get_id()) {
                continue;
            }

            $sibling_product = wc_get_product($product->ID);
            update_post_meta($product->ID, 'wcmlim_stock_at_'. $current_location, $new_quantity);

            $sibling_product->set_stock_quantity($current_product_total_stock);

            if ($current_product_total_stock < 0) {
                $sibling_product->set_stock_status('outofstock');
            } else {
                $sibling_product->set_stock_status('instock');
            }

            $sibling_product->save();
            $this->hack_product_visibility($sibling_product);
        }
    }

    public function modify_product_location_stock_quantity_update($stock_qty, $product_id, $location_term_id)
    {
        $product = wc_get_product($product_id);
        $is_bulk_product = $product->get_meta('is_bulk_product');

        if ($is_bulk_product !== 'yes') {
            return $stock_qty;
        }

        return $this->calculate_bulk_product_quantity($stock_qty);
    }

    public function add_update_metadata($meta_args, $product_id, $data, $obj)
    {
        if (isset($data['is_bulk_product'])) {
            $meta_args['is_bulk_product'] = $data['is_bulk_product'];
        }

        if (isset($data['tier_price_id'])) {
            $meta_args['tier_price_id'] = $data['tier_price_id'];
        }

        if (isset($data['is_tier_price_product'])) {
            $meta_args['is_tier_price_product'] = $data['is_tier_price_product'];
        }

        return $meta_args;
    }

    public function modify_product_order_quantity($quantity, $order, $item)
    {
        $product = wc_get_product($item->get_product_id());
        $is_bulk_product = $product->get_meta('is_bulk_product');

        if ($is_bulk_product !== 'yes') {
            return $quantity;
        }

        return (float) ($quantity * $product->get_weight());
    }

    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }

    //    public function adjust_sibling_products_stock_quantity($product)
    //    {
    //        $this->reduce_sibling_bulk_product_quantity($product);
    //    }

    public function get_product_by_catalog_id($product)
    {
        $is_bulk_product = $product->get_meta('is_bulk_product');

        if (!$is_bulk_product) {
            return $product;
        }

        $is_tier_price_product = $product->get_meta('is_tier_price_product');

        if ($is_tier_price_product === 'no') {
            return $product;
        }

        $catalog_id = $product->get_meta('cova_catalog_id');
        $base_bulk_product = $this->get_base_bulk_product($catalog_id);

        if (!$base_bulk_product) {
            return $product;
        }

        return $base_bulk_product;
    }

    public function modify_product_props($props, $product, $data, $obj)
    {
        if (isset($data['is_tier_price_product']) && $data['is_tier_price_product'] === 'yes') {
            $props['date_created'] = $data['date_added'];
        }

        if (isset($data['is_bulk_product']) && $data['is_bulk_product'] === 'yes') {
            $props['stock_quantity'] = $this->calculate_bulk_product_quantity($data['stocks']['total_stock']);
        }

        return $props;
    }

    public function get_base_bulk_product($catalog_id)
    {
        $query = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'posts_per_page' => 1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_catalog_id',
                    'value' => $catalog_id,
                    'compare' => '='
                ],
                [
                    'key' => 'is_tier_price_product',
                    'value' => 'yes',
                    'compare' => '!='
                ]
            ]
            ]
        );

        if ($query->found_posts < 1) {
            return false;
        }

        return wc_get_product($query->posts[0]->ID);
    }

    public function remove_unused_price_tier_products($catalog_id, $tier_ids)
    {
        $query = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_catalog_id',
                    'value' => $catalog_id,
                    'compare' => '='
                ],
                [
                    'key' => 'is_tier_price_product',
                    'value' => 'yes',
                    'compare' => '='
                ],
                [
                    'key' => 'tier_price_id',
                    'value' => $tier_ids,
                    'compare' => 'NOT IN'
                ]
            ]
            ]
        );

        if ($query->found_posts < 1) {
            return;
        }

        foreach ($query->posts as $post) {
            wp_delete_post($post->ID, true);
        }
    }

    public function get_price_tier_product($catalog_id, $tier_id)
    {
        $product = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'posts_per_page' => 1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_catalog_id',
                    'value' => $catalog_id,
                    'compare' => '='
                ],
                [
                    'key' => 'tier_price_id',
                    'value' => $tier_id,
                    'compare' => '='
                ]
            ]
            ]
        );

        if ($product->found_posts > 0) {
            return $product->posts[0];
        }

        return false;
    }

    public function update_bulk_products($product, $obj)
    {
        if (!isset($obj->data['price_tiers']) || empty($obj->data['price_tiers'])) {
            return;
        }

        $this->remove_unused_price_tier_products($obj->data['catalog_id'], array_keys($obj->data['price_tiers']));

        foreach ($obj->data['price_tiers'] as $tier_id => $tier_item) {

            $tier_price = [];
            $details = $obj->data;

            $details['tier_price_id'] = $tier_id;
            $details['is_tier_price_product'] = 'yes';

            $product = new \WC_Product_Simple();

            if (isset($details['is_update'])) {
                $tier_product = $this->get_price_tier_product($details['catalog_id'], $tier_id);

                if ($tier_product !== false) {
                    $product = wc_get_product($tier_product->ID);
                }
            }

            $details['wc_product'] = $product;

            foreach ($obj->data['tiered_items'] as $location_id => $prices) {
                foreach ($prices as $price) {
                    if ($tier_id === $price['PricingTierId']) {
                        $tier_price = $price;
                        break;
                    }
                }

                $regular_price = ((float) $tier_price['RegularPrice'] * (float) $tier_item['QuantityLowerBound']);
                $sale_price = ((float) $tier_price['OverridePrice'] * (float) $tier_item['QuantityLowerBound']);

                $details['pricing']['location_pricing'][$location_id] = [
                    'RegularPrice'  => number_format(round($regular_price, 2), 2),
                    'OverridePrice' => number_format(round($sale_price, 2), 2)
                ];

                $details['pricing']['default_pricing'] = $details['pricing']['location_pricing'][$location_id]['RegularPrice'];
            }

            $details['stock_weight'] = [
                'value' => $tier_item['QuantityLowerBound'],
                'unit'  => 'g'
            ];

            $details['sku']     = $details['sku'] .'-'. $tier_id;
            $details['title']   = $details['original_data']['title'] .' - '. $details['stock_weight']['value'] . $details['stock_weight']['unit'];
            $details['weight']  = $details['stock_weight'];

            if (isset($details['price_tiers'])) {
                unset($details['price_tiers']);
            }

            $update_product = new WC_Simple_Product_Updater();
            $update_product->set_data($details);
            $update_product->update();
        }
    }

    public function calculate_bulk_product_quantity($quantity)
    {
        return (float) ($quantity / 1000);
    }

    public function customize_product_details($details, $obj)
    {
        $price_tiers = $this->get_price_tiers($obj->data);

        if (empty($price_tiers)) {
            return $details;
        }

        $details['is_bulk_product'] = 'yes';
        $details['is_tier_price_product'] = 'no';
        $details['price_tiers'] = $price_tiers;
        //        $details['stocks']['total_stock'] = $this->calculate_bulk_product_quantity($details['stocks']['total_stock']);
        //        $details['stocks']['total_stock'] = $details['stocks']['total_stock'];

        foreach ($details['stocks']['location_stocks'] as $location_id => $stock_qty) {
            //            $details['stocks']['location_stocks'][$location_id] = $this->calculate_bulk_product_quantity($stock_qty);
            $details['stocks']['location_stocks'][$location_id] = $stock_qty;
        }

        $tiered_items = [];
        $default_price = 0;
        $base_price = [];

        foreach ($obj->cova_global_data['pricing'] as $location_id => $prices) {
            if (!isset($prices[$obj->data['catalog_id']])) {
                break;
            }

            foreach ($prices[$obj->data['catalog_id']] as $price_id => $price) {
                if (!$price['PricingTierId']) {
                    $default_price = $price['RegularPrice'];
                    $base_price[$location_id] = $price;
                } else {
                    $tiered_items[$location_id][$price_id] = $price;
                }
            }
        }

        $details['pricing']['default_pricing'] = $default_price;
        $details['tiered_items'] = $tiered_items;
        $details['original_data'] = [
            'title' => $details['title']
        ];

        $details['title'] = $details['title'] .' - '. $details['weight']['value'] . $details['weight']['unit'];
        $details['pricing']['location_pricing'] = $base_price;

        return $details;
    }

    public function get_price_tiers($data)
    {
        global $cova_api;

        $pricing_tiers = $cova_api['pricing']->get_price_tiers();

        if (empty($pricing_tiers)) {
            return [];
        }

        $locations = cova_get_available_locations();
        $tiered_prices = [];

        foreach ($locations as $key => $term) {
            $location = get_term_meta($term['term_id'], 'location_id', true);
            $cova_prices = Cova_Data_Manager::get_stored_data('pricing-'. $location);

            if (!isset($cova_prices[$location][$data['catalog_id']])) {
                continue;
            }

            foreach ($cova_prices[$location][$data['catalog_id']] as $price_key => $price) {
                if (isset($pricing_tiers[$price['PricingTierId']])) {
                    $tiered_prices[$price['PricingTierId']] = $pricing_tiers[$price['PricingTierId']];
                }
            }
        }

        return $tiered_prices;
    }
}
