jQuery(function(){
    $cookieName = 'wcmlim_selected_location';

    // console.log($cookieName, getCookie($cookieName));
    // console.log(getCookie($cookieName) === 'undefined');

    if (
        getCookie($cookieName) === undefined ||
        getCookie($cookieName) === 'null' ||
        getCookie($cookieName) == null ||
        parseInt(getCookie($cookieName)) < 0
    ) {
        jQuery.fancybox.open({
            src  : '#store-locator-dialog',
            type : 'inline',
            clickOutside: false,
            clickSlide: false,
            // Set `touch: false` to disable panning/swiping
            touch: {
                vertical: false, // Allow to drag content vertically
                momentum: false // Continue movement after releasing mouse/touch when panning
            },
            afterClose: function() {
                jQuery("#wcmlim-change-lc-select").val(0).trigger("change");
            }
        });
    } else {
        if (jQuery('#wcmlim-change-lc-select').val() < 0) {
            jQuery("#wcmlim-change-lc-select").val(getCookie($cookieName)).trigger("change");
        }
    }

    // location pin
    jQuery('#location_pin span').click(function() {
        jQuery.fancybox.open({
            src  : '#store-locator-dialog',
            type : 'inline',
            clickOutside: false,
            clickSlide: false,
            // Set `touch: false` to disable panning/swiping
            touch: {
                vertical: false, // Allow to drag content vertically
                momentum: false // Continue movement after releasing mouse/touch when panning
            },
            afterClose: function() {
                // jQuery("#wcmlim-change-lc-select").val(0).trigger("change");
            }
        });
    });

    jQuery('.js-locations-buttons').each(function(){
        jQuery(this).on('click touchstart', function(e){
            e.preventDefault();
            jQuery("#wcmlim-change-lc-select").val(jQuery(this).attr('data-value')).trigger("change");
        });
    });
});

function getCookie(name) {
    let cookie = {};
    document.cookie.split(';').forEach(function(el) {
        let [k,v] = el.split('=');
        cookie[k.trim()] = v;
    })
    return cookie[name];
}