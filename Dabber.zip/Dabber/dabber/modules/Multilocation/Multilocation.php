<?php

namespace Dabber\Modules\Multilocation;

class Multilocation
{
    public static $module_info = [
        'name' => 'Multilocation',
        'description' => 'Manage multilocation plugin dropdown and popup'
    ];
    public $options = [];

    public function run()
    {
        new Dropdown();
        new Popup();
    }
}
