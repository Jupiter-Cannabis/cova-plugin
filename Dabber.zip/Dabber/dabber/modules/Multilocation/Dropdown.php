<?php

namespace Dabber\Modules\Multilocation;

class Dropdown
{
    public $options = [];

    public function __construct()
    {
        // ToDo: Get options from wp options
        //        $this->options = [
        //            'key' => 'elfsight-app-c01fc93b-ba5a-4b86-bc39-c59087981070'
        //        ];

        $this->run();
    }

    public function run()
    {
        add_action('wp_head', [$this, 'wpHead']);
        add_shortcode('dabber_multilocation_dropdown', [$this, 'doDropdownShortcode']);
    }

    public function wpHead()
    {
        wp_register_style('dabber-multilocation-dropdown-style', plugin_dir_url(__FILE__) . 'assets/css/dropdown.css');
        wp_enqueue_style('dabber-multilocation-dropdown-style');
    }

    public function doDropdownShortcode()
    {
        //        echo '<div class="tnj-header-store-locator">';
        echo do_shortcode('[wcmlim_locations_switch]');
        //        echo '</div>';
    }
}
