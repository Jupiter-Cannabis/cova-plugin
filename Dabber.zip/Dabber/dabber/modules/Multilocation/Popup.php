<?php

namespace Dabber\Modules\Multilocation;

class Popup
{
    public $version = '1.0';
    public $options = [];

    public function __construct()
    {
        // ToDo: Get options from wp options
        $this->setOptions();

        $this->run();
    }

    public function run()
    {
        add_filter('body_class', [$this, 'bodyClass']);
        add_action('wp_head', [$this, 'wpHead']);
        add_action('wp_footer', [$this, 'wpFooter']);
        add_shortcode('dabber_multilocation_pin',  [$this, 'getPin']);
    }

    public function setOptions()
    {
        $this->options = [
            'image'     => ''
        ];

        //        $terms = new \WP_Term_Query([
        //            'taxonomy'         => 'locations',
        //            'hide_empty'     => false,
        //            'orderby'         => 'name',
        //            'order'         => 'ASC',
        //            'number'         => 0,
        //            'hierarchical'     => false
        //        ]);
        //
        //        if (!is_null($terms->terms)) {
        //            foreach ($terms->terms as $location) {
        //                $this->options['locations'][] = (array)$location;
        //            }
        //        }

        $this->options['locations'] = cova_get_available_locations();
    }

    public function bodyClass($classes)
    {
        $classes[] = 'enable-store-locator';

        return $classes;
    }

    public function wpHead()
    {
        wp_register_style('fancybox-style', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_register_style('dabber-multilocation-popup-style', plugin_dir_url(__FILE__) . 'assets/css/popup.css');

        wp_enqueue_style('fancybox-style');
        wp_enqueue_style('dabber-multilocation-popup-style');
    }

    public function wpFooter()
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/popup.php', true, $this->options);

        wp_register_script('fancybox-script', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.js', ['jquery'], '3.5.7', true);
        wp_register_script('dabber-multilocation-popup-js', plugin_dir_url(__FILE__) . 'assets/js/popup.js', ['jquery', 'fancybox-script'], $this->version, true);

        wp_enqueue_script('fancybox-script');
        wp_enqueue_script('dabber-multilocation-popup-js');
    }

    public function getPin()
    {
        $cookie = isset($_COOKIE['wcmlim_selected_location']) ? $_COOKIE['wcmlim_selected_location'] : 0;

        if (count($this->options['locations']) < 2 || !isset($this->options['locations'][$cookie])) {
            return;
        }

        echo '<div id="location_pin"><span>'. $this->options['locations'][$cookie]['name']. '</span></div>';
    }
}
