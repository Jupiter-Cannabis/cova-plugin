<div id="store-locator-dialog" class="store-locator-dialog">
    <figure class="store-locator-dialog__banner">
        <img src="<?php echo $args['image'] ?>">
    </figure>
    <h2 class="store-locator-dialog__title">Select Your Location</h2>
    <!--<p>We've got two convenient locations <br />to serve you</p>-->
    <?php // do_shortcode('[wcmlim_locations_switch]'); ?>
    <div class="locations-buttons woocommerce">
        <?php foreach($args['locations'] as $key => $location): ?>
            <a class="js-locations-buttons button" data-value="<?php echo $key; ?>"><?php echo $location['name']; ?></a>
            <!--<button type="button" data-value="<?php /*= $key; */?>" class="js-locations-buttons"><?php /*= $location['name']; */?></button>-->
        <?php endforeach; ?>
    </div>
</div>
