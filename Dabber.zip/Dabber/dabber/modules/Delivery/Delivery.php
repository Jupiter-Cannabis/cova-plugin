<?php

namespace Dabber\Modules\Delivery;

use WC_Shipping_Zones;

class Delivery
{

    private $tab_key = 'delivery';

    public static $must_use = true;

    public static $module_info = [
        'name' => 'Delivery',
        'description' => 'Delivery settings.'
    ];

    public function run()
    {
        add_filter('dabber_admin_module_nav_items', [$this, 'add_tab'], 60);
        add_filter('dabber_admin_module_sub_nav_items_delivery', [$this, 'add_submenu_item'], 60);
        add_action('dabber_render_module_admin_section_delivery_'. $this->tab_key, [$this, 'render_tab_section']);
        add_action('dabber_admin_module_save_settings_delivery_'. $this->tab_key, [$this, 'save_cova_wc_delivery']);

        add_action('dabber_register_module_hooks_mapping_'. $this->tab_key, [$this, 'register_hooks']);

        add_action('wp', [$this, 'hide_delivery_checkbox']);
        add_filter('woocommerce_package_rates', [$this, 'woocommerce_package_rates'], 999, 2);
    }

    public function register_hooks()
    {
        // add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function add_tab($tabs)
    {
        $tabs['delivery'] = __('Delivery');

        return $tabs;
    }

    public function add_submenu_item($submenu_items)
    {
        $submenu_items['delivery'] = __('Delivery', 'dabber');

        return $submenu_items;
    }

    public function render_tab_section()
    {
        $zones     = self::get_shipping_zones_and_methods();
        $locations = self::get_locations();

        if (isset($_POST['cova_shipping_settings_save']) && isset($_POST['settings'])) {

            $settings_update = $_POST['settings'];

            update_option('cova_shipping_settings', $settings_update);
        }

        $settings = get_option('cova_shipping_settings', []);

        load_template(
            plugin_dir_path(__FILE__) .'templates/delivery.php', true, [
            'class'     => $this,
            'zones'     => $zones,
            'settings'  => $settings,
            'locations' => $locations
            ]
        );
    }

    public function save_cova_wc_delivery()
    {
        if (isset($_POST['cova_shipping_settings_save']) && isset($_POST['settings'])) {
            update_option('cova_shipping_settings', $_POST['settings']);
        }
    }

    public static function get_shipping_zones_and_methods()
    {

        $output = [];
        $zones  = WC_Shipping_Zones::get_zones();

        foreach ($zones as $zone) {
            $zone_id = $zone['id'];

            $output[$zone_id]['name']    = $zone['zone_name'];
            $output[$zone_id]['methods'] = [];

            $methods = $zone['shipping_methods'];

            foreach ($methods as $method) {
                //echo '<pre>'; var_dump($method); echo '</pre>';
                if ($method->id != 'local_pickup') {
                    $output[$zone_id]['methods'][$method->id.':'.$method->get_instance_id()] = $method->get_title();
                }
            }

            if (empty($output[$zone_id]['methods'])) {
                unset($output[$zone_id]);
            }
        }

        return $output;
    }

    public static function get_locations()
    {
        $locations = [];
        $terms     = new \WP_Term_Query(
            [
            'taxonomy'      => 'locations',
            'hide_empty'    => false,
            'orderby'       => 'name',
            'order'         => 'ASC',
            'number'        => 0,
            'hierarchical'  => false
            ]
        );

        if (is_null($terms->terms)) {
            return $locations;
        }

        foreach ($terms->terms as $location) {
            $locations[] = (array)$location;
        }

        return $locations;
    }

    public static function get_time_zone_select($name, $value = '')
    {
        $zone_groups = [
            'Canada' => [
                'America/St_Johns'    => 'Newfoundland (GMT-3:30)',
                'America/Halifax'     => 'Halifax Regional Municipality, NS, Canada (GMT-4)',
                'America/Toronto'     => 'Ottawa (GMT-5)',
                'America/Winnipeg'    => 'Winnipeg (GMT-6)',
                'America/Regina'      => 'Regina (GMT-6)',
                'America/Edmonton'    => 'Edmonton (GMT-7)',
                'America/Vancouver'   => 'Vancouver (GMT-8)',
            ],
            'USA' => [
                'America/New_York'    => 'Washington (GMT-5)',
                'America/Chicago'     => 'Chicago (GMT-6)',
                'America/Denver'      => 'Denver (GMT-7)',
                'America/Phoenix'     => 'Phoenix (GMT-7)',
                'America/Los_Angeles' => 'Los Angeles (GMT-8)',
                'America/Anchorage'   => 'Anchorage (GMT-9)',
                'America/Adak'        => 'Honolulu (GMT-10)',
            ]
        ];

        $output = '<select name="'.$name.'" style="width: 215px;">';
        $output.= '<option value="">-</option>';
        foreach ($zone_groups as $group => $zones) {
            $output.= '<optgroup label="'.$group.'">';
            foreach ($zones as $z => $zone) {
                $selected = $value == $z ? ' selected' : '';
                $output  .= sprintf('<option value="%s"%s>%s</option>', $z, $selected, $zone);
            }
            $output .= '</optgroup>';
        }
        $output .= '</select>';

        return $output;
    }

    public static function get_time_select($name, $value = '')
    {
        $start = strtotime('00:00');
        $end   = strtotime('23:30');
        $now   = $start;

        $output = '<select name="'.$name.'" style="width: 100px;">';
        $output.= '<option value="">-</option>';
        while ($now <= $end) {
            $selected = $value == date('H:i', $now) ? ' selected' : '';
            $output  .= sprintf('<option value="%s"%s>%s</option>', date('H:i', $now), $selected, date("h:ia", $now));
            $now      = strtotime('+30 minutes', $now);
        }
        $output .= '</select>';

        return $output;
    }

    public function hide_delivery_checkbox()
    {

        $settings = get_option('cova_shipping_settings', []);
        $total    = WC()->cart->cart_contents_total;
        $location = self::get_selected_location();

        // echo '<pre>[rates]'; var_dump($rates); echo '</pre>';
        // echo '<pre>[package]'; var_dump($package); echo '</pre>';
        // echo '<pre>[settings]'; var_dump($settings); echo '</pre>';
        // echo '<pre>[location]'; var_dump($location); echo '</pre>';

        $has_delivery = false;

        foreach ($settings as $r => $setting) {

            $locations = isset($setting['locations']) ? $setting['locations'] : [];
            $limit     = $setting['limit'];
            $time_zone = $setting['time_zone'];
            $time      = $setting['time'];

            // Location
            if (!in_array($location, $locations)) {

                continue;
            }

            // Minimum order
            if ($limit && $limit > 0 && $limit >= $total) {
                continue;
            }

            // Time
            if (self::not_available($time, $time_zone)) {
                continue;
            }

            $has_delivery = true;
        }

        if (!$has_delivery) {
            add_filter('woocommerce_cart_needs_shipping_address', '__return_false');
        }
    }

    public function woocommerce_package_rates($rates, $package)
    {

        $settings = get_option('cova_shipping_settings', []);
        $total    = WC()->cart->cart_contents_total;
        $location = self::get_selected_location();

        // echo '<pre>[rates]'; var_dump($rates); echo '</pre>';
        // echo '<pre>[package]'; var_dump($package); echo '</pre>';
        // echo '<pre>[settings]'; var_dump($settings); echo '</pre>';
        // echo '<pre>[location]'; var_dump($location); echo '</pre>';

        $output = $rates;

        foreach ($rates as $r => $rate) {

            if (!isset($settings[$r])) {
                continue;
            }

            $locations = isset($settings[$r]['locations']) ? $settings[$r]['locations'] : [];
            $limit     = $settings[$r]['limit'];
            $time_zone = $settings[$r]['time_zone'];
            $time      = $settings[$r]['time'];

            // Location
            if (!in_array($location, $locations)) {
                unset($output[$r]);
            }

            // Minimum order
            if ($limit && $limit > 0 && $limit >= $total) {
                unset($output[$r]);
            }

            // Time
            if (self::not_available($time, $time_zone)) {
                unset($output[$r]);
            }
        }

        return $output;
    }

    public static function get_selected_location()
    {
        return $_COOKIE['wcmlim_selected_location'];
    }

    public static function not_available($settings = [], $time_zone = '')
    {
        if ($time_zone && $time_zone != '') {
            date_default_timezone_set($time_zone);
        }

        $current_day  = date('N');
        $current_time = time();
        // $current_day  = 0;                  // Uncomment to test (0-7)
        // $current_time = strtotime("12:30"); // Uncomment to test

        if (!isset($settings[$current_day])) {
            return false;
        }

        $start = isset($settings[$current_day]['start']) && $settings[$current_day]['start'] != '' ? $settings[$current_day]['start'] : false;
        $end   = isset($settings[$current_day]['end'])   && $settings[$current_day]['end']   != '' ? $settings[$current_day]['end']   : false;

        if (!$start || !$end) {
            return false;
        }

        $start = strtotime($start);
        $end   = strtotime($end);

        return ($current_time < $start || $current_time > $end);
    }
}
