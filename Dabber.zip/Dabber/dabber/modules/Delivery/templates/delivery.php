<?php
$class     = $args['class'];
$zones     = $args['zones'];
$settings  = $args['settings'];
$locations = $args['locations'];
?>

<form action="" method="post">
    <fieldset style="margin-bottom: 10px;">
        <?php foreach ($zones as $zone) : ?>
            <div class="has-data">
                <span><?php echo $zone['name']; ?></span>
                <div class="data">
                    <table class="form-table">
                        <tbody>
                        <?php foreach ($zone['methods'] as $method_id => $method) : ?>
                            <tr>
                                <th scope="row" colspan="2"><?php echo $method; ?><hr></th>
                            </tr>
                            <tr>
                                <td>Stores:</td>
                                <td>
                                    <p style="margin-left: 35px;">
                                        <?php foreach($locations as $l => $location) : ?>
                                            <label for="site-status-live" style="margin-right: 20px;">
                                                <input type="checkbox" name="settings[<?php echo $method_id ?>][locations][<?php echo $l ?>]" value="<?php echo $l ?>"<?php echo isset($settings[$method_id]['locations'][$l]) ? ' checked' : '' ?>>
                                                <?php echo $location['name'] ?>
                                            </label>
                                        <?php endforeach ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td>Minimum Order:</td>
                                <td>
                                    <label for="site-status-live" style="display: inline-block; width: 30px; text-align: right;">$</label>
                                    <input type="text" name="settings[<?php echo $method_id ?>][limit]" style="text-align: right; width: 100px;" value="<?php echo isset($settings[$method_id]['limit']) ? $settings[$method_id]['limit'] : '0.00' ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>Time Zone:</td>
                                <td>
                                    <label for="site-status-live" style="display: inline-block; width: 30px;">&nbsp;</label>
                                    <?php echo $class::get_time_zone_select('settings['.$method_id.'][time_zone]', isset($settings[$method_id]['time_zone']) ? $settings[$method_id]['time_zone'] : '') ?>
                                </td>
                            </tr>
                            <tr>
                                <td>Availability:</td>
                                <td>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Mon: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][1][start]', isset($settings[$method_id]['time'][1]['start']) ? $settings[$method_id]['time'][1]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][1][end]', isset($settings[$method_id]['time'][1]['end']) ? $settings[$method_id]['time'][1]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Tue: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][2][start]', isset($settings[$method_id]['time'][2]['start']) ? $settings[$method_id]['time'][2]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][2][end]', isset($settings[$method_id]['time'][2]['end']) ? $settings[$method_id]['time'][2]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Wed: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][3][start]', isset($settings[$method_id]['time'][3]['start']) ? $settings[$method_id]['time'][3]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][3][end]', isset($settings[$method_id]['time'][3]['end']) ? $settings[$method_id]['time'][3]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Thu: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][4][start]', isset($settings[$method_id]['time'][4]['start']) ? $settings[$method_id]['time'][4]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][4][end]', isset($settings[$method_id]['time'][4]['end']) ? $settings[$method_id]['time'][4]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Fri: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][5][start]', isset($settings[$method_id]['time'][5]['start']) ? $settings[$method_id]['time'][5]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][5][end]', isset($settings[$method_id]['time'][5]['end']) ? $settings[$method_id]['time'][5]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Sat: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][6][start]', isset($settings[$method_id]['time'][6]['start']) ? $settings[$method_id]['time'][6]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][6][end]', isset($settings[$method_id]['time'][6]['end']) ? $settings[$method_id]['time'][6]['end'] : '') ?>
                                    </p>
                                    <p>
                                        <label for="site-status-live" style="display: inline-block; width: 30px;">Sun: </label>
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][7][start]', isset($settings[$method_id]['time'][7]['start']) ? $settings[$method_id]['time'][7]['start'] : '') ?>
                                        -
                                        <?php echo $class::get_time_select('settings['.$method_id.'][time][7][end]', isset($settings[$method_id]['time'][7]['end']) ? $settings[$method_id]['time'][7]['end'] : '') ?>
                                    </p>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    </fieldset>

    <input type="submit" id="submit" class="button button-primary" value="Save Changes">
    <input type="hidden" name="cova_shipping_settings_save" value="1">
</form>

<style type="text/css">
    .has-data {
        background: #efefef;
        border-bottom: 1px solid #fff;
        position: relative;
    }
    .has-data:after {
        content: "\f107";
        font-family: FontAwesome;
        color: #000;
        position: absolute;
        top: 12px;
        right: 10px;
    }
    .has-data span {
        cursor: pointer;
        font-size: 1.3em;
        font-weight: bold;
        width: 100%;
        display: block;
        padding: 10px;
        padding-bottom: 8px;
    }
    .has-data .data {
        padding: 0 10px;
        background: #fff;
        border: 1px solid #efefef;
    }
</style>
<script>
    jQuery(document).ready(function(){
        jQuery(".has-data span").click(function(){
            jQuery(this).parent(".has-data").toggleClass("open");
        });
    });
</script>
