<?php

namespace Dabber\Modules\CustomCoupons;

class CouponTypes
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new CouponTypes();
        }

        return self::$instance;
    }

    public static function get_discount_types()
    {
        return apply_filters(
            'dabber_custom_discount_types', [
            'cova_price_percentage'  => [
                'label' => __('Cova Price Level Percentage Discount', 'dabber'),
                'type'  => 'Percentage'
            ],
            'cova_price_fixed' => [
                'label' => __('Cova Price Level Fixed Amount Discount', 'dabber'),
                'type' => 'Amount'
            ]
            ]
        );
    }

    public function add_custom_coupon_discount_types($discount_types)
    {
        $custom_discounts = [];

        foreach (self::get_discount_types() as $key => $val) {
            $custom_discounts[$key] = $val['label'];
        }

        return array_merge($discount_types, $custom_discounts);
    }
}
