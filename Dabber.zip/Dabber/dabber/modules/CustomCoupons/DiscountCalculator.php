<?php

namespace Dabber\Modules\CustomCoupons;

class DiscountCalculator
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new DiscountCalculator();
        }

        return self::$instance;
    }

    public static function get_discounted_amount($price, $quantity, $discounts, $subtotal)
    {
        if (empty($discounts)) {
            return $price;
        }

        $percentage_discounts_sum = 0;
        $fixed_amount_discounts_sum = 0;
        $price = (float) $price;

        foreach ($discounts as $discount) {
            if ($discount['valueType'] === 'cova_price_percentage') {
                $discount_amount = self::calculate_percentage_discount($price, $quantity, $discount['value']);
                $percentage_discounts_sum += $discount_amount;
            }
            if ($discount['valueType'] === 'cova_price_fixed') {
                $discount_amount = self::calculate_fixed_amount_discount($price, $discount['value'], $subtotal);
                $fixed_amount_discounts_sum += $discount_amount;
            }
        }

        if ($percentage_discounts_sum < 0 && $fixed_amount_discounts_sum < 0) {
            return $price;
        }

        $price -= $percentage_discounts_sum;
        $price -= $fixed_amount_discounts_sum;

        return round($price, 2, PHP_ROUND_HALF_UP);
    }

    private static function calculate_percentage_discount($price, $quantity, $discount_amount)
    {
        $discount = $price * $quantity * ($discount_amount / 100);
        $discount = round($discount, 2, PHP_ROUND_HALF_UP);
        $discount = $price * $quantity - $discount;
        $discount = $discount / $quantity;
        $discount = round($discount, 2, PHP_ROUND_HALF_UP);
        $discount = $price - $discount;

        return round($discount, 2, PHP_ROUND_HALF_UP);
    }

    private static function calculate_fixed_amount_discount($price, $discount_amount, $subtotal)
    {
        $subtotal_percent = ((float) $price / $subtotal);
        $subtotal_percent = round($subtotal_percent, 4, PHP_ROUND_HALF_UP);

        return $discount_amount * $subtotal_percent;
    }
}
