<?php

namespace Dabber\Modules\CustomCoupons;

class CouponFrontend
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new CouponFrontend();
        }

        return self::$instance;
    }

    public function modify_checkout_discount_amount_html($coupon_html, $coupon, $discount_amount_html)
    {
        if (!array_key_exists($coupon->get_discount_type(), CouponTypes::get_discount_types())) {
            return $coupon_html;
        }

        return '<a href="'. wc_get_checkout_url() .'/?remove_coupon='. $coupon->get_code() .'" class="woocommerce-remove-coupon" data-coupon="'. $coupon->get_code() .'">[Remove]</a>';
    }
}
