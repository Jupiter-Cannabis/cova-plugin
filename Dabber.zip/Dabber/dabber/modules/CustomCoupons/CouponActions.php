<?php

namespace Dabber\Modules\CustomCoupons;

class CouponActions
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new CouponActions();
        }

        return self::$instance;
    }

    public function attach_cova_discount($order_data, $order)
    {
        $coupons = $order->get_coupon_codes();

        if (empty($coupons)) {
            return $order_data;
        }

        $custom_discounts = CouponTypes::get_discount_types();

        foreach ($coupons as $coupon_code) {
            $coupon = new \WC_Coupon($coupon_code);
            $type   = $coupon->get_discount_type();

            if (!array_key_exists($type, $custom_discounts)) {
                continue;
            }

            $order_data['Discount']['invoiceLevel'][] = [
                'name' => $coupon_code,
                'value' => $coupon->get_amount(),
                'valueType' => $custom_discounts[$type]['type']
            ];
        }

        return $order_data;
    }

    public function update_cart_item_prices_after_coupon_applied($cart_object)
    {
        if (is_admin() && ! defined('DOING_AJAX') ) {
            return;
        }

        $discounts = self::get_cart_applied_coupons();
        $subtotal = 0;

        foreach ($cart_object->get_cart() as $value) {
            $product_price = $value['data']->get_price() * $value['quantity'];
            $subtotal += $product_price;
        }

        foreach ( $cart_object->get_cart() as $value ) {
            $new_price = (string) DiscountCalculator::get_discounted_amount($value['data']->get_price(), $value['quantity'], $discounts, $subtotal);
            $price = $value['data']->get_price();

            if ($new_price != $price) {
                $value['data']->set_price($new_price);
            }
        }
    }

    public static function get_cart_applied_coupons()
    {
        $coupons = WC()->cart->get_applied_coupons();

        if (empty($coupons)) {
            return [];
        }

        return self::get_coupon_codes_data($coupons);
    }

    private static function get_coupon_codes_data($coupon_codes): array
    {
        $applied_coupons = [];

        foreach ($coupon_codes as $coupon_code) {
            $coupon = new \WC_Coupon($coupon_code);
            $applied_coupons[] = [
                'name' => $coupon_code,
                'value' => $coupon->get_amount(),
                'valueType' => $coupon->get_discount_type()
            ];
        }

        return $applied_coupons;
    }

    public static function get_order_coupons($order): array
    {
        $coupons = $order->get_coupon_codes();

        if (empty($coupons)) {
            return [];
        }

        return self::get_coupon_codes_data($coupons);
    }
}
