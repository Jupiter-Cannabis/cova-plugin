<?php

namespace Dabber\Modules\CustomCoupons;

class CustomCoupons
{
    public static $must_use = true;
    public static $module_info = [
        'name' => 'WC - Cova Discount'
    ];

    public function run()
    {
        add_filter('woocommerce_coupon_discount_types', [CouponTypes::getInstance(), 'add_custom_coupon_discount_types']);

        add_filter('dabber_cova_order_data', [CouponActions::getInstance(), 'attach_cova_discount'], 10, 2);
        add_action('woocommerce_before_calculate_totals', [CouponActions::getInstance(), 'update_cart_item_prices_after_coupon_applied'], 100);
        add_filter('woocommerce_cart_totals_coupon_html', [CouponFrontend::getInstance(), 'modify_checkout_discount_amount_html'], 10, 3);
        add_filter('wc_sc_percent_discount_types', [$this, 'add_cova_custom_percentage_discount_types'], 10, 2);
        add_filter('wc_sc_coupon_type', [$this, 'update_cova_customer_discount_type_label_display'], 11, 1);
    }

    /**
     * include the 'cova_price_percentage in the percentage types so smart coupon plugin
     */
    public function add_cova_custom_percentage_discount_types($discount_type, $object)
    {
        $current_type = $object['coupon_object']->get_discount_type();
    
        if (str_contains($current_type, 'percentage')) {
            $discount_type[] = $current_type;
        }

        return $discount_type;
    }

    /**
     * Change the Cova custom coupon label to DISCOUNT
     */
    public function update_cova_customer_discount_type_label_display($default_coupon_type)
    {
        if (str_contains($default_coupon_type, 'cova')) {
            return $default_coupon_type;
        }
        return 'DISCOUNT';
    }
}
