<?php

namespace Dabber\Modules\CustomerSync;

class AdminUserListing
{

    public function __construct()
    {
        add_action('manage_users_columns', [$this, 'register_custom_user_column']);
        add_action('manage_users_custom_column', [$this, 'register_custom_user_column_view'], 10, 3);
    }

    function register_custom_user_column($columns)
    {
        $columns['cova_id'] = 'Cova ID';
        $columns['loyalty_points'] = 'Loyalty Points Balance';
        $columns['lifetime_points'] = 'Lifetime Points Balance';
        return $columns;
    }

    function register_custom_user_column_view($value, $column_name, $user_id)
    {
        $cova_id = get_user_meta($user_id, 'dabber_customer_id', true);
        $dabber_customer_points_balance = get_user_meta($user_id, 'dabber_customer_points_balance', true);
        $dabber_customer_lifetime_points = get_user_meta($user_id, 'dabber_customer_lifetime_points', true);
        if($column_name == 'cova_id') { return $cova_id;
        }
        if($column_name == 'loyalty_points') { return $dabber_customer_points_balance;
        }
        if($column_name == 'lifetime_points') { return $dabber_customer_lifetime_points;
        }
        return $value;

    }

}
