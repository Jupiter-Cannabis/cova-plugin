<?php

namespace Dabber\Modules\CustomerSync;

use CovaAPI\Customer as Customer;

class CovaCustomerHandler
{
    public static $customerTypeId = 2;
    public static $referralSource = 'WooCommerce';
    public static $emailContactMethodCategoryId = 2;
    public static $emailContactMethodTypeId = 9;
    public static $phoneContactMethodCategoryId = 1;
    public static $phoneContactMethodTypeId = 1;
    public static $billingAddressTypeId = 2;
    public static $shippingAddressTypeId = 3;

    public static function get_cova_customer_id($email, $order)
    {
        $user_id = $order->get_user_id();

        // If used is signed in, use his account email instead of
        // billing email in order to get POS customer profile
        if ($user_id) {
            $wc_customer = new \WC_Customer($user_id);
            $email = $wc_customer->get_email();
        }

        $customer = self::get_customer($email);

        // Create Cova customer
        if (empty($customer)) {
            return self::create_customer_from_wc_order($order);
        }

        // Update Cova customer shipping address
        self::update_cova_customer_shipping_address($order, $customer);

        return $customer['Id'];
    }

    public static function create_customer_from_wc_order($order)
    {
        $customer_data = self::format_cova_user_order_info($order);
        $customer      = self::create_cova_customer($customer_data);

        if (!$customer) {
            return false;
        }

        $customer_id = $order->get_user_id();

        if ($customer_id) {
            update_user_meta($customer_id, 'cova_customer_id', $customer['Id']);
        }

        return $customer['Id'];
    }

    public static function create_cova_customer($customerData)
    {
        $client   = new Customer();
        $customer = json_decode($client->create($customerData), true);

        if (!isset($customer)) {
            return false;
        }

        return $customer;
    }

    public static function update_cova_customer_shipping_address($order, $customer)
    {
        // Exit if no required shipping info
        if (
            empty($order->get_shipping_country()) ||
            empty($order->get_shipping_state()) ||
            empty($order->get_shipping_postcode()) ||
            empty($order->get_shipping_address_1())
        ) {
            return null;
        }

        // Get customer's shipping address if there's one
        $shippingAddress = [];
        if (isset($customer['Addresses']) && !empty($customer['Addresses'])) {
            foreach ($customer['Addresses'] as $customerAddress) {
                if ($customerAddress['AddressTypeId'] == self::$shippingAddressTypeId) {
                    $shippingAddress = $customerAddress;
                }
            }
        }

        // Create customer address data
        $api = new Customer;
        $data = [
            'CustomerId'     => $customer['Id'],
            'AddressTypeId'  => self::$shippingAddressTypeId,
            'CountryCode'    => $order->get_shipping_country(),
            'StateCode'      => $order->get_shipping_state(),
            'PostalCode'     => $order->get_shipping_postcode(),
            'StreetAddress1' => $order->get_shipping_address_1(),
            'StreetAddress2' => $order->get_shipping_address_2(),
            'Locality'       => $order->get_shipping_city(),
            'Email'          => $order->get_billing_email(),
            'Phone'          => $order->get_billing_phone(),
        ];

        // Create new address
        if (empty($shippingAddress)) {
            return json_decode($api->createAddress($data, $customer['Id']), true);
        }

        // Update address and its data
        $data['Id'] = $shippingAddress['Id'];

        return json_decode($api->updateAddress($data, $customer['Id'], $shippingAddress['Id']), true);
    }

    private static function format_cova_user_order_info($order)
    {
        $user_id = $order->get_user_id();
        $object  = $order;
        $user_identifier = uniqid();

        if ($user_id) { // if customer exists in WP users
            $object = new \WC_Customer($user_id);
            $user_identifier = $user_id;
        }

        $customerData = [
            'Addresses'        => array(),
            'ContactMethods'   => array(),
            'CustomerTypeId'   => self::$customerTypeId,
            'PrimaryName'      => $object->get_billing_first_name(),
            'FamilyName'       => $object->get_billing_last_name(),
            'ReferralSource'   => self::$referralSource,
            'AlternateName'    => $object->get_billing_first_name() . ' ' . $object->get_billing_last_name(),
            'UniqueIdentifier' => $user_identifier
        ];

        $billingAddress = new \stdClass;
        $billingAddress->AddressTypeId  = self::$billingAddressTypeId;
        $billingAddress->CountryCode    = $object->get_billing_country();
        $billingAddress->StateCode      = $object->get_billing_state();
        $billingAddress->Email          = $object->get_billing_email();
        $billingAddress->Phone          = $object->get_billing_phone();
        $billingAddress->PostalCode     = $object->get_billing_postcode();
        $billingAddress->StreetAddress1 = $object->get_billing_address_1();
        $billingAddress->StreetAddress2 = $object->get_billing_address_2();

        $shippingAddress = new \stdClass;
        $shippingAddress->AddressTypeId  = self::$shippingAddressTypeId;
        $shippingAddress->CountryCode    = (!empty($object->get_shipping_country()))? $object->get_shipping_country() : $object->get_billing_country();
        $shippingAddress->StateCode      = (!empty($object->get_shipping_state()))? $object->get_shipping_state() : $object->get_billing_state();
        $shippingAddress->Email          = $object->get_billing_email();
        $shippingAddress->Phone          = $object->get_billing_phone();
        $shippingAddress->PostalCode     = (!empty($object->get_shipping_postcode()))? $object->get_shipping_postcode() : $object->get_billing_postcode();
        $shippingAddress->StreetAddress1 = $object->get_shipping_address_1();
        $shippingAddress->StreetAddress2 = $object->get_shipping_address_2();

        $contactMethodEmail = new \stdClass;
        $contactMethodEmail->ContactMethodCategoryId = self::$emailContactMethodCategoryId;
        $contactMethodEmail->ContactMethodTypeId     = self::$emailContactMethodTypeId;
        $contactMethodEmail->Value                   = $object->get_billing_email();
        $contactMethodEmail->DoNotContact            = false;
        $contactMethodEmail->Default                 = true;

        $contactMethodPhone = new \stdClass;
        $contactMethodPhone->ContactMethodCategoryId = self::$phoneContactMethodCategoryId;
        $contactMethodPhone->ContactMethodTypeId     = self::$phoneContactMethodTypeId;
        $contactMethodPhone->Value                   = $object->get_billing_phone();
        $contactMethodPhone->DoNotContact            = false;
        $contactMethodPhone->Default                 = true;

        array_push($customerData['Addresses'], $billingAddress);
        array_push($customerData['Addresses'], $shippingAddress);
        array_push($customerData['ContactMethods'], $contactMethodEmail);
        array_push($customerData['ContactMethods'], $contactMethodPhone);

        return $customerData;
    }

    /**
     * This customer search function will only return single
     * cova customer based on the recently last modified date.
     *
     * @param  $criteria
     * @return array|mixed
     */
    public static function get_customer($criteria)
    {
        $api = new Customer;

        $customers = json_decode(
            $api->search(['$filter' => 'Criteria eq \'' . $criteria . '\'']), true
        );

        if (empty($customers)) {
            return [];
        }

        if (count($customers) < 2) {
            return $customers[0]; // only return single result
        }

        // Sort by Last Modified
        uasort(
            $customers, function ($a, $b) {
                return strtotime($b['LastModifiedDateUtc']) <=> strtotime($a['LastModifiedDateUtc']);
            }
        );

        $customers = array_values($customers);

        return $customers[0]; // only return single result
    }
}
