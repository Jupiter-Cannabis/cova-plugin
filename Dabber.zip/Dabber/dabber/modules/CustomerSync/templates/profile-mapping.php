<div style="background:#fff;padding: 10px 20px 20px;">
    <h3>User Cova Information</h3>
    <?php if(isset($args['info'][0])) : ?>
    <table>
        <?php foreach ($args['info'][0] as $key => $value): ?>
            <tr>
                <td valign="top"><?php echo $key; ?>:</td>
                <td>
                    <?php
                    if(is_array($value) ) {
                        echo "<table>";
                        if(isset($value[0])) :
                            foreach($value[0] as $k => $v):

                                echo "<tr><td>".$k.": </td><td>".$v."</td></tr>";

                            endforeach;
                        endif;
                        echo "</table>";

                    } else {
                        echo $value;
                    }
                    ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php else: ?>
    <p>No data...</p>
    <?php endif; ?>
</div>
