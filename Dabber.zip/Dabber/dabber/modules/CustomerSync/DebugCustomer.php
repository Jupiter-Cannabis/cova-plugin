<?php

namespace Dabber\Modules\CustomerSync;

use CovaAPI\Customer as Customer;
use CovaAPI\LoyaltyPoints;

class DebugCustomer
{
    public function __construct()
    {
        if (isset($_GET['test_php'])) {
            $test = [];

            $test[] = [
                'test' => 'asd'
            ];

            echo "<pre>";
            print_r(current($test));
            echo "</pre>";
        }

        if (isset($_GET['get_user_data'])) {
            $user = new \WC_Customer($_GET['get_user_data']);
            echo "<pre>";
            print_r($user);
            is_null($user);
            echo "</pre>";
        }

        if (isset($_GET['find_user'])) {
            $sync = new CustomerSync();
            $user = $sync->get_customer_cova_data($_GET['find_user']);
            echo "<pre>";
            echo count($user);
            echo "</pre>";
        }

        if (isset($_GET['create_user'])) {
            $sync = new CreateCustomerFull();

            echo "<pre>";
            print_r($sync->create($_GET['create_user']));
            echo "</pre>";
        }

        if (isset($_GET['show_woo_user_meta'])) {
            $id = get_user_meta($_GET['show_woo_user_meta'], 'dabber_customer_id');
            $info = get_user_meta($_GET['show_woo_user_meta'], 'dabber_customer_info');
            echo "<pre>";
            var_dump($info);
            echo "</pre>";
        }

        if (isset($_GET['reset_user_cova_id'])) {

            update_user_meta(234, 'dabber_customer_id', '');
            update_user_meta(232, 'dabber_customer_id', '');
            update_user_meta(240, 'dabber_customer_id', '');
            update_user_meta(241, 'dabber_customer_id', '');

        }

        if (isset($_GET['search_customer_by_email'])) {

            $api = new Customer;

            $customers = json_decode(
                $api->search(['$filter' => 'Criteria eq \'' . $_GET['search_customer_by_email'] . '\'']), true
            );

            d($customers);
            die();

        }

        if (isset($_GET['create_customer_address'])) {

            $customerId = 'e7d6310f-e1b9-4b63-a117-404592138e21';
            $data       = [
                'CustomerId'     => 'e7d6310f-e1b9-4b63-a117-404592138e21',
                'AddressTypeId'  => 3,
                'CountryCode'    => 'CA',
                'StateCode'      => 'ON',
                'PostalCode'     => 'L2G 5V1',
                'StreetAddress1' => '6787 Dorchester Rd',
                'StreetAddress2' => '',
            ];

            $api = new Customer;

            $address = json_decode($api->createAddress($data, $customerId), true);

            d($address);
            die();

        }

        if (isset($_GET['update_customer_address'])) {

            $addressId  = 'f8b100aa-42e4-4a6e-abe6-45b9c6e20c76';
            $customerId = 'e7d6310f-e1b9-4b63-a117-404592138e21';
            $data       = [
                'Id'             => 'f8b100aa-42e4-4a6e-abe6-45b9c6e20c76',
                'CustomerId'     => 'e7d6310f-e1b9-4b63-a117-404592138e21',
                'AddressTypeId'  => 3,
                'CountryCode'    => 'CA',
                'StateCode'      => 'ON',
                'PostalCode'     => 'L2G 5V1',
                'StreetAddress1' => '6787 Dorchester Rd',
                'StreetAddress2' => '',
            ];

            $api = new Customer;

            $address = json_decode($api->updateAddress($data, $customerId, $addressId), true);

            d($address);
            die();

        }
    }
}
