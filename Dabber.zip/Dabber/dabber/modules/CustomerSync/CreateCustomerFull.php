<?php

namespace Dabber\Modules\CustomerSync;

class CreateCustomerFull
{

    private int $customer_type_id = 2;

    public function __construct()
    {

    }

    public function create($customerId)
    {

        $customerSync = new CustomerSync();

        $obj = [
            "Addresses" => [],
            "ContactMethods" => self::prepare_contact_methods($customerId)
        ];

        $data = array_merge($obj, self::prepare_basic_information($customerId));

        $api = new \CovaAPI\Customer;

        return json_decode($api->create($data), true);

    }

    public function prepare_basic_information($wooUserId)
    {

        $user = new \WC_Customer($wooUserId);

        $data['CustomerTypeId'] = $this->customer_type_id;
        $data['Title'] = "";
        $data['PrimaryName'] = $user->first_name;
        $data['AlternateName'] = "";
        $data['MiddleName'] = "";
        $data['FamilyName'] = $user->last_name;
        $data['ReferralSource'] = "Website";
        $data['DateOfBirth'] = "";
        $data['PricingGroupId'] = null;
        $data['Notes'] = "This customer was created from woocommerce.";
        $data['UniqueIdentifier'] = "woo_" . $wooUserId;
        $data['Disabled'] = false;
        $data['DoNotContact'] = false;

        return $data;

    }

    public function prepare_addresses()
    {
        $addresses = [];

        $address = [];

        $address['AddressTypeId'] = 2;
        $address['Default'] = true;
        $address['DoNotContact'] = false;
        $address['CountryCode'] = 'CA';
        $address['Locality'] = 'Regina';
        $address['StateCode'] = 'SK';
        $address[]['PostalCode'] = 'S4S 4S4';
        $address['StreetAddress1'] = '14 Fake St.';
        $address['Notes'] = '';

        return $addresses;
    }

    public function prepare_contact_methods($wooUserId)
    {

        $user = new \WC_Customer($wooUserId);

        $contact_methods = [];

        $contact_method = [];

        //Email
        $contact_method['ContactMethodCategoryId'] = 2; // 2 - email
        $contact_method['ContactMethodTypeId'] = 9; // 9 - Home Email
        $contact_method['Value'] = $user->email;
        $contact_method['DoNotContact'] = true;
        $contact_method['Default'] = true;

        //Phone
        if($user->get_billing_phone() ) {
            $contact_method['ContactMethodCategoryId'] = 1; // 2 - email
            $contact_method['ContactMethodTypeId'] = 1; // 1 - Home Phone
            $contact_method['Value'] = $user->get_billing_phone();
            $contact_method['DoNotContact'] = true;
            $contact_method['Default'] = true;
        }

        $contact_methods[] = $contact_method;

        return $contact_methods;
    }

    public function prepare_customer_extensions()
    {

    }


}
