<?php

namespace Dabber\Modules\CustomerSync;

use CovaAPI\Customer;
use Dabber\Modules\CustomerSync\DebugCustomer;
use Dabber\Modules\CustomerSync\AdminUserListing;
use Dabber\Modules\LoyaltyPoints\LoyaltyPoints;
use Dabber\Modules\LoyaltyPoints\Points;

class CustomerSync
{

    public static array $module_info = [
        'name' => 'Customer Sync',
        'description' => 'Sync customer information from cova to woocommerce'
    ];

    public static bool $must_use = true;

    /**
     *
     * @return void
     */
    public function run(): void
    {

        add_action('init', [$this, 'init']);
        add_action('edit_user_profile', [$this, 'show_cova_user_information'], 100);

        /**
         * User register, Profile Update
         */
        add_action('woocommerce_created_customer', [$this, 'update_woo_user_data']);
        add_action('user_register', [$this, 'update_woo_user_data'], 10, 1);
        add_action('profile_update', [$this, 'update_woo_user_data'], 12);

        /**
         * User login
         *
         * @todo content into a separate functions
         */
        add_action(
            'wp_login', function ($user_login, $user) {
                self::update_woo_customer_data($user->ID);
            }, 10, 2 
        );

        /**
         * On checkout
         *
         * @todo content into a separate functions
         */
        add_action(
            'woocommerce_thankyou', function ($order_id) {

                $order = wc_get_order($order_id);

                if($order->get_payment_method() !== 'cod' ) {
                    return;
                }

                self::update_woo_customer_data($order->get_user_id());
            }
        );

        /**
         * On Payment Complete
         *
         * @todo content into a separate functions
         */
        add_action(
            'woocommerce_payment_complete', function ($order_id) {

                $order = wc_get_order($order_id);

                self::update_woo_customer_data($order->get_user_id());
            }
        );

        //Initialize Classes
        $debug = new DebugCustomer();
        $userListing = new AdminUserListing();

    }

    public function init()
    {
        $b2bPro = new B2BPro();
        $b2bPro->init();
        self::update_woo_customers_data();

    }

    public function update_woo_user_data($wooUserId)
    {

        if(!is_user_logged_in() ) { return;
        }

        //Get user cova id
        $userCovaId = get_user_meta($wooUserId, 'dabber_customer_id', true);

        //Woo User already have cova ID defined
        if($userCovaId && $userCovaId !== "" ) {

            //Using user cova id, pull the information from cova
            $customer = self::get_customer_cova_data_by_id($userCovaId);

            self::save_customer_id($wooUserId, $customer);
            self::save_customer_info($wooUserId, $customer);

            //Woo User does not have cova ID
        } else {

            $criteria_phone = self::get_user_meta_value('billing_phone', $wooUserId);
            $criteria_email = get_userdata($wooUserId);
            $customer = self::get_customer_cova_data($criteria_email->user_email);


            //Cannot find by email
            if (count($customer) == 0) {

                //Find by phone
                $customer = self::get_customer_cova_data($criteria_phone);

                //Cannot find by phone
                //User does not exists in cova
                if(count($customer) == 0 ) {

                    //Create user in cova
                    $sync = new CreateCustomerFull();
                    $response = $sync->create($wooUserId);

                    if(isset($response['Id'])) {
                        self::save_customer_id($wooUserId, $response);
                        self::save_customer_info($wooUserId, $response);
                    }

                    //User exists in cova, pull information
                } else {
                    self::save_customer_id($wooUserId, $customer[0]);
                    self::save_customer_info($wooUserId, $customer[0]);

                }
            } else {
                self::save_customer_id($wooUserId, $customer[0]);
                self::save_customer_info($wooUserId, $customer[0]);
            }
        }

    }

    /**
     * @return void
     */
    public function update_woo_customers_data()
    {

        if(!isset($_GET['sync_cova_customers']) ) { return;
        }

        $wooUsers = get_users();

        foreach( $wooUsers as $user ) {
            self::update_woo_user_data($user->ID);
        }

    }

    /**
     * @param  $wooUserId
     * @return mixed
     */
    public function get_user_meta_value($key, $wooUserId)
    {
        return get_user_meta($wooUserId, $key, true);
    }

    /**
     * @param  $criteria
     * @return mixed
     */
    public function get_customer_cova_data_by_id($covaUserId)
    {
        $api = new \CovaAPI\Customer;
        return json_decode($api->byId($covaUserId), true);
    }

    /**
     * @param  $criteria
     * @return mixed
     */
    public function get_customer_cova_data($criteria)
    {
        $api = new \CovaAPI\Customer;
        return json_decode(
            $api->search(
                [
                '$filter' => 'Criteria eq \'' . $criteria . '\''
                ]
            ), true
        );
    }

    /**
     * @param  $wooUserId
     * @return void
     */
    public function update_woo_customer_data($wooUserId)
    {
        self::update_woo_user_data($wooUserId);
    }


    /**
     * @param  $wooUserId
     * @param  $covaUserId
     * @return void
     */
    public function save_customer_id($wooUserId, $covaUserId)
    {

        if(!is_null($covaUserId) ) {
            $covaUserId = $covaUserId['Id'];
        }

        update_user_meta($wooUserId, 'dabber_customer_id', $covaUserId);

    }

    public function delete_customer_cova_id($wooUserId)
    {
        if(get_userdata($wooUserId) ) {
            delete_user_meta($wooUserId, 'dabber_customer_id');
        }
    }

    /**
     * @param  $wooUserId
     * @param  $covaUserInfo
     * @return void
     */
    public function save_customer_info($wooUserId, $covaUserInfo)
    {
        update_user_meta($wooUserId, 'dabber_customer_info', $covaUserInfo);
        $points = new Points();
        $points->sync($wooUserId);

    }

    public function delete_customer_cova_info($wooUserId)
    {
        if(get_userdata($wooUserId) ) {
            delete_user_meta($wooUserId, 'dabber_customer_info');
        }

    }

    /**
     * @param  $user
     * @return void
     */
    public function show_cova_user_information($user)
    {
        $user_info = get_user_meta($user->ID, 'dabber_customer_info');

        load_template(
            plugin_dir_path(__FILE__) .'templates/profile-mapping.php', true, [
            'info' => $user_info
            ]
        );

    }


}
