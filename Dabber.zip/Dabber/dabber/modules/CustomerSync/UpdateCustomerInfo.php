<?php

namespace Dabber\Modules\CustomerSync;

use CovaAPI\Customer;

class UpdateCustomerInfo
{

    public function __construct()
    {

    }

    public function first_name($wooUserId, $data)
    {
        update_user_meta($wooUserId, "first_name", $data);
    }

    public function last_name($wooUserId, $data)
    {
        update_user_meta($wooUserId, "first_name", $data);
    }

}
