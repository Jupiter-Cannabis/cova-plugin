<?php

namespace Dabber\Modules\CustomerSync;

/**
 * @description
 */
class B2BPro
{

    public function init()
    {
        add_action('eib2bpro_account_approved', [$this, 'sync_approved_user'], 30, 1);
    }

    public function sync_approved_user($customerId)
    {
        $customerSync = new CustomerSync();
        $customerSync->update_woo_customer_data($customerId);
    }

}
