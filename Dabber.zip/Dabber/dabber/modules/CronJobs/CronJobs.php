<?php

namespace Dabber\Modules\CronJobs;

class CronJobs
{
//    public static $must_use = true;
//    public static $module_info = [
//        'name' => 'Cron Jobs',
//        'description' => 'Enable/disable registered cron jobs.'
//    ];
    public $options = [];

    public function run()
    {
        add_filter('dabber_admin_module_sub_nav_items_advanced', [$this, 'add_sub_tab'], 20);
        add_action('dabber_render_module_admin_section_advanced_manage_cron_jobs', [$this, 'render_cron_job_tab']);
        add_action('dabber_admin_module_save_settings_advanced_manage_cron_jobs', [$this, 'save_settings']);
    }

    public function add_sub_tab($tabs)
    {
        $tabs['manage_cron_jobs'] = __('Cron Jobs');

        return $tabs;
    }

    public function save_settings($post_data)
    {
        if (isset($post_data['dabber_enabled_crons'])) {
            update_option('dabber_enabled_crons', array_map('sanitize_text_field', $post_data['dabber_enabled_crons']));
        } else {
            update_option('dabber_enabled_crons', []);
        }
    }

    public function render_cron_job_tab()
    {
        $cron_jobs = [
            'cova_update_pricing'   => __('Pricing Sync', 'dabber'),
            'cova_update_inventory' => __('Inventory Sync', 'dabber'),
            'cova_update_products'  => __('Products Sync', 'dabber'),
            'cova_import_products'  => __('Product Import', 'dabber'),
            'cova_global_data'        => __('Bulk cova data', 'dabber')
        ];

        $enabled_jobs = (array) get_option('dabber_enabled_crons');

        load_template(
            plugin_dir_path(__FILE__). 'templates/settings.php', true, [
            'cron_jobs' => $cron_jobs,
            'enabled_jobs' => $enabled_jobs
            ]
        );
    }
}
