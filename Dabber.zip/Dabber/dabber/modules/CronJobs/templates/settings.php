
<h3>Enable/Disable Jobs</h3>
<table class="form-table">
    <tbody>
    <?php foreach($args['cron_jobs'] as $key => $name) : ?>
        <tr>
            <th scope="row"><?php echo $name ?></th>
            <td>
                <fieldset>
                    <label for="dabber_enable_<?php echo $key ?>">
                        <input name="dabber_enabled_crons[<?php echo $key ?>]" <?php echo ((array_key_exists($key, $args['enabled_jobs']))? 'checked="checked"' : '') ?> type="checkbox" id="dabber_enable_<?php echo $key ?>" value="1">
                    </label>
                </fieldset>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<input type="submit" id="submit" name="dabber-cron-jobs-settings" class="button button-primary" value="Save Changes">
