<?php

namespace Dabber\Modules\Cart;

use Dabber\Modules\Cart\DabberWidgets as DabberWidgets;
use Cova_Integration\Sync\Purchase_Limits as PurchaseLimits;
use Cova_Integration\Sync\Traits\Purchase_Limits_Traits as PurchaseLimitsTraits;

class Cart
{
    use PurchaseLimitsTraits;

    public $version = '1.0';
    public static $enable_default = true;
    public static $module_info = [
        'name' => 'Cart',
        'description' => 'Adds cart with grams indicator UI element'
    ];
    public $options = [];

    public function run()
    {
        // ToDo: Get options from wp options
        $this->options = [
            'main-color'    => '#afcc7a',
            'border-color'  => '#dadada',
            'border-radius' => '0', // 25px
        ];

        add_action('wp_head', [$this, 'loadCss']);

        //        $this->loadJavascript();

        add_action('wp_enqueue_scripts', [$this, 'loadJavascript']);
        add_shortcode('dabber_gram_cart', [$this, 'loadTemplate']);

        add_filter('woocommerce_add_to_cart_fragments', [$this, 'getFragments']);

        add_action('init', [$this, 'init']);
    }

    public function init()
    {
        global $dabber_widgets;
        $dabber_widgets = new DabberWidgets();
    }

    public function loadCss()
    {
        wp_register_style('dabber-cart-vars', false);
        wp_enqueue_style('dabber-cart-vars');
        wp_add_inline_style('dabber-cart-vars', self::generateCssVars($this->options));
        wp_enqueue_style('dabber-cart', plugin_dir_url(__FILE__) . 'assets/css/cart.css', [], $this->version, 'all');
    }

    public function loadJavascript()
    {
        wp_enqueue_script('dabber-cart', plugin_dir_url(__FILE__) . 'assets/js/cart.js', ['jquery'], $this->version, true);
    }

    public function loadTemplate()
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/cart.php', false, $this->options);
    }

    public function getFragments($fragments)
    {
        $options = get_option('dabber_cart_limits');

        if (!isset($options['integration_type']) || $options['integration_type'] == 'API') {
            return $this->getFragmentsByAPI($fragments);
        }

        return $this->getFragmentsByManual($fragments);
    }

    public function getFragmentsByAPI($fragments)
    {
        $_cart_total = WC()->cart->get_cart_subtotal();
        $_cart_qty   = WC()->cart->cart_contents_count;
        $_cart_qty   = (int)($_cart_qty > 0 ? $_cart_qty : '0');

        $fragments['.cart-count'] = '<span class="cart-count">' . $_cart_qty . '</span>';
        $fragments['.cart-price'] = '<span class="cart-price">' . $_cart_total . '</span>';

        $purchase_limits_response = $this->getPurchaseLimits();

        $fragments['.cart-gaugages'] = $this->formatPurchaseLimitsResponse($purchase_limits_response);
        $fragments['.cart-errors']   = $this->formatPurchaseLimitsErrors();

        return $fragments;
    }

    public function getFragmentsByManual($fragments)
    {
        $cart_limits        = dabber_get_cart_limits();
        $_cart_total        = WC()->cart->get_cart_subtotal();
        $_cart_qty          = WC()->cart->cart_contents_count;
        $_cart_qty          = (int)($_cart_qty > 0 ? $_cart_qty : '0');
        $_weight_limit      = $cart_limits['maximum_limit'];
        $_weight_unit       = get_option('woocommerce_weight_unit');
        $_cart_weight       = WC()->cart->cart_contents_weight . $_weight_unit;
        $_cart_weight_limit = $_weight_limit . $_weight_unit;

        $fragments['.cart-count'] = '<span class="cart-count">' . $_cart_qty . '</span>';
        $fragments['.cart-price'] = '<span class="cart-price">' . $_cart_total . '</span>';

        $purchase_limits_response = [
            'gauges' => [[
                'fullTitle'  => '',
                'limit'      => $_weight_limit,
                'amountUsed' => WC()->cart->cart_contents_weight,
                'unit'       => $_weight_unit,
            ]]
        ];

        $fragments['.cart-gaugages'] = $this->formatPurchaseLimitsResponse($purchase_limits_response);
        $fragments['.cart-errors']   = $this->formatPurchaseLimitsErrors();

        return $fragments;
    }

    private static function generateCssVars($options)
    {
        $css = '.gram-cart-widget-wrapper {';

        foreach ($options as $key => $value) {
            $css .= '--dabber-' . $key . ': ' . $value . ';';
        }

        $css .= '}';

        return $css;
    }

    public function getPurchaseLimits()
    {
        global $dabber_current_location_data;

        $location_id = $dabber_current_location_data['cova_location_id'];

        $purchase_limits = new PurchaseLimits();
        $purchase_limits->run();

        return $purchase_limits->getTransactionLimits($location_id);
    }

    public function formatPurchaseLimitsResponse($response)
    {
        if (isset($response['errors']) && !empty($response['errors'])) {
            return 'There is a problem!';
        }

        if (isset($response['gauges']) && empty($response['gauges'])) {
            return 'No gauges!';
        }

        $html = '<div class="cart-gaugages">';

        foreach ($response['gauges'] as $gauges) {
            $percentage = 0;
            if ($gauges['limit'] > 0) {
                $percentage = ($gauges['amountUsed'] / $gauges['limit']) * 100;
            }
            $amountUsed = number_format($gauges['amountUsed'], 2, '.', '');
            $limit      = number_format($gauges['limit'], 2, '.', '');

            $html .= sprintf('<div class="bar-wrapper"><div class="bar" style=" width: %s%s; background-color: red;"></div></div>', $percentage, '%');
            $html .= sprintf('<span>%s%s / %s%s</span>', (empty($gauges['fullTitle']) ? '' : $gauges['fullTitle'] . ' '), $amountUsed, $limit, $gauges['unit']);
        }

        $html .= '</div>';

        return $html;
    }

    public function formatPurchaseLimitsErrors()
    {
        if (wc_has_notice($this->getOverLimitsMessage(), 'error')) {
            WC()->session->set('wc_notices', null);

            return '<div class="gram-cart-widget-grams-side cart-errors"><span>' . __($this->getOverLimitsMessage(), "woocommerce") . '</span></div>';
        } else {
            WC()->session->set('wc_notices', null);
            return '<div class="gram-cart-widget-grams-side cart-errors"></div>';
        }
    }
}
