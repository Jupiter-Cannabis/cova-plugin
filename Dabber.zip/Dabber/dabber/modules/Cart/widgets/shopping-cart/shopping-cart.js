var DabberShoppingCart = {

    init: function () {
        DabberShoppingCart.cartCanvasToggle();
    },
    cartCanvasToggle: function () {
        jQuery('body').on(
            'click', '.canvas-close', function ( e ) {
                e.preventDefault();
                jQuery('body').removeClass('canvas-active');
            } 
        )
        jQuery('.canvas-close').each(
            function () {
                $(this).on(
                    'click', function () {
                        e.preventDefault();
                        jQuery('body').removeClass('canvas-active');
                    }
                );
            }
        );
        jQuery('body').on(
            'click', '.canvas-overlay', function ( e ) {
                jQuery('body').removeClass('canvas-active');
            } 
        )
        if (jQuery('.cart-popup.cart-canvas').length && jQuery('.cart-popup').hasClass('cart-link-click') ) {
            jQuery('body').on(
                'click', '.cart-dropdown .dropdown-toggle', function ( e ) {
                    e.preventDefault();
                    jQuery('body').addClass('canvas-active');
                } 
            )
        }
    }


};

jQuery(document).ready(
    function ( $ ) {
        'use strict';
        DabberShoppingCart.init();
    }
);