jQuery(
    function () {
        jQuery('body').on(
            'click', '.gram-cart-widget', function (e) {
                e.preventDefault();
                jQuery('body').addClass('canvas-active');
            }
        );

        jQuery('body').on(
            'added_to_cart', function (e) {
                // if (!jQuery('body').hasClass('single-product')) {
                //     jQuery('.dropdown-toggle').click();
                // }
                e.preventDefault();
                jQuery('body').addClass('canvas-active');
            }
        );
    }
);
