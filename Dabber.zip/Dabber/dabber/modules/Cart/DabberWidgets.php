<?php

namespace Dabber\Modules\Cart;

class DabberWidgets
{

    public function __construct()
    {
        if (! function_exists('molla_option') ) :
            wp_register_style('dabber-cart-widget-shopping-cart', plugin_dir_url(__FILE__) . 'widgets/shopping-cart/shopping-cart.css');
            wp_enqueue_style('dabber-cart-widget-shopping-cart');
            wp_register_script('dabber-cart-widget-shopping-cart-js', plugin_dir_url(__FILE__) . 'widgets/shopping-cart/shopping-cart.js', ['jquery'], null, true);
            wp_enqueue_script('dabber-cart-widget-shopping-cart-js');
        endif;

    }

}
