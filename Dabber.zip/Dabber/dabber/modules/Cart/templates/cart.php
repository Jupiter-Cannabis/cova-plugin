<div class="gram-cart-widget-wrapper">
    <div class="gram-cart-widget">
        <div class="gram-cart-widget-cart">
            <span class="cart-limits"><i class="icon-limits"></i> Purchase Limit</span>
            <span class="cart-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>0.00</bdi></span></span>
            <span class="cart-icon"><i class="icon-cart"></i></span>
        </div>
    </div>
</div>

<?php
$cart_canvas  = true;
$cart_classes = 'cart-popup widget_shopping_cart';
$cart_action  = null;

if (function_exists('molla_option')) {
    $cart_canvas  = molla_option('cart_canvas_type');
    $cart_action  = molla_option('cart_canvas_open');
}

if ($cart_canvas) {
    $cart_classes .= ' cart-canvas canvas-container';
    $cart_classes .= $cart_action ? ' after-added-product' : ' cart-link-click';
} else {
    $cart_classes .= ' dropdown-menu with-arrows';
}
?>
<div class="<?php echo esc_attr($cart_classes); ?>">
<?php if ($cart_canvas) : ?>
    <div class="cart-canvas-header">
        <h4><?php esc_html_e('Cart', 'dabber'); ?></h4>
        <a href="#" class="canvas-close"><?php esc_html_e('Close', 'dabber'); ?><i class="icon-close"></i></a>
    </div>
<?php endif; ?>
    <div class="gram-cart-widget-grams-side">
        <div class="cart-gaugages"> </div>
    </div>
    <div class="gram-cart-widget-grams-side cart-errors"></div>
    <div class="widget_shopping_cart_content">
    <?php if (class_exists('WooCommerce')) : ?>
        <div class="cart-loading"></div>
    <?php else : ?>
        <ul class="cart_list"><li class="empty"><?php esc_html_e('Woocommerce is not installed.', 'dabber'); ?></li></ul>
    <?php endif; ?>
    </div>
</div>
<?php
if ($cart_canvas) {
    echo '<div class="sidebar-overlay canvas-overlay"></div>';
}
?>
