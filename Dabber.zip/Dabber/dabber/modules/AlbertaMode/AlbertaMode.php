<?php

namespace Dabber\Modules\AlbertaMode;

class AlbertaMode
{
    public $options = [];

    public static $enable_default = false;
    public static $module_info = [
        'name' => 'Alberta Mode',
        'description' => ''
    ];

    public function run()
    {
        add_action('init', [$this, 'load_options']);
        add_action('dabber_admin_module_save_settings_general_settings', [$this, 'save_settings']);
        add_action('dabber_render_module_admin_section_general_settings', [$this, 'render_settings'], 12);

        add_action(
            'init', function () {
                if (is_user_logged_in()) {
                    return;
                }

                add_action('wp_enqueue_scripts', [$this, 'cova_wp_enqueue_scripts']);

                remove_action('woocommerce_before_shop_loop_item_title', 'molla_woocommerce_loop_product_image_hover', 12);
                add_action('woocommerce_before_shop_loop_item_title', [$this, 'molla_woocommerce_loop_product_image_hover'], 12);

                remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
                add_action('woocommerce_before_shop_loop_item_title', [$this, 'woocommerce_template_loop_product_thumbnail'], 10);

                add_filter('wc_get_template', [$this, 'get_product_gallery_template'], 10, 5);

                add_filter('woocommerce_package_rates', [$this, 'woocommerce_package_rates'], 100, 2);
                add_filter('woocommerce_available_payment_gateways', [$this, 'woocommerce_available_payment_gateways'], 100, 1);

                add_filter('woocommerce_cart_needs_shipping_address', '__return_false');

                add_action('wp_login', [$this, 'wp_login_check_approval'], 10, 2);

                //add_action('woocommerce_register_form', [$this, 'alberta_register_checkbox'] , 999);
            }
        );
    }

    public function render_settings()
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/admin-settings.php', true, $this->options);
    }

    public function load_options()
    {
        $this->options = [
            'image' => get_option('cova_alberta_mode_image')
        ];
    }

    public function save_settings($post_data)
    {
        update_option('cova_alberta_mode_image', sanitize_text_field($post_data['cova_alberta_mode_image']));
    }

    /**
     * NOTE: This method doesn't work here.
     *       In order to remove hover image, it is placed in Jango Fett theme
     */
    public function molla_woocommerce_loop_product_image_hover()
    {
        // if ( ! function_exists( 'molla_woocommerce_loop_product_image_hover' ) ) {
        // function molla_woocommerce_loop_product_image_hover() {
        echo '';
        // }
        // }
    }

    public function woocommerce_template_loop_product_thumbnail()
    {
        echo $this->woocommerce_get_product_thumbnail();
    }

    public function woocommerce_get_product_thumbnail( $size = 'shop_catalog' )
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/product-image.php', false, $this->options);
    }

    public function get_product_gallery_template( $located, $template_name, $args, $template_path, $default_path )
    {
        if ('single-product/product-image.php' == $template_name) {
            return plugin_dir_path(__FILE__) . 'templates/product-image.php';
        }

        return $located;
    }

    public function woocommerce_package_rates($rates, $package)
    {
        foreach($rates as $key => $method) {
            if (preg_match("/flat_rate/i", $key)) {
                unset($rates[$key]);
            }
        }

        return $rates;
    }

    public function woocommerce_available_payment_gateways($gateways)
    {
        foreach ($gateways as $gateway_id => $gateway) {
            if ($gateway_id != 'cod') {
                unset($gateways[$gateway_id]);
            }
        }

        return $gateways;
    }

    public function cova_wp_enqueue_scripts()
    {
        wp_register_style('cova-alberta-mode-style', plugin_dir_url(__FILE__) . 'assets/css/alberta-mode.css');
        wp_enqueue_style('cova-alberta-mode-style');
    }

    public function wp_login_check_approval($user_login, $user)
    {

        $user_approval = get_user_meta($user->ID, 'eib2bpro_user_approved', true);

        if ('no' === $user_approval) {
            wp_logout();
            do_action('woocommerce_set_cart_cookies',  true);
            wc_add_notice(esc_html__('Your account requires approval. We will review it as soon as possible.', 'eib2bpro'), 'success');
        }

    }

    public function alberta_register_checkbox()
    {
        ?>
        <p class="alberta-checbox form-row">
            <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="alberta_checbox" <?php echo isset($_POST['alberta_checbox']) ? 'checked' : ''; ?> id="alberta_checbox" />
                <span class="alberta_checbox__checkbox-text">To continue using this website, we need to verify your age with a picture of your Government ID together with your face. We use this information solely to confirm you have reached the minimum age to access our services. The picture will be stored securely by our web provider and will be deleted shortly after verification is complete.</span>
            </label>
        </p>
        <?php
    }
}
