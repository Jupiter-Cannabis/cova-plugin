<hr>
<h2><?php _e('Alberta Mode', 'cova') ?></h2>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row"><?php _e('Image Path/URL', 'cova') ?></th>
        <td>
            <fieldset>
                <label for="cova_alberta_mode_image">
                    <input type="text" name="cova_alberta_mode_image" value="<?php echo $args['image'] ?>">
                </label>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
