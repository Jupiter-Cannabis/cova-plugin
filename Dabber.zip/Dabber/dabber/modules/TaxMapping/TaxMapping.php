<?php

namespace Dabber\Modules\TaxMapping;

use PHPMailer\PHPMailer\Exception;

class TaxMapping
{
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Tax Mapping',
        'description' => 'Map Cova hub taxes to Woocommerce'
    ];

    private $taxes;

    public function run()
    {
        add_action('woocommerce_cart_calculate_fees', [$this, 'calculate_tax']);
    }

    /**
     * Reset and recalculate taxes on the checkout page to make sure taxes are applied.
     *
     * @return void
     */
    function calculate_tax()
    {
        if (!function_exists('is_checkout') || !function_exists('is_cart')) {
            return;
        }

        if (is_checkout() && is_cart()) {
            return;
        }

        $this->reset_cart_taxes();
        $this->calculate_cart_taxes();
    }

    public function reset_cart_taxes()
    {
        $cart = WC()->cart;
        $cart->fees_api()->remove_all_fees();
    }

    public function calculate_cart_taxes()
    {
        global $dabber_current_location_data;

        $cart = WC()->cart;
        $cart_items = $cart->get_cart();
        $line_items = [];

        $i = 1;
        foreach ( $cart_items as $item ) {
            $line_items[] = [
                'LineNumber' => $i,
                'ProductCatalogId' => get_post_meta($item['data']->get_id(), 'cova_catalog_id', true),
                'Quantity' => $item['quantity'],
                'Price' => (float) $item['data']->get_price(),
                'BasePriceListPrice' => (float) cova_get_product_location_regular_price($item['data']->get_id(), $dabber_current_location_data['wc_location_id'])
            ];
            $i++;
        }

        $taxes = new \CovaAPI\Taxes();
        $response = $taxes->get_tax_calculation($line_items, $dabber_current_location_data['cova_location_id']);
        $response = json_decode($response);

        if (empty($response->LineItems)) {
            return;
        }

        $tax_items = [];
        foreach ($response->LineItems as $tax_item) {
            foreach ($tax_item->TaxDetails as $tax_detail) {
                $tax_label = (!empty($tax_detail->TaxDisplayName))? $tax_detail->TaxDisplayName : $tax_detail->TaxName;
                if (isset($tax_items[$tax_label])) {
                    $tax_items[$tax_label] += $tax_detail->Tax;
                } else {
                    $tax_items[$tax_label] = $tax_detail->Tax;
                }
            }
        }

        if (empty($tax_items)) {
            return;
        }

        //        $coupons = $cart->get_applied_coupons();
        //
        //
        //        foreach ($coupons as $coupon_code) {
        //            $coupon = new \WC_Coupon($coupon_code);
        //            $applied_coupons[] = [
        //                'name' => $coupon_code,
        //                'value' => $coupon->get_amount(),
        //                'valueType' => ($coupon->get_discount_type() === 'percent')? 'Percentage' : 'Amount'
        //            ];
        //        }

        foreach ($tax_items as $label => $tax_amount) {
            $cart->add_fee($label, $tax_amount);
        }
    }


}
