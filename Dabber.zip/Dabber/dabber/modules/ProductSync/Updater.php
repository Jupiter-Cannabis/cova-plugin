<?php

namespace Dabber\Modules\ProductSync;

use Dabber\Modules\ProductSync\SimpleProduct\Update;
use Dabber\Modules\ProductSync\SyncValidator\InventoryValidator;

class Updater
{
    private $update_num_limit = 15;
    private $update_stock_num_limit = 100;
    private $last_updated_timestamp;
    private $products_to_update;
    private $updated_products;
    private $updated_inventory_items;
    private static $default_last_modified_timestamp = 'PT30M';
    private static $timestamp_allowance = 'PT30S';

    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new Updater();
        }

        return self::$instance;
    }

    public function schedule_product_update()
    {
        if (!wp_next_scheduled('cova_update_products')) {
            wp_schedule_event(time(), 'every_30_minutes', 'cova_update_products');
        }
    }

    public function ajax_sync_single_product()
    {
        if (empty($_POST['params']['product_id']) || empty($_POST['params']['catalog_id'])) {
            return;
        }

        do_action('cova_update_specific_products', [
            $_POST['params']['product_id'] => $_POST['params']['catalog_id']
        ]);

        wp_send_json_success(
            [
                'status' => 'complete',
                'data' => $_POST
            ], 200
        );
    }

    /**
     * @param $wc_products // array key pair of product ID and cova catalog ID. [product_id => cova_catalog_id]
     * @return void
     */
    public function initialize_specific_product_update($wc_products)
    {
        if (empty($wc_products)) {
            return;
        }

        $update = new Update();
        $update->update_bulk(
            [
                'imported_catalog_ids' => $wc_products,
                'cova_products' => $this->get_cova_products_by_catalog_ids($wc_products),
            ], false
        );
    }

    public function initialize_all_products_update()
    {
        $offset = $this->get_last_catalog_ids_offset();
        $catalog_ids = $this->get_catalog_ids_to_update($offset);

        $this->updated_products = [
            'updated_products' => [],
            'completed' => false,
        ];

        if (!empty($catalog_ids)) {
            $update = new Update();
            $this->updated_products['updated_products'] = $update->update_bulk(
                [
                'imported_catalog_ids' => $catalog_ids,
                'cova_products' => $this->get_cova_products_by_catalog_ids($catalog_ids),
                ], false
            );
        } else {
            $this->updated_products['completed'] = true;
        }

        $this->save_last_catalog_ids_offset();
    }

    public static function get_last_sync_offset($key)
    {
        $offset = get_option($key);

        if (empty($offset)) {
            return 0;
        }

        return $offset;
    }

    public static function save_last_sync_offset($key, $items_count, $update_limit = 200)
    {
        if ($items_count < 1) {
            $offset = 0;
        } else {
            $offset = self::get_last_sync_offset($key);
            $offset += $update_limit;
        }

        update_option($key, $offset);
    }

    public function get_last_catalog_ids_offset()
    {
        $offset = get_option('cova_catalog_ids_sync_offset');

        if (empty($offset)) {
            return 0;
        }

        return $offset;
    }

    public function save_last_catalog_ids_offset()
    {
        if (empty($this->updated_products['updated_products'])) {
            $offset = 0;
        } else {
            $offset = $this->get_last_catalog_ids_offset();
            $offset += $this->update_num_limit;
        }

        update_option('cova_catalog_ids_sync_offset', $offset);
    }

    /**
     * Get catalog IDs to be updated in "update all products" function
     *
     * @return array
     */
    public function get_catalog_ids_to_update($offset)
    {
        global $wpdb;

        $sql = "SELECT meta.meta_value, meta.post_id
				FROM {$wpdb->prefix}postmeta as meta
				LEFT JOIN {$wpdb->prefix}posts as products
				ON products.ID = meta.post_id
				WHERE meta.meta_key = 'cova_catalog_id'
				AND (
					products.post_status = 'publish' OR
					products.post_status = 'private'
				) 
                ORDER BY products.ID ASC
		        LIMIT %d OFFSET %d";


        $sql = $wpdb->prepare($sql, $this->update_num_limit, $offset);
        $result = $wpdb->get_results($sql);

        if (empty($result)) {
            return [];
        }

        $ids = [];

        foreach ($result as $item) {
            $ids[$item->post_id] = $item->meta_value;
        }

        return array_unique($ids);
    }

    public function initialize_last_modified_products_update()
    {
        $sync_timestamp = get_option('cova_last_seven_days_product_sync_update_timestamp');
        $this->last_updated_timestamp = self::get_last_sync_modified_timestamp('cova_last_seven_days_product_sync_update');

        if (!empty($sync_timestamp) && $sync_timestamp !== 'false') {
            $this->last_updated_timestamp['timestamp'] = $sync_timestamp;
        } else {
            $current_date = new \DateTime(gmdate('Y-m-d H:i:s'));
            $current_date->modify('-7 days'); // Get last modified from 7 days ago.
            $last_request = $current_date->format('Y-m-d\TH:i:s');

            update_option('cova_last_seven_days_product_sync_update_timestamp', $last_request);

            $this->last_updated_timestamp['timestamp'] = $last_request;
        }

        $this->products_to_update = $this->get_products_to_update();

        $this->updated_products = [
            'updated_products' => [],
            'completed' => false,
        ];

        if (count($this->products_to_update['api_catalog_ids']) < $this->update_num_limit) {
            $this->updated_products['completed'] = true;
            update_option('cova_last_seven_days_product_sync_update_timestamp', 'false');
        }

        if (!empty($this->products_to_update['cova_products'])) {
            $update = new Update();
            // This update will no longer update inventory stock because quantity updater cron runes every 3 minutes.
            $this->updated_products['updated_products'] = $update->update_bulk($this->products_to_update, $this->last_updated_timestamp['timestamp']);
        }

        self::save_last_sync_modified_timestamp('cova_last_seven_days_product_sync_update', count($this->products_to_update['api_catalog_ids']), $this->update_num_limit);
    }

    public function initialize_products_update()
    {
        $this->last_updated_timestamp = self::get_last_sync_modified_timestamp('cova_last_product_sync_update');
        $products_to_update = $this->get_products_to_update();

        if (!empty($products_to_update['cova_products'])) {
            $update = new Update();
            // This sync will no longer update inventory stock because quantity updater cron runes every 3 minutes.
            $update->update_bulk($products_to_update, $this->last_updated_timestamp['timestamp'], true);
        }

        self::save_last_sync_modified_timestamp('cova_last_product_sync_update', count($products_to_update['api_catalog_ids']), $this->update_num_limit);
    }

    public function ajax_update_inventory()
    {
        do_action('cova_sync_inventory');

        if ($this->updated_inventory_items['completed'] === true) {
            wp_send_json_success(
                [
                    'status' => 'complete',
                    'message' => 'No more products to update',
                    'message_type' => 'success'
                ], 200
            );
        }

        $messages = [
            'Successfully scanned '. count($this->updated_inventory_items['data']['products']) .' products.'
        ];

        if (!empty($this->updated_inventory_items['data']['updated_stocks'])) {
            $messages[] = count($this->updated_inventory_items['data']['updated_stocks']) .' products updated.';
        }

        wp_send_json_success(
            [
                'status' => 'ok',
                'message' => implode(' ', $messages),
                'data' => [
                    'offset' => $this->updated_inventory_items['data']['offset'],
                    'updated_items' => $this->updated_inventory_items['data']['updated_stocks']
                ],
            ], 200
        );
    }

    public function initialize_specific_product_inventory_update($catalog_ids = [])
    {
        if (empty($catalog_ids)) {
            return;
        }

        $inventory_validator = InventoryValidator::getInstance();
        $inventory_validator->update_inventory($catalog_ids);
    }

    public function initialize_product_inventory_update()
    {
        $inventory_validator = InventoryValidator::getInstance();

        $this->updated_inventory_items = [
            'completed' => false,
        ];

        $products = $inventory_validator->update_inventory();

        $this->updated_inventory_items['data'] = $products;

        if (empty($products['products'])) {
            $this->updated_inventory_items['completed'] = true;
        }
    }

    public function ajax_update_all_products()
    {
        do_action('cova_update_all_products');

        if ($this->updated_products['completed'] === true) {
            wp_send_json_success(
                [
                'status' => 'complete',
                'message' => 'No more products to update',
                'message_type' => 'success'
                ], 200
            );
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'message' => 'Successfully updated '. count($this->updated_products['updated_products']) .' product(s)',
            'data' => $this->updated_products['updated_products'],
            ], 200
        );
    }

    public function ajax_update_products()
    {
        do_action('cova_update_last_modified_products');

        $message = 'Successfully updated '. count($this->updated_products['updated_products']) .' product(s)';

        if ($this->updated_products['completed'] === true) {
            $args = [
                'status' => 'complete',
                'message' => 'No more products to update',
                'message_type' => 'success'
            ];
            if (count($this->updated_products['updated_products']) > 0) {
                $args['message'] = $message .' No more products to update';
                $args['data'] = $this->updated_products['updated_products'];
            }
            wp_send_json_success($args, 200);
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'message' => $message,
            'data' => $this->updated_products['updated_products'],
            ], 200
        );
    }

    public function get_cova_products($timestamp, $skip)
    {
        $catalog_ids = [];

        $products = CovaAPI('v2')->catalog->get_update_as_of(
            $timestamp, [
            "IncludeProductSkusAndUpcs" => true,
            "IncludeProductSpecifications" => true,
            "IncludeProductAssets" => true,
            "IncludeAvailability" => true,
            "IncludePackageDetails" => true,
            "IncludePricing" => true,
            "InStockOnly" => false,
            "SellingRoomOnly" => true,
            "Skip" => $skip,
            "Top" => $this->update_num_limit
            ]
        );

        if (empty($products['Products'])) {
            return [
                'catalog_ids' => [],
                'products' => []
            ];
        }

        foreach ($products['Products'] as $cova_product) {
            $catalog_ids[] = $cova_product['ProductId'];
        }

        $to_update_products = $this->get_cova_products_by_catalog_ids(array_values($catalog_ids));

        $catalog_ids_to_update = [];
        foreach ($products['Products'] as $cova_product) {
            $catalog_ids_to_update[] = $cova_product['ProductId'];
        }

        return [
            'catalog_ids' => array_unique($catalog_ids_to_update),
            'products' => $to_update_products
        ];
    }

    public function get_cova_products_by_catalog_ids($catalog_ids)
    {
        return CovaAPI('v2')->catalog->get_detailed_products_by_catalog_ids(
            [
            'IncludeProductSkusAndUpcs' => true,
            'IncludeProductSpecifications' => true,
            'IncludeProductAssets' => true,
            'IncludeAvailability' => true,
            'IncludePackageDetails' => true,
            'IncludePricing' => true,
            'InStockOnly' => false,
            'SellingRoomOnly' => true,
            'ProductIds' => array_values($catalog_ids)
            ]
        );
    }

    public function get_products_to_update()
    {
        $cova_products = $this->get_cova_products($this->last_updated_timestamp['timestamp'], $this->last_updated_timestamp['skip']);
        $imported_catalog_ids = $this->filter_imported_catalog_ids($cova_products['catalog_ids']);
        $update_catalog_ids = [];

        if (!empty($cova_products['products']['Products'])) {
            // Get only catalog_ids to update if exists in WC
            foreach ($cova_products['products']['Products'] as $key => $product) {
                if (!in_array($product['ProductId'], $imported_catalog_ids)) {
                    unset($cova_products['products']['Products'][$key]);
                } else {
                    $update_catalog_ids[] = $product['ProductId'];
                }
            }
        }

        return [
            'imported_catalog_ids' => $imported_catalog_ids,
            'catalog_ids_to_update' => $update_catalog_ids,
            'cova_products' => $cova_products['products'],
            'api_catalog_ids' => $cova_products['catalog_ids']
        ];
    }

    /**
     * Return only imported catalog IDs
     *
     * @param  $catalog_ids
     * @return array
     */
    public function filter_imported_catalog_ids($catalog_ids)
    {
        global $wpdb;

        $sql = "SELECT meta.post_id, meta.meta_value
				FROM {$wpdb->prefix}postmeta as meta
				LEFT JOIN {$wpdb->prefix}posts as products
				ON products.ID = meta.post_id
				WHERE meta.meta_key = 'cova_catalog_id'
				AND (
					products.post_status = 'publish' OR
					products.post_status = 'private'
				)
				AND meta.meta_value IN('". implode("', '", $catalog_ids) ."')";

        $result = $wpdb->get_results($sql);

        if (empty($result)) {
            return [];
        }

        $ids = [];

        foreach ($result as $item) {
            $ids[$item->post_id] = $item->meta_value;
        }

        return array_unique($ids);
    }

    public static function get_last_sync_modified_timestamp($key)
    {
        $last_modified_timestamp = get_option($key);

        if (!empty($last_modified_timestamp)) {

            return self::save_last_sync_request_timestamp($key, $last_modified_timestamp);
        }

        // set default values
        $current_date = new \DateTime(gmdate('Y-m-d H:i:s'));
        $current_date->sub(new \DateInterval(self::$default_last_modified_timestamp)); // Get last modified from 30 minutes ago.
        $last_request = $current_date->format('Y-m-d\TH:i:s');

        return apply_filters(
            $key, [
                'skip' => 0,
                'timestamp' => $last_request,
                'last_request' => $last_request
            ]
        );
    }

    public static function save_last_sync_request_timestamp($key, $last_modified_timestamp = false)
    {
        if ($last_modified_timestamp === false) {
            $last_modified_timestamp = get_option($key);
        }

        $current_date = new \DateTime(gmdate('Y-m-d H:i:s'));
        $current_date->sub(new \DateInterval(self::$timestamp_allowance)); // rollback 1 min. to fix time gap
        $last_request = $current_date->format('Y-m-d\TH:i:s');

        $last_modified_timestamp['last_request'] = $last_request;
        $last_modified_timestamp = apply_filters($key, $last_modified_timestamp);

        update_option($key, $last_modified_timestamp);

        return $last_modified_timestamp;
    }

    public static function save_last_sync_modified_timestamp($key, $items_count, $update_limit)
    {
        $last_modified_timestamp = self::get_last_sync_modified_timestamp($key);

        if ($items_count < $update_limit) {
            $last_modified_timestamp['skip'] = 0;
            $last_modified_timestamp['timestamp'] = $last_modified_timestamp['last_request'];
        } else {
            $last_modified_timestamp['skip'] = $last_modified_timestamp['skip'] + $update_limit;
        }

        $last_modified_timestamp = apply_filters($key, $last_modified_timestamp);

        update_option($key, $last_modified_timestamp);
    }

    public static function reset_last_sync_modified_timestamp($key)
    {
        $last_modified_timestamp['skip'] = 0;
        $date_time = new \DateTime(gmdate('Y-m-d H:i:s'));
        $date_time->sub(new \DateInterval('PT1M')); // delay -1 minute to fix time gap
        $last_modified_timestamp['timestamp'] = $date_time->format('Y-m-d\TH:i:s');
        $last_modified_timestamp['last_request'] = $date_time;

        update_option($key, $last_modified_timestamp);
    }
}
