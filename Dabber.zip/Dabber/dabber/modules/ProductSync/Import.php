<?php

namespace Dabber\Modules\ProductSync;

use Dabber\Modules\ProductSync\SimpleProduct\Create;

class Import
{
    private $import_batch_num = 100;

    /**
     * 1. Find products in cova hub to import to Ecomm - limit 200 products
     *      - get all cova hub catalog ids @/Catalog/Items
     *      - get all Ecomm catalogids
     *      - get difference (200 limit)
     * 2. Parse product data from Cova hub to Ecomm
     *      - group product basic data (title, description, slug, etc.) to an array
     *      - group metadata to an array
     *      - group taxonomies to an array
     *      - group images to upload to an array
     * 3. Insert product items to DB
     * 4. Create and attach metadata from metadata_array source to inserted products
     * 5. Create and taxonomies and add the products to it.
     * 6. Upload all images
     *
     * Product data needed
     * - Metadata
     *      - stock qty
     *      - prices
     *      - batch data
     *      - etc.
     * - Taxonomies
     *      - Categories
     *      - Brand
     *      - Terpenes
     * - Images (can be metadata if we are using url resource from cova instead of uploading images to ecomm)
     * -
     */

    private static $instance = null;
    public $imported_products = false;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new Import();
        }

        return self::$instance;
    }

    public function schedule_product_import()
    {
        if (!wp_next_scheduled('cova_import_products')) {
            wp_schedule_event(time(), 'twicedaily', 'cova_import_products');
        }
    }

    public function ajax_import_products()
    {
        do_action('cova_import_products');

        update_option('dabber_disable_all_cron', 'yes');

        if (!empty($this->imported_products)) {

            wp_send_json_success(
                [
                'status' => 'ok',
                'message' => 'Successfully imported '. count($this->imported_products) .' product(s)',
                'data' => $this->imported_products,
                'message_type' => 'output'
                ], 200
            );
        }

        update_option('dabber_disable_all_cron', 'no');

        wp_send_json_success(
            [
            'status' => 'complete',
            'message' => 'No more products to import',
            'message_type' => 'success'
            ], 200
        );
    }

    public function initialize_product_import()
    {
        $cova_catalog_ids = $this->get_catalog_ids_to_import();

        if (empty($cova_catalog_ids)) {
            return;
        }

        $create = new Create(); // Bulk create simple products
        $this->imported_products = $create->create_bulk($cova_catalog_ids);
    }

    public function get_catalog_ids_to_import()
    {
        $cova_ids = $this->get_cova_catalog_ids();
        $wc_ids = $this->get_imported_catalog_ids();

        $to_import = array_diff($cova_ids, $wc_ids);
        $to_import = apply_filters('dabber_import_process_catalog_ids', array_values($to_import));

        return array_slice($to_import, 0, $this->import_batch_num);
    }

    public function get_imported_catalog_ids()
    {
        global $wpdb;

        $sql = "SELECT meta.meta_value
				FROM {$wpdb->prefix}postmeta as meta
				LEFT JOIN {$wpdb->prefix}posts as products
				ON products.ID = meta.post_id
				WHERE meta.meta_key = 'cova_catalog_id'
				AND (
					products.post_status = 'publish' OR
					products.post_status = 'private'
				)";

        $catalog_ids = $wpdb->get_results($sql);

        if (empty($catalog_ids)) {
            return [];
        }

        $ids = [];

        foreach ($catalog_ids as $item) {
            $ids[] = $item->meta_value;
        }

        return $ids;
    }

    public function get_cova_catalog_ids()
    {
        $cova_catalog_ids = CovaAPI()->catalog->items();
        $ids = [];

        foreach ($cova_catalog_ids as $item) {
            $ids[] = $item['CatalogItemId'];
        }

        return $ids;
    }

} // end Class
