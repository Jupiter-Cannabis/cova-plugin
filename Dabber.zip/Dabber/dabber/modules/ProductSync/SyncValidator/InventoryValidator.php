<?php

namespace Dabber\Modules\ProductSync\SyncValidator;

use Dabber\Modules\ProductSync\Updater;

class InventoryValidator
{
    private static $instance = null;
    public $update_limit = 300;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new InventoryValidator();
        }

        return self::$instance;
    }

    public function update_inventory($catalog_ids = [])
    {
        $offset = (!empty($catalog_ids))? 0 : (int) Updater::get_last_sync_offset('cova_inventory_sync_offset');

        $location_ids = dabber_get_location_ids();
        $wc_products = $this->get_wc_catalog_ids($offset, $this->update_limit, $location_ids, $catalog_ids);

        $updated_stocks = [];
        $stocks_to_update = $this->get_stocks_to_update($wc_products, $location_ids);

        if (!empty($stocks_to_update)) {
            $updated_stocks = $this->update_product_stocks($stocks_to_update);
        }

        if (empty($catalog_ids)) {
            Updater::save_last_sync_offset('cova_inventory_sync_offset', count($wc_products), $this->update_limit);
        }

        return [
            'offset' => $offset,
            'products' => $wc_products,
            'updated_stocks' => $updated_stocks
        ];
    }

    public function get_stocks_to_update($wc_products, $location_ids)
    {
        $location_ids_reversed = array_flip($location_ids);
        $catalog_ids = array_filter(array_keys($wc_products));

        $cova_products = CovaAPI('v2')->catalog->get_detailed_products_by_catalog_ids([
            'IncludeProductSkusAndUpcs' => false,
            'IncludeProductSpecifications' => false,
            'IncludeProductAssets' => false,
            'IncludeAvailability' => true,
            'IncludePackageDetails' => false,
            'IncludePricing' => false,
            'InStockOnly' => false,
            'SellingRoomOnly' => true,
            'ProductIds' => array_values($catalog_ids)
        ]);

        if (empty($cova_products['Products'])) {
            return [];
        }

        $default_loc_stocks = [];
        $order_products = $this->get_products_from_orders();

        foreach ($location_ids_reversed as $cova_loc => $wc_loc) {
            $default_loc_stocks['wcmlim_stock_at_'. $wc_loc] = 0;
        }

        $stocks_to_update = [];
        $stocks_to_insert = [];

        foreach ($cova_products['Products'] as $cova_item) {
            $wc_item = $wc_products[$cova_item['ProductId']];
            $location_stocks = json_decode($wc_item->location_stock, true);
            $location_stocks = array_filter($location_stocks, function($value) {
                return !is_null($value);
            });

            foreach ($location_stocks as $loc_stock_id => $loc_stock_qty) {
                if (!isset($order_products[$loc_stock_id][$wc_item->ID])) {
                    continue;
                }
                $order_qty = (float) $order_products[$loc_stock_id][$wc_item->ID];
                $as_is_qty = (float) $location_stocks[$loc_stock_id] + $order_qty;
                $location_stocks[$loc_stock_id] = $as_is_qty;
                $wc_item->stock = (float) $wc_item->stock + $order_qty;
            }

            if (empty($cova_item['Availability'])) {
                $check_zero_quantities = array_filter($location_stocks, function($value) {
                    return $value != "0";
                });

                if (!empty($check_zero_quantities) || $wc_item->stock > 0) {
                    $stocks_to_update[$wc_item->ID] = [
                        '_stock' => 0,
                        '_stock_status' => 'outofstock'
                    ];
                    foreach ($location_stocks as $wc_loc_id => $loc_qty) {
                        if ($loc_qty != 0) {
                            $stocks_to_update[$wc_item->ID][$wc_loc_id] = 0;
                        }
                    }
                }
                continue;
            }

            $cova_location_stocks = [];
            foreach ($cova_item['Availability'] as $stock_item) {
                if (!isset($location_ids_reversed[$stock_item['LocationId']])) { // skip locations that are not imported to eComm
                    continue;
                }
                if (isset($cova_location_stocks['wcmlim_stock_at_'. $location_ids_reversed[$stock_item['LocationId']]])) {
                    $cova_location_stocks['wcmlim_stock_at_'. $location_ids_reversed[$stock_item['LocationId']]] += $stock_item['InStockQuantity'];
                } else {
                    $cova_location_stocks['wcmlim_stock_at_'. $location_ids_reversed[$stock_item['LocationId']]] = $stock_item['InStockQuantity'];
                }
            }

            $total_stock = array_sum($cova_location_stocks);

            $cova_location_stocks = array_merge($default_loc_stocks, $cova_location_stocks);
            $location_stock_diff = array_diff_assoc($cova_location_stocks, $location_stocks);

            if ($wc_item->stock != $total_stock || !empty($location_stock_diff)) {

                $missing_stocks = array_diff_key($cova_location_stocks, $location_stocks);
                $update_stocks = array_intersect_key($location_stock_diff, $location_stocks);

                if (!empty($missing_stocks)) {
                    $stocks_to_insert[$wc_item->ID] = $missing_stocks;
                }

                if (!empty($location_stock_diff)) {
                    $stocks_to_update[$wc_item->ID] = $update_stocks;
                }

                $stocks_to_update[$wc_item->ID]['_stock'] = $total_stock;
                $stocks_to_update[$wc_item->ID]['_stock_status'] = ($total_stock > 0)? 'instock' : 'outofstock';

                $grouped_availability = array_reduce(
                    $cova_item['Availability'], function ($accumulator, $item) {
                    $accumulator[$item['LocationId']][] = $item;
                    return $accumulator;
                }, []);

                $grouped_availability = array_intersect_key($grouped_availability, $location_ids_reversed);
                $package_quantities = [];

                foreach ($grouped_availability as $availability_items) {
                    usort(
                        $availability_items, function ($a, $b) {
                        // Filter out items with stock <= 0
                        if ($a['InStockQuantity'] <= 0) return 1;
                        if ($b['InStockQuantity'] <= 0) return -1;

                        // Sort by ascending date
                        return strtotime($a['ReceivedDate']) - strtotime($b['ReceivedDate']);
                    });

                    $sorted_package_items = array_values($availability_items);
                    $package_quantities[$location_ids_reversed[$sorted_package_items[0]['LocationId']]][$sorted_package_items[0]['PackageId']] = (float) $sorted_package_items[0]['InStockQuantity'];
                }

                if ($wc_item->package_quantities === null) {
                    $stocks_to_insert[$wc_item->ID]['package_quantities'] = $package_quantities;
                } else {
                    $stocks_to_update[$wc_item->ID]['package_quantities'] = $package_quantities;
                }
            }
        }

        return [
            'insert_stocks' => $stocks_to_insert,
            'update_stocks' => $stocks_to_update
        ];
    }

    public function update_product_stocks($stock_items)
    {
        global $wpdb;

        if (!empty($stock_items['update_stocks'])) {
            $update_sql = "UPDATE {$wpdb->postmeta} SET ";

            $conditions = [];

            foreach ($stock_items['update_stocks'] as $post_id => $stocks) {
                foreach ($stocks as $meta_key => $meta_value) {
                    $meta_value = maybe_serialize($meta_value);
                    $conditions[] = "meta_value = CASE WHEN post_id = $post_id AND meta_key = '$meta_key' THEN '$meta_value' ELSE meta_value END";
                }
            }

            $update_sql .= implode(', ', $conditions);
            $wpdb->query($update_sql);
        }

        if (!empty($stock_items['insert_stocks'])) {

            $values = [];
            foreach ($stock_items['insert_stocks'] as $post_id => $metas) {
                foreach ($metas as $meta_key => $meta_value) {
                    $values[] = "($post_id, '$meta_key', '$meta_value')";
                }
            }

            $insert_sql = "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES " . implode(',', $values);
            $wpdb->query($insert_sql);
        }

        $updated_ids = array_values(array_keys($stock_items['update_stocks']));
        $inserted_ids = array_values(array_keys($stock_items['insert_stocks']));

        return array_merge($updated_ids, $inserted_ids);
    }

    public function get_wc_catalog_ids($offset, $limit, $location_ids, $catalog_ids)
    {
        global $wpdb;

        $select_locations = [];
        $select = [];
        $join = [];
        $where = [];

        $select[] = "post.ID";
        $select[] = "meta.meta_value AS cova_catalog_id";
        $select[] = "stock.meta_value AS stock";
        $select[] = "package_qty.meta_value AS package_quantities";

        $join[] = "LEFT JOIN wp_postmeta AS meta ON post.ID = meta.post_id AND meta.meta_key = 'cova_catalog_id'";
        $join[] = "LEFT JOIN wp_postmeta AS stock ON post.ID = stock.post_id AND stock.meta_key = '_stock'";
        $join[] = "LEFT JOIN wp_postmeta AS package_qty ON post.ID = package_qty.post_id AND package_qty.meta_key = 'package_quantities'";

        foreach ($location_ids as $wc_loc => $cova_loc) {
            $select_locations[] = "'wcmlim_stock_at_$wc_loc', loc_$wc_loc.meta_value";
            $join[] = "LEFT JOIN wp_postmeta AS loc_$wc_loc ON post.ID = loc_$wc_loc.post_id AND loc_$wc_loc.meta_key = 'wcmlim_stock_at_$wc_loc'";
        }

        $select[] = "JSON_OBJECT(". implode(', ', $select_locations) .") AS location_stock";


        $where[] = "post.post_type = 'product'";
        $where[] = "AND post.post_status IN ('publish', 'private') ";
        $where[] = "AND meta.meta_value IS NOT NULL";

        if (!empty($catalog_ids)) {
            $where[] = "AND meta.meta_value IN ('". implode("', '", $catalog_ids) ."')";
        }

        $sql = "
            SELECT 
                ". implode(', ', $select) ."
            FROM wp_posts AS post                         
                ". implode(' ', $join) ."
            WHERE 
                ". implode(' ', $where) ."                        
            GROUP BY post.ID 
            ORDER BY post.ID ASC 
            LIMIT $offset,$limit;";

        $results = $wpdb->get_results($sql);

        if (empty($results)) {
            return [];
        }

        $wc_products = [];
        foreach ($results as $item) {
            $wc_products[$item->cova_catalog_id] = $item;
        }

        return $wc_products;
    }

    public function validate_inventory()
    {
        if (!is_admin()) {
            return;
        }
        if (!isset($_GET['_dabber_validate_inventory_sync'])) {
            return;
        }

        $result = self::compare_wc_cova_inventory(-1);
        !d($result);
        die();
    }

    public static function compare_wc_cova_inventory($limit = 15)
    {
        global $wpdb;

        $location_ids = dabber_get_location_ids();
        $validated_products = [];

        foreach ($location_ids as $wc_loc_id => $cova_location_id) {

            $sql = "SELECT post.ID, post.post_title, post.guid, m1.meta_value as stock, m2.meta_value as catalog_id
                FROM {$wpdb->posts} as post
                LEFT JOIN {$wpdb->postmeta} as m1
                ON m1.post_id = post.ID
                LEFT JOIN {$wpdb->postmeta} as m2
                ON m2.post_id = post.ID
                WHERE m1.meta_key = 'wcmlim_stock_at_{$wc_loc_id}'
                AND m2.meta_key = 'cova_catalog_id'
            ";

            $sql = $wpdb->prepare($sql);
            $wc_products = $wpdb->get_results($sql);
            $formatted_wc_products = array_reduce(
                $wc_products,
                function ($result, $item) {
                    $catalogId = $item->catalog_id;
                    $result[$catalogId] = $item;
                    return $result;
                },
                array()
            );

            $inventory = CovaAPI()->inventory->all($cova_location_id);

            foreach ($inventory as $product) {
                if (!isset($formatted_wc_products[$product['Id']])) {
                    continue;
                }
                $wc_product = $formatted_wc_products[$product['Id']];
                if ($wc_product->stock != $product['Quantity']) {
                    $validated_products[] = [
                        'location_id' => $cova_location_id,
                        'product_name' => $wc_product->post_title,
                        'wc_product_id' => (int) $wc_product->ID,
                        'catalog_id' => $wc_product->catalog_id,
                        'wc_url' => $wc_product->guid,
                        'wc_stock' => (int) $wc_product->stock,
                        'cova_stock' => (int) $product['Quantity'],
                        'last_updated' => $product['UpdatedDateUtc']
                    ];
                }
            }
        }

        if (empty($validated_products)) {
            return [];
        }

        if ($limit === -1) { // return all items
            return $validated_products;
        }
        return array_slice($validated_products, 0, $limit);
    }

    public function get_products_from_orders()
    {
        global $wpdb;

        $sql = "
        SELECT
            orders.ID AS order_id,
            order_meta.meta_value AS location_id,
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    'product_id', order_products.product_id,
                    'quantity', order_products.product_qty
                )
            ) AS stocks
        FROM
            {$wpdb->posts} AS orders
        JOIN {$wpdb->prefix}wc_order_product_lookup AS order_products ON orders.ID = order_products.order_id
        JOIN {$wpdb->postmeta} AS order_meta ON orders.ID = order_meta.post_id
        WHERE
            orders.post_type = 'shop_order'
            AND order_meta.meta_key = '_multilocation'
            AND orders.post_status IN ('wc-ready-pickup', 'wc-ready-delivery', 'wc-in-progress', 'wc-processing')
            AND orders.post_date > DATE_SUB(NOW(), INTERVAL 1 DAY)
        GROUP BY
            orders.ID, orders.post_status, orders.post_date
        ORDER BY
            orders.ID ASC;";

        $result = $wpdb->get_results($sql);

        if (empty($result)) {
            return [];
        }

        $products = [];

        foreach ($result as $item) {
            $stocks = json_decode($item->stocks);
            $location = maybe_unserialize($item->location_id);

            foreach ($stocks as $stock_item) {
                if (isset($products['wcmlim_stock_at_'. $location[0]][$stock_item->product_id])) {
                    $products['wcmlim_stock_at_'. $location[0]][$stock_item->product_id] += (float) $stock_item->quantity;
                } else {
                    $products['wcmlim_stock_at_'. $location[0]][$stock_item->product_id] = (float) $stock_item->quantity;
                }
            }
        }

        return $products;
    }
}