<?php

namespace Dabber\Modules\ProductSync\SimpleProduct;

use Dabber\Modules\ProductSync\WpPostFormatter;

class Create
{
    public $data;
    private $last_inserted_ids = [];

    public function create_bulk($cova_catalog_ids)
    {
        do_action('cova_before_bulk_create_products');

        $this->delete_incomplete_import_ids();
        $this->generate_products_to_import($cova_catalog_ids);
        $this->create_products();
        $this->create_metadata();
        $this->create_taxonomies();
        $this->add_tax_terms_to_products();

        $imported_products = $this->wc_update_products();

        do_action('cova_after_bulk_create_products', $this->last_inserted_ids);

        return $imported_products;
    }

    public function generate_products_to_import($cova_catalog_ids)
    {
        // {{Url}}/v1/Companies/{{CompanyId}}/DetailedProductData/ByProductIdList
        $cova_products = CovaAPI('v2')->catalog->get_detailed_products_by_catalog_ids(
            [
            'IncludeProductSkusAndUpcs' => true,
            'IncludeProductSpecifications' => true,
            'IncludeProductAssets' => true,
            'IncludeAvailability' => true,
            'IncludePackageDetails' => true,
            'IncludePricing' => true,
            'InStockOnly' => true,
            'SellingRoomOnly' => true,
            'ProductIds' => array_values($cova_catalog_ids)
            ]
        );

        $this->data = (new WpPostFormatter())->get_cova_products_formatted_data($cova_products);
    }

    public function create_products()
    {
        global $wpdb;

        $product_values = [];
        $prepared_values = [];

        foreach ($this->data['products'] as $product) {
            unset($product['cova_status']);

            if (isset($product['wc_id'])) {
                unset($product['wc_id']);
            }
            foreach ($product as $product_detail) {
                $prepared_values[] = $product_detail;
            }
            $product_values[] = $product;
        }

        $placeholders = array_fill(0, count($product_values), '(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)');
        $product_query = $wpdb->prepare("INSERT INTO {$wpdb->prefix}posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, post_name, post_modified, post_modified_gmt, post_type, guid) VALUES " . implode(', ', $placeholders), $prepared_values);
        $wpdb->query($product_query);

        $this->last_inserted_ids = $this->get_last_inserted_ids();

        $this->update_last_created_posts();
    }

    public function delete_incomplete_import_ids()
    {
        $product_ids = $this->get_last_inserted_ids();
        if (empty($product_ids)) {
            return;
        }

        foreach ($product_ids as $product_id) {
            wp_delete_post($product_id, true);
        }
    }

    public function get_last_inserted_ids()
    {
        global $wpdb;

        $query = "SELECT * FROM {$wpdb->prefix}posts WHERE post_status = 'import_pending'";
        $posts = $wpdb->get_results($query);

        $post_ids = [];

        foreach ($posts as $item) {
            $post_ids[$item->guid] = $item->ID;
        }

        return $post_ids;
    }

    /**
     * Update post_parent and guid
     *
     * @return void
     */
    public function update_last_created_posts()
    {
        global $wpdb;

        $site_url = get_site_url();

        $values = [];

        foreach ($this->last_inserted_ids as $product_id) {
            $values[] = "WHEN id = ". $product_id ." THEN '". $site_url ."/?page_id=". $product_id ."'";
        }

        $sql = "UPDATE {$wpdb->prefix}posts
                SET guid = 
                CASE
                    ". implode(' ', $values) ."
                ELSE guid
                END
                WHERE id IN (". implode(', ', array_values($this->last_inserted_ids)) .");";

        $wpdb->query($sql);
    }

    public function create_metadata()
    {
        global $wpdb;

        if (empty($this->last_inserted_ids)) {
            return;
        }

        $product_meta_values = [];
        $prepared_values = [];

        foreach ($this->data['metadata'] as $catalog_id => $items) {
            foreach ($items as $meta_key => $meta_val) {
                $product_meta_values[] = [
                    'post_id'       => $this->last_inserted_ids[$catalog_id],
                    'meta_key'      => $meta_key,
                    'meta_value'    => maybe_serialize($meta_val)
                ];
                $prepared_values[] = $this->last_inserted_ids[$catalog_id];
                $prepared_values[] = $meta_key;
                $prepared_values[] = maybe_serialize($meta_val);
            }
        }

        $placeholders = array_fill(0, count($product_meta_values), '(%s, %s, %s)');
        $product_meta_query = $wpdb->prepare("INSERT INTO {$wpdb->prefix}postmeta (post_id, meta_key, meta_value) VALUES " . implode(', ', $placeholders), $prepared_values);

        $wpdb->query($product_meta_query);
    }

    public function create_taxonomies()
    {
        if (empty($this->last_inserted_ids)) {
            return;
        }

        foreach ($this->data['tax_terms'] as $tax_key => $terms) {
            foreach ($terms as $item) {
                $term_exists = term_exists($item, $tax_key);
                if (empty($term_exists)) {
                    wp_insert_term(
                        $item, $tax_key, apply_filters(
                            'cova_insert_term_args', [
                            'parent' => 0,
                            'slug' => dabber_sanitize_slug($item)
                            ]
                        )
                    );
                }
            }
        }
    }

    public function add_tax_terms_to_products()
    {
        foreach ($this->data['taxonomies'] as $catalog_id => $tax_items) {
            foreach ($tax_items as $tax_key => $term_items) {
                $product_id = $this->last_inserted_ids[$catalog_id];
                wp_set_object_terms($product_id, $term_items, $tax_key, true);
            }
        }
    }

    public function wc_update_products()
    {
        if (empty($this->last_inserted_ids)) {
            return [];
        }

        $products = [];

        foreach ($this->last_inserted_ids as $id) {
            $product = wc_get_product($id);
            $status = $product->get_meta('cova_status');

            // temporarily update visibility
            $product->set_catalog_visibility('catalog');
            $product->set_status($status);
            $product->save();

            // reset visibility
            $product->set_catalog_visibility('visible');
            $product->save();

            $cova_catalog_id = $product->get_meta('cova_catalog_id');
            $cova_slug = $product->get_meta('cova_slug');
            $wc_url = $product->get_permalink();
            $cova_url = 'https://hub.covasoft.net/#CatalogManager/products/'. $cova_catalog_id .'/'. $cova_slug;

            $products[] = [
                'name' => $product->get_title(),
                'woocommerce_url' => '<a href="'. $wc_url .'" target="__blank">'. $wc_url .'</a>',
                'cova_url' => '<a href="'. $cova_url .'" target="__blank">'. $cova_url .'</a>',
            ];
        }

        return $products;
    }
}
