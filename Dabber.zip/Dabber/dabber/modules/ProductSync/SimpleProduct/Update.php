<?php

namespace Dabber\Modules\ProductSync\SimpleProduct;

use Dabber\Modules\ProductBatchData\ProductBatchData;
use Dabber\Modules\ProductSync\WpPostFormatter;

class Update
{
    public $data;
    public $catalog_ids;
    public $products;
    public $to_update_info = [];
    public $update_timestamp;
    private $existing_product_metas = [];
    private $skip_inventory_update;

    /**
     * Bulk update products
     *
     * @param  $cova_products    // products to update
     * @param  $update_timestamp // use to compare which product data to update.
     * @param  $skip_inventory   // Allow inventory specific CRON to update stock quantity.
     * @return array
     */
    public function update_bulk($cova_products, $update_timestamp = false, $skip_inventory = false)
    {
        $this->update_timestamp = $update_timestamp;
        $this->skip_inventory_update = $skip_inventory;
        $this->catalog_ids = array_flip($cova_products['imported_catalog_ids']);
        $this->products = (new WpPostFormatter())->get_cova_products_formatted_data($cova_products['cova_products']);

        $this->generate_products_info_to_update();

        do_action('cova_before_bulk_update_products');

        $this->update_product_details();
        $this->update_product_meta();
        $this->update_product_terms();
        $this->update_product_visibility();

        do_action('cova_after_bulk_update_products', $this->to_update_info);

        wp_cache_flush(); // Needs to flush post metadata cache to reflect changes after product update

        if (empty($this->products['products'])) {
            return [];
        }

        $updated_products = [];

        foreach ($this->products['products'] as $catalog_id => $product) {
            $cova_url = 'https://hub.covasoft.net/#CatalogManager/products/'. $catalog_id .'/'. $this->products['metadata'][$catalog_id]['cova_slug'];
            $product_permalink = get_permalink($product['wc_id']);
            $updated_products[] = [
                'name' => $product['post_title'],
                'woocommerce_url' => '<a href="'. $product_permalink .'" target="__blank">'. $product_permalink .'</a>',
                'cova_url' => '<a href="'. $cova_url .'" target="__blank">'. $cova_url .'</a>',
            ];
        }

        return $updated_products;
    }

    public function get_posts_meta_to_update()
    {
        $post_meta_data = [];

        foreach ($this->to_update_info as $product_id => $items) {
            if (!isset($items['metadata'])) {
                continue;
            }
            $post_meta_data[$product_id] = $items['metadata'];
        }

        return $post_meta_data;
    }

    public function get_product_details_to_update()
    {
        $product_details = [];

        foreach ($this->to_update_info as $product_id => $items) {
            if (!isset($items['products'])) {
                continue;
            }
            $product_details[$product_id] = $items['products'];
        }

        return $product_details;
    }

    public function update_product_details()
    {
        global $wpdb;

        $post_data = $this->get_product_details_to_update();

        if (empty($post_data)) {
            return false;
        }

        $sql = "UPDATE {$wpdb->posts} SET ";

        $conditions = [];
        $values = [];

        foreach ($post_data as $post_id => $data) {
            foreach ($data as $field => $value) {
                $conditions[] = "$field = CASE WHEN ID = %d THEN %s ELSE $field END";
                array_push($values, $post_id, $value);
            }
        }

        $sql .= implode(', ', $conditions);
        $sql = $wpdb->prepare($sql, $values);

        return $wpdb->query($sql);
    }

    public function update_product_meta()
    {
        global $wpdb;

        $post_meta_data = $this->get_posts_meta_to_update();

        $to_update_items = [];
        $to_insert_items = [];

        foreach ($post_meta_data as $post_id => $meta_keys) {
            $to_update_vals = array_intersect_key($meta_keys, $this->existing_product_metas[$post_id]);
            if (!empty($to_update_vals)) {
                $to_update_items[$post_id] = array_intersect_key($meta_keys, $this->existing_product_metas[$post_id]);
            }

            $to_insert_vals = array_diff_key($meta_keys, $this->existing_product_metas[$post_id]);
            if (!empty($to_insert_vals)) {
                $to_insert_items[$post_id] = array_diff_key($meta_keys, $this->existing_product_metas[$post_id]);
            }
        }
        // -------------

        if (!empty($to_update_items)) {

            $update_sql = "UPDATE {$wpdb->postmeta} SET meta_value = CASE";

            $update_items_conditions = [];
            $values = [];

            foreach ($to_update_items as $post_id => $meta_data) {
                foreach ($meta_data as $meta_key => $meta_value) {
                    $update_items_conditions[] = " WHEN post_id = %d AND meta_key = %s THEN %s";
                    array_push($values, $post_id, $meta_key, maybe_serialize($meta_value));
                }
            }

            $update_sql .= implode(' ', $update_items_conditions);
            $update_sql .= " ELSE meta_value END";
            $update_sql = $wpdb->prepare($update_sql, $values);

            $wpdb->query($update_sql);
        }

        // insert non-existing metadata
        if (!empty($to_insert_items)) {

            $query = "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES ";
            $values = [];

            foreach ($to_insert_items as $pid => $meta_pairs) {
                foreach ($meta_pairs as $mkey => $mval) {
                    $values[] = $wpdb->prepare('(%d, %s, %s)', $pid, $mkey, maybe_serialize($mval));
                }
            }

            $query .= implode(', ', $values);

            $wpdb->query($query);
        }
    }

    public function update_product_terms()
    {
        $default_category = get_option('default_product_cat');
        $default_category = (!empty($default_category))? (int) $default_category : 'uncategorized';

        foreach ($this->to_update_info as $product_id => $items) {
            if (!isset($items['taxonomies'])) {
                continue;
            }

            foreach ($items['taxonomies'] as $tax_key => $terms) {

                /**
                 * @todo review for improvement.
                 */
                // reset product tax terms before updating product terms to remove unused ones.
                wp_set_object_terms($product_id, [], $tax_key, false);

                foreach ($terms as $term_name) {
                    $existing_term = term_exists($term_name, $tax_key);
                    if (!$existing_term) {
                        $term = wp_insert_term(
                            $term_name, $tax_key, apply_filters(
                                'cova_insert_term_args', [
                                'parent' => 0,
                                'slug' => dabber_sanitize_slug($term_name)
                                ]
                            )
                        );
                        $term_id = (is_wp_error($term))? false : (int) $term['term_id'];
                    } else {
                        $term_id = (int) $existing_term['term_id'];
                    }

                    if ($term_id !== false) {
                        wp_set_object_terms($product_id, $term_id, $tax_key, true);
                    }
                }
            }

            // Remove default category set by Woocommerce.
            wp_remove_object_terms($product_id, $default_category, 'product_cat');
        }

        return true;
    }

    public function update_product_visibility()
    {
        foreach ($this->to_update_info as $product_id => $items) {
            $product = wc_get_product($product_id);

            // temporarily update visibility
            $product->set_catalog_visibility('catalog');
            $product->save();

            // reset visibility
            $product->set_catalog_visibility('visible');
            $product->save();
        }
    }

    public function get_products_metadata($product_ids)
    {
        global $wpdb;

        $placeholders = array_fill(0, count($product_ids), '%d');
        $placeholders_string = implode(', ', $placeholders);

        $prepared_query = $wpdb->prepare(
            "SELECT meta.post_id, meta.meta_key, meta.meta_value
                FROM {$wpdb->prefix}postmeta as meta
                WHERE meta.post_id IN ($placeholders_string);",
            $product_ids
        );

        $results = $wpdb->get_results($prepared_query);

        foreach ($results as $item) {
            $this->existing_product_metas[$item->post_id][$item->meta_key] = $item->meta_value;
        }
    }

    public function generate_products_info_to_update()
    {
        $product_ids = [];
        $location_ids = dabber_get_location_ids();

        foreach ($this->products['last_updated_info'] as $catalog_id => $items) {
            $product_id = $this->catalog_ids[$catalog_id];
            $product_ids[] = $product_id;
            foreach ($items as $key => $last_updated_timestamp) {

                if ($this->update_timestamp !== false) { // Ignore timestamp. Used for updating all products
                    $update_timestamp = strtotime($this->update_timestamp);
                    $item_update_timestamp = strtotime($last_updated_timestamp);

                    if ($item_update_timestamp < $update_timestamp) {
                        continue;
                    }
                }

                $product_data = $this->products['products'][$catalog_id];
                $product_meta = $this->products['metadata'][$catalog_id];
                $product_tax  = $this->products['taxonomies'][$catalog_id];

                $this->to_update_info[$product_id]['metadata']['cova_catalog_id'] = $product_meta['cova_catalog_id'];

                if ($key === 'product') {
                    $this->to_update_info[$product_id]['products'] = [
                        'post_content'  => $product_data['post_content'],
                        'post_title'    => $product_data['post_title'],
                        'post_excerpt'  => $product_data['post_excerpt'],
                        'post_status'   => $product_meta['cova_status'],
                        'post_modified' => $product_data['post_modified'],
                        'post_modified_gmt' => $product_data['post_modified_gmt']
                    ];

                    $this->to_update_info[$product_id]['metadata']['cova_specifications'] = $product_meta['cova_specifications'];
                    $this->to_update_info[$product_id]['metadata']['classification_id'] = $product_meta['classification_id'];
                    $this->to_update_info[$product_id]['metadata']['featured_image'] = $product_meta['featured_image'];
                    $this->to_update_info[$product_id]['metadata']['images'] = $product_meta['images'];
                    $this->to_update_info[$product_id]['metadata']['_sku'] = $product_meta['_sku'];
                    $this->to_update_info[$product_id]['metadata']['net_weight'] = $product_meta['net_weight'];
                    $this->to_update_info[$product_id]['metadata']['net_weight_unit'] = $product_meta['net_weight_unit'];
                    $this->to_update_info[$product_id]['metadata']['equivalent_weight'] = $product_meta['equivalent_weight'];
                    $this->to_update_info[$product_id]['metadata']['equivalent_weight_unit'] = $product_meta['equivalent_weight_unit'];

                    if (isset($product_meta['terpene_percent'])) {
                        $this->to_update_info[$product_id]['metadata']['terpene_percent'] = $product_meta['terpene_percent'];
                    }
                    if (isset($product_tax['product_cat'])) {
                        $this->to_update_info[$product_id]['taxonomies']['product_cat'] = $product_tax['product_cat'];
                    }
                    if (isset($product_tax['product_brand'])) {
                        $this->to_update_info[$product_id]['taxonomies']['product_brand'] = $product_tax['product_brand'];
                    }
                    if (!empty($product_tax['strain'])) {
                        $this->to_update_info[$product_id]['taxonomies']['strain'] = $product_tax['strain'];
                    }
                    if (!empty($product_tax['terpenes'])) {
                        $this->to_update_info[$product_id]['taxonomies']['terpenes'] = $product_tax['terpenes'];
                    }
                }

                if (stripos($key, 'price_at_') !== false) {
                    $location_id = str_replace('price_at_', '', $key);
                    $this->to_update_info[$product_id]['metadata']['wcmlim_regular_price_at_'. $location_id] = $product_meta['wcmlim_regular_price_at_'. $location_id];
                    $this->to_update_info[$product_id]['metadata']['wcmlim_sale_price_at_'. $location_id] = $product_meta['wcmlim_sale_price_at_'. $location_id];
                    $this->to_update_info[$product_id]['metadata']['_regular_price'] = $product_meta['_regular_price'];
                    $this->to_update_info[$product_id]['metadata']['_price'] = $product_meta['_price'];
                }

                if (stripos($key, 'stock_at_') !== false && $this->skip_inventory_update === false) {

                    foreach ($location_ids as $wc_loc_id => $cova_loc_id) {
                        $this->to_update_info[$product_id]['metadata']['wcmlim_stock_at_'. $wc_loc_id] = $product_meta['wcmlim_stock_at_'. $wc_loc_id];
                    }

                    $this->to_update_info[$product_id]['metadata']['_stock'] = $product_meta['_stock'];
                    $this->to_update_info[$product_id]['metadata']['_stock_status'] = $product_meta['_stock_status'];
                    $this->to_update_info[$product_id]['metadata']['package_quantities'] = $product_meta['package_quantities'];
                }

                if (stripos($key, 'package_at_') !== false || stripos($key, 'stock_at_') !== false) {
                    foreach ($product_meta as $mkey => $mval) {
                        if (preg_match('/^package_at_/', $mkey) === 1 || $mkey === 'packages') {
                            $this->to_update_info[$product_id]['metadata'][$mkey] = $mval;
                        }
                    }
                }
            }

            $this->get_products_metadata($product_ids);
            $this->to_update_info = apply_filters('cova_product_sync_to_update_info', $this->to_update_info, $this->products, $this->existing_product_metas);
        }
    }

} // end Class
