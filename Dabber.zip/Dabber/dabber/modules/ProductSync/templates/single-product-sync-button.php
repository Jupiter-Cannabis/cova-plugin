<?php if (!empty($args['catalog_id'])) : ?>

    <script>
        let cova_product_catalog_id = '<?php echo $args['catalog_id']; ?>';
        let cova_product_id = <?php echo $args['product_id']; ?>;

        Object.defineProperty(window, 'cova_sync_product', {
            value: function() {
                jQuery.ajax({
                    url: cova_sync.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'cova_sync_product_single',
                        params: {
                            catalog_id: cova_product_catalog_id,
                            product_id: cova_product_id
                        }
                    },
                    beforeSend: function() {
                        console.log('Sync in-progress.');
                    },
                    success: function(response) {
                        console.log('Sync complete.');
                        location.reload();
                    },
                    error: function(err) {
                        console.log(err);
                    },
                });
            }
        });
    </script>

<?php endif; ?>