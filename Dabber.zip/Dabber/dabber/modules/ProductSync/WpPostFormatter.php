<?php

namespace Dabber\Modules\ProductSync;

class WpPostFormatter
{
    private $category_mapping;
    private $location_ids;

    public function get_cova_products_formatted_data($cova_products_raw)
    {
        $this->location_ids = array_flip(dabber_get_location_ids());
        $products = [];
        $metadata = [];
        $product_taxonomies = [];
        $taxonomies = [];
        $formatted_packages = [];

        $this->category_mapping = get_option('cova_category_mapping');

        foreach ($cova_products_raw['Packages'] as $package_item) {
            if (!empty($package_item['Strain'])) {
                $formatted_packages[$package_item['PackageId']]['strain'] = $package_item['Strain'];
            }
            if (!empty($package_item['TerpeneProfile'])) {
                $terpenes = explode(',', $package_item['TerpeneProfile']);
                $formatted_packages[$package_item['PackageId']]['terpenes'] = array_filter(array_map('trim', $terpenes));
            }
            if (!empty($package_item['Cannabinoids'])) {
                foreach ($package_item['Cannabinoids'] as $cannabinoid) {
                    if ($cannabinoid['CannabinoidType'] === 'THC' && $cannabinoid['MeasurementType'] === 'Percent') {
                        $formatted_packages[$package_item['PackageId']]['thc_percent'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'THC' && $cannabinoid['MeasurementType'] === 'Milligram') {
                        $formatted_packages[$package_item['PackageId']]['thc_min'] = [
                            'value' => $cannabinoid['MinValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                        $formatted_packages[$package_item['PackageId']]['thc_max'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'THCa' && $cannabinoid['MeasurementType'] === 'Percent') {
                        $formatted_packages[$package_item['PackageId']]['thca_percent'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'THCa' && $cannabinoid['MeasurementType'] === 'Milligram') {
                        $formatted_packages[$package_item['PackageId']]['thca_min'] = [
                            'value' => $cannabinoid['MinValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                        $formatted_packages[$package_item['PackageId']]['thca_max'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }

                    if ($cannabinoid['CannabinoidType'] === 'CBD' && $cannabinoid['MeasurementType'] === 'Percent') {
                        $formatted_packages[$package_item['PackageId']]['cbd_percent'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'CBD' && $cannabinoid['MeasurementType'] === 'Milligram') {
                        $formatted_packages[$package_item['PackageId']]['cbd_min'] = [
                            'value' => $cannabinoid['MinValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                        $formatted_packages[$package_item['PackageId']]['cbd_max'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }

                    if ($cannabinoid['CannabinoidType'] === 'CBDN' && $cannabinoid['MeasurementType'] === 'Percent') {
                        $formatted_packages[$package_item['PackageId']]['cbdn_percent'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'CBDN' && $cannabinoid['MeasurementType'] === 'Milligram') {
                        $formatted_packages[$package_item['PackageId']]['cbdn_min'] = [
                            'value' => $cannabinoid['MinValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                        $formatted_packages[$package_item['PackageId']]['cbdn_max'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }

                    if ($cannabinoid['CannabinoidType'] === 'CBDA' && $cannabinoid['MeasurementType'] === 'Percent') {
                        $formatted_packages[$package_item['PackageId']]['cbda_percent'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                    if ($cannabinoid['CannabinoidType'] === 'CBDA' && $cannabinoid['MeasurementType'] === 'Milligram') {
                        $formatted_packages[$package_item['PackageId']]['cbda_min'] = [
                            'value' => $cannabinoid['MinValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                        $formatted_packages[$package_item['PackageId']]['cbda_max'] = [
                            'value' => $cannabinoid['MaxValue'],
                            'unit' => $this->format_unit_symbol($cannabinoid['MeasurementType'])
                        ];
                    }
                }
            }

            $formatted_packages[$package_item['PackageId']]['last_updated'] = $package_item['UpdatedDateUtc'];
        }

        $update_timestamps = [];

        foreach ($cova_products_raw['Products'] as $product_item) {

            $wc_product_details = $this->get_formatted_post_data($product_item, $formatted_packages);

            $products[$product_item['ProductId']] = $wc_product_details['product_details'];
            $metadata[$product_item['ProductId']] = $wc_product_details['meta_data'];
            $product_taxonomies[$product_item['ProductId']] = $wc_product_details['taxonomies'];

            foreach ($this->location_ids as $wc_loc_id) {
                if (isset($wc_product_details['meta_data']['last_updated_stock_at_' . $wc_loc_id])) {
                    $update_timestamps[$wc_product_details['meta_data']['cova_catalog_id']]['stock_at_' . $wc_loc_id] = $wc_product_details['meta_data']['last_updated_stock_at_' . $wc_loc_id];
                }
                if (isset($wc_product_details['meta_data']['last_updated_price_at_' . $wc_loc_id])) {
                    $update_timestamps[$wc_product_details['meta_data']['cova_catalog_id']]['price_at_' . $wc_loc_id] = $wc_product_details['meta_data']['last_updated_price_at_' . $wc_loc_id];
                }
                if (isset($wc_product_details['meta_data']['last_updated_package_at_' . $wc_loc_id])) {
                    $update_timestamps[$wc_product_details['meta_data']['cova_catalog_id']]['package_at_' . $wc_loc_id] = $wc_product_details['meta_data']['last_updated_package_at_' . $wc_loc_id];
                }
            }

            $update_timestamps[$wc_product_details['meta_data']['cova_catalog_id']]['product'] = $product_item['UpdatedDateUtc'];
        }

        $data = apply_filters(
            'dabber_product_sync_formatted_post_data',
            [
                'products' => $products,
                'metadata' => $metadata,
                'taxonomies' => $product_taxonomies,
                'packages' => $formatted_packages,
                'last_updated_info' => $update_timestamps
            ]
        );

        $product_ids = $this->get_cova_catalog_id_wc_id(array_keys($products));

        if (!empty($product_ids)) {
            foreach ($product_ids as $item_catalog_id => $item_product_id) {
                $data['products'][$item_catalog_id]['wc_id'] = $item_product_id;
            }
        }

        foreach ($data['taxonomies'] as $tax_terms) {

            $taxonomies = array_merge_recursive($tax_terms, $taxonomies);

            foreach ($taxonomies as &$value) {
                $value = array_unique($value);
            }

            unset($value);
        }

        $data['tax_terms'] = apply_filters('cova_product_sync_tax_terms', $taxonomies, $data);

        return $data;
    }

    /**
     * Convert unit name to unit symbol.
     * @param $unit_name
     * @return string
     */
    public function format_unit_symbol($unit_name)
    {
        $units = [
            'Percent' => '%',
            'Milligram' => 'mg',
            'Gram' => 'g',
            'Grams' => 'g'
        ];

        if (!isset($units[$unit_name])) {
            return '';
        }

        return $units[$unit_name];
    }

    /**
     * Get product IDs matching catalog IDs
     *
     * @return array
     */
    public function get_cova_catalog_id_wc_id($catalog_ids)
    {
        global $wpdb;

        $meta_values = implode(
            ',',
            array_map(
                function ($item) {
                    return "'" . esc_sql($item) . "'";
                },
                $catalog_ids
            )
        );

        $query = "
            SELECT post_id, meta_value
            FROM {$wpdb->postmeta}
            WHERE meta_key = 'cova_catalog_id'
            AND meta_value IN ({$meta_values})
        ";

        $result = $wpdb->get_results($query);

        if (empty($result)) {
            return [];
        }

        $product_ids = [];

        foreach ($result as $item) {
            $product_ids[$item->meta_value] = $item->post_id;
        }

        return $product_ids;
    }

    public function get_formatted_post_data($product_item, $formatted_packages)
    {
        return apply_filters(
            'dabber_post_formatted_cova_product',
            [
                'product_details' => $this->get_general_product_details($product_item),
                'meta_data' => $this->get_metadata($product_item, $formatted_packages),
                'taxonomies' => $this->get_taxonomies($product_item)
            ]
        );
    }

    public function get_general_product_details($product_item)
    {
        $date_added = date('Y-m-d H:i:s', strtotime($product_item['CreatedDateUtc']));
        $date_modified = date('Y-m-d H:i:s', strtotime($product_item['UpdatedDateUtc']));

        return [
            'post_author'       => 1,
            'post_date'         => $date_added,
            'post_date_gmt'     => $date_added,
            'post_content'      => $product_item['LongDescription'],
            'post_title'        => $product_item['Name'],
            'post_excerpt'      => $product_item['ShortDescription'],
            'post_status'       => 'import_pending',
            'post_name'         => dabber_sanitize_slug($product_item['Name']),
            'post_modified'     => $date_modified,
            'post_modified_gmt' => $date_modified,
            'post_type'         => 'product',
            'guid'              => $product_item['ProductId']
        ];
    }

    public function get_taxonomies($product_item)
    {
        $taxonomies = [];
        $classification_name = false;

        if (!empty(trim($product_item['ClassificationName']))) {
            $classification_name = $product_item['ClassificationName'];
            $taxonomies['product_cat'][] = $classification_name;
        }

        $online_menu = '';
        $strain = '';

        foreach ($product_item['ProductSpecifications'] as $item) {
            if ($item['DisplayName'] === 'Brand') {
                $taxonomies['product_brand'][] = $item['Value'];
            }
            if ($item['DisplayName'] === 'Online Menu Category' && $item['Value'] !== $classification_name && $classification_name !== false) {
                $taxonomies['product_cat'][] = $product_item['ClassificationName'] . '-' . $item['Value'];
                $online_menu = $product_item['ClassificationName'] . '-' . $item['Value'];
            }
            if ($item['DisplayName'] === 'Terpenes') {
                $separators = [",", ":", ";", "|"];
                $terpenes = preg_split("/(" . implode("|", array_map("preg_quote", $separators)) . ")/", $item['Value']);
                $taxonomies['terpenes'] = array_filter(array_map('trim', $terpenes));
            }
            if ($item['DisplayName'] === 'Strain') {
                $taxonomies['strain'][] = $item['Value'];
                $strain = $item['Value'];
            }
        }

        return apply_filters(
            'cova_product_sync_taxonomies',
            $taxonomies,
            [
                'classification' => $product_item['ClassificationName'],
                'online_menu' => $online_menu,
                'strain' => $strain
            ],
            $this->category_mapping
        );
    }

    public function get_metadata($product_item, $formatted_packages)
    {
        $metadata = [];

        $specifications = $this->format_product_specifications($product_item['ProductSpecifications']);
        $metadata['cova_specifications'] = $specifications;
        $metadata['cova_catalog_id'] = $product_item['ProductId'];
        $metadata['classification_id'] = $product_item['ClassificationId'];
        $metadata['cova_slug'] = $product_item['Slug'];
        $metadata['featured_image'] = (!empty($product_item['HeroShotUri'])) ? $product_item['HeroShotAssetId'] : '';

        $images = [];

        foreach ($product_item['Assets'] as $image) {
            if ($image['Id'] == $product_item['HeroShotAssetId']) {
                continue;
            }
            $images[] = $image['Id'];
        }

        $metadata['images'] = $images;

        $metadata['package_quantities'] = [];
        $total_stock = 0;

        // set default location quantities
        foreach ($this->location_ids as $cova_loc_id => $wc_loc_id) {
            $metadata['wcmlim_stock_at_' . $wc_loc_id] = 0;
        }

        if (!empty($product_item['Availability'])) {

            // Group availability by location so only one availability will be used based on package Received Date sortation
            $grouped_availability = array_reduce(
                $product_item['Availability'],
                function ($accumulator, $item) {
                    $accumulator[$item['LocationId']][] = $item;
                    return $accumulator;
                },
                []
            );
            $grouped_availability = array_intersect_key($grouped_availability, $this->location_ids);
            $package_quantities = [];

            foreach ($grouped_availability as $availability_items) {
                usort(
                    $availability_items,
                    function ($a, $b) {
                        // Filter out items with stock <= 0
                        if ($a['InStockQuantity'] <= 0) return 1;
                        if ($b['InStockQuantity'] <= 0) return -1;

                        // Sort by ascending date
                        return strtotime($a['ReceivedDate']) - strtotime($b['ReceivedDate']);
                    }
                );

                $location_stock = array_reduce($availability_items, function ($carry, $item) {
                    if (isset($item['InStockQuantity']) && is_numeric($item['InStockQuantity'])) {
                        $carry += $item['InStockQuantity'];
                    }
                    return $carry;
                }, 0);

                if (is_numeric($location_stock)) {
                    $total_stock += (float) $location_stock;
                }

                $sorted_package_items = array_values($availability_items);

                $package_quantities[$this->location_ids[$sorted_package_items[0]['LocationId']]][$sorted_package_items[0]['PackageId']] = $sorted_package_items[0]['InStockQuantity'];
                $metadata['wcmlim_stock_at_' . $this->location_ids[$sorted_package_items[0]['LocationId']]] = $location_stock;
                $metadata['package_at_' . $this->location_ids[$sorted_package_items[0]['LocationId']]] = $sorted_package_items[0]['PackageId'];
                $metadata['packages']['package_at_' . $this->location_ids[$sorted_package_items[0]['LocationId']]] = $sorted_package_items[0]['PackageId'];
                $metadata['last_updated_stock_at_' . $this->location_ids[$sorted_package_items[0]['LocationId']]] = $sorted_package_items[0]['UpdatedDateUtc'];

                if (isset($formatted_packages[$sorted_package_items[0]['PackageId']])) {
                    $metadata['last_updated_package_at_' . $this->location_ids[$sorted_package_items[0]['LocationId']]] = $formatted_packages[$sorted_package_items[0]['PackageId']]['last_updated'];
                }
            }

            $metadata['package_quantities'] = $package_quantities;
        }

        if (!empty($product_item['Prices'])) {

            foreach ($product_item['Prices'] as $price_item) {
                if (!$price_item['GroupName']) {
                    $metadata['wcmlim_regular_price_at_' . $this->location_ids[$price_item['LocationId']]] = $price_item['Price'];
                    $metadata['wcmlim_sale_price_at_' . $this->location_ids[$price_item['LocationId']]] = (isset($price_item['SalePrices'][0]['SalePrice'])) ? $price_item['SalePrices'][0]['SalePrice'] : '';
                    $metadata['_regular_price'] = $price_item['Price'];
                    $metadata['_price'] = $price_item['Price'];
                    $metadata['last_updated_price_at_' . $this->location_ids[$price_item['LocationId']]] = $price_item['UpdatedDateUtc'];
                }
            }
        }

        $metadata['cova_status'] = ($product_item['LifeCycle'] === 'Active') ? 'publish' : 'private';
        $metadata['_stock'] = $total_stock;
        $metadata['_stock_status'] = ($total_stock > 0) ? 'instock' : 'outofstock';
        $metadata['_sku'] = $product_item['CatalogSku'];
        $metadata['_tax_status'] = 'taxable';
        $metadata['_tax_class'] = '';
        $metadata['_manage_stock'] = 'yes';
        $metadata['_backorders'] = 'no';
        $metadata['_sold_individually'] = 'no';
        $metadata['_virtual'] = 'no';
        $metadata['_downloadable'] = 'no';
        $metadata['_product_version'] = (defined('WC_VERSION')) ? WC_VERSION : '';
        $metadata['last_updated_product_info'] = $product_item['UpdatedDateUtc'];

        $weight = $this->get_wc_weight($specifications);
        $metadata['_weight'] = $weight['value'];
        $metadata['weight_unit'] = $weight['unit'];

        $equivalent_weight = 0;
        $net_weight = 0;
        $metadata['equivalent_weight_unit'] = '';
        $metadata['net_weight_unit'] = '';

        foreach ($product_item['ProductSpecifications'] as $item) {
            if ($item['DisplayName'] === 'Equivalent To') {
                $equivalent_weight = $item['Value'];
                $metadata['equivalent_weight_unit'] = $item['Unit'];
            }
            if ($item['DisplayName'] === 'Net Weight') {
                $net_weight = $item['Value'];
                $metadata['net_weight_unit'] = $item['Unit'];
            }
        }

        $metadata['equivalent_weight'] = $equivalent_weight;
        $metadata['net_weight'] = $net_weight;

        return $metadata;
    }

    public function format_product_specifications($specifications)
    {
        $data = [];

        foreach ($specifications as $item) {
            $data['details'][sanitize_title($item['DisplayName'])] = [
                'Id' => $item['FieldId'],
                'StringId' => $item['StringId'],
                'DisplayName' => $item['DisplayName'],
                'Name' => $item['FieldName'],
                'Value' => $item['Value'],
                'Type' => $item['Type'],
                'Unit' => $item['Unit'],
            ];
        }

        return $data;
    }

    /**
     * Get weight based on store type
     *
     * @param  $specifications
     * @return array
     */
    public function get_wc_weight($specifications)
    {
        // use thc-content for new mexico
        if (isset($specifications['details']['retail-marijuana-product-type-new-mexico']['Value'])) {
            $retail_type = $specifications['details']['retail-marijuana-product-type-new-mexico']['Value'];

            if ($retail_type === 'Edible' && isset($specifications['details']['thc-content']['Value'])) {

                $value = $specifications['details']['thc-content']['Value'];
                $unit = $specifications['details']['thc-content']['Unit'];

                if ($unit === 'mg') {
                    $value = $value / 1000;
                }

                if ($value > 0) {
                    return [
                        'value' => $value,
                        'unit'  => $unit
                    ];
                }
            }
        }
        //---

        if (isset($specifications['details']['equivalent-to']['Value'])) {

            $value = $specifications['details']['equivalent-to']['Value'];
            $unit = $specifications['details']['equivalent-to']['Unit'];

            if ($unit === 'mg') {
                $value = $value / 1000;
            }

            if ($value > 0) {
                return [
                    'value' => $value,
                    'unit'  => $unit
                ];
            }
        }

        if (isset($specifications['details']['net-weight']['Value'])) {

            $value = $specifications['details']['net-weight']['Value'];
            $unit = $specifications['details']['net-weight']['Unit'];

            if ($unit === 'mg') {
                $value = $value / 1000;
            }

            if ($value > 0) {
                return [
                    'value' => $value,
                    'unit'  => $unit
                ];
            }
        }

        return [
            'value' => 0,
            'unit'  => ''
        ];
    }
} // end Class
