<?php

namespace Dabber\Modules\ProductSync;

class Frontend
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function display_single_product_page_sync_button()
    {
        if (!is_user_logged_in() && !current_user_can('administrator')) { // only display sync button when logged in as administrator.
            return;
        }

        global $post;

        if ($post->post_type != 'product') {
            return;
        }

        load_template(
            plugin_dir_path(__FILE__) .'templates/single-product-sync-button.php', true, [
                'product_id' => $post->ID,
                'catalog_id' => get_post_meta($post->ID, 'cova_catalog_id', true)
            ]
        );
    }
}