<?php

namespace Dabber\Modules\ProductSync;

use Dabber\Modules\ProductSync\SyncValidator\InventoryValidator;

class QuantityUpdater
{
    public $update_stock_num_limit = 100;
    public static $quantity_sync_key = 'cova_last_modified_stock_sync';
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function schedule_inventory_sync()
    {
        if (!wp_next_scheduled('cova_sync_inventory_by_last_modified_date')) {
            wp_schedule_event(time(), 'every_3_minutes', 'cova_sync_inventory_by_last_modified_date');
        }
    }

    public function initialize_inventory_update_by_last_modified_date()
    {
        $last_updated_timestamp = Updater::get_last_sync_modified_timestamp(self::$quantity_sync_key);
        $products_to_update =  $this->get_catalog_ids_to_update($last_updated_timestamp);

        do_action('cova_sync_specific_products_inventory', $products_to_update);

        Updater::save_last_sync_modified_timestamp(self::$quantity_sync_key, count($products_to_update), $this->update_stock_num_limit);
    }

    public function initialize_all_outdated_product_stock_fix()
    {
        // get all mismatched product stock.
        $products_to_update = InventoryValidator::compare_wc_cova_inventory(-1);

        if (empty($products_to_update)) {
            return;
        }

        $catalog_ids = [];

        foreach ($products_to_update as $item) {
            $catalog_ids[] = $item['catalog_id'];
        }

        do_action('cova_sync_specific_products_inventory', $catalog_ids);
    }

    public function get_catalog_ids_to_update($last_updated_timestamp)
    {
        $products = CovaAPI('v2')->catalog->get_update_as_of(
            $last_updated_timestamp['timestamp'], [
                "IncludeProductSkusAndUpcs" => false,
                "IncludeProductSpecifications" => false,
                "IncludeProductAssets" => false,
                "IncludeAvailability" => true,
                "IncludePackageDetails" => false,
                "IncludePricing" => false,
                "InStockOnly" => false,
                "SellingRoomOnly" => true,
                "Skip" => $last_updated_timestamp['skip'],
                "Top" => $this->update_stock_num_limit
            ]
        );

        if (empty($products['Products'])) {
            return [];
        }

        $catalog_ids = [];

        foreach ($products['Products'] as $item) {
            $catalog_ids[] = $item['ProductId'];
        }

        return $catalog_ids;
    }
}