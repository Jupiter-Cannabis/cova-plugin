<?php

namespace Dabber\Modules\ProductSync;

use Dabber\Modules\ProductSync\SimpleProduct\Update;
use Dabber\Modules\ProductSync\SyncValidator\InventoryValidator;

class ProductSync
{
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Product Sync',
        'description' => 'Handles product synchronization.'
    ];

    public function run()
    {
        add_action('wp_ajax_cova_import_sync_import_products', [Import::getInstance(), 'ajax_import_products']);
        add_action('wp_ajax_cova_update_sync_update_products', [Updater::getInstance(), 'ajax_update_products']);
        add_action('wp_ajax_cova_update_sync_update_all_products', [Updater::getInstance(), 'ajax_update_all_products']);
        add_action('wp_ajax_cova_update_sync_update_inventory', [Updater::getInstance(), 'ajax_update_inventory']);
        add_action('wp_ajax_cova_sync_product_single', [Updater::getInstance(), 'ajax_sync_single_product']);

        /**
         * Import products from COVA Hub to WC.
         * This action is added in CRON to run twice daily.
         */
        add_action('cova_import_products', [Import::getInstance(), 'initialize_product_import']);

        /**
         * Update products by last modified.
         * This action will update all product data except inventory since "cova_sync_inventory_by_last_modified_date" is running every 3 minutes.
         * This action is added to CRON to run every 30 minutes.
         */
        add_action('cova_update_products', [Updater::getInstance(), 'initialize_products_update']);

        /**
         * "Update Last Modified Products"
         * Always pull and sync all products that have changes from 7 days ago to current date.
         * This action is intended for manual sync only.
         * Not added to CRON.
         */
        add_action('cova_update_last_modified_products', [Updater::getInstance(), 'initialize_last_modified_products_update']);

        /**
         * Update all products, get products from ECOMM DB. "Update All Products".
         * This action is intended for manual syncing only.
         * Not added to CRON.
         */
        add_action('cova_update_all_products', [Updater::getInstance(), 'initialize_all_products_update']);

        /**
         * Utility hook.
         * Updates all specified product catalog IDs.
         * This action is intended for manual syncing only to cherry-pick products that need to be updated.
         * Not added to CRON.
         */
        add_action('cova_update_specific_products', [Updater::getInstance(), 'initialize_specific_product_update']);

        /**
         * Update all mismatched product inventory. "Update product Inventory"
         * This action is intended for manual syncing only to update all WC products mismatched stocks.
         * Not added to CRON.
         */
        add_action('cova_sync_inventory', [Updater::getInstance(), 'initialize_product_inventory_update']);

        /**
         * Utility hook.
         * Update selected products inventory.
         * This action is intended for manual inventory update for selected products.
         * Not added to CRON.
         */
        add_action('cova_sync_specific_products_inventory', [Updater::getInstance(), 'initialize_specific_product_inventory_update']);


        /**
         * Update products inventory based on last modified date.
         * Added to CRON and runs every 3 minutes.
         */
        add_action('cova_sync_inventory_by_last_modified_date', [QuantityUpdater::getInstance(), 'initialize_inventory_update_by_last_modified_date']);

        /**
         * Update all mismatched product stock in the background process.
         * Added to CRON and runs every 3 hours daily.
         */
        add_action('cova_fix_all_outdated_product_stock', [QuantityUpdater::getInstance(), 'initialize_all_outdated_product_stock_fix']);

        add_filter('cron_schedules', [$this, 'add_cron_schedules']);
        add_action('init', [Import::getInstance(), 'schedule_product_import']);
        add_action('init', [Updater::getInstance(), 'schedule_product_update']);
        add_action('init', [QuantityUpdater::getInstance(), 'schedule_inventory_sync']);

        add_action('admin_init', [InventoryValidator::getInstance(), 'validate_inventory']);

        add_action('admin_footer', [Frontend::getInstance(), 'display_single_product_page_sync_button'], 0);
    }

    public function add_cron_schedules($schedules)
    {
        $schedules['every_3_minutes'] = [
            'interval' => 180,
            'display'  => __('Every 3 minutes', 'dabber'),
        ];

        $schedules['every_5_minutes'] = [
            'interval' => 300,
            'display'  => __('Every 5 minutes', 'dabber'),
        ];

        $schedules['every_15_minutes'] = [
            'interval' => 900,
            'display'  => __('Every 15 minutes', 'dabber'),
        ];

        $schedules['every_30_minutes'] = [
            'interval' => 1800,
            'display'  => __('Every 30 minutes', 'dabber'),
        ];

        return $schedules;
    }
}
