<?php

namespace Dabber\Modules\Agegate;

class Agegate
{
    public $options = [];

    public static $enable_default = true;
    public static $module_info = [
        'name' => 'Age Gate',
        'description' => ''
    ];

    public function run()
    {
        add_action('init', [$this, 'load_options']);
        add_action('dabber_admin_module_save_settings_general_settings', [$this, 'save_settings']);
        add_action('dabber_render_module_admin_section_general_settings', [$this, 'render_settings'], 11);
        add_action('wp_footer', [$this, 'loadTemplate'], 9999);
    }

    public function render_settings()
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/admin-settings.php', true, $this->options);
    }

    public function load_options()
    {
        $this->options = [
            'key' => get_option('dabber_agegate_key')
        ];
    }

    public function save_settings($post_data)
    {
        update_option('dabber_agegate_key', sanitize_text_field($post_data['dabber_agegate_key']));
    }

    public function loadTemplate()
    {
        load_template(plugin_dir_path(__FILE__) . 'templates/agegate.php', true, $this->options);
    }
}
