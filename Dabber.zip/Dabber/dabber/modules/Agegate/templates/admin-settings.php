<hr>
<h2><?php _e('Age Gate', 'cova') ?></h2>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row"><?php _e('Age gate key', 'cova') ?></th>
        <td>
            <fieldset>
                <label for="cova-enable-push-order">
                    <input type="text" name="dabber_agegate_key" value="<?php echo $args['key'] ?>">
                </label>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
