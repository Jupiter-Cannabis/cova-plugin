<script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="<?php echo $args['key'] ?>"></div>
