<?php

namespace Dabber\Modules\CovaOrderSync;

use CovaAPI\SalesOrder;
use Dabber\Modules\CustomerSync\CovaCustomerHandler;
use Monolog;

class CovaOrders
{
    private static $instance = null;

    public $cova_order_status = [
        'InProgress'        => 'in-progress',
        'OrderPlaced'       => 'processing',
        'ReadyForPickup'    => 'ready-pickup'
    ];

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new CovaOrders();
        }

        return self::$instance;
    }

    public function place_cova_order($order_id)
    {
        do_action('cova_place_order', $order_id);
    }

    public function add_shipping_fee_to_cova_order($shipping_fee, $order)
    {
        global $dabber_current_cova_location_id;

        $shipping_catalog = [];

        foreach( $order->get_items('shipping') as $item ){
            $item_data = $item->get_data();
            $shipping_catalog = get_option('woocommerce_'. $item_data['method_id'] .'_'. $item_data['instance_id'] .'_settings');

            if (!isset($shipping_catalog['cova_shipping_catalog_id'])) {
                return $shipping_fee;
            }
            break;
        }

        if (empty($shipping_catalog['cova_shipping_catalog_id'])) {
            return false;
        }

        return [
            'catalog_id' => $shipping_catalog['cova_shipping_catalog_id'],
            'amount' => $shipping_catalog['cova_shipping_location_prices'][$dabber_current_cova_location_id]
        ];
    }

    public function validate_product_quantities()
    {
        global $dabber_current_location_data;

        $cart = WC()->cart->get_cart_contents();
        $cart_items = [];

        foreach ($cart as $item) {
            $catalog_id = $item['data']->get_meta('cova_catalog_id');
            $cart_items[$catalog_id] = [
                'product_id' => $item['data']->get_id(),
                'name' => $item['data']->get_title(),
                'batch_id' => $item['product-batch-id'],
                'quantity' => (float) $item['quantity'],
                'sellAtPricePerUnit' => (float) number_format($item['data']->get_price(), 2)
            ];
        }

        $products = CovaAPI('v2')->catalog->get_detailed_products_by_catalog_ids([
            'LocationId' => $dabber_current_location_data['cova_location_id'],
            'IncludeProductSkusAndUpcs' => false,
            'IncludeProductSpecifications' => false,
            'IncludeProductAssets' => false,
            'IncludeAvailability' => true,
            'IncludePackageDetails' => false,
            'IncludePricing' => false,
            'InStockOnly' => false,
            'SellingRoomOnly' => true,
            'ProductIds' => array_keys($cart_items)
        ]);

        if (empty($products['Products'])) {
            $message = __('Apologies, our current inventory doesn\'t cover the full quantity in your cart. We regret any inconvenience this may cause.', "woocommerce");
            cova_add_wc_notice($message, 'error');
            return;
        }

        $cova_order_items = [];

        foreach ($products['Products'] as $cova_product) {

            // Check if the product has any stock.
            if (empty($cova_product['Availability'])) {
                $message = __('Sorry, we do not have enough <strong>'. $cova_product['Name'] .'</strong> in stock to fulfill your order (0 available). We apologize for any inconvenience caused', "woocommerce");
                cova_add_wc_notice($message, 'error');
                return;
            }

            // Sort packages by FIFO based on ReceivedDate
            usort(
                $cova_product['Availability'], function ($a, $b) {
                // Filter out items with stock <= 0
                if ($a['InStockQuantity'] <= 0) return 1;
                if ($b['InStockQuantity'] <= 0) return -1;

                // Sort by ascending date
                return strtotime($a['ReceivedDate']) - strtotime($b['ReceivedDate']);
            });

            $total_availability = array_sum(array_column($cova_product['Availability'], 'InStockQuantity'));

            // Check if quantity added to cart is greater than the total availability.
            if ($cart_items[$cova_product['ProductId']]['quantity'] > $total_availability) {
                $message = __('Sorry, we do not have enough <strong>'. $cova_product['Name'] .'</strong> in stock to fulfill your order ('. $total_availability .' available). We apologize for any inconvenience caused', "woocommerce");
                cova_add_wc_notice($message, 'error');
                return;
            }

            // At this point, the cova hub validates that it has enough stock for all items added to the cart.

            $total_batch_qty = 0;

            // $cova_product['Availability'] is already sorted by last received date in a FIFO sorting.
            foreach ($cova_product['Availability'] as $stock_item) {
                $cart_item = $cart_items[$cova_product['ProductId']];
                if ($stock_item['InStockQuantity'] >= $cart_item['quantity']) { // if cova stock is sufficient.
                    $cova_order_items[] = array_filter([
                        'name' => $cart_item['name'],
                        'catalogItemId' => $cova_product['ProductId'],
                        'quantity' => (float) $cart_item['quantity'] - $total_batch_qty,
                        'sellAtPricePerUnit' => (float) $cart_item['sellAtPricePerUnit'],
                        'PackageId' => $stock_item['PackageId']
                    ]);
                    break;
                }

                /**
                 * If cova batch stock isn't sufficient, add another item with sufficient batch stock.
                 * The process keeps going until the cart quantity is fulfilled.
                 */
                if ($total_batch_qty < $cart_item['quantity']) {
                    if ($stock_item['InStockQuantity'] <= 0) {
                        continue;
                    }

                    $to_add = $cart_item['quantity'] - $total_batch_qty;
                    $add_qty = ($stock_item['InStockQuantity'] <= $to_add)? $stock_item['InStockQuantity'] : $to_add;

                    $cova_order_items[] = array_filter([
                        'name' => $cart_item['name'],
                        'catalogItemId' => $cova_product['ProductId'],
                        'quantity' => (float) $add_qty,
                        'sellAtPricePerUnit' => (float) $cart_item['sellAtPricePerUnit'],
                        'PackageId' => $stock_item['PackageId']
                    ]);

                    $total_batch_qty += $add_qty;
                } else {
                    break;
                }
            }
        }

        $order_location_items = [];

        foreach ($cart_items as $order_item) {
            $order_location_items[$order_item['product_id']] = $order_item['quantity'];
        }

        $_POST['cova_order_items'] = $cova_order_items;
        $_POST['cova_order_location_items'] = [
            $dabber_current_location_data['wc_location_id'] => $order_location_items
        ];
    }

    public function create_order_callback($order_id)
    {
        global $cova_api_auth;

        $order = wc_get_order($order_id);

        if (!$order) {
            return false;
        }

        $cova_order_id = get_post_meta($order_id, 'cova_order_id', true);

        if (trim($cova_order_id) || !isset($cova_api_auth->credentials['company_id'])) { // bail if cova_order_id is already generated.
            return false;
        }

        $cova_location_id = WcOrders::get_order_location($order);
        $customer_id = 0;

        $order_guid = dabber_generate_guid();

        update_post_meta($order_id, 'cova_order_guid', $order_guid);

        $order_items = WcOrders::get_order_items_by_location($order);

        $cova_order_data = [
            'order_id'      => $order_guid,
            'IntegratorId'  => dabber_get_integrator_id(),
            'CompanyId'     => $cova_api_auth->credentials['company_id'],
            'EntityId'      => $cova_location_id['cova_location_id'],
            'FirstName'     => $order->get_billing_first_name(),
            'LastName'      => $order->get_billing_last_name(),
            'customerId'    => $customer_id,
            'IsDelivery'    => WcOrders::is_delivery($order),
            'Items'         => $order_items
        ];

        $enable_push_order = get_option('cova_enable_push_order');

        update_post_meta($order_id, 'cova_order_items', $order_items);

        if ($enable_push_order !== 'yes' || $cova_order_data['Items'] === false) {
            return false;
        }

        update_post_meta($order_id, 'cova_order_id', '');
        update_post_meta($order_id, 'cova_order_status', 0);
        update_post_meta($order_id, 'cova_order_version', 'v2'); // set order version to ignore orders from older versions to perform additional queries

        $cova_order_data['customerId'] = CovaCustomerHandler::get_cova_customer_id($order->get_billing_email(), $order);
        $cova_order_data = apply_filters('dabber_cova_order_data', $cova_order_data, $order);

        $salesorder = new \CovaAPI\SalesOrder();
        $new_order  =  json_decode($salesorder->create_order_v2($cova_order_data), true);

        cova_debugger(['api_order_response' => $new_order, '$cova_order_data' => $cova_order_data]);

        if (!isset($new_order['id'])) {
            return false;
        }

        update_post_meta($order_id, 'cova_order_id', $new_order['id']);

        if (WcOrders::is_online_payment($order)) {
            update_post_meta($order_id, 'dabber_is_order_payment_online', 'yes');
            update_post_meta($order_id, 'dabber_cova_order_data', $new_order);
        }

        do_action('dabber_after_cova_push_order', $new_order, $order);

        return true;
    }

    public function sync_order_status_callback()
    {
        $orders_to_sync = WcOrders::get_wc_order_to_update();

        foreach ($orders_to_sync as $order) {

            $cova_order_id = get_post_meta($order->ID, 'cova_order_id', true);
            $cova_order_status = CovaOrders::get_cova_order_status($cova_order_id);

            $wc_order = wc_get_order($order->ID);

            if ($cova_order_status['orderStatus'] === 'Cancelled') {
                $new_status = 'cancelled';
                update_post_meta($order->ID, 'cova_order_status', $new_status);
            } elseif($cova_order_status['orderStatus'] === 'Completed') {
                $new_status = 'completed';
                update_post_meta($order->ID, 'cova_order_status', $new_status);
            } elseif($cova_order_status['orderStatus'] === 'NonTransientProcessingFailure') {
                $new_status = 'failed';
                $this->HandleNonTransientProcessingFailure($cova_order_status['orderMessage'], $cova_order_id, $order->ID);
            } elseif ($this->cova_order_status[$cova_order_status['orderFulfillmentStatus']] === 'ready-pickup' && WcOrders::is_delivery($wc_order)) {
                $new_status = 'ready-delivery';
            } else {
                $new_status = $this->cova_order_status[$cova_order_status['orderFulfillmentStatus']];
            }

            $wc_order->set_status($new_status);
            $wc_order->save();

            wp_update_post(
                [
                'post_type' => 'shop_order',
                'ID' => $order->ID,
                'post_status' => 'wc-'. $new_status
                ]
            );
        }
    }

    private function HandleNonTransientProcessingFailure($failureMessage, $covaOrderId, $wcOrderId)
    {
        //Update the woo commerce order status to Failed.
        $new_status = 'failed';
        update_post_meta($wcOrderId, 'cova_order_status', $new_status);

        //Log an error into the logging system with the order details, and, the error details.
        // -Build the error details
        $errorData = print_r(
            [
            'orderStatus ' => 'NonTransientProcessingFailure',
            'message' => $failureMessage,
            'covaOrderId'  => $covaOrderId,
            'wcOrderID'    => $wcOrderId,
            'companyId' => get_company_id(),
            'timestamp' => date('Y-m-d H:i:s')
            ], true
        ); 

        // -Log it
        cova_LogglyLogger($errorData, 'NonTransientProcessingFailure', 'OrderStatusLogger', Monolog\Logger::ERROR);
    }

    public static function maybe_mark_as_paid($order)
    {
        global $cova_api_auth;

        $cova_order_id = get_post_meta($order->get_id(), 'cova_order_id', true);

        if (!$cova_order_id) {
            return false;
        }

        $cova_order_data = get_post_meta($order->get_id(), 'dabber_cova_order_data', true);

        $args = [
            'SaleID' => $cova_order_id,
            'CompanyId' => $cova_api_auth->credentials['company_id'],
            'TrackingNumber' => 'N/A',
            'Payments' => [
                [
                    'PreAuthorizationToken' => 'N/A',
                    'Amount' => (float) $order->get_total(),
                    'TimeTakenUtc' => $cova_order_data['dateCreatedUtc']
                ]
            ]
        ];

        $last_4 = get_post_meta($order->get_id(), 'last_4_digits', true);

        if ($last_4 && strlen($last_4) == 4) {
            $args['Payments'][0]['Last4Digits'] = $last_4;
        }

        cova_debugger($args);

        $sales_order = new SalesOrder();
        $response = $sales_order->set_to_paid($args);

        /**
         * @todo contact cova for endpoint response
         * @todo add condition based on response
         */
        update_post_meta($order->get_id(), 'dabber_order_is_marked_paid', 'yes');

        return json_decode($response);
    }

    public static function get_cova_order_status($cova_order_id)
    {
        $salesorder  = new \CovaAPI\SalesOrder();
        $order =  json_decode($salesorder->status($cova_order_id), true);

        if (!isset($order['orderStatus'])) {
            return false;
        }

        return $order;
    }

    public function save_order_last4($order, $response)
    {
        update_post_meta($order->get_id(), 'last_4_digits', $response->get_data()->card->lastDigits);
    }
}
