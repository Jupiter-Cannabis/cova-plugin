<?php

namespace Dabber\Modules\CovaOrderSync;

use Cova_Integration\Cova_Data_Manager;

/**
 * WC order UI mods
 */
class OrdersAdminUI
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new OrdersAdminUI();
        }

        return self::$instance;
    }

    public function add_custom_order_details_field($order)
    {
        $cova_id = get_post_meta($order->get_id(), 'cova_order_id', true);

        load_template(
            plugin_dir_path(__FILE__) .'templates/cova-order-id-field.php', true, [
            'cova_id'       => $cova_id,
            'has_cova_id'   => ($cova_id)? 1 : 0,
            'order_id'      => $order->get_id()
            ]
        );
    }

    /**
     * Add custom field to WC flat rate shipping settings
     *
     * @param  $fields
     * @return mixed
     */
    public function add_shipping_flat_rate_settings($fields)
    {
        $fields['cova_shipping_catalog_id'] = [
            'title' => __('Cova Shipping Catalog ID', 'dabber'),
            'type' => 'text',
            'placeholder' => '',
            'default' => ''
        ];

        return $fields;
    }

    public function add_shipping_by_drawing_settings($fields)
    {
        $new_fields = [];

        $new_fields['cova_shipping_catalog_id'] = [
            'title' => __('Cova Shipping Catalog ID', 'dabber'),
            'type' => 'text',
            'placeholder' => '',
            'default' => ''
        ];

        return array_merge($new_fields, $fields);
    }


    public function modify_shipping_method_option_value($settings, $object)
    {
        $locations = Cova_Data_Manager::get_global_data('locations', true);
        $shipping_prices = [];

        foreach ($locations as $loc_data) {
            $pricing = Cova_Data_Manager::get_global_data('pricing-'. $loc_data['Id'], true);

            if (!isset($pricing[$loc_data['Id']][$settings['cova_shipping_catalog_id']])) {
                continue;
            }

            foreach ($pricing[$loc_data['Id']][$settings['cova_shipping_catalog_id']] as $price) {
                $shipping_prices[$loc_data['Id']] = $price['RegularPrice'];
            }
        }

        $settings['cova_shipping_location_prices'] = $shipping_prices;

        return $settings;
    }

    public function register_custom_order_status($statuses)
    {
        $statuses['wc-ready-pickup']    = __('Ready For Pickup', 'dabber');
        $statuses['wc-ready-delivery']  = __('Ready For Delivery', 'dabber');
        $statuses['wc-in-progress']     = __('In Progress', 'dabber');

        $statuses['wc-processing'] = __('Order Placed', 'dabber');

        return $statuses;
    }

    public function modify_order_status_label_count($statuses)
    {
        $statuses['wc-processing']['label_count'] = _n_noop('Order Placed <span class="count">(%s)</span>', 'Order Placed <span class="count">(%s)</span>', 'woocommerce');
        return $statuses;
    }

    public function register_custom_order_post_status()
    {
        register_post_status(
            'wc-ready-pickup', [
            'label'                     => __('Ready For Pickup', 'dabber'),
            'public'                    => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list'    => true,
            'exclude_from_search'       => false
             ]
        );

        register_post_status(
            'wc-ready-delivery', [
            'label'                     => __('Ready For Delivery', 'dabber'),
            'public'                    => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list'    => true,
            'exclude_from_search'       => false
             ]
        );

        register_post_status(
            'wc-in-progress', [
            'label'                     => __('In Progress', 'dabber'),
            'public'                    => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list'    => true,
            'exclude_from_search'       => false
             ]
        );
    }

}
