<p class="form-field form-field-wide cova_order_id" style=" display: flex; flex-direction: row;">
    <input type="text" value="<?php echo $args['cova_id'] ?>" readonly="readonly">

    <?php if(!$args['has_cova_id']) : ?>
        <button id="dabber-push-order" type="button" class="button" style=" margin-left: 3px; ">Push to Cova</button>
    <?php endif; ?>
</p>

<script>
    (function($)
    {
        let script_vars = <?php echo json_encode(
            [
            'ajax_url' => admin_url('admin-ajax.php'),
            'order_id' => $args['order_id']
            ]
        ) ?>;

        $(document).ready(function()
        {
             $('#dabber-push-order').click(function(e)
             {
                 e.preventDefault();

                 if (confirm('Are you sure you want to push this order to cova database?')) {
                     $.ajax({
                         url: script_vars.ajax_url,
                         type: 'POST',
                         data: {
                             action: 'dabber_push_cova_order',
                             order_id: script_vars.order_id
                         },
                         beforeSend: function() {

                         },
                         success: function( response ) {
                             if (response.data.is_order_pushed === true) {
                                 alert('Order successfully pushed to cova Database');
                             } else {
                                 alert('Failed to push order!');
                             }
                         },
                         error: function() {}
                     });
                 }
             });
        });
    })(jQuery);
</script>
