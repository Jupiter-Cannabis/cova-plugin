<?php

namespace Dabber\Modules\CovaOrderSync;

class Cron
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new Cron();
        }

        return self::$instance;
    }

    public function add_cron_schedules()
    {
        $schedules['every_minute'] = array(
            'interval' => 60,
            'display'  => __('Every minute', 'cova'),
        );

        $schedules['every_5_minutes'] = array(
            'interval' => 60 * 5,
            'display'  => __('Every 5 minutes', 'cova'),
        );

        return $schedules;
    }

    public function add_scheduled_event()
    {
        if (! wp_next_scheduled('cova_cron_update_wc_order_status') ) {
            wp_schedule_event(time(), 'every_minute', 'cova_cron_update_wc_order_status');
        }
        if (! wp_next_scheduled('dabber_event_update_failed_orders') ) {
            wp_schedule_event(time(), 'every_5_minutes', 'dabber_event_update_failed_orders');
        }
    }

    public function cron_update_order_status_callback()
    {
        do_action('cova_update_wc_order_status');
        do_action('dabber_set_order_payment');
    }

    public function set_order_payment_callback()
    {
        $orders = WcOrders::get_to_set_paid_orders();

        foreach($orders as $order) {
            $wc_order = wc_get_order($order->ID);
            CovaOrders::maybe_mark_as_paid($wc_order);
        }
    }

    public function event_update_failed_orders_callback()
    {
        $orders_to_sync = WcOrders::get_wc_failed_orders();

        if (empty($orders_to_sync)) {
            return;
        }

        foreach ($orders_to_sync as $item) {
            do_action('cova_place_order', $item->ID);
        }
    }
}
