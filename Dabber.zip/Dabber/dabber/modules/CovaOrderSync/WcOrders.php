<?php

namespace Dabber\Modules\CovaOrderSync;

class WcOrders
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new WcOrders();
        }

        return self::$instance;
    }

    public function set_payinstore_methods($methods)
    {
        $methods[] = 'cod';

        return $methods;
    }

    public static function is_online_payment($order)
    {
        if (in_array($order->get_payment_method(), apply_filters('dabber_payinstore_methods', []))) {
            return false;
        }

        return true;
    }

    public static function is_delivery($order)
    {
        $shipping = $order->get_items('shipping');
        $shipping = array_shift($shipping);

        if (empty($shipping) || stripos('local_pickup', $shipping->get_method_id()) !== false) {
            return false;
        }

        if ($order->get_payment_method() === 'cod') {
            return false;
        }

        return true;
    }

    public static function get_order_location($order)
    {
        return get_post_meta($order->get_id(), 'cova_order_location_id', true);
    }

    public function add_order_location_id_meta($order_id, $data)
    {
        global $dabber_current_location_data;

        update_post_meta($order_id, 'cova_order_location_id', [
            'wc_location_id' => $dabber_current_location_data['wc_location_id'],
            'cova_location_id' => $dabber_current_location_data['cova_location_id']
        ]);
    }

    public function save_cova_order_line_items($order_id, $data)
    {
        if (!empty($_POST['cova_order_items'])) {
            update_post_meta($order_id, 'cova_order_items', $_POST['cova_order_items']);
        }

        if (!empty($_POST['cova_order_location_items'])) {
            update_post_meta($order_id, 'cova_order_location_items', $_POST['cova_order_location_items']);
        }
    }

    public static function get_order_items_by_location($order)
    {
        $cova_order_items = get_post_meta($order->get_id(), 'cova_order_items', true);

        if (empty($cova_order_items)) {
            return false;
        }

        $order_items = [];

        foreach ($cova_order_items as $order_item) {
            $order_items[] = $order_item;
        }

//        foreach ($order->get_items() as $key => $item) {
//
//            $product = $item->get_product();
//
//            if (!$product) {
//                continue;
//            }
//
//            $sell_price = $product->get_price();
//
//            $item_data = [
//                'name' => $item->get_name(),
//                'catalogItemId' => apply_filters('dabber_order_item_catalog_id', get_post_meta($product->get_id(), 'cova_catalog_id', true), $product),
//                'quantity' => $item['quantity'],
//                'sellAtPricePerUnit' => number_format($sell_price, 2)
//            ];
//
//            $order_items[] = apply_filters('dabber_order_item_data', $item_data, $item);
//        }

        $shipping_fee_product = apply_filters('dabber_shipping_fee_product', false, $order);

        if ($shipping_fee_product !== false) {
            $order_items[] = [
                'name' => 'Shipping Fee',
                'catalogItemId' => $shipping_fee_product['catalog_id'],
                'quantity' => 1,
                'sellAtPricePerUnit' => $shipping_fee_product['amount']
            ];
        }

        return apply_filters('dabber_order_items', $order_items);
    }

    public static function get_wc_failed_orders()
    {
        $orders = new \WP_Query(
            [
            'post_type' => 'shop_order',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_order_id',
                    'value' => '',
                    'compare' => '='
                ],
                [
                    'key' => 'cova_order_status',
                    'value' => '0',
                    'compare' => '='
                ]
            ]
            ]
        );

        if (empty($orders->posts)) {
            return [];
        }

        return $orders->posts;
    }

    public static function get_to_set_paid_orders()
    {
        $orders = new \WP_Query(
            [
            'post_type' => 'shop_order',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_order_version',
                    'value' => 'v2',
                    'compare' => '='
                ],
                [
                    'key' => 'dabber_is_order_payment_online',
                    'value' => 'yes',
                    'compare' => '='
                ],
                [
                    'key' => 'dabber_order_is_marked_paid',
                    'value' => '',
                    'compare' => 'NOT EXISTS'
                ]
            ]
            ]
        );

        if (empty($orders->posts)) {
            return [];
        }

        return $orders->posts;
    }

    public static function get_wc_order_to_update()
    {
        $orders = new \WP_Query(
            [
            'post_type' => 'shop_order',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_order_version',
                    'value' => 'v2',
                    'compare' => '='
                ],
                [
                    'key' => 'cova_order_id',
                    'value' => '',
                    'compare' => '!='
                ],
                [
                    'key' => 'cova_order_status',
                    'value' => '0',
                    'compare' => '='
                ]
            ]
            ]
        );

        if (empty($orders->posts)) {
            return [];
        }

        return $orders->posts;
    }
}
