<?php

namespace Dabber\Modules\CovaOrderSync;

class OrdersAjax
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new OrdersAjax();
        }

        return self::$instance;
    }

    public function ajax_push_order_to_cova()
    {
        if (!isset($_POST['order_id'])) {
            wp_send_json_success(
                [
                'status' => 'ok',
                'is_order_pushed' => false
                ]
            );
        }

        $cova_order = CovaOrders::getInstance();

        wp_send_json_success(
            [
            'status' => 'ok',
            'is_order_pushed' => $cova_order->create_order_callback($_POST['order_id'])
            ]
        );
    }
}
