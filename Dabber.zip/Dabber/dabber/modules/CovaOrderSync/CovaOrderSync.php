<?php

namespace Dabber\Modules\CovaOrderSync;

use Cova_Integration\Cova_Data_Manager;

class CovaOrderSync
{
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Cova Order Sync',
        'description' => 'Handles WC orders and Cova sales order synchronization.'
    ];

    public function run()
    {
        add_filter('dabber_payinstore_methods', [WcOrders::getInstance(), 'set_payinstore_methods']);

        /**
         * Custom UI
         */
        add_filter('woocommerce_shipping_instance_form_fields_flat_rate', [OrdersAdminUI::getInstance(), 'add_shipping_flat_rate_settings'], 100);
        add_filter('woocommerce_shipping_instance_form_fields_szbd-shipping-method', [OrdersAdminUI::getInstance(), 'add_shipping_by_drawing_settings'], 100);
        add_filter('woocommerce_shipping_flat_rate_instance_settings_values', [OrdersAdminUI::getInstance(), 'modify_shipping_method_option_value'], 100, 2);
        add_filter('woocommerce_shipping_szbd-shipping-method_instance_settings_values', [OrdersAdminUI::getInstance(), 'modify_shipping_method_option_value'], 100, 2);
        add_filter('wc_order_statuses', [OrdersAdminUI::getInstance(), 'register_custom_order_status']);
        add_filter('woocommerce_register_shop_order_post_statuses', [OrdersAdminUI::getInstance(), 'modify_order_status_label_count']);
        add_action('woocommerce_admin_order_data_after_order_details', [OrdersAdminUI::getInstance(), 'add_custom_order_details_field']);
        add_action('init', [OrdersAdminUI::getInstance(), 'register_custom_order_post_status']);

        /**
         * Cova order functions
         */
        add_filter('dabber_shipping_fee_product', [CovaOrders::getInstance(), 'add_shipping_fee_to_cova_order'], 100, 2);
        add_action('woocommerce_thankyou', [CovaOrders::getInstance(), 'place_cova_order'], 100);
        add_action('woocommerce_payment_complete', [CovaOrders::getInstance(), 'place_cova_order'], 100);
        add_action('cova_place_order', [CovaOrders::getInstance(), 'create_order_callback']);
        add_action('wc_paysafe_payment_response_processed', [CovaOrders::getInstance(), 'save_order_last4'], 100, 2);
        add_action('cova_update_wc_order_status', [CovaOrders::getInstance(), 'sync_order_status_callback']);

        add_action('wp_ajax_dabber_push_cova_order', [OrdersAjax::getInstance(), 'ajax_push_order_to_cova']);
        add_action('woocommerce_before_checkout_process', [CovaOrders::getInstance(), 'validate_product_quantities']);

        add_action('woocommerce_checkout_update_order_meta', [WcOrders::getInstance(), 'add_order_location_id_meta'], 10, 2);
        add_action('woocommerce_checkout_update_order_meta', [WcOrders::getInstance(), 'save_cova_order_line_items'], 100, 2);

        /**
         * Cron schedules
         */
        add_filter('cron_schedules', [Cron::getInstance(), 'add_cron_schedules']);
        add_action('admin_init', [Cron::getInstance(), 'add_scheduled_event']);
        add_action('dabber_set_order_payment', [Cron::getInstance(), 'set_order_payment_callback']);
        add_action('cova_cron_update_wc_order_status', [Cron::getInstance(), 'cron_update_order_status_callback']);
        add_action('dabber_event_update_failed_orders', [Cron::getInstance(), 'event_update_failed_orders_callback']);
    }
}
