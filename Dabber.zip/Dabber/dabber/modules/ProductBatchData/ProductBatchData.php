<?php

namespace Dabber\Modules\ProductBatchData;

use Cova_Integration\Cova_Data_Manager;

class ProductBatchData
{
    public static $must_use = false;
    public static $module_info = [
        'name' => 'Product Batch Data',
        'description' => 'Add support for product details by batch ID.'
    ];

    public static $map_meta = [
        'thc_min' => '',
        'thc_max' => '',
        'thc_percent' => '',
        'thca_min' => '',
        'thca_max' => '',
        'thca_percent' => '',
        'cbd_min' => '',
        'cbd_max' => '',
        'cbd_percent' => '',
        'cbdn_min' => '',
        'cbdn_max' => '',
        'cbdn_percent' => '',
        'cbda_min' => '',
        'cbda_max' => '',
        'cbda_percent' => '',
    ];
    private $map_taxonomy = [
        'product_cat' => [],
        'terpenes' => [],
        'strain' => []
    ];

    public function run()
    {
        add_action('init', [Taxonomies::getInstance(), 'register_taxonomies']);

        add_filter('dabber_product_sync_formatted_post_data', [$this, 'map_batch_data_fields'], 20);
        add_filter('cova_product_sync_to_update_info', [$this, 'add_to_update_info_items'], 10, 3);

        add_action('cova_sync_locations', [$this, 'create_package_based_taxonomies']);

        add_filter('woocommerce_add_cart_item_data', [$this, 'add_cart_batch_id_data'], 100, 3);
        add_filter('woocommerce_get_item_data', [$this, 'add_batch_id_item_data'], 10, 2);
        add_action('woocommerce_before_add_to_cart_button', [$this, 'render_custom_fields'], 10);
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'add_batch_id_meta_to_order'], 10, 4);

        add_filter('woocommerce_add_to_cart_validation', [$this, 'validate_add_to_cart'], 9999, 5);
        add_filter('woocommerce_update_cart_validation', [$this, 'validate_cart_page_add_to_cart'], 9999, 4);

        add_filter('woocommerce_notice_types', [$this, 'add_custom_cart_notice']);
        add_filter('wc_get_template', [$this, 'add_notice_template'], 10, 5);
        add_action('wp_head', [$this, 'add_notice_style']);
    }

    public function add_custom_cart_notice($notices)
    {
        $notices[] = 'cart_warning';

        return $notices;
    }

    public function add_notice_template($template, $template_name, $args, $template_path, $default_path)
    {
        if ($template_name !== 'notices/cart_warning.php') {
            return $template;
        }

        return dirname(__FILE__) .'/templates/notice-warning.php';
    }

    public function validate_batch_quantity($product_id, $quantity, $previous_qty = 0)
    {
        $batch_id = $this->get_product_current_batch_id($product_id);

        if (empty($batch_id)) { // if product has no package ID to check
            return true;
        }

        global $dabber_current_location_data;

        $product = wc_get_product($product_id);
        $cart = WC()->cart->get_cart_item_quantities();
        $total_qty_added = (isset($cart[$product_id]) && $previous_qty === 0)? (float) $cart[$product_id] + (float) $quantity : $quantity;

        $location_qty = get_post_meta($product_id, 'wcmlim_stock_at_'. $dabber_current_location_data['wc_location_id'], true);
        $message = ''; // default message.

        if ($total_qty_added > $location_qty) {
            $message = __('Sorry, we do not have enough <strong>'. $product->get_name() .'</strong> in stock to fulfill your order ('. $location_qty .' available). We apologize for any inconvenience caused', "woocommerce");

            return [
                'is_passed' => false,
                'message' => [
                    'type' => 'error',
                    'text' => $message
                ]
            ];
        }

        $package_qty = get_post_meta($product_id, 'package_quantities', true);

        if (isset($package_qty[$dabber_current_location_data['wc_location_id']][$batch_id])) {
            if ($total_qty_added > $package_qty[$dabber_current_location_data['wc_location_id']][$batch_id]) {

                if (apply_filters('cova_enable_cart_batch_qty_warning', false) === true) {
                    $available_qty = (float) $package_qty[$dabber_current_location_data['wc_location_id']][$batch_id];
                    $other_qty = $total_qty_added - $available_qty;
                    $message = [
                        'type' => 'cart_warning',
                        'text' => __('<li>There '. _n('is', 'are', $available_qty) .' only <strong>'. $package_qty[$dabber_current_location_data['wc_location_id']][$batch_id] .'</strong> '. _n('item', 'items', $available_qty) .' left of <strong>'. $product->get_title() .'</strong> with the displayed potency. The other <strong>'. $other_qty .'</strong> '. _n('item', 'items', $other_qty) .' will have a '. _n('different potency', 'variety of potencies', $other_qty) .'.</li>', "cova")
                    ];
                }
                return [
                    'is_passed' => true,
                    'message' => $message
                ];
            }
        } else {
            // If product don't have 'package_quantities' meta yet, call API and update stock details.
            $catalog_id = get_post_meta($product_id, 'cova_catalog_id', true);
            $cova_qty = $this->get_current_package_quantity($catalog_id, $batch_id);
            $is_instock = ($cova_qty['total_qty'] > 0)? 'instock' : 'outofstock';

            update_post_meta($product_id, 'package_quantities', $cova_qty['package_quantities']);
            update_post_meta($product_id, '_stock_status', $is_instock);
            update_post_meta($product_id, '_stock', $cova_qty['total_qty']);

            if ($total_qty_added > $cova_qty['total_qty']) {
                $message = __('Sorry, we do not have enough <strong>'. $product->get_name() .'</strong> in stock to fulfill your order ('. $cova_qty['total_qty'] .' available). We apologize for any inconvenience caused', "woocommerce");

                return [
                    'is_passed' => false,
                    'message' => [
                        'type' => 'error',
                        'text' => $message
                    ]
                ];
            }

            if ($total_qty_added > $cova_qty['current_batch_qty']) {

                if (apply_filters('cova_enable_cart_batch_qty_warning', false) === true) {
                    $other_qty = $total_qty_added - $cova_qty['current_batch_qty'];
                    $message = [
                        'type' => 'cart_warning',
                        'text' => __('<li>There '. _n('is', 'are', $cova_qty['current_batch_qty']) .' only <strong>'. $cova_qty['current_batch_qty'] .'</strong> '. _n('item', 'items', $cova_qty['current_batch_qty']) .' left of <strong>'. $product->get_title() .'</strong> with the displayed potency. The other <strong>'. $other_qty .'</strong> '. _n('item', 'items', $other_qty) .' will have a '. _n('different potency', 'variety of potencies', $other_qty) .'.</li>', "cova")
                    ];
                }
                return [
                    'is_passed' => true,
                    'message' => $message
                ];
            }
        }

        return true;
    }

    public function validate_cart_page_add_to_cart($passed,  $cart_item_key,  $values,  $quantity)
    {
        if (!$passed) { // skip if other validators already returned false.
            return false;
        }

        $product_id = (is_numeric($values['variation_id']) && $values['variation_id'] > 0)? $values['variation_id'] : $values['product_id'];
        $is_passed = $this->validate_batch_quantity($product_id, $quantity, $values['quantity']);

        if ($is_passed === true) {
            return $passed;
        }

        if (!empty($is_passed['message'])) {
            cova_add_wc_notice($is_passed['message']['text'], $is_passed['message']['type']);
        }

        return ($is_passed['is_passed'] !== null)? $is_passed['is_passed'] : $passed;
    }

    public function validate_add_to_cart($passed, $product_id, $quantity, $variation_id = '', $variations = '')
    {
        if (!$passed) { // skip if other validators already returned false.
            return false;
        }

        $is_passed = $this->validate_batch_quantity($product_id, $quantity);

        if ($is_passed === true) {
            return $passed;
        }

        if ($is_passed['is_passed'] === true) {
            $cart_contents = WC()->cart->get_cart_contents();
            foreach( $cart_contents as $cart_item_key => $cart_item ) {
                // Check if the added product is already in the cart and if their custom data match
                if($cart_item['product_id'] == $product_id) {
                    // Modify the quantity of the existing cart item
                    WC()->cart->set_quantity( $cart_item_key, $cart_item['quantity'] + $quantity, true );
                    // Stop the new product from being added to the cart separately
                    $is_passed['is_passed'] = false;
                    break;
                }
            }
        }

        if (!empty($is_passed['message'])) {
            cova_add_wc_notice($is_passed['message']['text'], $is_passed['message']['type']);
        }

        return ($is_passed['is_passed'] !== null)? $is_passed['is_passed'] : $passed;
    }

    public function get_current_package_quantity($catalog_id, $batch_id)
    {
        $product = CovaAPI('v2')->catalog->get_detailed_products_by_catalog_ids([
            'IncludeProductSkusAndUpcs' => false,
            'IncludeProductSpecifications' => false,
            'IncludeProductAssets' => false,
            'IncludeAvailability' => true,
            'IncludePackageDetails' => false,
            'IncludePricing' => false,
            'InStockOnly' => true,
            'SellingRoomOnly' => false,
            'ProductIds' => [$catalog_id]
        ]);

        if (!isset($product['Products'][0]['Availability'])) {
            return [
                'current_batch_qty' => 0,
                'package_quantities' => [],
                'total_qty' => 0
            ];
        }

        $grouped_availability = array_reduce(
            $product['Products'][0]['Availability'], function ($accumulator, $item) {
            $accumulator[$item['LocationId']][] = $item;
            return $accumulator;
        }, []);

        $location_ids = array_flip(dabber_get_location_ids());
        $grouped_availability = array_intersect_key($grouped_availability, $location_ids);
        $package_quantities = [];

        foreach ($grouped_availability as $availability_items) {
            usort(
                $availability_items, function ($a, $b) {
                // Filter out items with stock <= 0
                if ($a['InStockQuantity'] <= 0) return 1;
                if ($b['InStockQuantity'] <= 0) return -1;

                // Sort by ascending date
                return strtotime($a['ReceivedDate']) - strtotime($b['ReceivedDate']);
            });

            $sorted_package_items = array_values($availability_items);
            $package_quantities[$location_ids[$sorted_package_items[0]['LocationId']]][$sorted_package_items[0]['PackageId']] = (float) $sorted_package_items[0]['InStockQuantity'];
        }

        $current_batch_qty = 0;
        $total_qty = 0;

        foreach ($product['Products'][0]['Availability'] as $item) {
            if ($item['PackageId'] === $batch_id) {
                $current_batch_qty = $item['InStockQuantity'];
            }
            $total_qty += (float) $item['InStockQuantity'];
        }

        return [
            'current_batch_qty' => (float) $current_batch_qty,
            'package_quantities' => $package_quantities,
            'total_qty' => (float) $total_qty
        ];
    }

    /**
     * Map batch product batch data
     *
     * @param $data
     * @return array|mixed
     */
    public function map_batch_data_fields($data)
    {
        if (empty($data['packages'])) {
            return $data;
        }

        foreach ($data['metadata'] as $catalog_id => $meta_item) {
            if (empty($meta_item['packages'])) {
                continue;
            }

            $product_tax_data = array_intersect_key($meta_item, $this->map_taxonomy);

            foreach ($meta_item['packages'] as $key => $batch_id) {
                if (!isset($data['packages'][$batch_id])) {
                    continue;
                }
                $location_batch_info = $data['packages'][$batch_id];

                foreach($meta_item['packages'] as $package_wc_id => $package_batch_id) {
                    if (!isset($data['packages'][$package_batch_id])) {
                        continue;
                    }
                    foreach($data['packages'][$package_batch_id] as $package_key => $package_val) {
                        if (!isset(self::$map_meta[$package_key])) {
                            continue;
                        }
                        $data['metadata'][$catalog_id][$package_wc_id .'_'. $package_key] = $package_val['value'];
                        $data['metadata'][$catalog_id][$package_wc_id .'_'. $package_key .'_unit'] = $package_val['unit'];
                    }
                }

                $batch_tax = array_merge($product_tax_data, $location_batch_info);
                $batch_tax = array_diff_key($batch_tax, self::$map_meta);

                foreach ($batch_tax as $batch_taxkey => $batch_taxval) {
                    $batch_taxval = (is_array($batch_taxval))? $batch_taxval : [$batch_taxval];
                    $data['taxonomies'][$catalog_id][$key .'_'. $batch_taxkey] = $batch_taxval;
                }
            }
        }

        return $data;
    }

    /**
     * @param $to_update_items  // The items to update
     * @param $product_data     // The formatted product data
     * @param $existing_product_metas   // Existing product meta from postmeta table
     * @return array
     */
    public function add_to_update_info_items($to_update_items, $product_data, $existing_product_metas)
    {
        /**
         * Set default package values and make sure old metadata
         * that doesn't exist anymore and gets replaced with the default values.
         */
        $default_package_values = $this->get_default_package_info_values();

        foreach ($to_update_items as $product_id => $item) {
            $existing_meta_batch_data = array_intersect_key($existing_product_metas[$product_id], $default_package_values);
            $product_data_batch_data = array_intersect_key($product_data['metadata'][$item['metadata']['cova_catalog_id']], $default_package_values);
            $diff_meta = array_diff_key($existing_meta_batch_data, $product_data_batch_data);

            if (empty($diff_meta)) {
                continue;
            }

            $diff_meta = array_intersect_key($default_package_values, $diff_meta);

            $to_update_items[$product_id]['metadata'] = array_merge($to_update_items[$product_id]['metadata'] , $diff_meta);
        }

        return $to_update_items;
    }

    public function get_default_package_info_values()
    {
        $location_ids = dabber_get_location_ids();
        $package_data = array_keys(self::$map_meta);

        $default_package_values = [];
        $default_package_values['packages'] = [];

        foreach ($location_ids as $wc_loc_id => $cova_loc_id) {
            $default_package_values['package_at_'. $wc_loc_id] = '';

            foreach ($package_data as $package_item) {
                $default_package_values['package_at_'. $wc_loc_id .'_'. $package_item] = '';
                $default_package_values['package_at_'. $wc_loc_id .'_'. $package_item .'_unit'] = '';
            }
        }

        return $default_package_values;
    }

    /**
     * Register taxonomies for mapped potency terms
     *
     * @return void
     */
    public function create_package_based_taxonomies()
    {
        $locations = dabber_get_location_ids();

        foreach ($locations as $wc_location_id => $cova_location_id) {
            foreach (array_keys($this->map_taxonomy) as $tax_key) {
                $tax_package_key = 'package_at_'. $wc_location_id .'_'. $tax_key;
                if (taxonomy_exists($tax_package_key)) {
                    continue;
                }
                register_taxonomy(
                    $tax_package_key, ['product'], [
                    'hierarchical' => false,
                    'labels' =>[
                        'name' => $tax_package_key
                    ]
                    ]
                );
            }
        }
    }

    /**
     * Add batch ID in the cart item
     *
     * @param $cart_item_data
     * @param $product_id
     * @param $variation_id
     * @return mixed
     */
    public function add_cart_batch_id_data($cart_item_data, $product_id, $variation_id)
    {
        $batch_id = filter_input(INPUT_POST, 'product-batch-id');

        if (empty($batch_id)) {
            $batch_id = $this->get_product_current_batch_id($product_id);
        }

        $cart_item_data['product-batch-id'] = $batch_id;

        return $cart_item_data;
    }

    /**
     * Add the batch ID attribute
     *
     * @param $item_data
     * @param $cart_item
     * @return mixed
     */
    public function add_batch_id_item_data($item_data, $cart_item)
    {
        if (empty($cart_item['product-batch-id']) ) {
            return $item_data;
        }

        $item_data[] = array(
            'key'     => __('Batch ID', 'dabber'),
            'value'   => wc_clean($cart_item['product-batch-id']),
            'display' => '',
        );

        return $item_data;
    }

    /**
     * @desc Add batch ID hidden field to the product page
     */
    public function render_custom_fields()
    {
        global $post, $dabber_current_location_data;

        $batch_id = $this->get_product_current_batch_id($post->ID);

        echo '<input type="hidden" id="product-batch-id" name="product-batch-id" value="'. $batch_id .'">';

        $batch_quantity = get_post_meta($post->ID, 'package_quantities', true);
        if (is_array($batch_quantity) && isset($batch_quantity[$dabber_current_location_data['wc_location_id']][$batch_id])) {
            echo '<input type="hidden" id="product-batch-qty" name="product-batch-qty" value="'. $batch_quantity[$dabber_current_location_data['wc_location_id']][$batch_id] .'">';
        }
    }

    public function get_product_current_batch_id($product_id)
    {
        global $dabber_current_location_data;
        $batch_id = '';
        $packages = get_post_meta($product_id, 'packages', true);

        if (isset($packages['package_at_'. $dabber_current_location_data['wc_location_id']])) {
            $batch_id = $packages['package_at_'. $dabber_current_location_data['wc_location_id']];
        }

        return $batch_id;
    }

    function add_batch_id_meta_to_order( $item, $cart_item_key, $values, $order )
    {
        if (empty($values['product-batch-id']) ) {
            return;
        }

        $item->add_meta_data('Batch-ID', $values['product-batch-id']);
    }

    public function get_current_package_id($batch_data)
    {
        global $dabber_current_location_data;

        $oos_threshold = $dabber_current_location_data['oos_threshold'];

        foreach ($batch_data as $package_data) {
            if ($package_data['LocationId'] != $dabber_current_location_data['cova_location_id']) {
                continue;
            }

            if ($package_data['InStock'] <= $oos_threshold) {
                continue;
            }
            return $package_data['SerialNumber'];
        }

        return false;
    }

    public function get_product_package_items($catalog_id)
    {
        $locations  = Cova_Data_Manager::get_global_data('locations');
        $batch_data = Cova_Data_Manager::get_stored_data('inventory_batch');
        $batch_items  = [];

        foreach ($locations as $location_id => $loc_data) {
            if (!isset($batch_data[$location_id])) {
                return [];
            }

            foreach ($batch_data[$location_id] as $items) {
                if ($items['ProductId'] === $catalog_id) {
                    $batch_items[$items['SerialNumber']]['serial_number'] = $items['SerialNumber'];
                    $batch_items[$items['SerialNumber']]['cost'][$location_id] = $items['Cost'];
                    $batch_items[$items['SerialNumber']]['quantity'][$location_id] = $items['InStock'];
                }
            }
        }

        return $batch_items;
    }

    public function add_notice_style()
    {
        echo '<style>ul.woocommerce-info.cart_warning { background-color: #FDC300 !important; border-color: #edb700; }</style>';
    }

} // end class
