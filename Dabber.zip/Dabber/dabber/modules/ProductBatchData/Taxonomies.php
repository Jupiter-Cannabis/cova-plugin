<?php

namespace Dabber\Modules\ProductBatchData;

class Taxonomies
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new Taxonomies();
        }

        return self::$instance;
    }

    public function register_taxonomies()
    {
        $taxonomies = $this->get_batch_taxonomies();

        foreach ($taxonomies as $key => $name) {

            register_taxonomy(
                $key, ['product'], [
                'hierarchical' => false,
                'labels' =>[
                    'name' => $name
                ],
                'show_ui' => false
                ]
            );
        }
    }

    public function get_batch_taxonomies()
    {
        $tax_items = [
            'strain'    => 'Strain',
            'terpenes'  => 'Terpenes'
        ];

        $locations = cova_get_all_wc_locations();
        $location_tax_items = [];

        foreach ($locations as $location) {
            foreach ($tax_items as $tax_key => $tax_name) {
                $location_tax_items['package_at_'. $location['term_id'] .'_'. $tax_key] = $tax_name;
            }
        }

        return apply_filters('dabber_batch_taxonomies', $location_tax_items);
    }
}
