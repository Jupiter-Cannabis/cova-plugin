<?php
$is_connected      = get_option('dabber_is_api_connected');
$is_client_secret  = (isset($args['api']['live']['credentials']['client_secret']) && trim($args['api']['live']['credentials']['client_secret']) !== '')? __('Client Secret is set') : '';
$is_password        = (isset($args['api']['live']['credentials']['password']) && trim($args['api']['live']['credentials']['password']) !== '')? __('Password is set') : '';
$is_live_connected = ($is_connected === 'yes')? '<span style="color: #21b921;">('.__('Connected', 'dabber').')</span>' : '';

$is_sandbox_client_secret = (isset($args['api']['sandbox']['credentials']['client_secret']) && trim($args['api']['sandbox']['credentials']['client_secret']) !== '')? __('Sandbox Client Secret is set') : '';
$is_sandbox_password       = (isset($args['api']['sandbox']['credentials']['password']) && trim($args['api']['sandbox']['credentials']['password']) !== '')? __('Sandbox Password is set') : '';
$is_sandbox_connected       = ($args['api']['mode'] === 'sandbox')? '<span style="color: #21b921;">('.__('Connected', 'dabber').')</span>' : '';

$is_sandbox = ($args['api']['mode'] === 'sandbox')? true : false;
?>

        <h3><?php _e('Live Credentials', 'cova') ?> <?php echo $is_live_connected ?></h3>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><?php _e('Company ID', 'cova') ?></th>
                <td>
                    <input type="text" name="cova_api_company_id" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $args['api']['live']['credentials']['company_id'] ?>">
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Client ID', 'cova') ?></th>
                <td>
                    <input type="text" name="cova_api_client_id" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $args['api']['live']['credentials']['client_id'] ?>">
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Client Secret', 'cova') ?></th>
                <td>
                    <input type="password" name="cova_api_client_secret" placeholder="<?php echo $is_client_secret ?>" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Username', 'cova') ?></th>
                <td>
                    <input type="text" name="cova_api_username" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $args['api']['live']['credentials']['username'] ?>">
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Password', 'cova') ?></th>
                <td>
                    <input type="password" name="cova_api_password" placeholder="<?php echo $is_password ?>" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                </td>
            </tr>
            </tbody>
        </table>
        <p></p>
        <hr>
        <div style="display:none !important;">
            <h3><?php _e('Sandbox Credentials', 'dabber') ?> <?php echo $is_sandbox_connected ?></h3>
            <table class="form-table">
                <tbody>
                <tr>
                    <th scope="row"><?php _e('Enable Sandbox Mode', 'cova') ?></th>
                    <td>
                        <fieldset>
                            <label for="cova_api_enable_sandbox">
                                <input name="cova_api_enable_sandbox" <?php echo (($is_sandbox === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="cova_api_enable_sandbox" value="1">
                            </label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Company ID', 'cova') ?></th>
                    <td>
                        <input type="text" name="cova_api_sandbox_company_id" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Client ID', 'cova') ?></th>
                    <td>
                        <input type="text" name="cova_api_sandbox_client_id" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Client Secret', 'cova') ?></th>
                    <td>
                        <input type="password" name="cova_api_sandbox_client_secret" placeholder="<?php echo $is_sandbox_client_secret ?>" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Username', 'cova') ?></th>
                    <td>
                        <input type="text" name="cova_api_sandbox_username" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Password', 'cova') ?></th>
                    <td>
                        <input type="password" name="cova_api_sandbox_password" placeholder="<?php echo $is_sandbox_password ?>" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <p></p>
        <input type="hidden" id="dabber_update_live_credentials" name="dabber_update_live_credentials" value="">
        <input type="hidden" id="dabber_update_sandbox_credentials" name="dabber_update_sandbox_credentials" value="">
        <input type="submit" id="submit" name="cova-save-api-credentials" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">

<script type="text/javascript">
    jQuery(document).ready(function()
    {
        jQuery('.dabber-live-credentials').change(function()
        {
            jQuery('#dabber_update_live_credentials').val(1);
        });

        jQuery('.dabber-sandbox-credentials').change(function()
        {
            jQuery('#dabber_update_sandbox_credentials').val(1);
        });
    });
</script>
