<?php

namespace Dabber\Modules\CovaApiIntegration;

/**
 * @todo run location sync after successful API connection.
 */
class CovaApiIntegration
{
    private $tab_key = 'cova_api_integration';
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Cova API Integration',
        'description' => 'Connect to Cova hub.'
    ];

    public function run()
    {
        add_filter('dabber_admin_module_nav_items', [$this, 'add_tab'], 100);
        add_action('dabber_render_module_admin_section_'. $this->tab_key, [$this, 'render_tab_content']);
        add_action('dabber_admin_module_save_settings_'. $this->tab_key, [$this, 'save_settings']);
        add_action('admin_init', [$this, 'show_api_creds']);
    }

    public function show_api_creds()
    {
        if (!current_user_can('administrator')) {
            return;
        }
        if (!isset($_GET['dabber_show_apicreds'])) {
            return;
        }

        !d(get_option('dabber_api_details'));

        die();
    }
    public function add_tab($tabs)
    {
        $tabs[$this->tab_key] = __('API Integration');
        return $tabs;
    }

    public function save_settings()
    {
        $api = get_option('dabber_api_details');

        if ($_POST['dabber_update_live_credentials'] == 1) {

            $this->save_api_credentials(
                [
                'company_id'    => sanitize_text_field($_POST['cova_api_company_id']),
                'client_id'        => sanitize_text_field($_POST['cova_api_client_id']),
                'client_secret'    => (trim($_POST['cova_api_client_secret']) !== '')? sanitize_text_field($_POST['cova_api_client_secret']) : $api[$api['mode']]['credentials']['client_secret'],
                'username'        => sanitize_text_field($_POST['cova_api_username']),
                'password'        => (trim($_POST['cova_api_password']) !== '')? sanitize_text_field($_POST['cova_api_password']) : $api[$api['mode']]['credentials']['password'],
                'environment'   => (isset($_POST['cova_api_environment']))? sanitize_text_field($_POST['cova_api_environment']): ''
                ], 'live'
            );
        }
    }

    public function save_api_credentials($credentials, $mode)
    {
        $api = get_option('dabber_api_details');

        $cova_api = new \CovaAPI\Auth();
        $cova_api->set_credentials($credentials);
        $response = $cova_api->generate_access_token();

        if (!isset($response['access_token'])) {
            echo '<p style="color: red">'. __($mode .' API error', 'dabber') .': '. $response['Description'] .'</p>';
            update_option('dabber_is_api_connected', 'no');
            return;
        } else {

            $api_data = [
                'credentials' => $credentials,
                'auth' => [
                    'access_token'  => $response['access_token'],
                    'expires_in'    => $response['expires_in'],
                    'refresh_token' => $response['refresh_token'],
                    'generated_at'  => date('Y-m-d H:i:s'),
                    'expired_at'    => date('Y-m-d H:i:s', strtotime('+'. $response['expires_in'].' seconds'))
                ]
            ];

            update_option('dabber_is_api_connected', 'yes');
        }

        $api[$mode] = $api_data;
        $api['mode'] = $mode;

        update_option('dabber_api_details', $api);

        do_action('dabber_after_api_integration');
    }

    public function render_tab_content()
    {
        load_template(
            plugin_dir_path(__FILE__) .'templates/settings.php', true, [
            'api' => get_option('dabber_api_details'),
            ]
        );
    }
}
