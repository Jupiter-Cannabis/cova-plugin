<?php

use Dabber\Modules\RoleBasedPrice\RoleBasedPrice;

function cova_get_member_price_label($product)
{
    if ($product->is_on_sale()) {
        return __('Sale Price', 'cova');
    }

    //    if (!is_user_logged_in()) {
    //        return __('Member Price', 'cova');
    //    }
    //
    //    if (RoleBasedPrice::is_current_user_member()) {
    //        return __('Your Price', 'cova');
    //    }

    return __('Member Price', 'cova');
}

function cova_get_original_price_label($product)
{
    if ($product->is_on_sale()) {
        return __('Original', 'woocommerce');
    }

    //    if (RoleBasedPrice::is_current_user_member()) {
        return __('Reg. Price', 'cova');
    //    }

    //    return __('Your Price', 'cova');
}

function cova_get_member_price($product)
{
    $regular_price = $product->get_meta('wcmlim_regular_price_at_'. cova_get_current_location());
    $role_based_price = RoleBasedPrice::calculate_role_based_price(RoleBasedPrice::get_current_user_membership_price(), $regular_price);

    if (\Dabber\Modules\Promotions\Promotions::is_product_on_promo($product)) {
        return \Dabber\Modules\Promotions\Promotions::get_promo_price($product);
    }

    if ($product->is_on_sale()) {
        $sale_price = $product->get_meta('wcmlim_sale_price_at_'. cova_get_current_location());

        //        if ($sale_price < $role_based_price) {
            return number_format($sale_price, 2, '.', '');
        //        }
    }

    return number_format($role_based_price, 2, '.', '');;
}

function cova_get_original_price($product)
{
    //    if ($product->is_on_sale()) {
    //        return $product->get_meta('wcmlim_sale_price_at_'. cova_get_current_location());
    //    }

    $price = $product->get_meta('wcmlim_regular_price_at_'. cova_get_current_location());
    return number_format($price, 2, '.', '');
}
