<?php

namespace Dabber\Modules\RoleBasedPrice;

class RoleBasedPrice
{
    public static $module_info = [
        'name' => 'Role-based Pricing',
        'description' => ''
    ];

    private static $price_roles;
    private $is_apply_to_regular_price;
    private $is_apply_to_sale_price;
    private $is_apply_to_promotions;
    private static $default_role_based_price = [
        'discount' => true,
        'type' => 'percentage',
        'amount' => 10
    ];

    public function set_options()
    {
        $this->is_apply_to_regular_price = true;
        $this->is_apply_to_sale_price = false;
        $this->is_apply_to_promotions = false;

        self::$price_roles = $this->get_formatted_price_rules_array();
    }

    public function get_formatted_price_rules_array()
    {
        $price_rules = $this->get_role_based_prices();

        if (!is_array($price_rules)) {
            return [];
        }

        $formatted_array = [];

        foreach ($price_rules as $item) {
            $formatted_array[$item['user_role']][] = [
                'discount' => true,
                'type' => $item['type'],
                'amount' => $item['amount'],
                'priority' => $item['priority']
            ];
        }

        return $formatted_array;
    }

    public function run()
    {
        $this->set_options();

        add_filter('get_post_metadata', [$this, 'override_wcmlim_regular_price'], 200, 4);
        //        add_filter('get_post_metadata', [$this, 'override_wcmlim_sale_price'], 200, 4);


        add_filter('dabber_admin_module_nav_items', [$this, 'add_admin_settings_tab']);
        add_action('dabber_render_module_admin_section_role_based_pricing', [$this, 'render_settings_page']);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_scripts']);
        add_action('wp_ajax_cova_save_price_rule', [$this, 'ajax_save_price_rule']);
        add_action('wp_ajax_cova_delete_price_rule', [$this, 'ajax_remove_price_rule']);

        add_action('wp_login', [$this, 'set_is_user_after_login'], 0, 2);

        add_filter('woocommerce_add_cart_item', [$this, 'apply_role_based_price_on_add_to_cart']);
        //        add_action('wp', [$this, 'empty_cart'], 0);
        //        add_action('wp', [$this, 'reset_cart_added_items'], 300);

        add_action('cova_role_based_price_reset_cart_items', [$this, 'reset_cart_items']);

        add_filter('woocommerce_locate_template', [$this, 'override_price_template'], 200, 3);
        add_filter('woocommerce_locate_template', [$this, 'override_loop_price_template'], 200, 3);

        add_action('init', [$this, 'load_role_based_price_settings']);
        add_action('init', [$this, 'load_current_role_based_price']);

        include_once 'functions.php';
    }

    public static function get_default_role_based_price()
    {
        return self::$default_role_based_price;
    }

    /**
     * Used when updating backend settings
     *
     * @return void
     */
    public function reset_cart_items()
    {
        $products   = [];
        $cart_items = WC()->cart->get_cart();

        // store cart items to be used later for re-adding items to cart.
        foreach ($cart_items as $item) {
            $products[] = $item;
        }

        // empty cart items and prepare for re-adding items to cart.
        WC()->cart->empty_cart();

        foreach ($products as $product_item) {
            $currency_symbol = get_option('woocommerce_currency');
            $currency_symbol = (!$currency_symbol)? $currency_symbol : '$';

            $final_price = $this->get_product_final_price($product_item['data']);
            $product_item['select_location']['location_cart_price'] = $currency_symbol. $this->get_product_role_based_price($final_price['amount'], $final_price['is_sale']);

            WC()->cart->add_to_cart(
                $product_item['data']->get_id(), $product_item['quantity'], 0, [], [
                'select_location' => $product_item['select_location']
                ]
            );
        }
    }

    public function get_role_based_prices()
    {
        $prices = get_option('dabber_role_based_prices');

        return (is_array($prices))? $prices : [];
    }

    public function load_role_based_price_settings()
    {
        global $dabber_role_based_prices;

        $dabber_role_based_prices = $this->get_role_based_prices();
    }

    public function load_current_role_based_price()
    {
        global $dabber_current_role_based_price, $dabber_role_based_prices;

        $user = wp_get_current_user();
        $price_roles = [];

        foreach ($dabber_role_based_prices as $item) {
            if (!in_array($item['user_role'], $user->roles)) {
                continue;
            }

            $price_roles[] = $item;
        }

        if (empty($price_roles)) {
            return;
        }

        uasort(
            $price_roles, function ($a, $b) {
                return $a['priority'] <=> $b['priority'];
            }
        );

        $price_roles = array_values($price_roles);
        $dabber_current_role_based_price = $price_roles[0];
    }

    public static function get_current_user_membership_price()
    {
        global $dabber_current_role_based_price;

        if (empty($dabber_current_role_based_price)) {
            return self::get_default_role_based_price();
        }

        return [
            'discount' => true,
            'type' => $dabber_current_role_based_price['type'],
            'amount' => $dabber_current_role_based_price['amount']
        ];
    }

    public function apply_role_based_price_on_add_to_cart($data)
    {
        if ($data['data']->is_on_sale()) {
            return $data;
        }

        if (!is_user_logged_in()) {
            return $data;
        }

        $currency_symbol  = get_option('woocommerce_currency');
        $currency_symbol  = (!$currency_symbol)? $currency_symbol : '$';
        $current_location = cova_get_current_location();

        //        $sale_price     = cova_get_product_location_sale_price($data['data']->get_id(), $current_location);
        //        $regular_price  = cova_get_product_location_regular_price($data['data']->get_id(), $current_location);
        //
        //        $sale_role_based_price      = (float) $this->get_product_role_based_price($sale_price, true);
        //        $regular_role_based_price   = (float) $this->get_product_role_based_price($regular_price);
        //
        //        $final_price = min($sale_role_based_price, $regular_role_based_price);
        //        $final_price = ($final_price <= 0)? $regular_role_based_price : $final_price;
        //        $final_price = number_format($final_price, 2, '.', '');

        $regular_price  = cova_get_product_location_regular_price($data['data']->get_id(), $current_location);
        $regular_role_based_price   = (float) $this->get_product_role_based_price($regular_price);
        $regular_role_based_price   = number_format($regular_role_based_price, 2, '.', '');

        $data['select_location']['location_cart_price'] = $currency_symbol. $regular_role_based_price;

        return $data;
    }

    public function set_is_user_after_login($user_login, $user)
    {
        WC()->cart->empty_cart();
    }

    //    public function empty_cart()
    //    {
    //        if (!is_user_logged_in()) {
    //            return;
    //        }
    //
    //        if (is_admin()) {
    //            return;
    //        }
    //
    //        $user = wp_get_current_user();
    //        $is_after_login = get_user_meta($user->ID, 'cova_is_after_login', true);
    //
    //        if ($is_after_login !== 'yes') {
    //            return;
    //        }
    //
    //        $products   = [];
    //        $cart_items = WC()->cart->get_cart();
    //
    //        // store cart items to be used later for re-adding items to cart.
    //        foreach ($cart_items as $item) {
    //            $products[] = $item;
    //        }
    //
    //        $this->cart_items = $products;
    //
    //        // empty cart items and prepare for re-adding items to cart.
    //        WC()->cart->empty_cart();
    //    }

    //    public function reset_cart_added_items()
    //    {
    //        if (!is_user_logged_in()) {
    //            return;
    //        }
    //
    //        $user = wp_get_current_user();
    //        $is_after_login = get_user_meta($user->ID, 'cova_is_after_login', true);
    //
    //        if ($is_after_login !== 'yes') {
    //            return;
    //        }
    //
    //        if (empty($this->cart_items)) {
    //            return;
    //        }
    //
    //        foreach ($this->cart_items as $product_item) {
    //            $currency_symbol = get_option('woocommerce_currency');
    //            $currency_symbol = (!$currency_symbol)? $currency_symbol : '$';
    //
    //            $final_price = $this->get_product_final_price($product_item['data']);
    //            $product_item['select_location']['location_cart_price'] = $currency_symbol. $this->get_product_role_based_price($final_price['amount'], $final_price['is_sale']);
    //
    //            WC()->cart->add_to_cart($product_item['data']->get_id(), $product_item['quantity'], 0, [], [
    //                'select_location' => $product_item['select_location']
    //            ]);
    //        }
    //
    //        delete_user_meta($user->ID, 'cova_is_after_login');
    //    }

    public function get_product_final_price($product)
    {
        $current_location = cova_get_current_location();

        $sale_price = cova_get_product_location_sale_price($product->get_id(), $current_location);
        $regular_price = cova_get_product_location_regular_price($product->get_id(), $current_location);

        if (is_numeric($sale_price)) {
            return [
                'is_sale' => true,
                'amount' => $sale_price
            ];
        }

        return [
            'is_sale' => false,
            'amount' => $regular_price
        ];
    }

    public function add_admin_settings_tab($tabs)
    {
        $tabs['role_based_pricing'] = 'Role Based Pricing';

        return $tabs;
    }

    public function render_settings_page()
    {
        global $wp_roles;

        load_template(
            plugin_dir_path(__FILE__) .'templates/role-based-pricing.php', true, [
            'user_roles' => $wp_roles->roles
            ]
        );
    }

    public function update_price_rules()
    {
        $price_rules = $this->get_role_based_prices();

        if (empty($_POST['params']['user_role'])) {
            return;
        }

        $price_rules[] = [
            'name' => sanitize_text_field($_POST['params']['name']),
            'user_role' => sanitize_text_field($_POST['params']['user_role']),
            'type' => sanitize_text_field($_POST['params']['type']),
            'amount' => sanitize_text_field($_POST['params']['amount']),
            'priority' => sanitize_text_field($_POST['params']['priority']),
        ];

        update_option('dabber_role_based_prices', $price_rules);
    }

    public function edit_price_rule()
    {
        $price_rules = $this->get_role_based_prices();

        if (!isset($price_rules[$_POST['params']['id']])) {
            return;
        }

        $price_rules[$_POST['params']['id']] = [
            'name' => sanitize_text_field($_POST['params']['name']),
            'user_role' => sanitize_text_field($_POST['params']['user_role']),
            'type' => sanitize_text_field($_POST['params']['type']),
            'amount' => sanitize_text_field($_POST['params']['amount']),
            'priority' => sanitize_text_field($_POST['params']['priority']),
        ];

        update_option('dabber_role_based_prices', $price_rules);
    }

    public function ajax_save_price_rule()
    {
        if ($_POST['params']['action'] === 'create') {
            $this->update_price_rules();
        }

        if ($_POST['params']['action'] === 'edit') {
            $this->edit_price_rule();
        }
        //        do_action('cova_after_price_rule_save');
        //        do_action('cova_role_based_price_reset_cart_items');

        ob_start();

        load_template(
            plugin_dir_path(__FILE__) .'templates/price-rule-items.php', true, [
            'items' => $this->get_role_based_prices()
            ]
        );

        $price_rule_html = ob_get_clean();

        wp_send_json_success(
            [
            'price_rules_html' => $price_rule_html
            ], 200
        );
    }

    public function ajax_remove_price_rule()
    {
        $price_rules = $this->get_role_based_prices();

        if (array_key_exists($_POST['id'], $price_rules)) {
            unset($price_rules[$_POST['id']]);
        }

        update_option('dabber_role_based_prices', $price_rules);

        ob_start();

        load_template(
            plugin_dir_path(__FILE__) .'templates/price-rule-items.php', true, [
            'items' => $this->get_role_based_prices()
            ]
        );

        $price_rule_html = ob_get_clean();

        wp_send_json_success(
            [
            'price_rules_html' => $price_rule_html
            ], 200
        );
    }

    public static function calculate_role_based_price($role_base_price, $original_price)
    {
        if (!is_numeric($original_price)) {
            return $original_price;
        }

        if ($role_base_price['discount'] === true) {

            if ($role_base_price['type'] === 'percentage') {
                $price_off =  $original_price * ($role_base_price['amount'] / 100);
                $new_price = $original_price - $price_off;
                $new_price = ($new_price < 0)? 0 : $new_price;

                return number_format($new_price, 2, '.', '');
            }

            if ($role_base_price['type'] === 'dollar') {
                $new_price = $original_price - $role_base_price['amount'];
                $new_price = ($new_price < 0)? 0 : $new_price;

                return number_format($new_price, 2, '.', '');
            }

        } else {
            return $original_price;
        }

        return $original_price;
    }

    public function get_product_role_based_price($original_price, $from_sale = false, $user = null)
    {
        // skip if apply to sale price is disabled
        if ($from_sale === true && $this->is_apply_to_sale_price === false) {
            return $original_price;
        }

        // skipp if apply to regular price is disabled
        if ($from_sale === false && $this->is_apply_to_regular_price === false) {
            return $original_price;
        }

        $current_user = $user;

        if ($user === null) {
            $current_user = wp_get_current_user();
        }

        $prices = self::get_user_prices($current_user);

        if (empty($prices)) {
            return $original_price;
        }

        $highest_priority_price = min(array_keys($prices));
        $final_price_rule = $prices[$highest_priority_price];

        return self::calculate_role_based_price($final_price_rule, $original_price);
    }

    public static function get_user_prices($user)
    {
        // skip if current user has no role
        if (empty($user->roles)) {
            return [];
        }

        $prices = [];

        foreach ($user->roles as $role) {
            if (array_key_exists($role, self::$price_roles)) {
                foreach (self::$price_roles[$role] as $price_role) {
                    $prices[$price_role['priority']] = $price_role;
                }
            }
        }

        return $prices;
    }

    public static function is_current_user_member()
    {
        if (!is_user_logged_in()) {
            return false;
        }
        $user = wp_get_current_user();

        return (!empty(self::get_user_prices($user)));
    }

    public function override_wcmlim_sale_price($metadata, $object_id, $meta_key = '', $single = false)
    {
        if (is_admin()) {
            return $metadata;
        }

        global $product;

        if (!$product instanceof \WC_Product) {
            return $metadata;
        }

        $sale_price_meta = 'wcmlim_sale_price_at_'. cova_get_current_location();

        if ($meta_key !== $sale_price_meta) {
            return $metadata;
        }

        if (empty(self::$price_roles)) {
            return $metadata;
        }

        // unhook filter to avoid infinite loop
        remove_filter('get_post_metadata', [$this, 'override_wcmlim_sale_price'], 200);

        $original_price = $product->get_meta($sale_price_meta);
        $new_price = $this->get_product_role_based_price($original_price, true);

        if ($new_price <= 0) {
            $new_price = $original_price;
        }

        // rehook filter
        add_filter('get_post_metadata', [$this, 'override_wcmlim_sale_price'], 200, 4);

        return $new_price;
    }

    public function override_wcmlim_regular_price($metadata, $object_id, $meta_key = '', $single = false)
    {
        if (is_admin()) {
            return $metadata;
        }

        global $product;

        if (!$product instanceof \WC_Product) {
            return $metadata;
        }

        $regular_price_meta = 'wcmlim_regular_price_at_'. cova_get_current_location();

        if ($meta_key !== $regular_price_meta) {
            return $metadata;
        }

        if (empty(self::$price_roles)) {
            return $metadata;
        }

        // unhook filter to avoid infinite loop
        remove_filter('get_post_metadata', [$this, 'override_wcmlim_regular_price'], 200);

        if ($product->is_on_sale()) {
            $new_price = $metadata;
        } else {
            $original_price = $product->get_meta($regular_price_meta);
            $new_price = $this->get_product_role_based_price($original_price);
        }

        // rehook filter
        add_filter('get_post_metadata', [$this, 'override_wcmlim_regular_price'], 200, 4);

        return $new_price;
    }

    public function override_price_template($template, $template_name, $template_path)
    {
        if ($template_name !== 'single-product/price.php') {
            return $template;
        }

        //        if (is_user_logged_in()) {
        //            return $template;
        //        }

        return plugin_dir_path(__FILE__) .'templates/woocommerce/price.php';
    }

    public function override_loop_price_template($template, $template_name, $template_path)
    {
        if ($template_name !== 'loop/price.php') {
            return $template;
        }

        //        if (is_user_logged_in()) {
        //            return $template;
        //        }

        return plugin_dir_path(__FILE__) .'templates/woocommerce/loop-price.php';
    }

    public function enqueue_admin_scripts()
    {
        wp_enqueue_style('role-based-price', plugin_dir_url(__FILE__) .'assets/css/role-based-price.css', [], null);
        wp_enqueue_script('role-based-price', plugin_dir_url(__FILE__) .'assets/js/role-based-price.js', [], null, true);
    }

    public function enqueue_frontend_scripts()
    {
        wp_enqueue_style('role-based-price', plugin_dir_url(__FILE__) .'assets/css/front-end-role-based-price.css', [], null);
    }
}
