<h3><?php _e('Price Rules', 'cova') ?></h3>
<div class="cova-price-rules-wrap">
    <?php
        load_template(
            plugin_dir_path(__FILE__) .'price-rule-items.php', true, [
            'items' => get_option('dabber_role_based_prices')
            ]
        );
        ?>
</div>
<table class="form-table">
    <tbody>
    <tr>
        <td>
            <?php load_template(plugin_dir_path(__FILE__). 'create-price-rule.php', false, $args); ?>
            <button type="button" id="cova-add-price-rule"><?php _e('Add Price Rule', 'cova') ?></button>
        </td>
    </tr>
    </tbody>
</table>
