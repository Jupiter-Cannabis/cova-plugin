<?php
global $product;
?>

<span class="price">
    <span class="woocommerce-Price-amount amount member-price">
        <span class="members-price-tag"><?php echo cova_get_member_price_label($product) ?></span>
        <bdi><span class="woocommerce-Price-currencySymbol">$</span><?php echo cova_get_member_price($product); ?></bdi>
    </span>
    <span class="amount original-price woocommerce-Price-amount">
        <span class="original-price-tag"><?php echo cova_get_original_price_label($product) ?></span>
        <bdi><span class="woocommerce-Price-currencySymbol">$</span><?php echo cova_get_original_price($product); ?></bdi>
    </span>
</span>
