<div class="cova-add-price-rule-wrap">
    <table>
        <tr>
            <th>Name</th>
            <td>
                <input type="text" id="name" name="name">
            </td>
        </tr>
        <tr>
            <th>Apply to User Role</th>
            <td>
                <select id="user-role" name="user-role">
                    <?php foreach($args['user_roles'] as $key => $role) : ?>
                        <option value="<?php echo $key ?>" <?php selected('customer', $key) ?> ><?php echo $role['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th>Discount Type</th>
            <td>
                <select id="type" name="type">
                    <option value="percentage"><?php _e('Percentage', 'cova') ?></option>
                    <option value="dollar"><?php _e('Dollar', 'cova') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th>Amount</th>
            <td>
                <input id="amount" type="number" min="0" step="0.1" name="amount">
            </td>
        </tr>
        <tr>
            <th>Priority</th>
            <td>
                <input id="priority" type="number" min="0" step="1" name="priority" value="0">
            </td>
        </tr>
    </table>

    <input type="hidden" id="action" name="action" value="create">
    <input type="hidden" id="id" name="id" value="">

    <div>
        <button id="cova-save-price-rule" type="button">Save Price Rule</button>
        <button id="cova-cancel-price-rule" type="button">Cancel</button>
    </div>
</div>
