<?php if($args['items'] === false) : ?>
    <p>No price rules available.</p>
<?php else : ?>
    <div>
        <table class="dabber-price-rules">
            <thead>
            <tr>
                <th>Name</th>
                <th>User Role</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Priority</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php foreach($args['items'] as $key => $item) : ?>
                    <tr>
                        <td class="rule-name"><?php echo $item['name'] ?></td>
                        <td class="role"><?php echo $item['user_role'] ?></td>
                        <td class="type"><?php echo $item['type'] ?></td>
                        <td class="amount"><?php echo $item['amount'] ?></td>
                        <td class="priority"><?php echo $item['priority'] ?></td>
                        <td><a href="#" class="cova-edit-price-rule" data-id="<?php echo $key ?>">Edit</a> | <a href="#" class="cova-remove-price-rule" data-id="<?php echo $key ?>">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

<?php endif; ?>
