(function ($) {
    $(document).ready(
        function () {
            let price_rule_wrap = $('.cova-add-price-rule-wrap');

            $('#cova-save-price-rule').click(
                function () {
                    $.ajax(
                        {
                            url: cova_sync.ajax_url,
                            type: 'POST',
                            data: {
                                action: 'cova_save_price_rule',
                                params: {
                                    name: price_rule_wrap.find('#name').val(),
                                    user_role: price_rule_wrap.find('#user-role').val(),
                                    type: price_rule_wrap.find('#type').val(),
                                    amount: price_rule_wrap.find('#amount').val(),
                                    priority: price_rule_wrap.find('#priority').val(),
                                    action: price_rule_wrap.find('#action').val(),
                                    id: price_rule_wrap.find('#id').val()
                                }
                            },
                            beforeSend: function () {

                            },
                            success: function (response) {
                                $('.cova-price-rules-wrap').html(response.data.price_rules_html);
                                price_rule_wrap.hide();
                                $('#cova-add-price-rule').show();
                            }
                        }
                    );
                }
            );

            $(document.body).on(
                'click', '.cova-remove-price-rule', function (e) {
                    e.preventDefault();

                    let id = $(this).attr('data-id');
                    let rule_name = $(this).closest('tr').find('.rule-name').text();

                    if (confirm('Are you sure you want to delete Price rule: '+ rule_name +'? This action cannot be undone.')) {
                        $.ajax(
                            {
                                url: cova_sync.ajax_url,
                                type: 'POST',
                                data: {
                                    action: 'cova_delete_price_rule',
                                    id: id
                                },
                                beforeSend: function () {

                                },
                                success: function (response) {
                                    $('.cova-price-rules-wrap').html(response.data.price_rules_html);
                                }
                            }
                        );
                    }
                }
            );

            $('#cova-cancel-price-rule').click(
                function () {
                    price_rule_wrap.hide();
                    $('#cova-add-price-rule').show();
                }
            );

            $(document.body).on(
                'click', '.cova-edit-price-rule', function (e) {
                    e.preventDefault();

                    let parent = $(this).closest('tr');
                    let name = parent.find('.rule-name').text();
                    let role = parent.find('.role').text();
                    let type = parent.find('.type').text();
                    let amount = parent.find('.amount').text();
                    let priority = parent.find('.priority').text();

                    price_rule_wrap.show();
                    price_rule_wrap.find('#action').val('edit');
                    price_rule_wrap.find('#id').val($(this).attr('data-id'));

                    price_rule_wrap.find('#name').val(name);
                    price_rule_wrap.find('#user-role').val(role);
                    price_rule_wrap.find('#type').val(type);
                    price_rule_wrap.find('#amount').val(amount);
                    price_rule_wrap.find('#priority').val(priority);

                    $('#cova-add-price-rule').hide();
                }
            );

            $('#cova-add-price-rule').click(
                function () {
                    price_rule_wrap.show();
                    price_rule_wrap.find('#action').val('create');
                    price_rule_wrap.find('#id').val('');

                    price_rule_wrap.find('#name').val('');
                    price_rule_wrap.find('#user-role').val('');
                    price_rule_wrap.find('#type').val('');
                    price_rule_wrap.find('#amount').val('');
                    price_rule_wrap.find('#priority').val('');

                    $(this).hide();
                }
            );
        }
    );

})(jQuery);