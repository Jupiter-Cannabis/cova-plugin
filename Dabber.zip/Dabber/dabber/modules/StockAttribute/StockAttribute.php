<?php

namespace Dabber\Modules\StockAttribute;

class StockAttribute
{
    public function __construct()
    {
        $this->set_options();
        $this->run();
    }

    public function set_options()
    {

    }

    public function run()
    {
        add_action('plugins_loaded', [$this, 'register_hooks'], 100);
    }

    public function register_hooks()
    {
        if (!defined('MEWZ_WCAS_NAME')) {
            return;
        }

        add_filter('mewz_wcas_template_path', [$this, 'override_admin_inventory_template'], 100, 2);
        //        add_filter('mewz_attribute_stock_get_quantity', [$this, 'override_stock_quantity_value_by_location'], 100, 2);
        add_action('post_updated', [$this, 'save_attribute_data'], 100, 3);
    }

    public function override_stock_quantity_value_by_location($value, $object)
    {
        $current_location = cova_get_current_location();
        $stock_amount = $object->meta('cova_attribute_stock_quantity');

        if (!isset($stock_amount[$current_location])) {
            return $value;
        }

        return $stock_amount[$current_location];
    }

    public function save_attribute_data($post_id, $post_after, $post_before)
    {
        if ($post_after->post_type !== 'mewz_attribute_stock' || !isset($_POST['cova_attribute_stock_quantity'])) {
            return;
        }

        update_post_meta($post_id, 'cova_attribute_stock_quantity', $_POST['cova_attribute_stock_quantity']);
    }

    public function override_admin_inventory_template($template_path, $template)
    {
        if ($template !== 'admin/stock/panel-inventory') {
            return $template_path;
        }

        return plugin_dir_path(__FILE__) .'templates/admin/stock/panel-inventory.php';
    }
}
