<?php

use Mewz\Framework\Util\Number;

defined('ABSPATH') or die;

/**
* 
 *
 * @var Mewz\WCAS\Models\AttributeStock $stock 
*/

$lang = str_replace('_', '-', get_bloginfo('language'));

woocommerce_wp_text_input(
    [
    'label' => __('SKU', 'woocommerce'),
    'id' => 'mewz_wcas_sku',
    'name' => 'mewz_wcas[sku]',
    'description' => __('Unique identifier for stock keeping. Optional.', 'woocommerce-attribute-stock'),
    'desc_tip' => true,
    'value' => $stock->sku(),
    ]
);

//echo '<div style="display:none">';
//    woocommerce_wp_text_input([
//        'label' => __('Stock quantity', 'woocommerce'),
//        'id' => 'mewz_wcas_quantity',
//        'name' => 'mewz_wcas[quantity]',
//        'type' => 'hidden',
//        'placeholder' => number_format_i18n(0, 2),
//        'description' => __('Current stock quantity of this attribute stock item.', 'woocommerce-attribute-stock'),
//        'desc_tip' => true,
//        'value' => Number::period_decimal($stock->quantity()),
//        'custom_attributes' => ['step' => 'any', 'lang' => $lang],
//    ]);
//echo '</div>';

foreach (cova_get_all_wc_locations() as $location) {

    $quantity = $stock->meta('cova_attribute_stock_quantity', true);
    $quantity = (isset($quantity[$location['term_id']]))? $quantity[$location['term_id']] : 0;

    woocommerce_wp_text_input(
        [
        'label' => $location['name'] .' '. __('stock quantity', 'woocommerce'),
        'id' => 'cova_attribute_stock_quantity_at_'. $location['term_id'],
        'name' => 'cova_attribute_stock_quantity['. $location['term_id'] .']',
        'type' => 'number',
        'placeholder' => number_format_i18n(0, 2),
        'description' => __('Current stock quantity for '. $location['name'] .' location.', 'woocommerce-attribute-stock'),
        'desc_tip' => true,
        'value' => Number::period_decimal($quantity),
        'custom_attributes' => ['step' => 'any', 'lang' => $lang],
        ]
    );
}

woocommerce_wp_textarea_input(
    [
    'label' => __('Notes', 'woocommerce-attribute-stock'),
    'id' => 'mewz_wcas_notes',
    'name' => 'mewz_wcas[notes]',
    'rows' => 3,
    'description' => __('Internal notes about this attribute stock item.', 'woocommerce-attribute-stock'),
    'desc_tip' => true,
    'value' => $stock->notes(),
    ]
);
