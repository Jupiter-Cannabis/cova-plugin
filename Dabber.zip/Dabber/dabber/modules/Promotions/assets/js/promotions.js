(function ($) {
    function cova_initialize_promotion_sync()
    {
        sync_ajax(
            'promotion_sync', 'sync_promotions', {
                beforeSend: function () {
                },
                success: function (response) {

                    cova_print_log_message(response);
                    cova_sync_set_operation_status('complete');
                    console.log(response);
                }
            }
        );
    }

    $(document.body).on(
        'dabber_sync_promotions', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Syncing promotions...');
            cova_sync_set_operation_name('sync-promotions');
            cova_sync_set_operation_status('processing');

            cova_initialize_promotion_sync();
        }
    );
})(jQuery);