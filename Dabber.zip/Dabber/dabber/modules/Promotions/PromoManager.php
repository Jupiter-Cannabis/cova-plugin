<?php

namespace Dabber\Modules\Promotions;

class PromoManager
{
    public function generate_wc_promos()
    {
        $promotions = get_option('dabber_promotions');
        $promotions = (is_array($promotions))? $promotions : [];

        $enabled_promotions = get_option('dabber_enabled_promos');
        $enabled_promotions = (is_array($enabled_promotions))? $enabled_promotions : [];

        $cova_products = $this->get_cova_products($promotions);

        if (empty($cova_products)) {
            return [];
        }

        $all_promotions = [];

        foreach ($promotions as $location_id => $location_promos) {

            $wc_location = cova_get_wc_location_by_cova_location_id($location_id);

            foreach ($location_promos as $promo) {

                if (!in_array($promo['Id'], $enabled_promotions)) {
                    continue;
                }

                //                if (!$this->is_current_promo_period($promo['Period'])) {
                //                    continue;
                //                }

                foreach ($promo['Condition'] as $condition) {

                    if ($condition['Products']['Tag'] === 'All') {
                        $all_promotions[$wc_location->term_id]['all'][] = [
                            'promo_id'          => $promo['Id'],
                            'period'            => $promo['Period'],
                            'discount_amount'   => $promo['Rule']['Discount'][$promo['Rule']['Discount']['Tag']],
                            'discount_type'     => $promo['Rule']['Discount']['Tag']
                        ];
                    }

                    if (!empty($condition['Products']['Products'])) {
                        foreach ($condition['Products']['Products'] as $catalog_id) {
                            if (isset($cova_products['products'][$catalog_id])) {
                                $all_promotions[$wc_location->term_id][$cova_products['products'][$catalog_id]][] = [
                                    'promo_id'          => $promo['Id'],
                                    'period'            => $promo['Period'],
                                    'discount_amount'   => $promo['Rule']['Discount'][$promo['Rule']['Discount']['Tag']],
                                    'discount_type'     => $promo['Rule']['Discount']['Tag']
                                ];
                            }
                        }
                    }
                    if (!empty($condition['Products']['Classifications'])) {
                        foreach ($condition['Products']['Classifications'] as $classif_id) {
                            if (isset($cova_products['classification_products'][$classif_id])) {
                                foreach ($cova_products['classification_products'][$classif_id] as $product_id) {
                                    $all_promotions[$wc_location->term_id][$product_id][] = [
                                        'promo_id' => $promo['Id'],
                                        'period'            => $promo['Period'],
                                        'discount_amount'   => $promo['Rule']['Discount'][$promo['Rule']['Discount']['Tag']],
                                        'discount_type'     => $promo['Rule']['Discount']['Tag']
                                    ];
                                }
                            }
                        }
                    }
                    if (!empty($condition['Products']['Categories'])) {
                        foreach ($condition['Products']['Categories'] as $cat_id) {
                            if (isset($cova_products['category_products'][$cat_id])) {

                                foreach ($cova_products['category_products'][$cat_id] as $product_id) {
                                    $all_promotions[$wc_location->term_id][$product_id][] = [
                                        'promo_id'          => $promo['Id'],
                                        'period'            => $promo['Period'],
                                        'discount_amount'   => $promo['Rule']['Discount'][$promo['Rule']['Discount']['Tag']],
                                        'discount_type'     => $promo['Rule']['Discount']['Tag']
                                    ];
                                }
                            }
                        }
                    }
                }
            }
        }

        return $all_promotions;
    }

    public function is_current_promo_period($period): bool
    {
        $current_date = strtotime(current_time('Y-m-d G:i:s'));
        //        $current_date = strtotime('2022-06-28 08:00:00');
        $current_time = strtotime(current_time('G:i:s'));
        //        $current_time = strtotime('09:00:00');

        if (array_key_exists('Pattern', $period)) { // for recurring days.
            $start_date = strtotime($period['EffectiveDateRange']['StartDate']);
            $end_date   = strtotime($period['EffectiveDateRange']['EndDate']);

            if ($current_date < $start_date || $current_date > $end_date) {
                return false;
            }

            $current_day = current_time('l');
            //            $current_day = 'Tuesday';

            if (!in_array($current_day, $period['Pattern']['DaysOfTheWeek'])) {
                return false;
            }

            $start_time = strtotime($period['TimeSchedule']['StartTime']);
            $end_time   = strtotime($period['TimeSchedule']['EndTime']);

            if ($current_time >= $start_time && $current_time <= $end_time) {
                return true;
            }
        }

        if (array_key_exists('DateRanges', $period)) { // for specific dates or continuous days.
            foreach ($period['DateRanges'] as $range) {
                if ($current_date >= strtotime($range['StartDate']) && $current_date <= strtotime($range['EndDate'])) {
                    return true;
                }
            }
        }

        return false;
    }

    public function get_cova_products($promotions)
    {
        $catalog_ids             = [];
        $classification_ids      = [];
        $category_ids            = [];

        foreach ($promotions as $location_promos) {
            foreach ($location_promos as $promo) {
                foreach ($promo['Condition'] as $condition) {
                    if (!empty($condition['Products']['Products'])) {
                        foreach ($condition['Products']['Products'] as $catalog_id) {
                            $catalog_ids[] = $catalog_id;
                        }
                    }
                    if (!empty($condition['Products']['Classifications'])) {
                        foreach ($condition['Products']['Classifications'] as $classif_id) {
                            $classification_ids[] = $classif_id;
                        }
                    }
                    if (!empty($condition['Products']['Categories'])) {
                        foreach ($condition['Products']['Categories'] as $cat_id) {
                            $category_ids[] = $cat_id;
                        }
                    }
                }
            }
        }

        $products = [];

        if (!empty($catalog_ids)) {
            $catalog_ids = array_unique($catalog_ids);

            foreach ($catalog_ids as $catalog_id) {
                $product = dabber_get_product_by_catalog_id($catalog_id);
                if ($product !== false) {
                    $products[$catalog_id] = $product->get_id();
                }
            }
        }

        $classification_products = [];

        if (!empty($classification_ids)) {
            $classification_ids = array_unique($classification_ids);

            foreach ($classification_ids as $id) {
                $classification_catalog_ids = $this->get_catalog_ids_by_category_or_classifications($id);
                foreach ($classification_catalog_ids as $classif_catalog_id) {
                    $product = dabber_get_product_by_catalog_id($classif_catalog_id);
                    if ($product !== false) {
                        $classification_products[$id][$classif_catalog_id] = $product->get_id();
                    }
                }
            }
        }

        $category_products = [];

        if (!empty($category_ids)) {
            $category_ids = array_unique($category_ids);

            foreach ($category_ids as $id) {
                $category_catalog_ids = $this->get_catalog_ids_by_category_or_classifications($id);

                foreach ($category_catalog_ids as $category_catalog_id) {
                    $product = dabber_get_product_by_catalog_id($category_catalog_id);
                    if ($product !== false) {
                        $category_products[$id][$category_catalog_id] = $product->get_id();
                    }
                }
            }
        }

        return [
            'products' => $products,
            'classification_products' => $classification_products,
            'category_products' => $category_products
        ];
    }

    public function get_catalog_ids_by_category_or_classifications($id): array
    {
        $catalog = new \CovaAPI\Catalog();
        $catalog_ids = [];

        $items = $catalog->get_products_by_category_or_classification($id);
        $items = json_decode($items, true);

        if (!is_array($items) || !isset($items['Items'])) {
            return [];
        }

        foreach ($items['Items'] as $item) {
            $catalog_ids[] = $item['CatalogItemId'];
        }

        return array_unique($catalog_ids);
    }
}
