<?php

if (empty($args['promotions'])) {
    echo '<p>No available promotions.</p>';
    return;
}

    $promos_arr = [];

foreach ($args['promotions'] as $location_id => $promos) {
    foreach ($promos as $promo) {
        $promos_arr[$promo['Id']] = $promo;
    }
}

?>
<form action="" method="post">
    <h3>Enable/Disable Promotions</h3>
    <table class="form-table">
        <tbody>
        <?php foreach ($promos_arr as $promo_id => $promo) :

            $promo_details = \Dabber\Modules\Promotions\Promotions::get_promo_formatted_details($promo);
            ?>
            <tr>
                <th scope="row">
                    <?php echo $promo_details['name'] .' - '. $promo_details['discount']; ?>
                    <div class="promo-details">
                        <?php if (is_array($promo_details['schedule'])) : ?>
                            <?php foreach ($promo_details['schedule'] as $sched) : ?>
                                <p><?php echo $sched['start'] .' to '. $sched['end']  ?></p>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <p><?php echo $promo_details['schedule'] ?></p>
                        <?php endif; ?>
                    </div>
                </th>
                <td>
                    <fieldset>
                        <label for="dabber_enable_<?php echo $promo_id ?>">
                            <input name="dabber_enabled_promotions[<?php echo $promo_id ?>]" <?php echo ((in_array($promo_id, $args['enabled_promos']))? 'checked="checked"' : '') ?> type="checkbox" id="dabber_enable_<?php echo $promo_id ?>" value="1">
                            <input type="hidden" name="dabber_promos[]" value="<?php echo $promo_id; ?>">
                        </label>
                    </fieldset>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <hr/>
<!--    <table class="form-table">-->
<!--        <tbody>-->
<!--        <tr>-->
<!--            <th scope="row">Override product on sale price</th>-->
<!--            <td>-->
<!--                <fieldset>-->
<!--                    <label for="dabber_override_sale_prices">-->
<!--                        <input name="dabber_override_sale_prices" --><?php //echo (($args['override_sale_prices'] === 'on')? 'checked="checked"' : '') ?><!-- type="checkbox" id="dabber_override_sale_prices" value="1">-->
<!--                    </label>-->
<!--                </fieldset>-->
<!--            </td>-->
<!--        </tr>-->
<!--        </tbody>-->
<!--    </table>-->
    <input type="submit" id="submit" name="dabber-promotions-settings" class="button button-primary" value="Save Changes">
</form>

<style>
    .promo-details p {
        margin-bottom: 3px;
        margin-top: 0;
    }

    .promo-details {
        font-weight: normal;
    }
</style>
