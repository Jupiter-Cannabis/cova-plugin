<?php

use Dabber\Modules\CategoryMapping\CategoryMapping;

echo '<h2>Category Mapping</h2>';

echo '<table class="form-table">';
echo '<tbody>';
echo '<tr>';
echo '<th scope="row">';
echo '<label for="cova-classification-tree-id">'. __('Cova Classification Tree ID', 'cova') .'</label>';
echo '</th>';
echo '<td>';
echo '<input name="cova-classification-tree-id" type="text" id="cova-classification-tree-id" value="'. $args['classification_tree_id'] .'" class="regular-text ltr" autocomplete="off">';
echo '</td>';
echo '</tr>';
echo '</tbody>';
echo '</table>';


if (!$args['classification_tree_id']) {
    echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';
    return;
}

if (empty($args['merged_categories'])) {
    echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';
    return;
}

echo '<p></p>';
echo '<hr>';

echo '<h4>Top Level Categories</h4>';
foreach ($args['merged_categories'] as $key => $item) {

    $item_key = dabber_sanitize_slug($item['Name']);

    echo '<div class="cova-cat-mapping-wrap">';
    echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item['Name'] .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 0) .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 1) .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 2) .'">';
    echo '</div>';
}

echo '<p style="margin-bottom:20px;"></p>';
echo '<hr>';

echo '<h4>Online Menu Categories</h4>';
foreach ($args['cova_categories'] as $key => $item) {

    $item_key = str_replace(' >>> ', '-', $item);
    $item_key = dabber_sanitize_slug($item_key);
    $item = str_replace(' >>> ', ' → ', $item);

    echo '<div class="cova-cat-mapping-wrap">';
    echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 0) .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 1) .'">';
    echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. CategoryMapping::get_cova_mapping_value($args['mapping'], $item_key, 2) .'">';
    echo '</div>';
}

echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';

echo '<p style="margin: 30px 0;"></p>';
echo '<hr>';

echo '<h3>Regenerate Product Categories</h3>';

echo '<p><input type="submit" id="cova-regenerate-categories" class="cova-sync-btn button button-primary button-large" value="Regenerate"></p>';
