<?php

namespace Dabber\Modules\CategoryMapping;

class TermsMapper
{
    private $category_separator = '_cova_term_child_separator_';

    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new TermsMapper();
        }

        return self::$instance;
    }

    /**
     * We need this filter for the WP term_exists execution to
     * format the term_slug properly when searching for the term slug
     *
     * @param  $title
     * @param  $fallback_title
     * @param  $context
     * @return mixed|string
     */
    public function modify_term_slug_search($title, $fallback_title = '', $context = 'save')
    {
        if (stripos($title, $this->category_separator) !== false) {
            $new_term_slug = str_replace($this->category_separator, '-', $title);
            $title = dabber_sanitize_slug($new_term_slug);
        }

        return $title;
    }

    public function modify_term_name($term, $taxonomy, $args)
    {
        if (stripos($term, $this->category_separator) !== false) {
            $names = explode($this->category_separator, $term);
            $term = end($names);
        }

        return $term;
    }

    public function modify_term_insert_args($args)
    {
        if (stripos($args['slug'], $this->category_separator) !== false) {
            $child_slug = str_replace($this->category_separator, '-', $args['slug']);
            $terms = explode($this->category_separator, $args['slug']);

            $parent_slug = (count($terms) < 3)? $terms[0] : $terms[1];
            $parent = get_term_by('slug', $parent_slug, 'product_cat');

            $parent_id = (isset($parent->term_id))? $parent->term_id : 0;

            $args['slug'] = $child_slug;
            $args['parent'] = $parent_id;
        }

        return $args;
    }

    public function modify_product_sync_taxonomies($taxonomies, $cova_categories, $category_mapping)
    {
        if (empty($category_mapping) || empty($taxonomies['product_cat'])) {
            return $taxonomies;
        }

        $new_product_cat = [];

        foreach ($taxonomies['product_cat'] as $term) {
            $slug = dabber_sanitize_slug($term);
            if (!isset($category_mapping[$slug])) {
                continue;
            }

            foreach (array_filter($category_mapping[$slug]) as $index => $item) {
                if ($item === '{strain}') {
                    $strain = str_replace('{strain}', $cova_categories['strain'], $item);
                    $category_mapping[$slug][$index] = $strain;
                    $item = $strain;
                }
                $previous_items = array_slice($category_mapping[$slug], 0, $index);
                $parents = '';
                if (!empty($previous_items)) {
                    $parents = implode($this->category_separator, $previous_items) . $this->category_separator;
                }

                $new_product_cat[] = $parents . $item;
            }
        }

        if (!empty($new_product_cat)) {
            $taxonomies['product_cat'] = array_unique($new_product_cat);
        }

        return $taxonomies;
    }

} // end Class
