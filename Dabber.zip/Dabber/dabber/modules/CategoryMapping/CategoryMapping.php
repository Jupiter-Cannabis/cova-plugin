<?php

namespace Dabber\Modules\CategoryMapping;

use Cova_Integration\Cova_Product_Category;

class CategoryMapping
{
    private $tab_key = 'category_mapping';

    public static $must_use = true;
    public static $module_info = [
        'name' => 'Category Mapping',
        'description' => 'Map Woocommerce categories vs Cova categories.'
    ];

    public function run()
    {
        add_filter('dabber_admin_module_nav_items', [$this, 'add_tab'], 30);
        add_filter('dabber_admin_module_sub_nav_items_mapping', [$this, 'add_submenu_item'], 30);
        add_action('dabber_render_module_admin_section_mapping_'. $this->tab_key, [$this, 'render_tab_section']);
        add_action('dabber_admin_module_save_settings_mapping_'. $this->tab_key, [$this, 'save_cova_wc_mapping']);

        add_action('dabber_register_module_hooks_mapping_'. $this->tab_key, [$this, 'register_hooks']);

        add_filter('sanitize_title', [TermsMapper::getInstance(), 'modify_term_slug_search'], 100, 3);
        add_filter('cova_insert_term_args', [TermsMapper::getInstance(), 'modify_term_insert_args'], 100, 3);
        add_filter('pre_insert_term', [TermsMapper::getInstance(), 'modify_term_name'], 100, 3);
        add_filter('cova_product_sync_taxonomies', [TermsMapper::getInstance(), 'modify_product_sync_taxonomies'], 20, 3);
    }

    public function register_hooks()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script('cova-sync-func');
        wp_enqueue_script('cova-category-mapping', plugin_dir_url(__FILE__) .'assets/js/category-mapping.js', [], null, true);
    }

    public function add_tab($tabs)
    {
        $tabs['mapping'] = __('Mapping');

        return $tabs;
    }

    public function add_submenu_item($submenu_items)
    {
        $submenu_items['category_mapping'] = __('Category Mapping', 'dabber');

        return $submenu_items;
    }

    public function render_tab_section()
    {
        $classification_tree_id = trim(get_option('cova_classification_tree_id'));
        $merged_categories = Cova_Product_Category::get_all_cova_categories($classification_tree_id);
        $mapping = get_option('cova_category_mapping');
        $cova_categories = $this->get_cova_possible_categories();

        load_template(
            plugin_dir_path(__FILE__) .'templates/category-mapping.php', true, [
            'classification_tree_id'    => $classification_tree_id,
            'merged_categories'         => $merged_categories,
            'mapping'                   => $mapping,
            'cova_categories'           => $cova_categories
            ]
        );
    }

    public function get_cova_possible_categories()
    {
        //        $data = Cova_Data_Manager::get_stored_data('grouped_catalog_items');

        //        if ($data !== false && !empty($data)) {
        //            return $data;
        //        }

        $catalog_api = new \Cova_Integration\Sync\Catalog();
        $catalog_api->run();

        $all_items = $catalog_api->items();
        $catalog_ids = [];

        foreach ($all_items as $key => $item) {
            $catalog_ids[] = $item['CatalogItemId'];
        }

        $grouped_catalog_ids = array_chunk($catalog_ids, 450, false);
        $cova_categories = [];

        foreach ($grouped_catalog_ids as $key => $catalog_id_items) {

            $grouped_products = $catalog_api->bulk(
                [
                'CatalogItemIds' => $catalog_id_items
                ]
            );

            foreach ($grouped_products['CatalogItems'] as $catalog_id => $catalog_item) {

                $grouped_cats = [];

                if (isset($catalog_item['CanonicalClassification']['Name'])) {
                    $grouped_cats[] = $catalog_item['CanonicalClassification']['Name'];
                }

                if (isset($catalog_item['Specifications']) && !empty($catalog_item['Specifications'])) {
                    foreach ($catalog_item['Specifications'] as $key => $spec) {
                        if (strtolower($spec['Name']) === 'online menu') {
                            foreach ($spec['Fields'] as $field) {
                                if (strtolower($field['DisplayName']) === 'online menu category') {
                                    $grouped_cats[] = $field['Value'];
                                }
                            }
                        }
                    }
                }

                if (count($grouped_cats) > 1) { // only include items with sub category
                    $cova_categories[] = implode(' >>> ', $grouped_cats);
                }
            }
        }

        $cova_categories = array_unique($cova_categories);

        //        Cova_Data_Manager::store_data('grouped_catalog_items', $cova_categories);

        return $cova_categories;
    }

    public static function get_cova_mapping_value($mapping, $id, $index)
    {
        if (!isset($mapping[$id][$index])) {
            return '';
        }

        return $mapping[$id][$index];
    }

    public function save_cova_wc_mapping()
    {
        if (isset($_POST['cova_classification'])) {
            update_option('cova_category_mapping', $_POST['cova_classification']);
        }

        if (isset($_POST['cova-classification-tree-id'])) {
            update_option('cova_classification_tree_id', sanitize_text_field($_POST['cova-classification-tree-id']));
        }
    }
}
