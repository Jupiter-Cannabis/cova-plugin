<?php

namespace Dabber\Modules;

require_once __DIR__ . '/../vendor/autoload.php';

class DabberModuleLoader
{
    private $modules;

    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'load_modules'], 9);
    }

    public function load_modules()
    {
        global $dabber_available_modules, $dabber_enabled_modules;

        $this->modules = $this->get_modules();

        // Store available modules in a global variable.
        $dabber_available_modules = $this->modules['available_modules'];

        // Store enabled modules in a global variable.
        $dabber_enabled_modules = $this->modules['enabled_modules'];

        foreach ($this->modules['enabled_modules'] as $module) {
            $class_name = basename($module);
            if (!class_exists($class_name)) {
                continue;
            }
            $$class_name = (new $module())->run();
        }
    }

    /**
     * @todo   review $enable_default feature.
     * @return array[]
     */
    public function get_modules()
    {
        // Get all modules in module directory
        $modules = glob(__DIR__ .'/*', GLOB_ONLYDIR);

        if (empty($modules)) {
            return [
                'available_modules'  => [],
                'enabled_modules'    => []
            ];
        }

        $available_modules  = [];
        $must_use_modules   = [];
        //        $default_modules    = [];

        foreach ($modules as $module) {
            $module_name = basename($module);
            $class_name = '\Dabber\Modules\\' . $module_name . '\\' . $module_name;

            if (!class_exists($class_name) || !method_exists($class_name, 'run')) {
                continue;
            }

            if (!isset($class_name::$module_info)) {
                continue;
            }

            $class_name::$module_info['must_use'] = false;
            $class_name::$module_info['class'] = $class_name;

            if (isset($class_name::$must_use) && $class_name::$must_use === true) {
                $class_name::$module_info['must_use'] = true;
                $must_use_modules[] = $class_name;
            }

            //            if (isset($class_name::$enable_default) && $class_name::$enable_default === true) {
            //                $default_modules[] = $class_name;
            //            }

            $available_modules[] = $class_name::$module_info;
        }

        $saved_enabled_modules      = get_option('dabber_enabled_modules');
        $saved_enabled_modules      = (!empty($saved_enabled_modules))? $saved_enabled_modules : [];
        //        $enabled_modules            = array_merge($must_use_modules, $saved_enabled_modules, $default_modules);
        $enabled_modules            = array_merge($must_use_modules, $saved_enabled_modules);

        $formatted_classes = [];

        // Format class names from database and remove double backslash.
        foreach ($enabled_modules as $enabled_module) {
            $formatted_classes[] = str_replace('\\\\', '\\', $enabled_module);
        }

        return [
            'available_modules'  => $available_modules,
            'enabled_modules'    => $formatted_classes
        ];
    }

} // End class

new DabberModuleLoader();
