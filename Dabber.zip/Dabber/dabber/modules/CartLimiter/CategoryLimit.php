<?php

namespace Dabber\Modules\CartLimiter;

class CategoryLimit
{
    //    private $options = [];

    public function __construct()
    {
        add_action('admin_init', [$this, 'load_options']);

        add_filter('dabber_render_module_admin_section_cart_cart_limit', [$this, 'render_category_limit_settings']);
    }

    public function load_options()
    {
        //        $this->options = [
        //            'cart_limits' => dabber_get_cart_limits()
        //        ];
    }

    public function get_categories_array()
    {
        $categories = new \WP_Term_Query(
            [
            'taxonomy'   => 'product_cat',
            'hide_empty' => false
            ]
        );

        $categories_arr = [];

        foreach ($categories->terms as $category) {
            $parent_name = '';

            if ($category->parent) {
                $parent = get_term_by('id', $category->parent, 'product_cat');
                $parent_name = $parent->name .' > ';
            }
            $categories_arr[$category->slug] = $parent_name . $category->name;
        }

        return $categories_arr;
    }

    public function get_category_cart_limits_settings()
    {
        $settings = get_option('dabber_cart_limits');

        return (is_array($settings))? $settings : [];
    }

    public function render_category_limit_settings()
    {
        global $dabber_cart_limits;

        $categories = $this->get_categories_array();

        load_template(
            plugin_dir_path(__FILE__) . 'templates/category-limit-settings.php', true, [
            'categories' => $categories,
            'options' => $dabber_cart_limits
            ]
        );
    }
}
