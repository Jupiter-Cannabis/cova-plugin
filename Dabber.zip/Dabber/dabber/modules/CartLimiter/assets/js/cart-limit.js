(function ($) {
    $(document).ready(
        function () {
            if($('.cat-oos-item').length > 0) {
                $('.cat-oos-item').each(
                    function () {
                        let item = $(this);

                        item.find('.oos-cat').select2();
                        item.find('.oos-loc').select2();
                    }
                );
            }

            $('.add-limiter').click(
                function (e) {
                    e.preventDefault();

                    var new_row = $('.cart-limit-dummy:last').clone();

                    $(new_row).insertAfter(".cart-limit:last");
                    $(new_row).removeClass('cart-limit-dummy');
                    $(new_row).find('.cart-limit-cat').select2();
                }
            );

            $(document.body).on(
                'click', '.remove-cart-limit', function (e) {
                    var button = $(this);

                    button.closest('tr.cart-limit').remove();
                }
            );
        }
    );
})(jQuery);