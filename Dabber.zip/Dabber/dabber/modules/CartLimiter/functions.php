<?php

function dabber_get_cart_limits()
{
    $defaul_settings = [
        'cart_limits' => [
            'limit_type' => 'standard',
            'maximum_limit' => 30,
            'limits' => [
                [
                    'category' => 'concentrates',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ],
                [
                    'category' => 'topicals',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ],
                [
                    'category' => 'beverages',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ],
                [
                    'category' => 'flower',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ],
                [
                    'category' => 'pre-rolls',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ],
                [
                    'category' => 'edibles',
                    'limit_num' => 30,
                    'limit_unit' => 'g'
                ]
            ]
        ]
    ];

    $limits = get_option('dabber_cart_limits');

    if (empty($limits)) {
        $limits = $defaul_settings['cart_limits'];
    }

    return apply_filters('dabber_cart_limits', $limits);
}

function dabber_get_cart_limit_types()
{
    return apply_filters('dabber_cart_limit_types', [
        'standard',
        'mmceu'
    ]);
}
