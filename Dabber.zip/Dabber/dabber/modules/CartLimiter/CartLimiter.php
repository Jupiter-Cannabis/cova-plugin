<?php

namespace Dabber\Modules\CartLimiter;

use Cova_Integration\Sync\Purchase_Limits as PurchaseLimits;
use Cova_Integration\Sync\Traits\Purchase_Limits_Traits as PurchaseLimitsTraits;

class CartLimiter
{
    use PurchaseLimitsTraits;

    public $version = '1.0';
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Cart Limiter',
        'description' => 'Manage cart weight limits.'
    ];

    public $options = [];

    private static $over_limit = 'Over Limit';

    private static $integration_types = [
        'API',
        'Manual'
    ];

    private static $customer_types = [
        'Recreational',
        'Medical'
    ];

    public function run()
    {
        add_action('dabber_admin_module_save_settings_cart_cart_limit', [$this, 'save_settings']);

        add_action('init', [$this, 'load_options']);

        add_filter('dabber_admin_module_nav_items', [$this, 'add_cart_tab'], 50);
        add_filter('dabber_admin_module_sub_nav_items_cart', [$this, 'add_cart_sub_tab']);

        add_action('dabber_render_module_admin_section_cart_cart_limit', [$this, 'render_cart_limit_settings']);
        add_action('dabber_admin_enqueue_scripts_cart_cart_limit', [$this, 'enqueue_scripts']);
        add_action('dabber_render_module_admin_section_cart_cart_limit', [$this, 'add_save_button'], 9999);

        require_once 'functions.php';

        add_action('woocommerce_add_to_cart_validation', [$this, 'validate_products_cart_weight_limit'], 100, 5);
        add_action('woocommerce_update_cart_validation', [$this, 'validate_cart_items_weight_limit'], 100, 4);

        $this->load_classes();
    }

    public function load_options()
    {
        global $dabber_cart_limits;

        $dabber_cart_limits = [
            'limit_types' => dabber_get_cart_limit_types(),
            'cart_limits' => dabber_get_cart_limits()
        ];
    }

    public function load_classes()
    {
        global $dabber_class_limiters;

        $dabber_class_limiters['standard'] = new CategoryLimit();
        $dabber_class_limiters['mmceu']    = new MmceuLimit();
    }

    public function enqueue_scripts()
    {
        wp_enqueue_style('select2', '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', [], null);
        wp_enqueue_script('select2');

        wp_enqueue_style('cart-limit', plugin_dir_url(__FILE__) .'assets/css/cart-limit.css', []);
        wp_enqueue_script('cart-limit', plugin_dir_url(__FILE__) .'assets/js/cart-limit.js', [], null, true);
        wp_add_inline_script('cart-limit', 'let categorized_oos_vars = '. json_encode([
                'ajax_url' => admin_url('admin-ajax.php')
            ]), 'before');
    }

    public function save_settings($post_data)
    {
        $cart_limits = [];

        if (!empty($post_data['cart_limit_cat'])) {
            foreach ($post_data['cart_limit_cat'] as $key => $item) {
                $limit_num  = $post_data['cart_limit_num'][$key];
                $limit_unit = $post_data['cart_limit_unit'][$key];
                if (!$item || !$limit_num || !$limit_unit) {
                    continue;
                }

                $cart_limits[] = [
                    'category' => $item,
                    'limit_num' => $limit_num,
                    'limit_unit' => $limit_unit
                ];
            }
        }

        update_option('dabber_cart_limits', [
            'integration_type'  => $post_data['integration_type'],
            'customer_type'     => $post_data['customer_type'],
            'limit_type'        => $post_data['limit_type'],
            'maximum_limit'     => (float) $post_data['maximum_limit'],
            'limits'            => $cart_limits
        ]);
    }

    public function render_cart_limit_settings()
    {
        global $dabber_cart_limits;

        $dabber_cart_limits_db = get_option('dabber_cart_limits');

        if (!isset($dabber_cart_limits_db['integration_type'])) {
            $dabber_cart_limits_db['integration_type'] = self::$integration_types[0];
        }
        if (!isset($dabber_cart_limits_db['customer_type'])) {
            $dabber_cart_limits_db['customer_type'] = self::$customer_types[0];
        }

        load_template(plugin_dir_path(__FILE__) . 'templates/cart-limit-settings.php', true, [
            'integration_types' => self::$integration_types,
            'integration_type'  => $dabber_cart_limits_db['integration_type'],
            'customer_types'    => self::$customer_types,
            'customer_type'     => $dabber_cart_limits_db['customer_type'],
            'limit_types'       => $dabber_cart_limits['limit_types'],
            'options'           => $dabber_cart_limits
        ]);
    }

    public function add_save_button()
    {
        echo '<hr><input type="submit" id="submit" class="button button-primary" value="Save Changes">';
    }

    public function add_cart_tab($tabs)
    {
        $tabs['cart'] = __('Cart', 'dabber');

        return $tabs;
    }

    public function add_cart_sub_tab($sub_tabs)
    {
        $sub_tabs['cart_limit'] = __('Cart Limit', 'dabber');

        return $sub_tabs;
    }

    /**
     * Check weight limit on single product page add to cart
     */
    public function validate_products_cart_weight_limit($passed, $product_id, $quantity, $variation_id = '', $variations = '')
    {
        if ($variation_id) {
            $product_id = $variation_id;
        }

        $product = wc_get_product($product_id);

        if ($this->is_cart_limit_reached($product, $quantity) === true) {
            cova_add_wc_notice(__($this->getOverLimitsMessage(), "woocommerce"), 'error');
            return false;
        }

        return $passed;
    }

    /**
     * Check weight limit on cart items
     */
    public function validate_cart_items_weight_limit($true,  $cart_item_key,  $values,  $quantity)
    {
        $product_id = $values['variation_id'] ? $values['variation_id'] : $values['product_id'];
        $product    = wc_get_product($product_id);

        if ($quantity <= $values['quantity']) {
            return $true;
        }

        if ($this->is_cart_limit_reached($product, ($quantity - $values['quantity'])) === true) {
            cova_add_wc_notice(__($this->getOverLimitsMessage(), "woocommerce"), 'error');
            return false;
        }

        return $true;
    }

    /**
     * Check if total weight of the cart has reached the limit.
     */
    public function is_cart_limit_reached($product, $current_quantity): bool
    {
        global $dabber_current_location_data;

        $options = get_option('dabber_cart_limits');

        if (!isset($options['integration_type']) || $options['integration_type'] == 'API') {
            $location_id = $dabber_current_location_data['cova_location_id'];

            $purchase_limits = new PurchaseLimits();
            $purchase_limits->run();

            $response = $purchase_limits->getTransactionLimits($location_id, $product, $current_quantity);

            return self::is_transaction_limit_reached($response);
        }

        $cart_limiter = new Limiter();
        $cart_limiter->set_product($product);
        $cart_limiter->set_quantity($current_quantity);

        return $cart_limiter->is_cart_weight_full();
    }

    private static function is_transaction_limit_reached($response): bool
    {
        if (isset($response['gauges']) && empty($response['gauges'])) {
            return true;
        }

        $is_limit_reached = false;

        foreach ($response['gauges'] as $gauges) {
            if ($gauges['gaugeState'] == self::$over_limit) {
                $is_limit_reached = true;
            }
        }

        return $is_limit_reached;
    }
}
