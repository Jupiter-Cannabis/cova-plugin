<?php

namespace Dabber\Modules\CartLimiter;

use function GuzzleHttp\Psr7\_caseless_remove;

class MmceuLimit
{
    //    private $options = [];

    public function __construct()
    {
        //        add_action('init', [$this, 'load_options']);

        add_filter('dabber_render_module_admin_section_cart_cart_limit', [$this, 'render_mmceu_limit_settings'], 9);
        add_filter('dabber_cart_limit_over_text', [$this, 'override_cart_limit_over_text'], 100, 3);
    }

    //    public function load_options()
    //    {
    //        $this->options = [
    //            'cart_limits' => dabber_get_cart_limits()
    //        ];
    //    }

    public function override_cart_limit_over_text($text, $weight_limit, $weight_unit)
    {
        global $dabber_cart_limits;

        if ($dabber_cart_limits['cart_limits']['limit_type'] !== 'mmceu') {
            return $text;
        }

        return '<span class="cart-weight-limit">out of<br> 6 MMCEU</span>';
    }

    public function render_mmceu_limit_settings()
    {
        global $dabber_cart_limits;

        if ($dabber_cart_limits['cart_limits']['limit_type'] !== 'mmceu') {
            return;
        }

        load_template(
            plugin_dir_path(__FILE__) . 'templates/mmceu-limit-settings.php', true, [
            'options' => $dabber_cart_limits
            ]
        );
    }
}
