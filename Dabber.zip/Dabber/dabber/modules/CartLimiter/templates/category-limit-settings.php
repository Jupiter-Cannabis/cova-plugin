<h3>Limit by Categories</h3>

<div class="category-limit-wrap">
    <table class="form-table">
        <tbody>
        <tr>
            <td><strong>Category</strong></td>
            <td><strong>Limit</strong></td>
            <td><strong>Unit</strong></td>
            <td></td>
        </tr>
        <tr class="cart-limit-dummy cart-limit">
            <td>
                <select name="cart_limit_cat[]" class="cart-limit-cat" style="max-width: 200px;">
                    <option value="">-- Select Category ---</option>
                    <?php foreach($args['categories'] as $slug => $category_name) : ?>
                        <option value="<?php echo $slug ?>"><?php echo $category_name ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <input type="number" name="cart_limit_num[]" value="" step="0.1" min="0" style="max-width: 80px;">
            </td>
            <td>
                <select name="cart_limit_unit[]" style="max-width: 100px;">
                    <option value="">-- Select --</option>
                    <option value="g">Grams</option>
                    <option value="mg">Milligrams</option>
                </select>
            </td>
            <td><input type="button" class="remove-cart-limit" value="Remove Item"></td>
        </tr>

        <?php if (!empty($args['options']['cart_limits']['limits'])) : ?>
            <?php
            foreach ($args['options']['cart_limits']['limits'] as $limit_item) :
                ?>
                <tr class="cart-limit">
                    <td>
                        <select name="cart_limit_cat[]" class="cart-limit-cat" style="max-width: 200px;">
                            <option value="">-- Select Category ---</option>
                            <?php foreach($args['categories'] as $slug => $category_name) : ?>
                                <option <?php selected($slug, $limit_item['category']) ?> value="<?php echo $slug ?>"><?php echo $category_name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <input type="number" name="cart_limit_num[]" value="<?php echo $limit_item['limit_num'] ?>" step="0.1" min="0" style="max-width: 80px;">
                    </td>
                    <td>
                        <select name="cart_limit_unit[]" style="max-width: 100px;">
                            <option value="">-- Select --</option>
                            <option <?php selected('g', $limit_item['limit_unit']) ?> value="g">Grams</option>
                            <option <?php selected('mg', $limit_item['limit_unit']) ?> value="mg">Milligrams</option>
                        </select>
                    </td>
                    <td><input type="button" class="remove-cart-limit" value="Remove Item"></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>

        <tr>
            <td colspan="4">
                <div style="text-align: center">
                    <input type="button" class="add-limiter" value="Add Item">
                </div>
            </td>
        </tr>
        </tbody>
    </table>
</div>
