<h3 style="background-color: #efefef; padding: 10px;">General</h3>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row">Integration Type</th>
        <td>
            <select name="integration_type" style="min-width: 200px;">
                <?php foreach ($args['integration_types'] as $type) : ?>
                    <option <?php echo $type == $args['integration_type'] ? 'selected' : '' ?> value="<?php echo $type ?>"><?php echo $type ?></option>
                <?php endforeach; ?>
            </select>
        </td>
    </tr>
    </tbody>
</table>

<h3 style="background-color: #efefef; padding: 10px;">API</h3>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row">Customer Type</th>
        <td>
            <select name="customer_type" style="min-width: 200px;">
                <?php foreach ($args['customer_types'] as $type) : ?>
                    <option <?php echo $type == $args['customer_type'] ? 'selected' : '' ?> value="<?php echo $type ?>"><?php echo $type ?></option>
                <?php endforeach; ?>
            </select>
        </td>
    </tr>
    </tbody>
</table>

<h3 style="background-color: #efefef; padding: 10px;">Manual</h3>
<table class="form-table">
    <tbody>
    <tr>
        <th scope="row">Cart Limit Type</th>
        <td>
            <select name="limit_type" style="min-width: 200px;">
                <option <?php selected('standard', $args['options']['cart_limits']['limit_type']) ?> value="standard">Standard</option>
                <option <?php selected('mmceu', $args['options']['cart_limits']['limit_type']) ?> value="mmceu">MMCEU</option>
            </select>
        </td>
    </tr>
    <tr>
        <th scope="row">Maximum Cart Limit (g)</th>
        <td>
            <input type="number" name="maximum_limit" min="0" step="0.1" value="<?php echo $args['options']['cart_limits']['maximum_limit'] ?>" style="min-width: 200px;">
        </td>
    </tr>
    </tbody>
</table>
