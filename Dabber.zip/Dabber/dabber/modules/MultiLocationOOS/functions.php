<?php

function dabber_get_location_oos_threshold($location_id)
{
    $loc_threshold = get_term_meta($location_id, 'dabber_oos_threshold', true);

    if (!is_numeric($loc_threshold)) {
        //        return (int) get_option('woocommerce_notify_no_stock_amount');
        return 0;
    }

    return (int) $loc_threshold;
}
