
<h3>Out of stock threshold by location</h3>

<table class="form-table">
    <tbody>
        <?php
        foreach($args['locations'] as $location) :

            $loc_threshold = dabber_get_location_oos_threshold($location['term_id']);
            ?>
        <tr>
            <th><?php echo $location['name'] ?></th>
            <td>
                <input type="number" name="oos[<?php echo $location['term_id'] ?>]" min="0" value="<?php echo $loc_threshold ?>">
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
