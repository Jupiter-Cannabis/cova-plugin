<?php

namespace Dabber\Modules\MultiLocationOOS;

class MultiLocationOOS
{
    //    public static $must_use = false;
    //    public static $module_info = [
    //        'name' => 'Multi-location based out of stock threshold',
    //        'description' => ''
    //    ];

    public $options = [];

    public function run()
    {
        include_once 'functions.php';

        add_filter('dabber_admin_module_nav_items', [$this, 'add_new_tab'], 30);
        add_filter('dabber_admin_module_sub_nav_items_products', [$this, 'add_sub_tab']);
        add_filter('option_woocommerce_notify_no_stock_amount', [$this, 'override_wc_oos_threshold'], 100, 2);

        add_action('dabber_render_module_admin_section_products_inventory', [$this, 'render_inventory_tab_content']);
        add_action('dabber_render_module_admin_section_products_inventory', [$this, 'add_save_button'], 9999);
        add_action('dabber_admin_module_save_settings_products_inventory', [$this, 'save_settings']);

        add_action('woocommerce_add_to_cart_validation', [$this, 'validate_shop_page_oos_limit'], 100, 5);
        add_action('woocommerce_update_cart_validation', [$this, 'validate_cart_items_oos_limit'], 100, 4);
    }

    /**
     * Check oos limit on single product page add to cart
     */
    public function validate_shop_page_oos_limit($passed, $product_id, $quantity, $variation_id = '', $variations = '')
    {
        if ($variation_id) {
            $product_id = $variation_id;
        }

        $is_qty_enough = $this->check_product_cart_quantity($product_id, $quantity);

        if ($is_qty_enough !== true) {
            cova_add_wc_notice($is_qty_enough, 'error');
            return false;
        }

        return $passed;
    }

    /**
     * Check oos limit on cart items
     */
    public function validate_cart_items_oos_limit($true,  $cart_item_key,  $values,  $quantity)
    {
        $is_qty_enough = $this->check_product_cart_quantity($values['data']->get_id(), $quantity, true);

        if ($is_qty_enough !== true) {
            cova_add_wc_notice($is_qty_enough, 'error');
            return false;
        }

        return $true;
    }

    public function check_product_cart_quantity($product_id, $quantity_to_add, $is_cart_page = false)
    {
        global $dabber_current_location_data;

        $product = wc_get_product($product_id);

        $location_qty = dabber_get_product_location_stock_quantity($product_id, $dabber_current_location_data['wc_location_id']);
        $cart_qty = 0;

        // only get cart total when adding cart via shop/product page.
        if ($is_cart_page === false) {
            foreach ( WC()->cart->get_cart() as $cart_item ) {
                if ($cart_item['data']->get_id() !== $product_id) {
                    continue;
                }
                $cart_qty = $cart_item['quantity'];
            }
        }

        $total_qty = $quantity_to_add + $cart_qty;
        $total_available = $location_qty - $dabber_current_location_data['oos_threshold'];
        $total_available = ($total_available > 0)? $total_available : 0;

        //        var_dump([
        //            '$cart_qty' => $cart_qty,
        //            '$quantity_to_add' => $quantity_to_add,
        //            '$location_qty' => $location_qty,
        //            '$dabber_current_location_data' => $dabber_current_location_data,
        //            '$total_qty' => $total_qty,
        //            '$total_available' => $total_available
        //        ]);

        if ($total_qty > $total_available) {
            return __('Sorry, we do not have enough <strong>'. $product->get_name() .'</strong> in stock to fulfill your order ('. $total_available .' available). We apologize for any inconvenience caused', "woocommerce");
        }

        return true;
    }

    public function save_settings($post_data)
    {
        foreach ($post_data['oos'] as $term_id => $threshold) {
            update_term_meta($term_id, 'dabber_oos_threshold', $threshold);
        }
    }

    public function render_inventory_tab_content()
    {
        $locations = cova_get_all_wc_locations();

        load_template(
            plugin_dir_path(__FILE__) .'templates/oos-settings.php', true, [
            'locations' => $locations
            ]
        );
    }

    public function override_wc_oos_threshold($value, $option_name)
    {
        if ($option_name !== 'woocommerce_notify_no_stock_amount' || is_admin()) {
            return $value;
        }

        return dabber_get_location_oos_threshold(cova_get_current_location());
    }

    public function add_save_button()
    {
        echo '<hr><input type="submit" id="submit" class="button button-primary" value="Save Changes">';
    }

    public function add_new_tab($tabs)
    {
        $tabs['products'] = __('Products', 'dabber');

        return $tabs;
    }

    public function add_sub_tab($tabs)
    {
        $tabs['inventory'] = __('Inventory', 'dabber');

        return $tabs;
    }
}
