<?php

namespace Dabber\Modules\LoyaltyPoints;

class Rewards
{

    public function __construct()
    {
        self::store();
    }

    /**
     * Store Globals
     * Store Rewards Lists pulled from cova to a global variable
     *
     * @return void
     */
    public function store(): void
    {
        global $dabber_rewards;
        $results = self::all();
        $modifiedResults = [];

        foreach($results as $reward){
            if(isset($reward['Id'])) {
                $modifiedResults[$reward['Id']] = $reward;
            }
        }

        $dabber_rewards = $modifiedResults;
    }

    /**
     * Rewards Check
     * Check if selected rewards already exceeded the cart total
     *
     * @param  $rewards
     * @return bool|array
     */
    public function check($rewards)
    {

        $pointsBalance = get_user_meta(get_current_user_id(), 'dabber_customer_points_balance', true);

        if(WC()->cart->cart_contents_count == 0 ) {

            return [
                'result' => true,
                'message' => "Please add products into your cart."
            ];

        } else if(self::total($rewards) > WC()->cart->subtotal ) {

            return [
                'result' => true,
                'message' => "Reward values cannot exceed invoice total."
            ];

        } else if (self::total_points($rewards) > $pointsBalance ) {

            return [
                'result' => true,
                'message' => "Your Loyalty Points is not enough. You can purchase more to increase it."
            ];

        }

        return false;

    }

    /**
     * Get All Rewards
     * This will get all rewards from cova hub
     *
     * @return array
     */
    public function all(): array
    {
        $api = new \CovaAPI\LoyaltyPoints;
        return json_decode($api->all(cova_get_current_location()), true);
    }

    /**
     * Filter Rewards
     * This will filter and remove rewards that is below the users points balance
     *
     * @param  $rewards
     * @return array
     */
    public function filter($rewards): array
    {
        $pointsBalance = get_user_meta(get_current_user_id(), 'dabber_customer_points_balance', true);

        return array_filter(
            $rewards, function ($x) use ($pointsBalance) {
                return (int) $pointsBalance > (int) $x['PointsRequired'];
            }
        );

    }

    public function total($rewards = false)
    {

        if(!$rewards) {
            $rewards = WC()->session->get('reward_discounts');
        }

        if(!is_null($rewards) && count($rewards) > 0 ) {
            return array_sum(array_column($rewards, 'Value'));
        }

    }

    public function total_points($rewards = false)
    {

        if(!$rewards) {
            $rewards = WC()->session->get('reward_discounts');
        }

        if(!is_null($rewards) && count($rewards) > 0 ) {
            return array_sum(array_column($rewards, 'PointsRequired'));
        }

    }

    public function user_selection($reward): array
    {

        global $dabber_rewards;

        $rewards = WC()->session->get('reward_discounts');
        $getReward = $dabber_rewards[$reward['id']];
        $type = "add";

        //If no session set
        if(!isset($rewards) ) {
            //Set new array
            $rewards = array();
        }

        //If user already selected the reward,
        if(array_key_exists($getReward['Id'], $rewards) ) {
            //Remove it from the session array
            unset($rewards[$getReward['Id']]);
            $type = "remove";
            //If reward does not exists in session array
        } else {
            //Add the reward to session array
            $rewards[$getReward['Id']] = $getReward;
        }

        return [
            'rewards' => $rewards,
            'type' => $type
        ];
    }

}
