<?php

namespace Dabber\Modules\LoyaltyPoints;

class LoyaltyPoints
{
    
    //    public string $version = "2022";
    //    public static array $module_info = [
    //        'name' => 'Loyalty Points',
    //        'description' => 'Sync customer loyalty points from cova to woocommerce'
    //    ];
    //    public static $enable_default = true;
    public int $points_balance = 0;
    public int $lifetime_points = 0;
    private Rewards $rewards;
    private Cart $cart;
    private Checkout $checkout;
    private array $stored_rewards;

    public function run()
    {

        add_action('woocommerce_after_order_notes', [$this, 'html_template'], 10);
        add_action('wp_enqueue_scripts', [$this, 'loadJs']);
        add_action('wp_enqueue_scripts', [$this, 'loadCss']);
        add_action('init', [$this, 'loadClasses'], 10);
    }

    public function loadClasses(): void
    {
        $this->myaccount = new MyAccount();
        $this->cart = new Cart();
        $this->checkout = new Checkout();
    }

    public function loadCss(): void
    {
        wp_enqueue_style('dabber-loyalty-points-css', plugin_dir_url(__FILE__) . 'assets/css/dabber-loyalty-points.css', [], $this->version, 'all');
    }

    public function loadJs(): void
    {
        if(!is_user_logged_in() ) { return;
        }
        wp_enqueue_script('dabber-loyalty-points-js', plugin_dir_url(__FILE__) . 'assets/js/dabber-loyalty-points.js', ['jquery'], $this->version, true);
    }

    public function html_template(): void
    {

        if(is_user_logged_in() && $this->allow_checkoutpage_myaccount_only() ) {

            self::generate_rewards();

        } else {

            load_template(plugin_dir_path(__FILE__) .'templates/not-loggedin.php', true, []);

        }

    }

    public function allow_checkoutpage_myaccount_only(): bool
    {
        return is_checkout() && ! is_wc_endpoint_url() || is_wc_endpoint_url('loyalty-rewards');
    }

    public function generate_rewards(bool $is_myAccount = false): void
    {

        $this->rewards = new Rewards();
        global $dabber_rewards;
        $this->stored_rewards = $dabber_rewards;

        $hasRewards = false;
        $rewards = false;
        $rewards = $this->rewards->filter($this->stored_rewards);

        $this->points = new Points();
        $this->points->sync();
        $this->points_balance = (int) get_user_meta(get_current_user_id(), 'dabber_customer_points_balance', true);
        $this->lifetime_points = (int) get_user_meta(get_current_user_id(), 'dabber_customer_lifetime_points', true);

        if(!is_null($rewards) && count($rewards) > 0 ) {
            $hasRewards = true;
            $cartSelectedRewards = WC()->session->get('reward_discounts');

            foreach( $rewards as $key => $reward ){
                $rewards[$key]['ButtonLabel'] = "Use";
                $rewards[$key]['Class'] = "";
                if(isset($cartSelectedRewards[$reward['Id']])) {
                    $rewards[$key]['Class'] = " selected ";
                    $rewards[$key]['ButtonLabel'] = "Remove";
                }
            }
        }

        load_template(
            plugin_dir_path(__FILE__) .'templates/widget.php', true, [
            'rewards' => $rewards,
            'is_myAccount' => $is_myAccount,
            'hasRewards' => $hasRewards,
            'lifetimePoints' => $this->lifetime_points,
            'pointsBalance' => $this->points_balance
            ]
        );
    }


}
