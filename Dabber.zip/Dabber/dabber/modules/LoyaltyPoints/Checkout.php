<?php

namespace Dabber\Modules\LoyaltyPoints;


class Checkout
{

    private Points $points;

    public function __construct()
    {

        /**
         * On checkout
         */
        add_action('woocommerce_thankyou', [$this, 'thank_you_page'], 10);

        add_action('woocommerce_payment_complete', [$this, 'payment_complete'], 10);

        $this->points = new Points();

    }



    public function thank_you_page($order_id)
    {
        $order = wc_get_order($order_id);

        if($order->get_payment_method() !== 'cod' ) {
            return;
        }

        $this->points->update_user($order_id);
    }

    public function payment_complete($order_id)
    {
        $this->points->update_user($order_id);
    }

}
