<?php

namespace Dabber\Modules\LoyaltyPoints;

class MyAccount
{

    private Points $points;
    private Rewards $rewards;
    private $stored_rewards;
    private int $points_balance;
    private int $lifetime_points;

    public function __construct()
    {

        global $dabber_rewards;
        $this->stored_rewards = $dabber_rewards;
        $this->loyalty_rewards_endpoint();

        add_filter('query_vars', [$this, 'loyalty_rewards_query_vars'], 0);
        add_filter('woocommerce_account_menu_items', [$this, 'loyalty_rewards_link_my_account']);
        add_action('woocommerce_account_loyalty-rewards_endpoint', [$this, 'loyalty_rewards_content']);

    }

    public function loyalty_rewards_endpoint()
    {
        add_rewrite_endpoint('loyalty-rewards', EP_ROOT | EP_PAGES);
    }

    public function loyalty_rewards_query_vars( $vars )
    {
        $vars[] = 'loyalty-rewards';
        return $vars;
    }

    public function loyalty_rewards_link_my_account( $items )
    {
        $items['loyalty-rewards'] = 'Loyalty Rewards';
        return $items;
    }

    public function loyalty_rewards_content()
    {

        $loyaltyPoints = new LoyaltyPoints();
        $loyaltyPoints->generate_rewards(true);

    }

}
