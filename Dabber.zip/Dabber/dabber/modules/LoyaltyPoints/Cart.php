<?php

namespace Dabber\Modules\LoyaltyPoints;

class Cart
{
    private Rewards $rewards;

    public function __construct()
    {
        global $dabber_rewards;

        add_action('woocommerce_cart_calculate_fees', [$this, 'prefix_add_loyalty_line'], 20, 1);
        add_action('wp_enqueue_scripts', [$this, 'loadJs']);
        add_action('wp_ajax_apply_reward', [$this, 'apply_reward']);
        add_action('wp_ajax_nopriv_apply_reward', [$this, 'apply_reward']);
        add_action('woocommerce_remove_cart_item', [$this, 'deselect_rewards']);

        $this->rewards = new Rewards();

    }

    public function loadJs(): void
    {
        wp_enqueue_script('loyalty_points', plugin_dir_url(__FILE__) . 'assets/js/dabber-loyalty-points.js', array('jquery'));
        wp_localize_script('loyalty_points', 'wc_checkout_params_loyalty', array('ajaxurl' => admin_url('admin-ajax.php')));
    }

    public function apply_reward()
    {

        if(isset($_POST['id']) ) {

            $error = 0;
            $message = '';

            $rewards = $this->rewards->user_selection($_POST);
            $selectedRewards = $rewards['rewards'];
            $checkRewards = $this->rewards->check($selectedRewards);

            if($checkRewards['result'] ) {
                wc_add_notice($checkRewards['message'], 'error');
                $error = 1;
                $message = '<div class="woocommerce-notices-wrapper"><ul class="woocommerce-error" role="alert"><li>'.$checkRewards["message"].'</li></ul></div>';
            } else {
                WC()->session->set('reward_discounts', $selectedRewards);
            }

            wp_send_json(
                array(
                    'rewards' => json_encode(WC()->session->get('reward_discounts')),
                    'result' => $error ? 'failure' : 'success',
                    'html' => $message,
                    'type' => $rewards['type']
                )
            );
        }

        wp_die();

    }

    public function prefix_add_loyalty_line( $cart ): void
    {

        if (!is_user_logged_in() && ! defined('DOING_AJAX') ) { return;
        }
        $selectedRewards = WC()->session->get('reward_discounts');

        if(!is_null($selectedRewards) && count($selectedRewards) > 0 ) {

            foreach( $selectedRewards as $reward ){
                $cart->add_fee(__('Loyalty Reward ('.$reward["Name"].')', 'woocommerce'), -$reward["Value"]);
            }

        }

    }

    /**
     * Reset Rewards Selection
     * If user remove an item from the cart, reset rewards selection
     *
     * @return void
     */
    public function deselect_rewards(): void
    {
        WC()->session->set('reward_discounts', []);
        wc_add_notice('Reward values cannot exceed invoice total.', 'error');
    }

}
