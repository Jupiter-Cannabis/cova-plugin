

(function ($) {

    removeNotices();

    $('body').off('click').on(
        "click", '.js-dabber-loyalty-btn', function (e) {
            let _this = $(this);
            let nonce = _this.attr("data-nonce");
            let rewardId = _this.attr("data-id");
            let parent = _this.parents('.js-dabber-loyalty-reward');


            ajax(nonce, parent, rewardId, _this);
            e.preventDefault();
        }
    );

    function removeNotices()
    {
        if($('.woocommerce-notices-wrapper').length > 0 ) {
            $('.woocommerce-notices-wrapper').remove();
        }
    }

    function ajax(nonce, parent, rewardId, btn)
    {
        let btnLabel = btn.find('.dabber-loyalty-points__label');
        $.ajax(
            {
                type: "POST",
                data: {
                    action: 'apply_reward',
                    nonce: nonce,
                    id: rewardId
                },
                beforeSend: function () {

                    removeNotices();

                    if(parent.hasClass('selected')) {
                        parent.removeClass('selected')
                        btnLabel.text('Use');
                    } else {
                        parent.addClass('adding');
                    }

                    $('body').addClass('dabber-loyalty-cart-refreshing');

                    $('.js-dabber-loyalty-ajax-msg').addClass('active').find('span').text('Refreshing Cart');

                },
                dataType: "json",
                url: wc_checkout_params_loyalty.ajaxurl,
                success: function (response) {

                    console.log(response);

                    if(response.result === "success" ) {
                        if(response.type === "add" ) {
                            parent.addClass('selected');
                            btnLabel.text('Remove');
                        } else if(response.type === "remove" ) {
                            parent.removeClass('selected');
                            btnLabel.text('Use');

                        }
                    } else {
                        btnLabel.text('Use');
                    }

                    $('body').removeClass('dabber-loyalty-cart-refreshing');
                    $('.adding').removeClass('adding');
                    $('.js-dabber-loyalty-ajax-msg').removeClass('active').find('span').text('');

                    if($('body').hasClass('woocommerce-account') ) {
                        removeNotices();
                        if(response.html !== '' ) {
                            $('.woocommerce-MyAccount-content').prepend(response.html);
                        }
                    } else {
                        $('body').trigger('update_checkout');
                        $('.js-dabber-loyalty-ajax-msg').removeClass('active').find('span').text('');
                    }


                }
            }
        );

        $('body').on(
            'updated_checkout', function () {
                $('body').removeClass('dabber-loyalty-cart-refreshing');
                $('.adding').removeClass('adding');
                $('.js-dabber-loyalty-ajax-msg').removeClass('active').find('span').text('');
            }
        );

    }

})(jQuery);

