<?php

namespace Dabber\Modules\LoyaltyPoints;

class Points
{

    public function __construct()
    {
        global $cova_api_auth;
        $this->company_id = $cova_api_auth->credentials['company_id'] ?? false;
    }

    /**
     * Save User's Loyalty Points
     * This will save the cova users loyalty points to woocommerce user meta
     *
     * @return void
     */
    public function sync( $wooUserId = false ): void
    {
        if(!$wooUserId ) {
            $wooUserId = get_current_user_id();
        }

        $userCovaId =  get_user_meta($wooUserId, 'dabber_customer_id', true);
        $response = self::get((string) $userCovaId);

        cova_debugger($userCovaId);

        self::update_points_balance((int) $wooUserId, $response);
        self::update_lifetime_points((int) $wooUserId, $response);

    }

    /**
     * Get Users Loyalty Points
     * This will get the users Points Balance and Lifetime Points
     *
     * @param  string $userCovaId
     * @return array
     */
    public function get(string $userCovaId): array
    {
        $api = new \CovaAPI\LoyaltyPoints;
        return json_decode($api->byId($userCovaId), true);

    }

    /**
     * Update Users Loyalty Points Balance
     * This will add/update users points balance only
     *
     * @param  $wooUserId int
     * @param  $res       array
     * @return void
     */
    public function update_points_balance(int $wooUserId, array $res): void
    {
        $pointsBalance = 0;

        if(isset($res['PointsBalance'])) {
            $pointsBalance = $res['PointsBalance'];
        }
        update_user_meta($wooUserId, 'dabber_customer_points_balance', $pointsBalance);

    }

    /**
     * Update Users Loyalty Points Balance
     * This will add/update users lifetime points balance only
     *
     * @param  $wooUserId int
     * @param  $res       array
     * @return void
     */
    public function update_lifetime_points(int $wooUserId, array $res): void
    {
        $pointsBalance = 0;

        if(isset($res['LifetimePointsBalance'])) {
            $pointsBalance = $res['LifetimePointsBalance'];
        }
        update_user_meta($wooUserId, 'dabber_customer_lifetime_points', $pointsBalance);

    }

    public function update_user($orderId): void
    {

        if(!is_user_logged_in() || !$this->company_id ) { return;
        }

        $order = new \WC_Order($orderId);
        $wooUserId = $order->get_user_id();
        $userCovaId = get_user_meta($wooUserId, 'dabber_customer_id', true);
        $usedPoints = self::get_used_points();
        $api = new \CovaAPI\LoyaltyPoints;

        $response = json_decode(
            $api->update(
                $userCovaId, [
                'PointsAdjustmentAmount' => -$usedPoints,
                'Notes' => 'WooCommerce Order ID: {$orderId}, WooCommerce User ID: {$wooUserId}',
                'companyId' => $this->company_id,
                'customerId' => $userCovaId
                ]
            ), true
        );

        self::reset_selection();

    }

    public function get_used_points()
    {

        $points = 0;

        if(WC()->session ) {
            $selectedRewards = WC()->session->get('reward_discounts');
            $points = array_sum(array_column($selectedRewards, 'PointsRequired'));
        }

        return $points;
    }

    public function reset_selection(): void
    {
        WC()->session->set('reward_discounts', []);
    }

}
