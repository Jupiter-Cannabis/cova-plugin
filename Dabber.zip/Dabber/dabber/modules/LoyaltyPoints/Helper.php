<?php

namespace Dabber\Modules\LoyaltyPoints;

class Helper
{

    public function test()
    {

    }

}
