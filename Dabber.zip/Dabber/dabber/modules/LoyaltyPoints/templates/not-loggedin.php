<div class="dabber-loyalty-points">
    <div class="dabber-loyalty-points__area">
        <div class="dabber-loyalty-points__header">
            <h4>Loyalty Rewards</h4>
        </div>
        <p class="dabber-loyalty-points__text dabber-loyalty-points__text--notenough">Please login to access your Loyalty Rewards.</p>
    </div>
</div>