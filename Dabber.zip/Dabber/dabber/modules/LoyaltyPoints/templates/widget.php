<?php if($args['is_myAccount']) : ?>
<h2>Loyalty Rewards</h2>
<p>List of loyalty rewards which are valid & available for use. Click on the reward to use it. The loyalty reward point will be visible only when at least one product is present in the cart.</p>
<?php endif; ?>
<div class="dabber-loyalty-points">
    <div class="dabber-loyalty-points__area">
        <div class="dabber-loyalty-points__header">
            <h4>Loyalty Rewards</h4>
            <?php if($args['hasRewards']) : ?>
            <p><strong>Points Balance:</strong> <?php echo $args['pointsBalance']; ?> | <strong>Lifetime Points:</strong> <?php echo $args['lifetimePoints']; ?></p>
            <?php endif; ?>
        </div>
        <?php if($args['hasRewards']) : ?>
        <div class="dabber-loyalty-points__notes">
            <p>Note: Reward values cannot exceed invoice total</p>
            <p class="js-dabber-loyalty-ajax-msg dabber-loyalty-ajax-msg"><span class="js-dabber-loyalty-ajax-label"></span></p>
        </div>
        <div class="dabber-loyalty-points__rewards js-dabber-loyalty-points-rewards">
            <?php
            foreach( $args['rewards'] as $reward ):
                ?>
            <div class="js-dabber-loyalty-reward dabber-loyalty-points__reward <?php echo $reward['Class']; ?>">
                <div>
                    <p class="dabber-loyalty-points__text"><strong>reward</strong><br /><?php echo $reward['Name']; ?></p>
                </div>
                <div>
                    <p class="dabber-loyalty-points__text"><strong>reward value</strong><br /><?php echo wc_price($reward['Value']); ?></p>
                </div>
                <div>
                    <p class="dabber-loyalty-points__text"><strong>points needed</strong><br /><?php echo $reward['PointsRequired']; ?></p>
                </div>
                <div>
                    <button data-id="<?php echo $reward['Id']; ?>" data-nonce="<?php echo wp_create_nonce("my_user_like_nonce"); ?>" id="loyalty-btn-<?php echo $reward['Id']; ?>" class="js-dabber-loyalty-btn dabber-loyalty-points__btn"><span class="dabber-loyalty-points__label"
                        ><?php echo $reward['ButtonLabel']; ?></span></button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p class="dabber-loyalty-points__text dabber-loyalty-points__text--notenough">Your Loyalty Points is not enough. You can purchase more to increase it.
        </p>
        <?php endif; ?>
    </div>
</div>
