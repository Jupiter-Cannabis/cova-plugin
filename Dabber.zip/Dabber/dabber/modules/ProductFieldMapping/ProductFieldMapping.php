<?php

namespace Dabber\Modules\ProductFieldMapping;

use CovaAPI\FieldDefinitions;
use Dabber\Modules\Multilocation\Dropdown;
use Dabber\Modules\ProductBatchData\ProductBatchData;

/**
 * @Todo add attribute mapping support
 * @todo separate product loop and single product data rendering
 */
class ProductFieldMapping
{
    private $option_key = 'dabber_product_fields_mapping';

    public static $must_use = true;
    public static $module_info = [
        'name' => 'Product Field Mapping',
        'description' => ''
    ];

    public function run()
    {
        add_filter('dabber_product_mapping_wc_fields', [$this, 'set_wc_map_fields']);
        add_filter('dabber_admin_module_nav_items', [$this, 'add_mapping_tab']);
        add_filter('dabber_admin_module_sub_nav_items_mapping', [$this, 'add_submenu_items'], 30);
        add_action('dabber_render_module_admin_section_mapping_product_fields_mapping', [$this, 'render_section']);


        add_action('dabber_register_module_hooks_mapping_product_fields_mapping', [$this, 'init']);
        add_action('dabber_admin_module_save_settings_mapping_product_fields_mapping', [$this, 'save_settings']);

        add_action('init', [$this, 'register_taxonomy']);
        add_action('init', [$this, 'load_mapped_fields']);

        add_action('dabber_map_product_fields', [$this, 'map_product_fields'], 100, 2);

        add_filter('woocommerce_display_product_attributes', [$this, 'customize_product_attributes_display'], 100, 2);
        add_action('woocommerce_shop_loop_item_title', [$this, 'woocommerce_shop_loop_potency'], 10);

        add_filter('dabber_product_sync_formatted_post_data', [$this, 'post_formatter_metadata_mapping'], 10);

        add_filter('cova_product_attributes', [$this, 'modify_single_product_attributes'], 20, 3);
        add_filter('cova_product_attributes', [$this, 'fix_terpene_percentage_value'], 30, 3);
    }

    public function init()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function post_formatter_metadata_mapping($data)
    {
        $mapping_opt = get_option('dabber_product_fields_mapping');

        if (empty($mapping_opt)) {
            return $data;
        }

        $metadata_mapping = [];
        $term_tax_mapping = [];

        foreach ($mapping_opt as $key => $map_item) {
            if ($map_item['type'] === 'metadata') {
                $metadata_mapping[$key] = $map_item;
            }
            if ($map_item['type'] === 'product_taxonomy') {
                $term_tax_mapping[$key] = $map_item;
            }
        }

        $catalog_ids = array_keys($data['metadata']);

        foreach ($catalog_ids as $catalog_id) {
            $specifications = maybe_unserialize($data['metadata'][$catalog_id]['cova_specifications']);

            if (empty($specifications)) {
                continue;
            }

            $specifications = array_reduce(
                $specifications['details'], function ($accumulator, $item) {
                    $accumulator[$item['Id']] = $item;
                    return $accumulator;
                }, []
            );

            foreach ($metadata_mapping as $meta_key => $meta_info) {
                if (!isset($specifications[$meta_info['cova_field'][0]])) {
                    continue;
                }

                $meta_value = $specifications[$meta_info['cova_field'][0]]['Value'];

                if ($meta_key === 'terpene_percent') {
                    $meta_value = preg_replace('/[^0-9\.]/', '', $meta_value);
                }

                $data['metadata'][$catalog_id][$meta_key] = $meta_value;

                if ($meta_key === 'net_weight' || $meta_key === 'equivalent_weight') {
                    $data['metadata'][$catalog_id][$meta_key .'_unit'] = $specifications[$meta_info['cova_field'][0]]['Unit'];
                }
            }

            if (isset($data['metadata'][$catalog_id]['thc_max']) && !(isset($data['metadata'][$catalog_id]['thc_percent']))) {
                $data['metadata'][$catalog_id]['thc_percent'] = $data['metadata'][$catalog_id]['thc_max'];
            }

            foreach ($term_tax_mapping as $term_key => $term_info) {
                if (!isset($specifications[$term_info['cova_field'][0]]) 
                    || isset($data['taxonomies'][$catalog_id][$term_key])
                ) {
                    continue;
                }
                $val = array_values($specifications[$term_info['cova_field'][0]]);
                $tax_val = (is_array($val[0]))? $val[0] : [$val[0]];
                $data['taxonomies'][$catalog_id][$term_key] = $tax_val;
            }
        }

        return $data;
    }

    public function add_mapping_tab($tabs)
    {
        $tabs['mapping'] = __('Mapping', 'dabber');

        return $tabs;
    }

    public function get_product_additional_info($product_id, $show_in)
    {
        global $dabber_mapped_product_fields;

        // Filter items depending on page view
        $remove_value = 'single';

        if ($show_in === 'single') {
            $remove_value = 'archive';
        }

        foreach ($dabber_mapped_product_fields as $key => $subarray) {
            if (in_array($remove_value, $subarray)) {
                unset($dabber_mapped_product_fields[$key]);
            }
        }

        // Sort fields by position
        uasort(
            $dabber_mapped_product_fields, function ($a, $b) {
                return $a['position'] <=> $b['position'];
            }
        );

        $product_info = get_post_meta($product_id);
        $current_location_id = cova_get_current_location();
        $product_attributes = [];
        $available_batch_info = [];

        foreach ($dabber_mapped_product_fields as $field_key => $field_info) {
            if ($field_info['type'] === 'metadata') {
                if (isset($product_info['package_at_'. $current_location_id .'_'. $field_key])) {
                    $value = $product_info['package_at_'. $current_location_id .'_'. $field_key];

                    if (empty($value[0])) {
                        continue;
                    }
                    $unit = (isset($product_info['package_at_'. $current_location_id .'_'. $field_key .'_unit']))? $product_info['package_at_'. $current_location_id .'_'. $field_key .'_unit'][0] : '';
                    $product_attributes[$field_key] = [
                        'label' => wc_attribute_label($field_info['name']),
                        'value' => $value[0] . $unit,
                        'position' => $field_info['position']
                    ];
                    $available_batch_info[] = $field_key;

                } elseif(isset($product_info[$field_key])) {

                    if (array_key_exists($field_key, ProductBatchData::$map_meta)) { // do not include if key is for batch data
                        continue;
                    }

                    $value = $product_info[$field_key];
                    $unit = '';
                    if (empty($value[0])) {
                        continue;
                    }
                    if ($field_key == 'net_weight' || $field_key == 'equivalent_weight') {
                        $unit = (isset($product_info[$field_key .'_unit']))? $product_info[$field_key .'_unit'][0] : '';
                    }
                    if ($field_key === 'terpene_percent') {
                        $unit = '%';
                    }
                    $product_attributes[$field_key] = [
                        'label' => wc_attribute_label($field_info['name']),
                        'value' => $value[0] . $unit,
                        'position' => $field_info['position']
                    ];
                }
            }
            if ($field_info['type'] === 'product_taxonomy') {
                if (taxonomy_exists('package_at_'. $current_location_id .'_'. $field_key)) {
                    $terms = get_the_terms($product_id, 'package_at_'. $current_location_id .'_'. $field_key);
                    if (empty($terms)) {
                        continue;
                    }
                    $values = [];
                    foreach ($terms as $term) {
                        $values[] = '<a href="'. get_term_link($term->term_id, $term->taxonomy) .'">'. $term->name .'</a>';
                    }
                    $product_attributes[$field_key] = [
                        'label' => wc_attribute_label($field_info['name']),
                        'value' => implode(', ', $values),
                        'position' => $field_info['position']
                    ];
                } elseif (taxonomy_exists($field_key)) {
                    $terms = get_the_terms($product_id, $field_key);
                    if (empty($terms)) {
                        continue;
                    }
                    $values = [];
                    foreach ($terms as $term) {
                        $values[] = '<a href="'. get_term_link($term->term_id, $term->taxonomy) .'">'. $term->name .'</a>';
                    }
                    $product_attributes[$field_key] = [
                        'label' => wc_attribute_label($field_info['name']),
                        'value' => implode(', ', $values),
                        'position' => $field_info['position']
                    ];
                }
            }
        }

        if (empty($available_batch_info)) {
            $specifications = get_post_meta($product_id, 'cova_specifications', true);
            if (!empty($specifications) && isset($specifications['details'])) {
                foreach ($specifications['details'] as $detail_key => $detail_val) {
                    $detail_key = str_replace('-', '_', $detail_key);
                    if (!array_key_exists($detail_key, ProductBatchData::$map_meta) || !isset($dabber_mapped_product_fields[$detail_key])) {
                        continue;
                    }
                    $product_attributes[$detail_key] = [
                        'label' => wc_attribute_label($detail_val['DisplayName']),
                        'value' => $detail_val['Value'] . $detail_val['Unit'],
                        'position' => $dabber_mapped_product_fields[$detail_key]['position']
                    ];
                }
            }
        }

        return apply_filters('cova_product_attributes', $product_attributes, $product_id, $show_in);
    }

    public function customize_product_attributes_display($product_attributes, $product)
    {
        global $dabber_mapped_product_fields;

        if (empty($dabber_mapped_product_fields)) {
            return $product_attributes;
        }

        $product_id = $product->get_id();
        $attributes = $this->get_product_additional_info($product_id, 'single');

        if (empty($attributes)) {
            return $product_attributes;
        }

        foreach ($attributes as $attr_key => $item) {
            $attributes[$attr_key]['value'] = apply_filters('woocommerce_attribute', wpautop(wptexturize($item['value'])), [], [$item['value']]);
        }

        return array_values($attributes);
    }

    public function fix_terpene_percentage_value($attributes, $product_id, $showin)
    {
        if (!isset($attributes['terpene_percent'])) {
            return $attributes;
        }

        if (preg_match('/\d/', $attributes['terpene_percent']['value']) !== 1) {
            unset($attributes['terpene_percent']);
        }

        return $attributes;
    }

    public function modify_single_product_attributes($attributes, $product_id, $showin)
    {
        if ($showin !== 'single') {
            return $attributes;
        }

        if ((isset($attributes['thc_min']) && isset($attributes['thc_max'])) && ($attributes['thc_min']['value'] == $attributes['thc_max']['value'])) {
            unset($attributes['thc_min']);
        }
        if ((isset($attributes['cbd_min']) && isset($attributes['cbd_max'])) && ($attributes['cbd_min']['value'] == $attributes['cbd_max']['value'])) {
            unset($attributes['cbd_min']);
        }

        return $attributes;
    }

    public function woocommerce_shop_loop_potency()
    {
        global $product, $dabber_mapped_product_fields;

        if (!$product || empty($dabber_mapped_product_fields)) {
            return;
        }

        $attributes = $this->get_product_additional_info($product->get_id(), 'archive');

        if (empty($attributes)) {
            return;
        }

        // Filter THC potency
        $thc_min = (isset($attributes['thc_min']) && !empty($attributes['thc_min']))? strip_tags($attributes['thc_min']['value']) : false;
        $thc_max = (isset($attributes['thc_max']) && !empty($attributes['thc_max']))? strip_tags($attributes['thc_max']['value']) : false;

        $thc_potency = array_filter(
            [
            'thc_percent'    => (isset($attributes['thc_percent']))? strip_tags($attributes['thc_percent']['value']) : false,
            'thc_range'      => (!empty($thc_min) && !empty($thc_max) && $thc_min != $thc_max)? $thc_min .' - '. $thc_max : false,
            'thc_min'        => ($thc_min && !$thc_max)? $thc_min : false,
            'thc_max'        => ($thc_max)? $thc_max : false,
            'thc_content'    => (isset($attributes['thc_content']))? strip_tags($attributes['thc_content']['value']) : false
            ]
        );

        if (isset($thc_potency['thc_range'])) {
            $attributes['thc_range'] = [
                'label' => 'THC',
                'value' => $thc_potency['thc_range'],
                'position' => $attributes['thc_max']['position']
            ];
        }

        reset($thc_potency);
        $current_thc_potency = key($thc_potency);

        $attributes = array_filter(
            $attributes, function ($value, $key) use ($current_thc_potency) {
                if (stripos($key, 'thc_') !== false && $key != $current_thc_potency) {
                    return false;
                }
                return true;
            }, ARRAY_FILTER_USE_BOTH
        );

        if (isset($attributes[$current_thc_potency])) {
            $attributes[$current_thc_potency]['value'] = $thc_potency[$current_thc_potency];
        }
        // -------------------------------------------

        // Filter CBD potency
        $cbd_min = (isset($attributes['cbd_min']) && !empty($attributes['cbd_min']))? strip_tags($attributes['cbd_min']['value']) : false;
        $cbd_max = (isset($attributes['cbd_max']) && !empty($attributes['cbd_max']))? strip_tags($attributes['cbd_max']['value']) : false;

        $cbd_potency = array_filter(
            [
            'cbd_percent'    => (isset($attributes['cbd_percent']))? strip_tags($attributes['cbd_percent']['value']) : false,
            'cbd_range'      => (!empty($cbd_min) && !empty($cbd_max) && $cbd_min != $cbd_max)? $cbd_min .' - '. $cbd_max : false,
            'cbd_min'        => ($cbd_min && !$cbd_max)? $cbd_min : false,
            'cbd_max'        => ($cbd_max)? $cbd_max : false,
            'cbd_content'    => (isset($attributes['cbd_content']))? strip_tags($attributes['cbd_content']['value']) : false
            ]
        );

        if (isset($cbd_potency['cbd_range'])) {
            $attributes['cbd_range'] = [
                'label' => 'CBD',
                'value' => $cbd_potency['cbd_range'],
                'position' => $attributes['cbd_max']['position']
            ];
        }

        reset($cbd_potency);
        $current_cbd_potency = key($cbd_potency);

        $attributes = array_filter(
            $attributes, function ($value, $key) use ($current_cbd_potency) {
                if (stripos($key, 'cbd_') !== false && $key != $current_cbd_potency) {
                    return false;
                }
                return true;
            }, ARRAY_FILTER_USE_BOTH
        );

        if (isset($attributes[$current_cbd_potency])) {
            $attributes[$current_cbd_potency]['value'] = $cbd_potency[$current_cbd_potency];
        }
        // -------------------------------------------

        uasort(
            $attributes, function ($a, $b) {
                return $a['position'] <=> $b['position'];
            }
        );

        $atts_html = [];

        foreach ($attributes as $attr_key => $attr_val) {
            $atts_html[] = '<span>'. $attr_val['label'] .'</span> '. $attr_val['value'];
        }

        $output = '<div class="product-potency">' . (count($atts_html) ? implode(' | ', $atts_html) : '&nbsp;') . '</div>';

        echo apply_filters('dabber_product_loop_additional_info_v2', $output, $attributes, $product);
    }

    public function get_info_value($product_id, $key, $type)
    {
        if ($type === 'metadata') {
            $meta_value = get_post_meta($product_id, $key, true);

            return apply_filters('dabber_product_additional_info_value_html', trim($meta_value), $type, $key, $product_id);
        }

        if ($type === 'product_taxonomy') {
            $terms = get_the_terms($product_id, $key);

            if (empty($terms) || is_wp_error($terms)) {
                return '';
            }

            $html_terms = [];

            foreach ($terms as $term) {
                $html_terms[] = '<a href="'. get_term_link($term->term_id) .'">'. $term->name .'</a>';
            }

            return apply_filters('dabber_product_additional_info_value_html', implode(', ', $html_terms), $type, $key, $product_id);
        }

        return '';
    }

    public function load_mapped_fields()
    {
        global $dabber_mapped_product_fields;

        $dabber_mapped_product_fields = get_option($this->option_key);
    }

    public function register_taxonomy()
    {
        $mapped_fields = get_option($this->option_key);

        if (empty($mapped_fields)) {
            return;
        }

        foreach ($mapped_fields as $key => $item) {
            if ($item['type'] !== 'product_taxonomy') {
                continue;
            }

            if (taxonomy_exists($key)) {
                continue;
            }

            register_taxonomy(
                $key, ['product'], [
                'hierarchical' => false,
                'labels' =>[
                    'name' => $item['name'],
                ]
                ]
            );
        }

        if (!taxonomy_exists('strain')) {
            register_taxonomy(
                'strain', ['product'], [
                'hierarchical' => false,
                'labels' =>[
                    'name' => 'Strain'
                ]
                ]
            );
        }

        if (!taxonomy_exists('terpenes')) {
            register_taxonomy(
                'terpenes', ['product'], [
                'hierarchical' => false,
                'labels' =>[
                    'name' => 'Terpenes'
                ]
                ]
            );
        }
    }

    public function is_current_page($tab, $section = '')
    {
        $args = array_filter(
            [
            'page'  => 'cova_integration',
            'tab'   => $tab,
            'section' => $section
            ]
        );

        foreach ($args as $arg_key => $arg) {
            if (!isset($_GET[$arg_key]) || $_GET[$arg_key] !== $arg) {
                return false;
            }
        }

        return true;
    }

    public function enqueue_scripts()
    {
        wp_enqueue_style('product-field-mapping-select2', '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', [], null);
        wp_enqueue_script('product-field-mapping-select2', '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', [], null, true);
        wp_enqueue_script('product-field-mapping', plugin_dir_url(__FILE__) .'assets/js/product-field-mapping.js', [], null, true);
        wp_localize_script(
            'product-field-mapping', 'dabber_product_field_mapping_vars', [
            'ajax_url'  => admin_url('admin-ajax.php')
            ]
        );
    }

    public function add_submenu_items($submenu_items)
    {
        $submenu_items['product_fields_mapping'] = __('Product Fields Mapping', 'dabber');

        return $submenu_items;
    }

    public function render_section()
    {
        load_template(
            plugin_dir_path(__FILE__) .'templates/admin-mapping.php', true, [
            'wc_fields'     => apply_filters('dabber_product_mapping_wc_fields', []),
            'cova_fields'   => $this->get_cova_fields(),
            'object_types'  => $this->get_field_object_types(),
            'categories'    => [],
            'mapped_fields' => get_option($this->option_key)
            ]
        );
    }

    public function set_wc_map_fields($wc_fields)
    {
        $wc_fields['product_brand']     = 'Brand';
        $wc_fields['thc_percent']       = 'THC %';
        $wc_fields['thc_min']           = 'THC Min';
        $wc_fields['thc_max']           = 'THC Max';
        $wc_fields['thc_content']       = 'THC Content';
        $wc_fields['cbd_percent']       = 'CBD %';
        $wc_fields['cbd_min']           = 'CBD Min';
        $wc_fields['cbd_max']           = 'CBD Max';
        $wc_fields['cbd_content']       = 'CBD Content';
        $wc_fields['terpene_percent']   = 'Terpene %';
        $wc_fields['terpenes']          = 'Terpenes';
        $wc_fields['net_weight']        = 'Net Weight';
        $wc_fields['equivalent_weight'] = 'Equivalent To';
        $wc_fields['strain']        = 'Plant Type';

        return $wc_fields;
    }

    public function get_cova_fields()
    {
        $api = new FieldDefinitions();
        $fields = $api->get_fields();

        if (is_object($fields)) {
            return false;
        }

        return json_decode($fields);
    }

    public function get_field_object_types()
    {
        return apply_filters(
            'dabber_product_field_mapping_object_types', [
            'metadata'          => __('Metadata'),
            'product_taxonomy'  => __('Product Taxonomy'),
            //            'product_attribute' => __('Product Attribute')
            ]
        );
    }

    public function save_settings()
    {
        $products_mapping = $_POST['dabber_products_mapping'];
        $mapped_fields = [];

        foreach ($products_mapping as $wc_field_key => $wc_field_item) {
            if ($wc_field_item['type'] === '') {
                continue;
            }

            $mapped_fields[$wc_field_key] = $wc_field_item;
        }

        update_option($this->option_key, $mapped_fields);
    }

    public function search_mapped_field($field_id)
    {
        $mapped_settings = get_option($this->option_key);

        foreach ($mapped_settings as $key => $field) {
            if (is_array($field['cova_field']) && in_array($field_id, $field['cova_field'])) {
                $field['key'] = $key;
                return $field;
            }
        }

        return [];
    }

    public function map_product_fields($product, $object)
    {
        $map_meta = [];

        foreach ($object->data['cova_specifications'] as $spec) {
            foreach ($spec['Fields'] as $field) {

                $mapped_field = $this->search_mapped_field($field['Id']);

                if (empty($mapped_field)) {
                    continue;
                }

                $temp_val = str_replace(' ', '', $field['Value']);

                if ($temp_val === 'N/A') {
                    continue;
                }

                $args = [
                    'product'   => $product,
                    'field'     => $mapped_field,
                    'values'    => array_map('trim', preg_split('/[,|\/&]| and /', $field['Value']))
                ];

                $map_meta[$mapped_field['key']] = [
                    'type'      => $mapped_field['type'],
                    'key'       => $mapped_field['key']
                ];

                switch ($args['field']['type']) {
                case 'metadata':
                    $this->generate_metadata($args);
                    break;
                case 'product_attribute':
                    //                        $this->generate_attribute($args);
                    break;
                case 'product_taxonomy':
                    $this->generate_taxonomy_terms($args);
                    break;
                default:
                }
            }
        }

        update_post_meta($product->get_id(), 'dabber_product_mapped_fields', $map_meta);
    }

    public function generate_metadata($args)
    {
        $metadata = new MapProductMetadata();
        $metadata->set_data($args);
        $metadata->generate_metadata();
    }

    public function generate_taxonomy_terms($args)
    {
        $metadata = new MapProductTerms();
        $metadata->set_data($args);
        $metadata->generate_terms();
    }

    public function generate_attribute($args)
    {
        $metadata = new MapProductAttributes();
        $metadata->set_data($args);
        $metadata->generate_attribute();
    }

} // End class
