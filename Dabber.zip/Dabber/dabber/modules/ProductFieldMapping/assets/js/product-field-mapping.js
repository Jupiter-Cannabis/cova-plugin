(function ($) {
    $(document).ready(
        function () {
            $select_field = $('.dabbber-select2');

            if ($select_field.length > 0) {
                $select_field.each(
                    function (e) {
                        $select_field.select2();
                    }
                );
            }
        }
    );
})(jQuery);