<?php

namespace Dabber\Modules\ProductFieldMapping;

class MapProductTerms
{
    private $data;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function generate_terms()
    {
        if (!taxonomy_exists($this->data['field']['key'])) {
            return;
        }

        $terms = $this->maybe_add_product_terms();
        $term_ids = [];

        foreach ($terms as $item) {
            if (is_wp_error($item)) {
                continue;
            }
            $term_ids[] = (int) $item['term_id'];
        }

        wp_set_object_terms($this->data['product']->get_id(), $term_ids, $this->data['field']['key'], true);
    }

    public function maybe_add_product_terms()
    {
        $ids = [];

        foreach ($this->data['values'] as $value) {
            $id = term_exists($value, $this->data['field']['key']);

            if ($id ) {
                $ids[] = $id;
            } else {
                $ids[] = wp_insert_term($value, $this->data['field']['key']);

                // flush rewrite rules for new taxonomies
                flush_rewrite_rules();
            }
        }

        return $ids;
    }
}
