<?php

namespace Dabber\Modules\ProductFieldMapping;

class MapProductAttributes
{
    private $data;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function generate_attribute()
    {

    }
}
