<?php

namespace Dabber\Modules\ProductFieldMapping;

class MapProductMetadata
{
    private $data;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function generate_metadata()
    {
        if (count($this->data['values']) > 1) {
            update_post_meta($this->data['product']->get_id(), $this->data['field']['key'], $this->data['values']);
        } else {
            update_post_meta($this->data['product']->get_id(), $this->data['field']['key'], $this->data['values'][0]);
        }
    }
}
