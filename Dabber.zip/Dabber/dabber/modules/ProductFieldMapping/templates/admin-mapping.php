<h3>Product Field Mapping</h3>

<table class="form-table">
    <?php if(empty($args['cova_fields'])) : ?>
        <p>No available fields to display.</p>
    <?php else: ?>
        <table class="dabber-product-fields-wrap">
            <thead>
            <tr>
                <th>WC Fields</th>
                <th>Cova Fields</th>
                <th>Type</th>
                <?php if (!empty($args['categories'])) : ?>
                    <!--                            <th>Apply To</th>-->
                <?php endif; ?>
                <th>Display In</th>
                <th>Display Position</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($args['wc_fields'] as $field_key => $field_val) : ?>
                <tr>
                    <td>
                        <?php echo $field_val ?>
                        <input type="hidden" name="dabber_products_mapping[<?php echo $field_key ?>][name]" value="<?php echo $field_val ?>">
                    </td>
                    <td>
                        <select class="dabbber-select2" name="dabber_products_mapping[<?php echo $field_key ?>][cova_field][]" multiple>
                            <option value="">---</option>
                            <?php
                            $selected_field = (isset($args['mapped_fields'][$field_key]['cova_field']))? $args['mapped_fields'][$field_key]['cova_field'] : [];

                            foreach($args['cova_fields'] as $cova_field) :
                                ?>
                                <option value="<?php echo $cova_field->id ?>" <?php selected(in_array($cova_field->id, $selected_field)) ?>><?php echo $cova_field->displayName ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="dabber_products_mapping[<?php echo $field_key ?>][type]">
                            <option value="">---</option>
                            <?php
                            $selected_type = (isset($args['mapped_fields'][$field_key]['cova_field']))? $args['mapped_fields'][$field_key]['type'] : '';

                            foreach($args['object_types'] as $type_key => $type_name) :
                                ?>
                                <option value="<?php echo $type_key ?>" <?php selected($type_key, $selected_type) ?>><?php echo $type_name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <?php
                    if (!empty($args['categories'])) :
                        $selected_cat = (isset($args['mapped_fields'][$field_key]['apply_to']))? $args['mapped_fields'][$field_key]['apply_to'] : [];
                        ?>
                        <td>
                            <select class="dabbber-select2" name="dabber_products_mapping[<?php echo $field_key ?>][apply_to][]" multiple>
                                <option>---</option>
                                <option value="all" <?php selected(in_array('all', $selected_cat)) ?>>All</option>
                                <?php foreach ($args['categories'] as $category) : ?>
                                    <option value="<?php echo $category->term_id ?>" <?php selected(in_array($category->term_id, $selected_cat)) ?>><?php echo $category->name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    <?php endif; ?>
                    <td style="text-align: center">
                        <?php
                        $show_in = (isset($args['mapped_fields'][$field_key]['show_in']))? $args['mapped_fields'][$field_key]['show_in'] : '';
                        ?>
                        <select name="dabber_products_mapping[<?php echo $field_key ?>][show_in]">
                            <option value="">---</option>
                            <option value="archive" <?php selected('archive', $show_in) ?>>Product Archive Page</option>
                            <option value="single" <?php selected('single', $show_in) ?>>Single Product Page</option>
                            <option value="both" <?php selected('both', $show_in) ?>>Both Pages</option>
                        </select>
                    </td>
                    <td>
                        <?php
                        $position = (isset($args['mapped_fields'][$field_key]['position']))? $args['mapped_fields'][$field_key]['position'] : '';
                        ?>
                        <input type="number" name="dabber_products_mapping[<?php echo $field_key ?>][position]" value="<?php echo $position ?>">
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</table>

<p>
    <input type="submit" name="dabber-save-product-field-mapping" id="submit" class="button button-primary" value="Save Changes">
</p>
