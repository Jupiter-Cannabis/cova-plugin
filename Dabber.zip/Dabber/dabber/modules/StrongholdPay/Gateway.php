<?php

namespace Dabber\Modules\StrongholdPay;

use Dabber\Modules\StrongholdPay\API\Customers;
use Dabber\Modules\StrongholdPay\API\Paylinks;
use Dabber\Modules\StrongholdPay\API\PaymentSources;

class Gateway extends \WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id                   = 'cova_pay';
        $this->icon                 = plugin_dir_url(__FILE__) .'assets/img/cova-pay.png';
        $this->has_fields           = true;
        $this->method_title         = 'Cova Pay';
        $this->method_description   = 'Cova Pay payment gateway';

        $this->supports = ['products'];

        $this->init_form_fields();

        // Load the settings.
        $this->init_settings();
        $this->title            = $this->get_option('title');
        $this->description      = $this->get_option('description');
        $this->enabled          = $this->get_option('enabled');
        $this->sandbox         = 'yes' === $this->get_option('sandbox');
        $this->private_key      = $this->sandbox ? $this->get_option('test_private_key') : $this->get_option('private_key');
        $this->publishable_key  = $this->sandbox ? $this->get_option('test_publishable_key') : $this->get_option('publishable_key');

        // This action hook saves the settings
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);

        add_action('wp_ajax_covapay_process_payment', [$this, 'complete_payment']);
        add_action('wp_ajax_nopriv_covapay_process_payment', [$this, 'complete_payment']);
        // Webhook ready
        //         add_action('woocommerce_api_cova_pay_success', [$this, 'webhook']);
    }

    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title'       => 'Enable/Disable',
                'label'       => 'Enable Cova Pay',
                'type'        => 'checkbox',
                'description' => '',
                'default'     => 'no'
            ],
            'title' => [
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'This controls the title which the user sees during checkout.',
                'default'     => 'Debit Card',
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'This controls the description which the user sees during checkout.',
                'default'     => 'Pay using your debit card.',
            ],
            'sandbox' => [
                'title'       => 'Test mode',
                'label'       => 'Enable Test Mode',
                'type'        => 'checkbox',
                'description' => 'Place the payment gateway in test mode using test API keys.',
                'default'     => 'yes',
                'desc_tip'    => true,
            ],
            'test_publishable_key' => [
                'title'       => 'Test Publishable Key',
                'type'        => 'text'
            ],
            'test_private_key' => [
                'title'       => 'Test Secret Key',
                'type'        => 'password',
            ],
            'publishable_key' => [
                'title'       => 'Live Publishable Key',
                'type'        => 'text'
            ],
            'private_key' => [
                'title'       => 'Live Secret Key',
                'type'        => 'password'
            ]
        ];
    }

    public function payment_fields()
    {
        load_template(
            plugin_dir_path(__FILE__) .'templates/payment-form.php', true, [
            'id'            => $this->id,
            'description'   => $this->description,
            'sandbox'       => $this->sandbox,
            ]
        );
    }

    public function search_customer_id($search)
    {
        $api = new Customers();

        foreach ($search as $search_key => $search_val) {
            $customer = $api->list_customers(
                [
                $search_key => $search_val,
                'limit' => 100
                ]
            );

            if (isset($customer->result->items)) {
                foreach ($customer->result->items as $item) {
                    return $item->id;
                }
            }
        }

        return false;
    }

    public function create_customer($order)
    {
        $search = [
            'email' => $order->get_billing_email()
        ];

        $mobile = $order->get_billing_phone();

        if ($mobile) {
            $search['mobile'] = $mobile;
        }

        $customer_id = $this->search_customer_id($search);

        $api = new Customers();

        if ($customer_id === false) {
            $args = [
                'individual' => [
                    'first_name'    => $order->get_billing_first_name(),
                    'last_name'     => $order->get_billing_last_name(),
                    'date_of_birth' => $order->get_meta('_billing_birth_date'),
                    'email'         => $order->get_billing_email()
                ],
                'country'       => 'US',
                'state'         => $order->get_billing_country()
            ];

            if ($mobile) {
                $args['individual']['mobile'] = $mobile;
            }

            $customer = $api->create_customer($args);

            if (!isset($customer->result->id)) {
                return false;
            }

            $customer_id = $customer->result->id;
        }

        $customer_token = $api->create_customer_token(
            [
            'customer_id' => $customer_id
            ]
        );

        return [
            'id' => $customer_id,
            'token' => $customer_token->result->token
        ];
    }

    public function create_pay_link($customer_id, $order)
    {
        $items = [];

        foreach ($order->get_items() as $item) {
            $items[] = [
                'name'          => $item->get_name(),
                'quantity'      => $item->get_quantity(),
                'total_amount'  => $this->format_amount($item->get_total())
            ];
        }

        $args = [
            'customer_id'   => $customer_id,
            'type'          => 'checkout',
            'charge'        => [
                'external_id'   => (string) $order->get_id(),
            ],
            'order' => [
                'total_amount'  => $this->format_amount($order->get_total()),
                'tax_amount'    => $this->format_amount($order->get_total_tax()) + $this->format_amount($order->get_shipping_total()),
                'items'         => $items
            ],
            'authorize_only'    => false,
            'callbacks' => [
                'exit_url'      => get_site_url(),
                'success_url'   => get_site_url() .'?cova_pay=1&order_id='. $order->get_id()
            ]
        ];

        $pay_link_api = new Paylinks();
        $response = $pay_link_api->create_paylink($args);

        if (!isset($response->result->url)) {
            return false;
        }

        return $response->result->url;
    }

    private function format_amount($amount)
    {
        $amount = (float) $amount;
        $amount = $amount * 100;

        return ceil($amount);
    }

    public function list_payment_source($customer_id)
    {
        $api = new PaymentSources();
        $sources = $api->list_payment_sources(
            [
            'active' => 'true',
            'customer_id' => $customer_id
            ]
        );

        if (!isset($sources->result->items) || empty($sources->result->items)) {
            return false;
        }

        return $sources->result->items[0]->id;
    }

    public function generate_random_string()
    {
        return wp_generate_password(24, false);
    }

    public function process_payment( $order_id )
    {
        $order = wc_get_order($order_id);

        $customer_data = $this->create_customer($order);

        if ($customer_data === false) {
            return [
                'result' => 'failure',
                'message' => 'Failed to create  user.'
            ];
        }

        $payment_source = $this->list_payment_source($customer_data['id']);

        $amount = $this->format_amount($order->get_total());

        error_log(
            print_r(
                [
                'process_payment' => [
                'order_total' => $order->get_total(),
                'total2' => $amount
                ]
                ], true
            )
        );

        return [
            'result'         => 'success',
            'customer'       => $customer_data,
            'payment_source' => $payment_source,
            'total_amount'   => $amount,
            'external_id'    => $order_id .'-'. $this->generate_random_string()
        ];
    }

    public function complete_payment()
    {
        if (!isset($_POST['cova_pay_success'])) {
            return;
        }

        $order_id = $_POST['order_id'];

        $order = wc_get_order($order_id);

        $order->payment_complete();
        wc_reduce_stock_levels($order_id);

        wp_send_json_success(
            [
            'result'            => 'success',
            'payment_complete'  => 1,
            'redirect_url'      => $order->get_checkout_order_received_url()
            ]
        );
    }

    //    public function webhook() {
    //        error_log(print_r([
    //            'webhook' => 1
    //        ], true));
    //    }

} // End class
