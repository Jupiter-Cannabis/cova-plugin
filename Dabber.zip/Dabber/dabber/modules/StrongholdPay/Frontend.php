<?php

namespace Dabber\Modules\StrongholdPay;

class Frontend
{
    private $settings;

    public function run()
    {
        $this->settings = get_option('woocommerce_cova_pay_settings');

        if (!isset($this->settings['enabled']) || 'no' === $this->settings['enabled'] ) {
            return;
        }

        $this->settings['sandbox'] = (isset($this->settings['sandbox']))? $this->settings['sandbox'] : 'yes';

        if ($this->settings['sandbox'] === 'yes') {
            $this->settings['secret_key']   = $this->settings['test_private_key'] ?? '';
            $this->settings['publish_key']  = $this->settings['test_publishable_key'] ?? '';
        } else {
            $this->settings['secret_key'] = $this->settings['private_key'] ?? '';
            $this->settings['publish_key']  = $this->settings['publishable_key'] ?? '';
        }

        add_action('wp_enqueue_scripts', [$this, 'payment_scripts']);
        add_filter('woocommerce_billing_fields', [$this, 'add_custom_checkout_fields']);
        add_action('wp_head', [$this, 'add_inline_script']);
    }

    public function add_inline_script()
    {
        ?>
            <style>
                .wc_payment_methods li.payment_method_cova_pay {
                    margin: 10px 0 !important;
                }
                .payment_method_cova_pay img {
                    max-width: 160px;
                    margin-left: 0 !important;
                }
            </style>
        <?php
    }

    public function payment_scripts()
    {
        wp_enqueue_script('cova_stronghold', 'https://api.strongholdpay.com/v2/js', ['jquery'], null, true);
        wp_enqueue_script('cova_pay', plugin_dir_url(__FILE__) .'assets/js/strongholdpay.js', ['jquery'], null, true);
        wp_localize_script(
            'cova_pay', 'cova_pay_vars', [
            'publishableKey' => $this->settings['publish_key'],
            'env'       => ($this->settings['sandbox'])? 'sandbox' : 'live',
            'integration_id' => 'integration_aGgTo8589kAjDGgUlkaEQOpj',
            'ajax_url'  => admin_url('admin-ajax.php'),
            'site_url'  => site_url()
            ]
        );
    }

    public function add_custom_checkout_fields($fields)
    {
        $fields['billing_birth_date'] = [
            'type'          => 'date',
            'label'         => __('Birth Date', 'woocommerce'),
            'placeholder'   => 'dd/mm/yyyy',
            'required'      => true,
            'class'         => ['form-row-last'],
            'clear'         => true
        ];

        return $fields;
    }
}
