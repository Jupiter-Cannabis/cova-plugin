<?php

namespace Dabber\Modules\StrongholdPay\API;

class PaymentSources
{
    public function list_payment_sources($data)
    {
        $client = new Client();
        $client->set_endpoint('payment-sources');
        $client->set_data($data);

        return $client->get_response();
    }
}
