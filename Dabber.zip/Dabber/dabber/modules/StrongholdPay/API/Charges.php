<?php

namespace Dabber\Modules\StrongholdPay\API;

class Charges
{
    public function create_charge()
    {

    }

    public function authorize_charge()
    {

    }

    public function capture_charge()
    {

    }
}
