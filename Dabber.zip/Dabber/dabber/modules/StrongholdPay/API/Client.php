<?php

namespace Dabber\Modules\StrongholdPay\API;

use GuzzleHttp\Client as Guzzle;

class Client
{
    private $auth;
    private $data;
    private $endpoint;
    private $version = '2';
    private $method = 'get';
    private $api_base_url = 'https://api.strongholdpay.com/';

    public function __construct()
    {
        $this->auth = new Auth();
    }

    public function set_data($data = [])
    {
        $this->data = $data;
    }

    public function set_endpoint($endpoint)
    {
        $this->endpoint = $endpoint;
    }

    public function set_method($method)
    {
        $this->method = $method;
    }

    public function set_version($version)
    {
        $this->version = $version;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_endpoint()
    {
        return $this->endpoint;
    }

    public function get_method()
    {
        return $this->method;
    }

    public function get_version()
    {
        return $this->version;
    }

    public function get_response()
    {
        try {
            $args = [
                'headers' => [
                    'Accept'        => 'application/json',
                    'SH-SECRET-KEY' => $this->auth->get_secret_key()
                ]
            ];

            if (($this->method === 'get' || $this->method === 'GET') && !empty($this->data)) {
                $args['query'] = $this->data;
            }

            if (($this->method === 'post' || $this->method === 'POST') && !empty($this->data)) {
                $args['json'] = $this->data;
            }

            $args['verify'] = false;

            $client     = new Guzzle();
            $request    = $client->request($this->method, $this->api_base_url .'v'. $this->version .'/'. $this->endpoint, $args);
            $response   = $request->getBody()->getContents();

        } catch(\Exception $e) {
            return [
                'status'    => $e->getCode(),
                'message'   => $e->getMessage()
            ];
        }

        return json_decode($response);
    }
}
