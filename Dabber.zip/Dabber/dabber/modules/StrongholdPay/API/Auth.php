<?php

namespace Dabber\Modules\StrongholdPay\API;

use GuzzleHttp\Client as Guzzle;

class Auth
{
    private $secret_key;
    private $publish_key;

    public function __construct()
    {
        $options    = get_option('woocommerce_cova_pay_settings');
        $is_sandbox = (isset($options['sandbox']))? $options['sandbox'] : 'yes';

        if ($is_sandbox === 'yes') {
            $this->secret_key   = $options['test_private_key'] ?? '';
            $this->publish_key  = $options['test_publishable_key'] ?? '';
        } else {
            $this->secret_key = $options['private_key'] ?? '';
            $this->publish_key  = $options['publishable_key'] ?? '';
        }
    }

    public function get_secret_key()
    {
        return $this->secret_key;
    }

    public function get_publishable_key()
    {
        return $this->publish_key;
    }

    public function get_context()
    {
        try {

            $client     = new Guzzle();
            $request    = $client->request(
                'get', 'https://api.strongholdpay.com/v2/context', [
                'headers' => [
                    'Accept'        => 'application/json',
                    'SH-SECRET-KEY' => $this->get_secret_key()
                ]
                ]
            );

            $response = $request->getBody()->getContents();

        } catch(\Exception $e) {
            $response = [
                'status'    => $e->getCode(),
                'message'   => $e->getMessage()
            ];
        }

        return $response;
    }
}
