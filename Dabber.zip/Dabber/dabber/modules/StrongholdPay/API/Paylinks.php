<?php

namespace Dabber\Modules\StrongholdPay\API;

class Paylinks
{
    public function create_paylink($data)
    {
        $client = new Client();
        $client->set_endpoint('links');
        $client->set_method('post');
        $client->set_data($data);

        return $client->get_response();
    }
}
