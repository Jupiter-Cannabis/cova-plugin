<?php

namespace Dabber\Modules\StrongholdPay\API;

class Customers
{
    public function create_customer($data)
    {
        error_log(
            print_r(
                [
                'create_customer' => $data
                ], true
            )
        );

        $client = new Client();
        $client->set_endpoint('customers');
        $client->set_method('post');
        $client->set_data($data);

        return $client->get_response();
    }

    public function list_customers($data)
    {
        $client = new Client();
        $client->set_endpoint('customers');
        $client->set_data($data);

        return $client->get_response();
    }

    public function get_customer($data)
    {
        $args = wp_parse_args(
            $data, [
            'customer_id' => '',
            'is_external_id' => false
            ]
        );

        $client = new Client();
        $client->set_endpoint('customers/'. $args['customer_id']);
        $client->set_data($args['is_external_id']);

        return $client->get_response();
    }

    public function create_customer_token($data)
    {
        $args = wp_parse_args(
            $data, [
            'customer_id' => '',
            'is_external_id' => false
            ]
        );

        $client = new Client();
        $client->set_endpoint('customers/'. $args['customer_id'] .'/token');
        $client->set_data($args['is_external_id']);

        return $client->get_response();
    }
}
