(function ($) {

    var strongholdPay = Stronghold.Pay(
        {
            publishableKey: cova_pay_vars.publishableKey,
            environment: cova_pay_vars.env,
            integrationId: cova_pay_vars.integration_id
        }
    );

    $(document).ready(
        function () {
            wcCovaPayCheckout.onInit();
            CovaPayCheckoutBypass.init();
        }
    );

    $(document.body).on(
        'updated_checkout', function () {

        }
    );

    var wcCovaPayCheckout = {
        onInit: function () {

        },
        loadPaymentForm: function () {

        }
    };

    /**
     * The object replaces the WC checkout JS process with our own.
     * We wanted to keep the process as close as possible to the WC one, so there are a lot of methods copied over from
     * the WC process.
     *
     * @since 3.7.0
     */
    var CovaPayCheckoutBypass = {
        init: function () {
            CovaPayCheckoutBypass.form = $('form.checkout');
            CovaPayCheckoutBypass.replaceCheckout();
        },

        /**
         * Replace the WC Checkout when we use the Paysafe method
         *
         * @since 3.7.0
         */
        replaceCheckout: function () {
            var form = $('form.checkout');

            form.on(
                'checkout_place_order_cova_pay', function () {
                    form.addClass('processing');

                    CovaPayCheckoutBypass.blockOnSubmit(form);

                    // Attach event to block reloading the page when the form has been submitted
                    CovaPayCheckoutBypass.attachUnloadEventsOnSubmit();

                    // ajaxSetup is global, but we use it to ensure JSON is valid once returned.
                    $.ajaxSetup(
                        {
                            dataFilter: function (raw_response, dataType) {
                                // We only want to work with JSON
                                if ('json' !== dataType) {
                                    return raw_response;
                                }

                                if (CovaPayCheckoutBypass.is_valid_json(raw_response)) {
                                    return raw_response;
                                } else {
                                    // Attempt to fix the malformed JSON
                                    var maybe_valid_json = raw_response.match(/{"result.*}/);

                                    if (null === maybe_valid_json) {
                                        console.log('Unable to fix malformed JSON');
                                    } else if (CovaPayCheckoutBypass.is_valid_json(maybe_valid_json[0])) {
                                        console.log('Fixed malformed JSON. Original:');
                                        console.log(raw_response);
                                        raw_response = maybe_valid_json[0];
                                    } else {
                                        console.log('Unable to fix malformed JSON');
                                    }
                                }

                                return raw_response;
                            },
                        }
                    );

                    $.ajax(
                        {
                            type    : 'POST',
                            url     : wc_checkout_params.checkout_url,
                            data    : form.serialize(),
                            dataType: 'json',
                            success : function (result) {
                                // Detach the unload handler that prevents a reload / redirect
                                CovaPayCheckoutBypass.detachUnloadEventsOnSubmit();

                                console.log(result);

                                try {
                                    if ('success' === result.result) {

                                        var payment_source_id = false;

                                        if (result.payment_source === false) {

                                            strongholdPay.addPaymentSource(
                                                result.customer.token, {
                                                    onSuccess: function (paymentSource) {
                                                        payment_source_id = paymentSource.id;
                                                    },
                                                    onExit: function () {

                                                        if (payment_source_id !== false) {
                                                            CovaPayCheckoutBypass.createCharge(
                                                                {
                                                                    'customer_token': result.customer.token,
                                                                    'payment_source': payment_source_id,
                                                                    'order_id': result.order_id,
                                                                    'total_amount': result.total_amount,
                                                                    'external_id': result.external_id
                                                                }
                                                            );
                                                        } else {
                                                            CovaPayCheckoutBypass.unBlock();
                                                        }

                                                    },
                                                    onError: function (err) {}
                                                }
                                            );
                                        } else {
                                            strongholdPay.updatePaymentSource(
                                                result.customer.token, {
                                                    paymentSourceId: result.payment_source,
                                                    onSuccess: function (paymentSource) {
                                                        payment_source_id = paymentSource.id;
                                                    },
                                                    onExit: function () {

                                                        if (payment_source_id !== false) {
                                                            CovaPayCheckoutBypass.createCharge(
                                                                {
                                                                    'customer_token': result.customer.token,
                                                                    'payment_source': payment_source_id,
                                                                    'order_id': result.order_id,
                                                                    'total_amount': result.total_amount,
                                                                    'external_id': result.external_id
                                                                }
                                                            );
                                                        } else {
                                                            CovaPayCheckoutBypass.unBlock();
                                                        }
                                                    },
                                                    onError: function (err) {}
                                                }
                                            );
                                        }

                                        // if (form.triggerHandler('checkout_place_order_success') !== false) {
                                        //     if (-1 === result.redirect.indexOf('https://') || -1 === result.redirect.indexOf('http://')) {
                                        //         window.location = result.redirect;
                                        //     } else {
                                        //         window.location = decodeURI(result.redirect);
                                        //     }
                                        // }

                                    } else if ('failure' === result.result) {
                                        throw 'Result failure';
                                    } else {
                                        throw 'Invalid response';
                                    }
                                } catch (err) {
                                    // Reload page
                                    if (true === result.reload) {
                                        window.location.reload();
                                        return;
                                    }

                                    // Trigger update in case we need a fresh nonce
                                    if (true === result.refresh) {
                                        $(document.body).trigger('update_checkout');
                                    }

                                    // Add new errors
                                    if ('Result failure' !== err && 'Invalid response' !== err) {
                                        CovaPayCheckoutBypass.submit_error(err);
                                    } else if (result.messages) {
                                        CovaPayCheckoutBypass.submit_error(result.messages);
                                    } else {
                                        CovaPayCheckoutBypass.submit_error('<div class="woocommerce-error">' + wc_checkout_params.i18n_checkout_error + '</div>'); // eslint-disable-line max-len
                                    }
                                }
                            },

                            error: function (jqXHR, textStatus, errorThrown) {
                                // Detach the unload handler that prevents a reload / redirect
                                CovaPayCheckoutBypass.detachUnloadEventsOnSubmit();

                                CovaPayCheckoutBypass.submit_error('<div class="woocommerce-error">' + errorThrown + '</div>');
                            },
                        }
                    );

                    return false;
                }
            );
        },
        createCharge: function (data) {
            strongholdPay.charge(
                data.customer_token, {
                    authorizeOnly: false, // Set to true to not capture the charge immediately and create it as `authorized`.
                    charge: {
                        type: 'customer_not_present',
                        amount: data.total_amount,
                        currency: 'usd',
                        paymentSourceId: data.payment_source,
                        externalId: data.external_id,
                    },
                    onSuccess: function (charge) {
                        $.ajax(
                            {
                                type    : 'POST',
                                url     : cova_pay_vars.ajax_url,
                                data    : {
                                    action: 'covapay_process_payment',
                                    'cova_pay_success': true,
                                    'order_id': data.order_id
                                },
                                dataType: 'json',
                                success : function (result) {
                                    if (result.success === true) {
                                        window.location = result.data.redirect_url;
                                    }
                                },
                            }
                        );
                    },
                    onExit: function () {

                    },
                    onError: function (err) {}
                }
            );
        },
        handleUnloadEvent: function (e) {
            // Modern browsers have their own standard generic messages that they will display.
            // Confirm, alert, prompt or custom message are not allowed during the unload event
            // Browsers will display their own standard messages

            // Check if the browser is Internet Explorer
            if ((navigator.userAgent.indexOf('MSIE') !== -1) || (!!document.documentMode)) {
                // IE handles unload events differently than modern browsers
                e.preventDefault();
                return undefined;
            }

            return true;
        },
        attachUnloadEventsOnSubmit: function () {
            $(window).on('beforeunload', CovaPayCheckoutBypass.handleUnloadEvent);
        },
        detachUnloadEventsOnSubmit: function () {
            $(window).unbind('beforeunload', CovaPayCheckoutBypass.handleUnloadEvent);
        },
        unBlock: function () {
            CovaPayCheckoutBypass.form.unblock();
            CovaPayCheckoutBypass.form.removeClass('processing');
        },
        blockOnSubmit: function ( $form ) {
            var isBlocked = $form.data('blockUI.isBlocked');

            if (1 !== isBlocked ) {
                $form.block(
                    {
                        message: null,
                        overlayCSS: {
                            background: '#fff',
                            opacity: 0.6
                        }
                    }
                );
            }
        },
        submit_error: function (error_message) {
            $('.woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message').remove();

            CovaPayCheckoutBypass.form.prepend('<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' + error_message + '</div>'); // eslint-disable-line max-len

            CovaPayCheckoutBypass.resetCheckoutForm();
            CovaPayCheckoutBypass.scroll_to_notices();

            $(document.body).trigger('checkout_error');
        },
        resetCheckoutForm: function () {
            CovaPayCheckoutBypass.form.removeClass('processing').unblock();
            CovaPayCheckoutBypass.form.find('.input-text, select, input:checkbox').trigger('validate').blur();
        },
        scroll_to_notices: function () {
            var scrollElement = $('.woocommerce-NoticeGroup-updateOrderReview, .woocommerce-NoticeGroup-checkout');

            if (!scrollElement.length) {
                scrollElement = CovaPayCheckoutBypass.form;
            }
            $.scroll_to_notices(scrollElement);
        },
        is_valid_json: function (raw_json) {
            try {
                var json = $.parseJSON(raw_json);

                return (json && 'object' === typeof json);
            } catch (e) {
                return false;
            }
        },
    };


})(jQuery);