<?php

namespace Dabber\Modules\StrongholdPay;

class StrongholdPay
{
    //    public static $must_use = false;
    public static $module_info = [
        'name' => 'Cova Pay',
        'description' => 'Add support for Cova Pay payment method.'
    ];

    public function run()
    {
        add_filter('woocommerce_payment_gateways', [$this, 'add_gateway_class']);
        add_action('plugins_loaded', [$this, 'load_classes']);
    }

    public function add_gateway_class($gateways)
    {
        $gateways[] = 'Dabber\Modules\StrongholdPay\Gateway';

        return $gateways;
    }

    public function load_classes()
    {
        (new Frontend())->run();
    }
}
