<?php

if ($args['description'] ) {

    if ($args['sandbox'] ) {
        $args['description'] .= ' TEST MODE ENABLED.';
        $args['description']  = trim($args['description']);
    }
    echo wpautop(wp_kses_post($args['description']));
}
?>

<!--<fieldset id="cova---><?php //echo esc_attr( $args['id'] ) ?><!---cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">-->
<!---->
<!--    <div class="form-row form-row-wide"><label>Card Number <span class="required">*</span></label>-->
<!--        <input id="cova_stronghold_ccNo" type="text" autocomplete="off">-->
<!--    </div>-->
<!--    <div class="form-row form-row-first">-->
<!--        <label>Expiry Date <span class="required">*</span></label>-->
<!--        <input id="cova_stronghold_expdate" type="text" autocomplete="off" placeholder="MM / YY">-->
<!--    </div>-->
<!--    <div class="form-row form-row-last">-->
<!--        <label>Card Code (CVC) <span class="required">*</span></label>-->
<!--        <input id="cova_stronghold_cvv" type="password" autocomplete="off" placeholder="CVC">-->
<!--    </div>-->
<!--    <div class="clear"></div>-->
<!--</fieldset>-->
