<div class="cova-sync-wrap">

    <?php
        do_action('cova_admin_before_body');
    ?>

    <form action="" method="post">
        <h2>
            <?php
                _e('Stronghold Pay', 'cova');

            if ($args['is_connected'] === true) {
                echo '<span style="color: green; font-size:12px;"> ('. __('Connected', 'cova') .')</span>';
            } else {
                echo '<span style="color: red; font-size:12px;"> ('. __('Not Connected', 'cova') .')</span>';
            }
            ?>
        </h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><?php _e('Enable Payment Method', 'cova') ?></th>
                <td>
                    <fieldset>
                        <label for="cova-enable-strongholdpay">
                            <input name="cova-enable-strongholdpay" type="checkbox" <?php checked($args['is_enabled'], 'yes') ?> id="cova-enable-strongholdpay" value="1">
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Enable Sandbox Mode', 'cova') ?></th>
                <td>
                    <fieldset>
                        <label for="cova-enable-strongholdpay-sandbox">
                            <input name="cova-enable-strongholdpay-sandbox" type="checkbox" <?php checked($args['environment'], 'sandbox') ?> id="cova-enable-strongholdpay-sandbox" value="1">
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Publishable Key', 'cova') ?></th>
                <td>
                    <fieldset>
                        <label for="cova-stronghold-publishable-key">
                            <input type="text" name="cova-stronghold-publishable-key" value="<?php echo $args['publishable_key'] ?>">
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Secret Key', 'cova') ?></th>
                <td>
                    <fieldset>
                        <label for="cova-stronghold-secret-key">
                            <?php if($args['secret_key']) : ?>
                                <input type="text" name="cova-stronghold-secret-key" placeholder="Secret Key is entered" value="">
                            <?php else : ?>
                                <input type="text" name="cova-stronghold-secret-key" value="">
                            <?php endif; ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
            </tbody>
        </table>
        <input type="submit" id="submit" name="cova-save-payments" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">
    </form>
</div>
