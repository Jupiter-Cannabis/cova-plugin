(function ($) {
    $(document).ready(
        function () {
            if($('.cat-oos-item').length > 0) {
                $('.cat-oos-item').each(
                    function () {
                        let item = $(this);

                        item.find('.oos-cat').select2();
                        item.find('.oos-loc').select2();
                    }
                );
            }

            $('.add-oos-cat').click(
                function (e) {
                    e.preventDefault();

                    var new_row = $('.cat-oos-dummy:last').clone();

                    $(new_row).insertAfter(".cat-oos:last");
                    $(new_row).removeClass('cat-oos-dummy');
                    $(new_row).find('.oos-cat').select2();
                    $(new_row).find('.oos-loc').select2();
                }
            );

            $(document.body).on(
                'click', '.remove-oos-cat', function (e) {
                    var button = $(this);

                    button.closest('tr.cat-oos').remove();
                }
            );

            dabber_reindex_products();
        }
    );

    function dabber_reindex_products()
    {
        $.ajax(
            {
                url: categorized_oos_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'dabber_reindex_product_visibility'
                },
                beforeSend: function () {
                },
                success: function ( response ) {

                    $('.reindex-console .processing').hide();
                    $('.reindex-console .progress').show();

                    if (response.data.status == 'reindexing') {
                        $('.reindex-console .index-progress').html(response.data.progress.progress);
                        $('.reindex-console .index-total').html(response.data.progress.total_products);
                        dabber_reindex_products();
                    }

                    if (response.data.status === 'complete') {
                        $('.reindex-console').addClass('index-complete').html('<p><strong>Product visibility indexing completed.</strong></p>');
                    }
                },
                error: function () {

                },
                statusCode: {
                    502: function () {
                        dabber_reindex_products();
                    }
                }
            }
        );
    }
})(jQuery);