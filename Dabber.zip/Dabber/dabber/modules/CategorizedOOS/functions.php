<?php

function dabber_get_oos_threshold($location_id)
{
    $loc_threshold = get_term_meta($location_id, 'dabber_oos_threshold', true);

    if (!is_numeric($loc_threshold)) {
        return 0;
    }

    return (float) $loc_threshold;
}

function dabber_get_product_oos_limit($product_id, $location_id)
{
    $global_limit = (int) get_option('dabber_global_threshold');

    $limit = [
        'location' => $location_id,
        'category' => false,
        'limit' => $global_limit
    ];

    $oos_settings = get_option('dabber_product_visibility_terms');

    if (empty($oos_settings)) {
        //        $oos_term = get_term_by('slug', 'oos_at_'. $location_id, 'dabber_product_visibility');
        //        $limit['category'] = $oos_term->term_id;
        return $limit;
    }

    $oos_settings_arr = [];

    foreach ($oos_settings as $oos_setting_item) {
        if ($oos_setting_item['location'] != $location_id) {
            continue;
        }
        $oos_settings_arr[$oos_setting_item['location'] .'_'. $oos_setting_item['category']] = $oos_setting_item['limit'];
    }

    $categories = get_the_terms($product_id, 'product_cat');

    $child_terms = [];
    $parent_terms = [];

    if (!empty($categories)) {
        foreach ($categories as $term_item) {
            if ($term_item->parent > 0) {
                if (isset($oos_settings_arr[$location_id .'_'. $term_item->term_id])) {
                    $child_terms[] = $term_item->term_id;
                }
            } else {
                if (isset($oos_settings_arr[$location_id .'_'. $term_item->term_id])) {
                    $parent_terms[] = $term_item->term_id;
                }
            }
        }
    }

    $term_limit = 0;
    $terms_arr = $child_terms;

    if (empty($child_terms)) {
        $terms_arr = $parent_terms;
    }

    foreach ($terms_arr as $terms_arr_item) {
        $term_key = $location_id . '_' . $terms_arr_item;
        if (!isset($oos_settings_arr[$term_key])) {
            continue;
        }
        if ($oos_settings_arr[$term_key] > $term_limit) {
            $term_limit = $oos_settings_arr[$term_key];
            $limit['category'] = $terms_arr_item;
            $limit['limit'] = (int) $term_limit;
        }
    }

    return $limit;
}

function dabber_get_product_oos_limit_old($product_id, $location_id)
{
    $global_limit = (int) get_option('dabber_global_threshold');

    $limit = [
        'location' => $location_id,
        'category' => 0,
        'limit' => $global_limit
    ];

    $oos_settings = get_option('dabber_product_visibility_terms');

    if (empty($oos_settings)) {
        return $limit;
    }

    $oos_terms = get_the_terms($product_id, 'dabber_product_visibility');

    if (empty($oos_terms)) {
        return $limit;
    }

    $oos_settings_arr = [];

    foreach ($oos_settings as $oos_setting_item) {
        if ($location_id != $oos_setting_item['location']) {
            continue;
        }
        $oos_settings_arr[$oos_setting_item['location'] .'_'. $oos_setting_item['category']] = $oos_setting_item['limit'];
    }

    $oos_limit = 0;
    foreach ($oos_terms as $oos_term_item) {
        if (!array_key_exists($oos_term_item->slug, $oos_settings_arr)) {
            continue;
        }
        $term_limit = $oos_settings_arr[$oos_term_item->slug];
        if ($oos_limit === 0 || $term_limit < $oos_limit) { // get only the lowest limit quantity
            $oos_limit = $term_limit;
            $limit['category'] = $oos_term_item->term_id;
            $limit['limit'] = $oos_settings_arr[$oos_term_item->slug];
        }
    }

    return $limit;
}
