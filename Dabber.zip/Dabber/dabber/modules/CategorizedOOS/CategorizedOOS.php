<?php

namespace Dabber\Modules\CategorizedOOS;

class CategorizedOOS
{
    public static $must_use = true;
    public static $module_info = [
        'name' => 'Location & Category OOS',
        'description' => 'Location and product category based out of stock threshold'
    ];

    public $options;
    private $selected_oos_cats_items = [];
    private $product_index_group_num = 200;

    public function run()
    {
        $this->load_options();
        add_action('init', [$this, 'register_taxonomy'], 0);

        add_action('dabber_admin_enqueue_scripts_products_inventory', [$this, 'enqueue_scripts']);

        add_filter('dabber_admin_module_nav_items', [$this, 'add_new_tab'], 30);
        add_filter('dabber_admin_module_sub_nav_items_products', [$this, 'add_sub_tab']);
        add_filter('woocommerce_product_query_tax_query', [$this, 'modify_query_args'], 100);
        add_filter('prdctfltr_tax_query', [$this, 'modify_query_args'], 100);

        add_action('dabber_render_module_admin_section_products_inventory', [$this, 'render_settings'], 20);
        add_action('dabber_render_module_admin_section_products_inventory', [$this, 'add_save_button'], 9999);
        add_action('init', [$this, 'save_settings']);

        // after metadata added
        add_action('added_post_meta', [$this, 'update_product_visibility'], 10, 4);
        // after metadata updated
        add_action('updated_post_meta', [$this, 'update_product_visibility'], 10, 4);

        add_action('wp_ajax_dabber_reindex_product_visibility', [$this, 'reindex_product_visibility']);
        add_filter('woocommerce_product_is_in_stock', [$this, 'override_is_in_stock'], 11, 2);

        add_action('cova_after_bulk_create_products', [$this, 'index_product_visibility_after_import'], 20);
        add_action('cova_after_bulk_update_products', [$this, 'index_product_visibility_after_update'], 20);

        include_once 'functions.php';
    }

    public function enqueue_scripts()
    {
        wp_enqueue_style('select2', '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', [], null);
        wp_enqueue_script('select2');
        wp_enqueue_style('categorized-oos', plugin_dir_url(__FILE__) .'assets/css/main-style.css', [], null);

        wp_enqueue_script('categorized-oos', plugin_dir_url(__FILE__) .'assets/js/main-script.js', [], null, true);
        wp_add_inline_script(
            'categorized-oos', 'let categorized_oos_vars = '. json_encode(
                [
                'ajax_url'   => admin_url('admin-ajax.php')
                ]
            ), 'before'
        );
    }

    public function load_options()
    {
        $this->options = [
            'taxonomy_name' => 'dabber_product_visibility',
            'categories' => $this->get_selected_terms()
        ];
    }

    public function reindex_product_visibility()
    {
        $reindex = ProductVisibilityIndexer::start();

        wp_send_json_success(
            [
            'progress' => $reindex['progress'],
            'status' => $reindex['status']
            ], 200
        );
    }

    public function index_product_visibility_after_update($products)
    {
        $locations = cova_get_all_wc_locations();

        foreach ($products as $product_id => $product) {
            foreach ($locations as $loc_item) {
                if (!isset($product['metadata']['wcmlim_stock_at_'. $loc_item['term_id']])) {
                    continue;
                }
                self::set_product_visibility_term($product_id, $loc_item['term_id']);
            }
        }
    }

    public function index_product_visibility_after_import($product_ids)
    {
        $locations = cova_get_all_wc_locations();

        foreach ($product_ids as $product_id) {
            foreach ($locations as $loc_item) {
                self::set_product_visibility_term($product_id, $loc_item['term_id']);
            }
        }
    }

    public function save_settings()
    {
        if (!isset($_POST['dabber_admin_module_save_settings_products_inventory'])) {
            return;
        }

        $selected_oos_cats = [];

        if (!empty($_POST['location_category_oos'])) {
            $items_handler = [];
            foreach ($_POST['location_category_oos'] as $type => $items) {
                foreach ($items as $key => $item) {
                    if ($type === 'location') {
                        $items_handler[$key]['location'] = $item;
                    }
                    if ($type === 'category') {
                        $items_handler[$key]['category'] = $item;
                    }
                    if ($type === 'limit') {
                        $items_handler[$key]['limit'] = $item;
                    }
                }
            }

            foreach ($items_handler as $oos_item) {
                if (empty($oos_item['location'])) {
                    continue;
                }
                $selected_oos_cats[] = $oos_item;
                $this->selected_oos_cats_items[$oos_item['location']][] = $oos_item['location'] .'_'. $oos_item['category'];
            }
        }

        update_option('woocommerce_notify_no_stock_amount', 0);
        update_option('dabber_global_threshold', sanitize_text_field($_POST['global_oos']));
        update_option('dabber_product_visibility_terms', $selected_oos_cats);

        $this->reset_oos_terms();
        $this->generate_products_to_update_visibility();
    }

    public function generate_products_to_update_visibility()
    {
        $products = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'posts_per_page' => -1,
            'post_status' => 'any',
            'fields' => 'ids'
            ]
        );

        $items = array_chunk($products->posts, apply_filters('dabber_product_index_group_num', $this->product_index_group_num), false);

        self::update_index_data('index-product-visibility-progress', 1);
        self::update_index_data('index-product-visibility', $items);
        self::update_index_data('index-product-visibility-total', count($products->posts));
    }

    public function reset_oos_terms()
    {
        $selected_oos_cats_items = [];

        if (!empty($this->selected_oos_cats_items)) {
            foreach ($this->selected_oos_cats_items as $location_id => $items) {
                foreach ($items as $item) {
                    $term_arr = explode('_', $item);
                    $term_item = term_exists($item, $this->options['taxonomy_name']);
                    if (!$term_item) {
                        $term_item = wp_insert_term($item, $this->options['taxonomy_name']);
                    }
                    $selected_oos_cats_items[$location_id][] = $term_arr[1] .'_'. $term_item['term_id'];
                }
            }
        }

        $locations = cova_get_all_wc_locations();

        foreach ($locations as $location) {
            $term_item_name = 'oos_at_'. $location['term_id'];
            $term_item = term_exists($term_item_name, $this->options['taxonomy_name']);
            if (!$term_item) {
                $term_item = wp_insert_term($term_item_name, $this->options['taxonomy_name']);
            }
            $selected_oos_cats_items[$location['term_id']][] = $term_item['term_id'] .'_'. $term_item['term_id'];
        }

        update_option('dabber_product_visibility_term_items', $selected_oos_cats_items);
    }

    public function get_selected_terms()
    {
        $selected_terms = get_option('dabber_product_visibility_term_items');

        return (is_array($selected_terms))? $selected_terms : [];
    }

    public function render_settings()
    {
        $selected_categories = get_option('dabber_product_visibility_terms');
        $selected_categories = (is_array($selected_categories))? $selected_categories : [];

        $categories = $this->get_categories_array();
        $locations  = $this->get_locations_array();

        $global_threshold = (int) get_option('dabber_global_threshold');

        $reindex_progress = CategorizedOOS::get_index_data('index-product-visibility-progress');
        $reindex_progress = (isset($reindex_progress->index_value))? $reindex_progress->index_value : 0;

        load_template(
            plugin_dir_path(__FILE__) .'templates/oos-settings.php', true, [
            'categories' => $categories,
            'locations' => $locations,
            'selected_categories' => $selected_categories,
            'global_threshold' => $global_threshold,
            'reindex_inprogress' => $reindex_progress
            ]
        );
    }

    public function add_save_button()
    {
        echo '<hr><input type="submit" id="submit" class="button button-primary" value="Save Changes">';
    }

    public function get_categories_array()
    {
        $categories = new \WP_Term_Query(
            [
            'taxonomy'   => 'product_cat',
            'hide_empty' => false
            ]
        );

        $categories_arr = [];

        foreach ($categories->terms as $category) {
            $parent_name = '';

            if ($category->parent) {
                $parent = get_term_by('id', $category->parent, 'product_cat');
                $parent_name = $parent->name .' > ';
            }
            $categories_arr[$category->term_id] = $parent_name . $category->name;
        }

        return $categories_arr;
    }

    public function get_locations_array()
    {
        $locations  = cova_get_all_wc_locations();

        if (empty($locations)) {
            return [];
        }

        $locations_arr = [];

        foreach ($locations as $location) {
            $locations_arr[$location['term_id']] = $location['name'];
        }

        return $locations_arr;
    }

    /**
     * Remove Woocommerce visibility term query
     * @param $tax_query
     * @return mixed
     */
    public function modify_query_args($tax_query)
    {
        if (is_admin()) {
            return $tax_query;
        }

        foreach ($tax_query as $key => $item) {
            if (!isset($item['taxonomy']) || $item['taxonomy'] != 'product_visibility') {
                continue;
            }
            unset($tax_query[$key]);
        }

        return $tax_query;
    }

    public function get_exclude_category_ids()
    {
        $exclude_ids = [];

        global $dabber_current_location_data;

        if (empty($this->options['categories']) 
            || !isset($this->options['categories'][$dabber_current_location_data['wc_location_id']])
        ) {
            return $exclude_ids;
        }

        foreach ($this->options['categories'][$dabber_current_location_data['wc_location_id']] as $slugs) {
            $slug = explode('_', $slugs);
            $exclude_ids[] = $slug[1];
        }

        return $exclude_ids;
    }

    public function update_product_visibility($meta_id, $object_id, $meta_key, $meta_value)
    {
        if (stripos($meta_key, 'wcmlim_stock_at_') === false) {
            return;
        }

        $location_id = str_replace('wcmlim_stock_at_', '', $meta_key);

        self::set_product_visibility_term($object_id, $location_id, $meta_value);
    }

    public static function set_product_visibility_term($product_id, $location_id, $quantity = false)
    {
        if ($quantity === false) {
            $quantity = (int) get_post_meta($product_id, 'wcmlim_stock_at_'. $location_id, true);
        }

        $stock_info = dabber_get_product_oos_limit($product_id, $location_id);
        $term_slug = 'oos_at_'. $location_id;

        if ($stock_info['category'] != false) {
            $term_slug = $location_id .'_'. $stock_info['category'];
        }

        $oos_term = get_term_by('slug', $term_slug, 'dabber_product_visibility');

        if (!$oos_term) {
            return false;
        }

        if ($quantity > $stock_info['limit']) {

            $product = wc_get_product($product_id);

            update_post_meta($product_id, '_stock_status', 'instock');

            $product->set_catalog_visibility('catalog');
            $product->save();

            $product->set_catalog_visibility('visible');
            $product->save();

            return wp_remove_object_terms($product_id, $oos_term->term_id, 'dabber_product_visibility');
        }

        return wp_set_post_terms($product_id, [$oos_term->term_id], 'dabber_product_visibility', true);
    }

    public function override_is_in_stock($is_show, $product)
    {
        global $dabber_current_location_data;

        if (is_admin()) {
            return $is_show;
        }

        $oos_info = dabber_get_product_oos_limit($product->get_id(), $dabber_current_location_data['wc_location_id']);
        $location_quantity = dabber_get_product_location_stock_quantity($product->get_id(), $dabber_current_location_data['wc_location_id']);

        if ($location_quantity > $oos_info['limit']) {
            return true;
        }

        return false;
    }

    function register_taxonomy()
    {
        $labels = array(
            'name'                       => _x('Dabber Product Visibilities', 'Taxonomy General Name', 'dabber'),
            'singular_name'              => _x('Dabber Product Visibility', 'Taxonomy Singular Name', 'dabber'),
            'menu_name'                  => __('Dabber Product Visibility', 'dabber'),
            'all_items'                  => __('All Items', 'dabber'),
            'parent_item'                => __('Parent Item', 'dabber'),
            'parent_item_colon'          => __('Parent Item:', 'dabber'),
            'new_item_name'              => __('New Item Name', 'dabber'),
            'add_new_item'               => __('Add New Item', 'dabber'),
            'edit_item'                  => __('Edit Item', 'dabber'),
            'update_item'                => __('Update Item', 'dabber'),
            'view_item'                  => __('View Item', 'dabber'),
            'separate_items_with_commas' => __('Separate items with commas', 'dabber'),
            'add_or_remove_items'        => __('Add or remove items', 'dabber'),
            'choose_from_most_used'      => __('Choose from the most used', 'dabber'),
            'popular_items'              => __('Popular Items', 'dabber'),
            'search_items'               => __('Search Items', 'dabber'),
            'not_found'                  => __('Not Found', 'dabber'),
            'no_terms'                   => __('No items', 'dabber'),
            'items_list'                 => __('Items list', 'dabber'),
            'items_list_navigation'      => __('Items list navigation', 'dabber'),
        );
        $args = array(
            'labels'                     => $labels,
            'hierarchical'               => false,
            'public'                     => false,
            'show_ui'                    => false,
            'show_admin_column'          => false,
            'show_in_nav_menus'          => false,
            'show_tagcloud'              => false,
        );

        register_taxonomy($this->options['taxonomy_name'], array( 'product', 'product_variation' ), $args);
    }

    public function add_new_tab($tabs)
    {
        $tabs['products'] = __('Products', 'dabber');

        return $tabs;
    }

    public function add_sub_tab($tabs)
    {
        $tabs['inventory'] = __('Inventory', 'dabber');

        return $tabs;
    }

    public static function add_index_data($key, $value)
    {
        global $wpdb;

        $value = maybe_serialize($value);
        $sql = "INSERT INTO {$wpdb->prefix}dabber_index (index_key, index_value, timestamp) VALUES (%s, %s, %s)";
        return $wpdb->query($wpdb->prepare($sql, $key, $value, current_time('mysql', 1)));
    }

    public static function update_index_data($key, $value)
    {
        global $wpdb;

        if (self::is_index_data_exists($key) === false) {
            return self::add_index_data($key, $value);
        }

        $sql = "UPDATE {$wpdb->prefix}dabber_index SET index_value = %s, timestamp = %s WHERE index_key = %s";
        return $wpdb->query($wpdb->prepare($sql, maybe_serialize($value), current_time('mysql', 1), $key));
    }

    public static function is_index_data_exists($key)
    {
        return (self::get_index_data($key));
    }

    public static function get_index_data($key)
    {
        global $wpdb;

        $sql = "SELECT * FROM {$wpdb->prefix}dabber_index WHERE index_key = %s";
        $result = $wpdb->get_row($wpdb->prepare($sql, $key));

        if (!$result) {
            return false;
        }

        $result->index_value = maybe_unserialize($result->index_value);

        return $result;
    }
} // end Class
