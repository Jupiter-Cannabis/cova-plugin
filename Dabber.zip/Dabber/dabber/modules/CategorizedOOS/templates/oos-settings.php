<h3>Out of stock threshold</h3>

<div class="category-oos-wrap" style="max-width: 680px;">
    <?php if($args['reindex_inprogress']) : ?>
        <div class="reindex-console">
            <p><strong>Product visibility indexing is in progress.</strong><br>This process may take a while. Please don't close the browser while the indexing is in progress.</p>
            <p class="progress" style="display: none">Progress: <span class="index-progress"></span> / <span class="index-total"></span></p>
            <p class="processing">Processing...</p>
        </div>
    <?php endif; ?>
    <table class="form-table">
        <tbody>
            <tr>
                <td style="width:115px;"><strong>Global threshold</strong></td>
                <td><input type="number" name="global_oos" value="<?php echo $args['global_threshold'] ?>"></td>
            </tr>
        </tbody>
    </table>
    <table class="form-table">
        <tbody>
            <tr>
                <td><strong>Location</strong></td>
                <td><strong>Category</strong></td>
                <td><strong>Quantity</strong></td>
                <td></td>
            </tr>
            <tr class="cat-oos-dummy cat-oos">
                <td>
                    <select name="location_category_oos[location][]" class="oos-loc">
                        <option value="">-- Select Location --</option>
                        <?php foreach($args['locations'] as $loc_id => $loc_name) : ?>
                            <option value="<?php echo $loc_id ?>"><?php echo $loc_name ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <select name="location_category_oos[category][]" class="oos-cat">
                        <option value="">-- Select category --</option>
                        <?php foreach($args['categories'] as $cat_id => $cat_name) : ?>
                            <option value="<?php echo $cat_id ?>"><?php echo $cat_name ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input name="location_category_oos[limit][]" type="number" min="0" step="1" value="0"></td>
                <td><input type="button" class="remove-oos-cat" value="Remove Item"></td>
            </tr>

            <?php if (!empty($args['selected_categories'])) : ?>
                <?php foreach($args['selected_categories'] as $item) : ?>
                    <tr class="cat-oos cat-oos-item">
                        <td>
                            <select name="location_category_oos[location][]" class="oos-loc">
                                <option value="">-- Select Location --</option>
                                <?php foreach($args['locations'] as $loc_id => $loc_name) : ?>
                                    <option <?php selected($item['location'], $loc_id) ?> value="<?php echo $loc_id ?>"><?php echo $loc_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="location_category_oos[category][]" class="oos-cat">
                                <option value="">-- Select category --</option>
                                <?php foreach($args['categories'] as $cat_id => $cat_name) : ?>
                                    <option <?php selected($item['category'], $cat_id) ?> value="<?php echo $cat_id ?>"><?php echo $cat_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input name="location_category_oos[limit][]" type="number" min="0" step="1" value="<?php echo $item['limit']; ?>"></td>
                        <td><input type="button" class="remove-oos-cat" value="Remove Item"></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <div style="text-align: center">
        <input type="button" class="add-oos-cat" value="Add Item">
    </div>
</div>
