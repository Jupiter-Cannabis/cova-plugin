<?php

namespace Dabber\Modules\CategorizedOOS;

class ProductVisibilityIndexer
{
    public static function start()
    {
        $reindex_progress = CategorizedOOS::get_index_data('index-product-visibility-progress');
        $reindex_progress = (isset($reindex_progress->index_value))? $reindex_progress->index_value : 0;

        if (!$reindex_progress) {
            return ['progress' => [], 'status' => 'complete'];
        }

        $update_products = CategorizedOOS::get_index_data('index-product-visibility');
        $update_products = (isset($update_products->index_value))? $update_products->index_value : [];

        if (empty($update_products[0])) {
            CategorizedOOS::update_index_data('index-product-visibility-progress', 0);
            CategorizedOOS::update_index_data('index-product-visibility-total', 0);
            return ['progress' => [], 'status' => 'complete'];
        }

        $locations = cova_get_all_wc_locations();

        foreach ($update_products[0] as $item) {
            foreach ($locations as $loc_item) {
                CategorizedOOS::set_product_visibility_term($item, $loc_item['term_id']);
            }
        }

        unset($update_products[0]);

        $update_products = array_values($update_products);
        $to_update_count = 0;

        foreach ($update_products as $update_items) {
            $to_update_count += count($update_items);
        }

        CategorizedOOS::update_index_data('index-product-visibility', $update_products);

        $total_products = CategorizedOOS::get_index_data('index-product-visibility-total');

        $progress = [
            'progress' => $total_products->index_value - $to_update_count,
            'total_products' => $total_products->index_value
        ];

        return [
            'progress' => $progress,
            'status' => 'reindexing'
        ];
    }
}
