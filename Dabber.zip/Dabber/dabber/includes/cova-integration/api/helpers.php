<?php

function dabber_generate_guid()
{
    if (function_exists('com_create_guid')) {
        return com_create_guid();
    } else {
        mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
        $charid = md5(uniqid(rand(), true));
        $hyphen = chr(45);// "-"
        $uuid = substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid, 12, 4).$hyphen
            .substr($charid, 16, 4).$hyphen
            .substr($charid, 20, 12);
        return $uuid;
    }
}

function dabber_get_integrator_id()
{
    return apply_filters('dabber_integrator_id', 'ac7c9640-747f-4cc6-999c-f621e1fd388b');
}

function get_company_id()
{
    global $cova_api_auth;
    $companyId = 0;
    try{
        $companyId = $cova_api_auth->credentials['company_id'];
    }catch (\Exception $e) {
        $companyId = -1;
    }

    return $companyId;
}

//----------------------------------------------------------------

function cova_LogglyLogger($logItem, $tags, $loggerName, $logType = \Monolog\Logger::INFO)
{
    //Ensure tags and logitem were supplied. If not, do not log.
    if (empty($tags) || empty($logItem)) {
        return;
    }

    try
    {
        $log = new Monolog\Logger($loggerName);
        $logglyHandler = new Monolog\Handler\LogglyHandler(LOGGLY_API_KEY . '/tag/' . urlencode(LOGGLY_TAGS . ',' .$tags), LOGGING_LEVEL, true);
        $log->pushHandler(@$logglyHandler);

        if ($logType === \Monolog\Logger::ERROR) {
            $log->error($logItem);
        }
        elseif ($logType === \Monolog\Logger::DEBUG) {
            $log->debug($logItem);
        }
        else //Log all other types as info
        {
            $log->info($logItem);
        }

    } catch (\Exception $e) {
        //Fail silently, since logging isn't critical.
    }
}



function cova_debugger($vars, $send_email = false)
{
    if (is_array($vars)) {
        $vars = print_r($vars, true);
    }
    
    //Get the companyId. If auth hasn't set this yet, we can assume zero or negative one.
    global $cova_api_auth;
    $companyId = get_company_id();
       
    $backtrace  = debug_backtrace(0, 2);
    $debug_vars = print_r(
        [
        'function'  => (isset($backtrace[1]['function']))? $backtrace[1]['function'] : $backtrace[0]['function'],
        'source'    => $backtrace[0]['file'] .':'. $backtrace[0]['line'],
        'variables' => $vars,
        'timestamp' => date('Y-m-d H:i:s'),
        'companyid' =>  $companyId
        ], true
    );


    //We only want to write to the log file if we're at a debug log level, otherwise the text file will grow very large.
    //Normally, the log level is info.
    if (LOGGING_LEVEL == \Monolog\Logger::DEBUG) {
        $log_file_path = ABSPATH .'/cova_debug.log';

        if (!file_exists($log_file_path)) {
            $f = fopen($log_file_path, 'a+');
            fclose($f);
        }
    
        error_log($debug_vars, 3, $log_file_path);
    }

    if ($send_email === true) {
        wp_mail(
            [
            'paul@dabber.io'
            ], get_bloginfo('name') .' dabber debug log', $debug_vars
        );
    }

    //the loggly stuff
    cova_LogglyLogger($debug_vars, 'cova-ecom-apicall', 'cova-debugger', Monolog\Logger::DEBUG);
}

function dabber_cron_logger($vars)
{
    if (is_array($vars)) {
        $vars = print_r($vars, true);
    }

    $backtrace  = debug_backtrace(0, 2);
    $debug_vars = print_r(
        [
        'function'  => (isset($backtrace[1]['function']))? $backtrace[1]['function'] : $backtrace[0]['function'],
        'source'    => $backtrace[0]['file'] .':'. $backtrace[0]['line'],
        'variables' => $vars,
        'timestamp' => date('Y-m-d H:i:s')
        ], true
    );

    $log_file_path = ABSPATH .'/dabber_cron.log';

    if (!file_exists($log_file_path)) {
        $f = fopen($log_file_path, 'a+');
        fclose($f);
    }

    error_log($debug_vars, 3, $log_file_path);
}


/**
 * This function is similar to dabber_cron_logger, except it logs the cron start and stop, tied togeter by an iteration Id
 * The iterationid can be genereted by md5(microtime());
 */
function dabber_cron_logger2($vars, $iterationid = "", float $duration = 0, bool $success = true)
{
    //Record the statsD
    // Initialize StatsD client for Hosted Graphite
    $connection = new Domnikl\Statsd\Connection\UdpSocket(STATSD_HOST, STATSD_PORT);
    $namespace = STATSD_APIKEY_NAMESPACEPREPEND . '.' . STATSD_ENVIRONMENT . '.Cova.ECommerce.Plugin.Crons';
    $sampleRateAllMetrics = 1.0;
    $statsd = new Domnikl\Statsd\Client($connection, $namespace, $sampleRateAllMetrics);

    $backtrace  = debug_backtrace(0, 2);
    $funcname = (isset($backtrace[1]['function']))? $backtrace[1]['function'] : $backtrace[0]['function'];
    
    //write the statsd for either a starting or complete event.
    if ($success) {
        if ($duration > 0) {//If the duration is > 0, then we can assume the cron is completing
            $statsd->increment($funcname . '.completed');
            $statsd->timing($funcname, $duration);
        }
        else
        {//otherwise, it's starting.
            $statsd->increment($funcname . '.starting');    
        }
    }
    else
    {
        $statsd->increment($funcname . '.failed');
    }  
    
    //Record the logs
    if (is_array($vars)) {
        $vars = print_r($vars, true);
    }

    global $cova_api_auth;
    $companyId = get_company_id();
     
    $debug_vars = print_r(
        [
        'function'  => $funcname,
        'source'    => $backtrace[0]['file'] .':'. $backtrace[0]['line'],
        'variables' => $vars,
        'timestamp' => date('Y-m-d H:i:s'),
        'companyId' => $companyId,
        'iterationId' => @$iterationid,
        'Success' => $success,
        'CronStatus' => ($duration > 0) ? ('Cron executed in ' . $duration . ' seconds.') : ('Cron starting.')
        ], true
    );

    cova_LogglyLogger($debug_vars, 'cova-ecom-cron', 'CronLogger2', $success ? Monolog\Logger::DEBUG : Monolog\Logger::ERROR);

}

function dabber_api_endpoint_v2($module, $function, $version = 'v1', $host = 'iqmetrix', $env = '')
{
    $hosts = [
        'iqmetrix'  => 'iqmetrix.net',
        'iqmetrix2' => 'api'. $env .'.iqmetrix.net',
        'cova'      => 'api'. $env .'.covasoft.net'
    ];

    $host = $hosts[$host];

    if ($host === 'iqmetrix.net') {
        $module = $module . $env;
    }

    $segments = [
        'https:/',
        $host,
        $module,
        $version,
        $function
    ];

    return implode('/', $segments);
}

function dabber_api_endpoint($module='', $function='', $host=null, $version=null)
{
    $config   = [
    "protocol"    => 'https',
    "host"        => [
    'main' => 'iqmetrix.net',
    'cova' => 'covasoft.net',
    ],
    "version"     => 'v1',
    ];
    $host     = isset($host) ? $config['host'][$host] : $config['host']['main'];
    $version  = isset($version) ? $config['version'] : null;

    $data = [
    $config['protocol'].':/',
    $module.'.'.$host,
    $version,
    $function
    ];

    if(is_null($data[2])) {
        unset($data[2]);
    }

    return implode('/', $data);
}

//----------------------------------------------------------------

// function config($full = false) {
//     $config = include(plugin_dir_path( __FILE__ ) .'config.php');

//     if( $full ) {
//         return $config;
//     }

//     $mode   = $config['live_mode'] ? 'live' : 'sandbox';
//     return $config[$mode];
// }

//----------------------------------------------------------------

// function root_dir($filename = '') {
//     $data = [plugin_dir_path( __FILE__ ).'..', $filename];
//     return implode('/', $data);
// }

//----------------------------------------------------------------

function dabber_urldecode_build_query($params = [])
{
    $params = array_filter($params);
    return urldecode(http_build_query($params));
}

//----------------------------------------------------------------
