<?php

require COVA_PLUGIN_DIR .'vendor/autoload.php';

require_once plugin_dir_path(__FILE__) .'InstrumentedHttp.php';
require_once plugin_dir_path(__FILE__) .'helpers.php';
require_once plugin_dir_path(__FILE__) .'Auth.php';

$modules = array_filter(
    glob(plugin_dir_path(__FILE__) .'modules/*.php'), function ($v) {
        return false === strpos($v, 'index.php');
    }
);

asort($modules);

foreach( $modules as $module ) {
    include $module;
}
