<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class SalesInvoice
{

    function __construct($config = []) 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Create a Sales Order and Convert it to Invoice in RQ
     * Creates an order in RQ then automatically creates the associated invoice.
     * Note: a successful response for this endpoint does not indicate successful import into RQ, it only confirms response format and validation.
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleInvoice
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Create-a-Sales-Order-and-Convert-it-to-Invoice-in-RQ
     *
     * @param  $search array
     * @return Object
     */
    function create($data = []) 
    { 
        try {

            $endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleInvoice', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    /**
     * Get invoice summaries
     * Pulls back Invoice Summaries for a Company with Filtering
     *
     * @endpoint https://invoice.iqmetrix.net/v1/Companies({CompanyId})/InvoiceSummaries
     * @document https://api.covasoft.net/swagger/ui/index#!/SalesInvoice/SalesInvoice_GetInvoiceSummaries
     *
     * @param  $search array
     * @return Object
     */
    function invoiceSummaries($search = []) 
    { 
        try {

            $params = dabber_urldecode_build_query($search);

            $endpoint = dabber_api_endpoint('invoice', 'companies('.$this->company_id.')/InvoiceSummaries?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

} 
