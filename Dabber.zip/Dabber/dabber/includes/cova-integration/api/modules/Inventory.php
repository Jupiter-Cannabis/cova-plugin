<?php
namespace CovaAPI;

use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class Inventory
{

    function __construct() 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get Inventory
     * Get Availability of a Catalog Item - Location Level
     *
     * @endpoint https://availability.iqmetrix.net/v1/Companies({CompanyId})/Entities({LocationId})/CatalogItems
     * @document https://developers.iqmetrix.com/api/availability#operation/Get-Availability-for-All-Catalog-Items-Location-Level
     * 
     * @return string
     */
    function all($location_id = '') 
    { 
        try {
 
            $endpoint = 'https://api.covasoft.net/availability/v1/Companies('.$this->company_id.')/Entities('.$location_id.')/CatalogItems/SellingRoomOnly';
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getMessage();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_paged_default_selling_room_quantities($location_id, $per_page = 1000)
    {
        $skip       = 0;
        $items      = [];

        while (true) {
            $response = json_decode($this->get_default_selling_room_quantities($location_id, $skip, $per_page), true);
            $items = array_merge($items, $response);
            $skip += $per_page;

            if (empty($response)) {
                return $items;
            }
        }
    }

    public function get_product_default_selling_room_quantities($location_id, $catalog_id)
    {
        try {
            $endpoint = dabber_api_endpoint('api', 'availability/v1/Companies('. $this->company_id .')/Entities('. $location_id .')/DefaultSellingRoomQuantities?$filter=ProductId eq guid'. "'". $catalog_id ."'", 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getMessage();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_default_selling_room_quantities($location_id, $skip = 0, $top = 1000)
    {
        try {
            $endpoint = dabber_api_endpoint('api', 'availability/v1/Companies('. $this->company_id .')/Entities('. $location_id .')/DefaultSellingRoomQuantities?$filter=InStock ge 0l&$skip='. $skip .'&$top='. $top, 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getMessage();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function sellingRoomOnly($location_id = '') 
    { 
        try {
 
            // $endpoint = dabber_api_endpoint('availability', 'Companies('.$this->company_id.')/Entities('.$location_id.')/CatalogItems/SellingRoomOnly', null, true);
            
            $endpoint = 'https://api.covasoft.net/availability/v1/Companies('.$this->company_id.')/Entities('.$location_id.')/CatalogItems/SellingRoomOnly';

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getMessage();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    function sellingRoomById($location_id = '', $catalog_id) 
    { 
        try {

            $endpoint = 'https://api.covasoft.net/availability/v1/Companies('.$this->company_id.')/Entities('.$location_id.')/CatalogItems('.$catalog_id.')/SellingRoomOnly';

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
        
    } 

    function byProduct($location_id = '', $catalog_id) 
    { 
        try {
 
            $endpoint = dabber_api_endpoint('availability', 'companies('.$this->company_id.')/Entities('.$location_id.')/CatalogItems('.$catalog_id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function detailedQuantity($location_id = '', $catalog_id) 
    { 
        try {

            $endpoint = 'https://api.covasoft.net/availability/v1/Companies('.$this->company_id.')/Entities('.$location_id.')/CatalogProductQuantitiesDetailed('.$catalog_id.')';

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }     
} 
