<?php
namespace CovaAPI;

use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class PurchaseLimits
{
    private $httpClient;

    public function __construct()
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->httpClient = new InstrumentedHttp($guzzle);

        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get gauges per location
     *
     * @return Object
     */
    public function byLocationId($location_id, $body)
    {
        try {
            $endpoint = 'https://api.covasoft.net/commerceprovider/v1/companies/'.$this->company_id.'/locations/'.$location_id.'/calculategauges';

            $response = $this->httpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ],
                'body'    => json_encode($body)
                ]
            );
        } catch(\Exception $e) {
            $response = $e->getResponse();
        }

        if (!is_object($response)) {
            cova_debugger($response);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $response;
        }

        return $response->getBody()->getContents();
    }
}
