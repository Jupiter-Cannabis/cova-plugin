<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class Catalog
{

    function __construct($config = []) 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get Catalog
     * Pulls back all Catalog Items for a Company
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-All-Catalog-Items
     *
     * @var    $search array
     * @return Object
     */
    function items($search = []) 
    { 
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $params = dabber_urldecode_build_query($search);

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get a Catalog Item
     * Get a Catalog Item (CatalogItemId) from your company's Catalog.
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items({CatalogItemId})
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-a-Catalog-Item
     *
     * @var    $id integer
     * @return Object
     */
    function byItemId($id='') 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/catalog/items('.$id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get catalog structure by id
     * This get the product structure including the master product and its variations
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/companies({CompanyId})/catalog/items({CatalogItemId})/productdetails
     *
     * @var     $id integer
     * @returns Object
     */
    function structure($id='') 
    {
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/catalog/items('.$id.')/ProductDetails', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get catalog structure by id
     * This Call gets a catalog item in Cova by and exernal id stored in the RmsId field
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items(RmsId={RmsId})
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-Catalog-Items-by-Product-Library-Identifier
     *
     * @var     $id integer 
     * @returns Object
     */
    function itemsRms($id='') 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/catalog/items(RmsId='.$id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get catalog items by manufacturer sku
     * This Call gets a catlog item in Cova by the Manufacturer's Sku
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items/ByManufacturerSku
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-Catalog-Items-by-Manufacturer-SKU
     *
     * @var    $search array() 
     * @return Object
     */
    function byManufacturerSku($search = []) 
    { 
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $params = dabber_urldecode_build_query($search);

            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/catalog/items/bymanufacturersku?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get catalog items by catalog sku
     * This Call gets a catalog item in Cova by the Catalog Sku
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items/ByVendorSku
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-Catalog-Items-by-Vendor-SKU
     *
     * @var    $search array
     * @return Object
     */
    function byVendorSku($search = []) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $params = dabber_urldecode_build_query($search);

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/catalog/items/ByVendorSku?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 


    /**
     * Get Catalog Items by Search Criteria
     * Get a list of Catalog Items matching the provided criteria, see Query Parameters below for more details.
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Search
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-Catalog-Items-by-Search-Criteria
     *
     * @var     $search array
     * @returns Object
     */
    function search($search = []) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try {

            $params = dabber_urldecode_build_query($search);

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Search?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 


    /**
     * Get Product Details for a List of Catalog Items
     * Get details for a list of Products (CatalogItemId) from your Catalog.
     *
     * @endpoint https://catalogs.iqmetrix.net/v1/Companies({CompanyId})/Catalog/Items/ProductDetails/Bulk
     * @document https://developers.iqmetrix.com/api/catalog#operation/Get-Product-Details-for-a-Catalog-Item
     *
     * @var     $search array
     * @returns Object
     */
    function bulk($data = []) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try { 

            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items/ProductDetails/Bulk', null, true);
            
            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ],
                'json' => $data,
                'verify'      => false, 
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * API calls below are for testing
     */
    
    function extendedAttribute($catalog_id) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try { 
            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items('. $catalog_id .')/attributes', null, true);
    
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    function compatibleProduct($catalog_id) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }
        
        try { 
            $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items({'. $catalog_id .'})/Compatible', null, true);
    
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    function bySlug($slug) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try { 

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items(Slug='. $slug .')', null, true);
    
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    function bySku($sku) 
    {  
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try { 

               $endpoint = dabber_api_endpoint('catalogs', 'companies('.$this->company_id.')/Catalog/Items(CatalogSku='. $sku .')', null, true);
    
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }     

    function product_manager($slug)
    {
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }

        try { 

               $endpoint = 'https://api.covasoft.net/productlibrary/ProductManager/products/'. $slug;
    
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();        
    }

    function get_products_by_category_or_classification($id)
    {
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }
        
        try {

            $params = dabber_urldecode_build_query(
                [
                'CategoryOrClassificationId' => $id,
                'Page' => 1,
                'PageSize' => 10000
                ]
            );
            $endpoint = 'https://api.covasoft.net/catalogs/v1/Companies('. $this->company_id .')/Catalog/Search?'. $params;

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
} 
