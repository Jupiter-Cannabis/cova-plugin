<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class Dispensary
{

    function __construct() 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get Dispensary 
     * Pulls back Dispensary Package Testing Details
     * https://api.covasoft.net/dispensary/companies({CompanyId})/ProductTestResults?filter={filter}
     * 
     * @var     $filter string
     * @returns Object
     */
    function productTestResults($filter='') 
    { 
        try {

            $endpoint = dabber_api_endpoint('api', 'dispensary/companies('.$this->company_id.')/ProductTestResults?filter='.$filter, 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

} 

