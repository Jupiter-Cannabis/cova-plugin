<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class Location
{
    private $InstrumentedHttpClient;

    function __construct() 
    {
        global $cova_api_auth;
        

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);

        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get Locations
     * Get all entities with the role of Location for a Company.
     *
     * @endpoint https://entitymanagerrc.iqmetrix.net/v1/Companies({CompanyId})/Locations
     * @document https://developers.iqmetrix.com/api/entity-store/#operation/Create-a-Location
     * 
     * @return Object
     */
    function all($search = []) 
    { 
        //If the companyId is not set, then there is no sense making the call because it will just return an error.
        if (empty($this->company_id)) {
            return null;
        }
    
        try {

            $endpoint = dabber_api_endpoint('entitymanager', 'companies('.$this->company_id.')/Locations', null, true);
            
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,   
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  
} 
