<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class ItemPricing
{

    function __construct() 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    public function get_product_prices($location_id, $catalog_id)
    {
        try {
            $endpoint = dabber_api_endpoint_v2('pricing', 'Companies('. $this->company_id .')/ProductPrices?$filter=EntityId eq '. $location_id .' and CatalogItemId eq guid'. "'". $catalog_id ."'", 'v1', 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    /**
     * Get Item Pricing 
     * This Call Returns Pricing for all the items in the specified Location within the Company
     * https://api.covasoft.net/pricing/v1/Companies({CompanyId})/Entities({IntityID})/CatalogItems
     * 
     * @var    $id int
     * @return Object
     */
    function byId($entities=null, $id=null) 
    { 
        try {
 
            $endpoint = 'https://api.covasoft.net/pricing/v1/Companies('.$this->company_id.')/Entities('.$entities.')/CatalogItems('.$id.')/Pricing';
 
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }   

    function byLocation($entities=null) 
    { 
        try {
 
            $endpoint = 'https://api.covasoft.net/pricing/v1/Companies('.$this->company_id.')/Entities('.$entities.')/CatalogItems';
 
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    function pricing_tiers()
    {
        try {
 
            $endpoint = 'https://api.covasoft.net/pricing/v1/Companies('.$this->company_id.')/PricingTiers';
 
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();        
    }

    public function pricing_groups()
    {
        try {
 
            $endpoint = 'https://api.covasoft.net/pricing/v1/Companies('.$this->company_id.')/PricingGroups';
 
            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();                
    }
} 
