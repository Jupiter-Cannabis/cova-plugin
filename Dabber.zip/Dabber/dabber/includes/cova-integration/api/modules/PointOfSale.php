<?php
namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class PointOfSale
{

    function __construct() 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    function get_completed_orders($location_id)
    { 
        try {
            $endpoint = "https://api.covasoft.net/pointofsale/Companies(". $this->company_id .")/Locations(". $location_id .")/CompletedOrders?$filter=Created ge datetimeoffset'2022-02-01T00:00:00.000Z' and Created le datetimeoffset'2022-03-15T15:59:59.999Z'";

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                // 'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_order_details($order_id)
    {        
        try {
            $endpoint = 'https://api.covasoft.net/pointofsale/Companies('. $this->company_id .')/Sales('. $order_id .')';

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();        
    }

    public function set_order_status($order_id, $data)
    {        
        try {

            $endpoint = 'https://api.covasoft.net/pointofsale/Companies('. $this->company_id .')/OrderStatus('. $order_id .')';

            $res = $this->InstrumentedHttpClient->request(
                'PUT', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '. $this->access_token,     
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
}
