<?php
namespace CovaAPI;
use CovaAPI\Auth;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class Customer
{

    function __construct() 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    /**
     * Get All Customers By Criteria
     * This Call Returns all the Customers in a Company
     *
     * @endpoint https://crm.iqmetrix.net/v1/companies({CompanyId})/CustomerSearch
     * @document https://developers.iqmetrix.com/api/crm#operation/Searching
     * @param    $search array
     * @return   Object
     */

    function search($search = [])
    {
        try {

            $params = dabber_urldecode_build_query($search);

            $endpoint = dabber_api_endpoint('crm', 'companies('.$this->company_id.')/CustomerSearch?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    /**
     * Get All Customers
     * This Call Returns all the Customers in a Company
     *
     * @endpoint https://crm.iqmetrix.net/v1/companies({CompanyId})/customers
     * @document https://developers.iqmetrix.com/api/crm#operation/Get-All-Customers
     *
     * @param  $search array
     * @return Object
     */
    function customers($search = []) 
    { 
        try {

            $params = dabber_urldecode_build_query($search);

            $endpoint = dabber_api_endpoint('crm', 'companies('.$this->company_id.')/customers?'.$params, null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    /**
     * Get customer details 
     * This Call Returns all the Customers in a Company
     *
     * @endpoint https://crm.iqmetrix.net/v1/companies({CompanyId})/CustomerFull({CustomerId})
     * @document https://developers.iqmetrix.com/api/crm#operation/Get-a-Full-Customer
     *
     * @var    $id int
     * @return Object
     */
    function byId($id='') 
    { 
        try {

            $endpoint = dabber_api_endpoint('crm', 'companies('.$this->company_id.')/CustomerFull('.$id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  


    function create($data = []) 
    { 
        try {

            $endpoint = dabber_api_endpoint('crm', 'companies('.$this->company_id.')/CustomerFull', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    function update($data = [], $customerCovaId) 
    { 
        try {

            $endpoint = dabber_api_endpoint('crm', 'companies('.$this->company_id.')/CustomerFull('.$customerCovaId.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'PUT', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function createAddress($data = [], $customerId)
    {
        try {

            $endpoint = dabber_api_endpoint('crm', 'Companies('.$this->company_id.')/Customers('.$customerId.')/Addresses', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                    'headers' => [
                        'Accept'        => 'application/json',
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer '.$this->access_token,
                    ],
                    'verify'      => false,
                    'body'        => json_encode($data),
                    'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function updateAddress($data = [], $customerId, $addressId)
    {
        try {

            $endpoint = dabber_api_endpoint('crm', 'Companies('.$this->company_id.')/Customers('.$customerId.')/Addresses('.$addressId.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'PUT', $endpoint, [
                    'headers' => [
                        'Accept'        => 'application/json',
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer '.$this->access_token,
                    ],
                    'verify'      => false,
                    'body'        => json_encode($data),
                    'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
} 
