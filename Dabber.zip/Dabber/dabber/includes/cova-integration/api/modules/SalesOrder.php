<?php
namespace CovaAPI;
use CovaAPI\Auth;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class SalesOrder
{

    function __construct($config = []) 
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    public function set_to_paid($data)
    {
        try {
            $endpoint = 'https://api.covasoft.net/covaorderintake/v1/CovaOrderPayment';

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function create_order_v2($data)
    {
        try {

            $order_guid = $data['order_id'];
            unset($data['order_id']);

            $endpoint = dabber_api_endpoint_v2('covaorderintake', 'CovaOrder('. $order_guid .')', 'v2', 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'PUT', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    /**
     * Create a Sales Order with No Invoice
     * Creates a Sales Order in RQ but does not automatically create the invoice. The invoice must be created manually.
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleOrder
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Create-a-Sales-Order-with-No-Invoice
     *
     * @param  $order_id string
     * @return Object
     */
    function create($data = []) 
    { 
        try {

            //$endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleOrder', null, true);
            $endpoint = 'https://api.covasoft.net/covaorderintake/v1/CovaOrder';
            
            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  


    /**
     * Get a Sales Order
     * Get information for the Sales Order that corresponds with the given SalesOrderId.
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleOrder({SaleOrderId})
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Get-a-Sales-Order
     *
     * @param  $order_id string
     * @return Object
     */
    function byId($order_id = '') 
    { 
        try {

            $endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleOrder('.$order_id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }


        return $res->getBody()->getContents();
    }  


    /**
     * Get the Status of a Sales Order
     * Get the current status of a Sale Order that corresponds with the given SalesOrderId.
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleOrderStatus({SaleOrderId})
     * @document https://developers.iqmetrix.com/api/sales-order#tag/Sales-Order-Status
     *
     * @param  $order_id string
     * @return Object
     */
    function status($order_id = '') 
    { 
        try {

            //$endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleOrderStatus('.$order_id.')', null, true);
            //            $endpoint = 'https://api.covasoft.net/covaorderintake/v1/Companies('.$this->company_id.')/CovaOrder('.$order_id.')/Status';
            $endpoint = 'https://api.covasoft.net/covaorderintake/v2/Companies('.$this->company_id.')/CovaOrder('. $order_id .')/Status';

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    /**
     * Get Log Entries for a Sales Order
     * Get all log entries associated with a SaleOrderId
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleOrder({SaleOrderId})/StatusLog
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Get-Log-Entries-for-a-Sales-Order
     *
     * @param  $order_id string
     * @return Object
     */
    function statusLog($order_id = '') 
    { 
        try {

            $endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleOrder('.$order_id.')/StatusLog', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }  

    /**
     * Get Details for a Sales Order Log Entry
     * Get all log entries associated with a LogEntryId and its accompanying SaleOrderId
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/SaleOrder({SaleOrderId})/StatusLog({LogEntryId})
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Get-Log-Entries-for-a-Sales-Order
     *
     * @param  $order_id string | $log_entry_id string
     * @return Object
     */
    function statusLogEntry($order_id = '', $log_entry_id = '') 
    { 
        try {

            $endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/SaleOrder('.$order_id.')/StatusLog('.$log_entry_id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

    /**
     * Get all Sales Order by its Printable ID
     * Get all Sales Orders associated with a PrintableId
     *
     * @endpoint https://salesorder.iqmetrix.net/v1/Companies({CompanyId})/PrintableId({PrintableId})
     * @document https://developers.iqmetrix.com/api/sales-order#operation/Get-all-Sales-Order-by-its-Printable-ID
     *
     * @param  $printable_id string
     * @return Object
     */
    function byPrintableId($printable_id = '') 
    { 
        try {

            $endpoint = dabber_api_endpoint('salesorder', 'companies('.$this->company_id.')/PrintableId('.$printable_id.')', null, true);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,     
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    } 

} 
