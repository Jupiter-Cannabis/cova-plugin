<?php
namespace CovaAPI;

use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class PackageDetails
{

    function __construct()
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
    }

    function get_package_details($package_ids = [])
    {
        try {
            $endpoint = dabber_api_endpoint_v2('packagedetails', 'companies/'. $this->company_id .'/producttestresultsbypackagelist', 'v2', 'cova');

            $data = [
                'PackageIds' => $package_ids
            ];

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '. $this->access_token,
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
}
