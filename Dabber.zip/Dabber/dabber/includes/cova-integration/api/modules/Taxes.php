<?php

namespace CovaAPI;

use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class Taxes
{
    function __construct($config = [])
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id = $cova_api_auth->credentials['company_id'];
    }

    public function get_catalog_items_tax($catalog_ids)
    {

    }

    public function get_tax_rate_details($tax_id)
    {

    }

    public function get_tax_calculation($items, $location_id)
    {
        try {
            $data = [
                'CompanyId' => $this->company_id,
                'EntityId' => $location_id,
                'LineItems' => $items
            ];

            $endpoint = dabber_api_endpoint_v2('taxes', 'TaxCalculation', 'v2', 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '. $this->access_token,
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_tax_categories()
    {
        try {
            $endpoint = dabber_api_endpoint_v2('taxes', 'Companies('. $this->company_id .')/TaxCategories', 'v1', 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_all_tax_rates()
    {
        try {
            $endpoint = dabber_api_endpoint_v2('taxes', 'Companies('. $this->company_id .')/TaxRates', 'v1', 'cova');

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
}
