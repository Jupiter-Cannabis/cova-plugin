<?php
namespace CovaAPI;

use CovaAPI\Auth;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;

class LoyaltyPoints
{

    function __construct()
    {
        global $cova_api_auth, $dabber_current_location_id;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id = $cova_api_auth->credentials['company_id'];
        $this->entity_id = $dabber_current_location_id;
    }


    function byId($id='')
    {
        try {

            //$endpoint = dabber_api_endpoint('api', 'companies('.$this->company_id.')/entities('.$this->company_id.')/Customers('.$id.')/Summary', 'covasoft.net/iqloyalty', true);
            $endpoint = "https://api.covasoft.net/iqloyalty/v1/Companies(".$this->company_id.")/Entities(".$this->company_id.")/Customers(".$id.")/Summary";

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function all($entity_id='')
    {
        try {

            //$endpoint = dabber_api_endpoint('api', 'companies('.$this->company_id.')/entities('.$this->company_id.')/Customers('.$id.')/Summary', 'covasoft.net/iqloyalty', true);
            $endpoint = "https://api.covasoft.net/iqloyalty/v1/Companies(".$this->company_id.")/Entities(".$entity_id.")/Rewards";

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    function update($id='', $data = [])
    {
        try {

            //$endpoint = dabber_api_endpoint('api', 'companies('.$this->company_id.')/entities('.$this->company_id.')/Customers('.$id.')/Summary', 'covasoft.net/iqloyalty', true);
            $endpoint = "https://api.covasoft.net/iqloyalty/v1/companies(".$this->company_id.")/entities(".$this->entity_id.")/customers(".$id.")/adjustment";

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ],
                'verify'      => false,
                'body'        => json_encode($data),
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

}
