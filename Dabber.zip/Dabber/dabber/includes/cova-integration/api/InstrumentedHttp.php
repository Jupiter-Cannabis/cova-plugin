<?php 
/**
 * This is a decorator around the Guzzle http client that will send API call times, and volumes to a statsD collector
 */
namespace CovaAPI;
use Domnikl\Statsd\Client;
use Domnikl\Statsd\Connection\UdpSocket;
use Monolog;

class InstrumentedHttp
{

    private $guzzle;
    private $statsd;
    private $log;

    function __construct($guzzle) 
    {
        // Initialize StatsD client for Hosted Graphite
        $connection = new UdpSocket(STATSD_HOST, STATSD_PORT);
        $namespace = STATSD_APIKEY_NAMESPACEPREPEND . '.' . STATSD_ENVIRONMENT . '.Cova.ECommerce.Plugin.Api';
        $sampleRateAllMetrics = 1.0;
        $this->statsd = new Client($connection, $namespace, $sampleRateAllMetrics);

        // Ingest Guzzle client
        $this->guzzle = $guzzle;
    }


    /**
     * This function wraps the request function in Guzzle\client.php
     */
    public function request($method, $uri = '', array $options = [])
    {
        // Start timing
        $apiName = str_replace('//', '_', $method . '_' . $uri); //change double the forward slashes
        $apiName = str_replace('/', '_', $apiName); //change the forward slashes
        $apiName = str_replace('.', '_', $apiName); //Change the dots
        $apiName = str_replace(':', '', $apiName); //Change the :
        $apiName = preg_replace('/\([^()]*\)/', '', $apiName); //Remove anything between parenthesis.
        $apiName = preg_replace('/(?:\()\w{8}-\w{4}-\w{4}-\w{4}-\w{12}(?:\))?/', '', $apiName); //Remove the guids from the code in ().
        $apiName = preg_replace('/\b\w{8}-\w{4}-\w{4}-\w{4}-\w{12}\b/', '', $apiName); //Remove the guids on their own in the query filter
        $apiName = preg_replace('/[0-9]+/', '', $apiName); //Remove the numbers, otherwise we'll get a diferent metric for each location
        $apiName = preg_replace('/filter=.*$/i', '', $apiName); //Remove anything after the string "filter" as we don't want to keep filter in the metrics.

        $start = microtime(true);
        $statusCode = 0;

        // Make API call using injected Guzzle client
        try {
            // Make API call using injected Guzzle client
            $response = $this->guzzle->request($method, $uri, $options);
            $statusCode = $response->getStatusCode();
        } catch (\Exception $e) {
            // Record error metric in StatsD
            $this->statsd->increment($apiName . '.errors');
            // Record the timing anyway.
            $duration = microtime(true) - $start;
            $this->statsd->timing($apiName, $duration);           
            
            
            // Log error
            //remove the password, if it's in the options, since we don't want to log this.
            if (isset($options['form_params']['password'])) {
                unset($options['form_params']['password']);
            }
            if (isset($options['form_params']['client_secret'])) {
                unset($options['form_params']['client_secret']);
            }
            $debug_vars = print_r(
                [
                'errormessage' => $e->getMessage(),
                'uri'  => $uri,
                'verb'    => $method,
                'headers' => $options,
                'companyId' => get_company_id(),
                'timestamp' => date('Y-m-d H:i:s')
                ], true
            );        

            cova_LogglyLogger($debug_vars, 'cova-ecom-apicall,cova-ecomapierror', 'HttpClient', Monolog\Logger::ERROR);
            // Rethrow exception to propagate it up the call stack
            throw $e;
        }

        // End timing and record duration
        $duration = microtime(true) - $start;
        $this->statsd->timing($apiName, $duration);
        $this->statsd->increment($apiName . '.status_code.' . $statusCode);

        //Debug log the request and response
        //Create an array with two items: the requeset and response.
        $reqres = array($method, $uri, substr($response->getBody()->getContents(), 0, 5000) , $statusCode); 
        cova_debugger($reqres);
        $response->getBody()->rewind();

        //LOG ERRORS >= 400 TO LOGGLY
        if ($statusCode >= 400) {
            //remove the password, if it's in the options, since we don't want to log this.
            if (isset($options['form_params']['password'])) {
                unset($options['form_params']['password']);
            }
            if (isset($options['form_params']['client_secret'])) {
                unset($options['form_params']['client_secret']);
            }

            $debug_vars = print_r(
                [
                'statuscode' => $statusCode,
                'uri'  => $uri,
                'verb'    => $method,
                'headers' => $options,
                'timestamp' => date('Y-m-d H:i:s')
                ], true
            );
            
            cova_LogglyLogger($debug_vars, 'cova-ecom-apicall,cova-ecomapierror', 'HttpClient', Monolog\Logger::ERROR);
        }

        return $response;
    }
}
