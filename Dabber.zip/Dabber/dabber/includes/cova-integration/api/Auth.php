<?php

namespace CovaAPI;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\InstrumentedHttp;
//require_once dirname(__FILE__). '/InstrumentedHttp.php';

class Auth
{
    private $credentials;

    public function set_credentials($credentials)
    {
        $this->credentials = $credentials;
    }

    public function generate_access_token()
    {
        $endpoint = dabber_api_endpoint('accounts', 'oauth2/token', null, true);

        $credentials = [
            'grant_type'    => 'password',
            'client_id'     => $this->credentials['client_id'],
            'client_secret' => $this->credentials['client_secret'],
            'username'      => $this->credentials['username'],
            'password'      => $this->credentials['password'],
        ];
        
        //Only attempt to get a token if the username has a value. For new sites, or sites not connected,
        //this will prevent noise in the logs due to failed auth calls.
        if (!empty($this->credentials['username'])) {

            $client = new Guzzle();
            $InstrumentedHttpClient = new InstrumentedHttp($client);
            $res = $InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'form_params' => $credentials,
                'http_errors' => false
                ]
            );

            $response = $res->getBody()->getContents();
            $response = json_decode($response, true);

            return $response;
        }
        else
        {
            return "No password";
        }
    }

    public function refresh_access_token()
    {
        $api = get_option('dabber_api_details');

        $this->set_credentials(
            [
            'grant_type'    => 'password',
            'client_id'     => $api[$api['mode']]['credentials']['client_id'],
            'client_secret' => $api[$api['mode']]['credentials']['client_secret'],
            'username'      => $api[$api['mode']]['credentials']['username'],
            'password'      => $api[$api['mode']]['credentials']['password'],
            ]
        );

        $response = $this->generate_access_token();

        if (!isset($response['access_token'])) {
            return false;
        }

        $api[$api['mode']]['auth'] = [
            'access_token'  => $response['access_token'],
            'expires_in'    => $response['expires_in'],
            'refresh_token' => $response['refresh_token'],
            'generated_at'  => date('Y-m-d H:i:s'),
            'expired_at'    => date('Y-m-d H:i:s', strtotime('+'. $response['expires_in'].' seconds'))
        ];

        update_option('dabber_api_details', $api);

        return (object) $api[$api['mode']];
    }

    public function get_token()
    {
        $api  = get_option('dabber_api_details');

        if (!isset($api['live']['credentials']['environment'])) {
            $api['live']['credentials']['environment'] = ''; // for back compatibility
        }

        if (!isset($api[$api['mode']]) || $api[$api['mode']] == false) {
            return $this->refresh_access_token();
        } else {

            if(strtotime($api[$api['mode']]['auth']['expired_at']) < strtotime(date('Y-m-d H:i:s')) ) {
                return $this->refresh_access_token();
            }

            return (object) $api[$api['mode']];
        }
    }
}

function cova_api_auth_init()
{
    global $cova_api_auth;

    $auth  = new Auth();
    $cova_api_auth = $auth->get_token();
}
cova_api_auth_init();

