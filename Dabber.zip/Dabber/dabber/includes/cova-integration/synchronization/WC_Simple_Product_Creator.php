<?php

namespace Cova_Integration;

class WC_Simple_Product_Creator
{
    public $data;
    public $api;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    /**
     * Breakdown variable products if the current product belongs
     * to a an existing variable product in WC.
     */
    public function breakdown_variable_product()    
    {
        $slug = $this->get_variation_sibling();

        if ($slug === false) {
            return;
        }
        
        do_action('cova_breakdown_products', [$slug]);
    }

    public function get_variation_sibling()
    {
        $slug = cova_truncate_slug($this->data['Id']);
        $products = $this->cova_global_data['catalog'][$slug];

        if (count($products) > 1) {
            return $slug;
        }

        return false;
    }

    public function create()
    {        
        $this->breakdown_variable_product();

        $details_manager = new Simple_Product_Details_Manager($this->api);
        $details_manager->set_data($this->data);
        $details_manager->set_cova_global_data($this->get_cova_global_data());

        $details = $details_manager->get_wc_product_details();

        /**
         * Remove product if sku already exists
         */
        $existing_id = wc_get_product_id_by_sku($details['sku']);
        if ($existing_id) {
            wp_delete_post($existing_id, true);
        }

        $details['wc_product'] = new \WC_Product_Simple();

        $update_product = new WC_Simple_Product_Updater();
        $update_product->set_data($details);

        return $update_product->update();
    }
}
