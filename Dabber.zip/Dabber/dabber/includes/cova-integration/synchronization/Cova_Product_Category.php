<?php

namespace Cova_Integration;

/**
 * Create category and assign product to a category on product sync.
 */
class Cova_Product_Category
{
    // public $cova_data;
    public $product_id;
    public $categories;
    public $cova_api;
    public $online_menu_as_category = false;
    private $dynamic_cats = [
    '{strain}'
    ];

    public function run()
    {
        add_action('wp_ajax_cova_category_mapping_regenerate_categories', [$this, 'regenerate_categories']);
    }

    public function set_product_id($product_id)
    {
        $this->product_id = $product_id;
    }

    public function set_product_catalog_id($catalog_id)
    {
        $this->product_catalog_id = $catalog_id;
    }

    public function set_categories($categories)
    {
        $this->categories = $categories;
    }

    public function get_product_id()
    {
        return $this->product_id;
    }

    // public function set_cova_data($cova_data)
    // {
    //     $this->cova_data = $cova_data;
    // }

    public function get_product_catalog_id()
    {
        return $this->product_catalog_id;
    }

    public function get_categories()
    {
        return $this->categories;
    }

    // public function get_cova_data()
    // {
    //     return $this->cova_data;
    // }

    // public function set_online_menu_as_subcategory($is_true)
    // {
    //     $this->online_menu_as_category = $is_true;
    // }

    // public function get_online_menu_as_subcategory($is_true)
    // {
    //     return $this->online_menu_as_category;
    // }

    public function regenerate_categories()
    {
        $catalog = new Sync\Catalog();
        $catalog->run();
        $this->cova_api['catalog'] = $catalog;

        $update_products = $this->get_products_and_categories();

        $this->save_classification_data();

        if ($update_products === true) {
            wp_send_json_success(
                [
                'status' => 'complete',
                'message' => 'Regenerate categories complete.'
                ], true
            );
        }

        foreach ($update_products as $key => $product_item) {
            $this->update_product_category($product_item);
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'date' => $update_products
            ], 200
        );
    }

    public function update_product_category($product_data)
    {
        wp_set_object_terms($product_data['product_id'], "", 'product_cat'); // remove existing attached categories

        if ($product_data['categories']['classification'] !== '') {
            $this->map_parent_category($product_data['product_id'], $product_data['categories']['classification']);
        }

        if ((isset($product_data['categories']['online-menu']) && $product_data['categories']['online-menu'] !== '') 
            || (isset($product_data['categories']['strain']) && $product_data['categories']['strain'] !== '')
        ) {
            $this->map_sub_categories($product_data['product_id'], $product_data['categories']);
        }
    }

    public function map_parent_category($product_id, $parent_cat)
    {
        $mapped_categories = get_option('cova_category_mapping');
        $parent_cat = dabber_sanitize_slug($parent_cat);

        if (!isset($mapped_categories[$parent_cat])) {
            return;
        }

        $category_ids = $this->create_term_array_hierarchy($mapped_categories[$parent_cat]);
        $product = wc_get_product($product_id);
        $parent_id = $product->get_parent_id();

        if ($parent_id > 0) {
            wp_set_object_terms($parent_id, $category_ids, 'product_cat');    
        }

        wp_set_object_terms($product_id, $category_ids, 'product_cat');

        //        error_log(print_r([
        //            'map_parent_category' => [
        //                'product_id' => $product_id,
        //                'parent_cat' => $parent_cat,
        //                // 'mapped_categories' => $mapped_categories,
        //                'category_ids' => $category_ids
        //            ]
        //        ], true));

        $product->set_catalog_visibility('catalog');
        $product->save();

        $product->set_catalog_visibility('visible');
        $product->save();
    }

    public function map_sub_categories($product_id, $categories)
    {
        $mapped_categories = get_option('cova_category_mapping');
        $mapped_key  = $categories['classification'];

        if (isset($categories['online-menu'])) {
            $submenu_arr = array_map('trim', explode(' - ', $categories['online-menu']));
            $mapped_key  = $mapped_key .'-'. implode('-', $submenu_arr);
        }
        
        $mapped_key = dabber_sanitize_slug($mapped_key);
        
        if (!isset($mapped_categories[$mapped_key]) || (!isset($categories['online-menu']) && !isset($categories['strain']))) {
            return;
        }

        $remap_categories = [];

        foreach ($mapped_categories[$mapped_key] as $key => $category) {
            switch ($category) {
            case '{strain}':
                $remap_categories[] = $categories['strain'];
                break;                
            default:
                $remap_categories[] = $category;
                break;
            }
        }

        $remap_categories = array_unique($remap_categories);
        $remap_categories = array_filter($remap_categories);

        $category_ids = $this->create_term_array_hierarchy($remap_categories);
        $product = wc_get_product($product_id);
        $parent_id = $product->get_parent_id();

        if ($parent_id > 0) {
            wp_set_object_terms($parent_id, $category_ids, 'product_cat');    
        }

        wp_set_object_terms($product_id, $category_ids, 'product_cat');
    }



    public function create_term_array_hierarchy($terms)
    {
        $last_term_slug = [];
        $category_ids = [];

        foreach ($terms as $key => $term) {
            
            if ($term === '' || in_array($term, $this->dynamic_cats)) {
                continue;
            }
            
            $parent_slug = implode('-', $last_term_slug);
            $prefix_slug = ($parent_slug !== '')? $parent_slug .'-' : '';
            $term_slug   = $prefix_slug . dabber_sanitize_slug($term);
            $term_name   = sanitize_text_field($term);

            $last_term_slug[] = dabber_sanitize_slug($term);
            $is_term = get_term_by('slug', $term_slug, 'product_cat');

            if (isset($is_term->term_id)) {
                $category_ids[] = $is_term->term_id;
                continue;
            }

            $parent_id = 0;

            if ($parent_slug !== '') {
                $parent_cat = get_term_by('slug', $parent_slug, 'product_cat');
                if (isset($parent_cat->term_id)) {
                    $parent_id = $parent_cat->term_id;
                }
            }            

            $new_cat = wp_insert_term(
                $term_name, 'product_cat', [
                'parent' => $parent_id,
                'slug' => $term_slug
                ]
            );

            if (! is_wp_error($new_cat) ) {
                      $category_ids[] = $new_cat['term_id'];
            }
        }

        return $category_ids;
    }

    public function get_products_and_categories()
    {
        $page = App::get_sync_transient_data('category_mapping_current_index_page', 1);
        $catalog_ids = $this->get_all_cova_products_paginated();

        if ($page > count($catalog_ids)) {
            App::save_sync_transient_data('category_mapping_current_index_page', 1);            
            return true;
        }

        $catalog_ids = $catalog_ids[$page];

        $cova_products = $this->cova_api['catalog']->bulk(
            [
            'CatalogItemIds' => $catalog_ids
            ]
        );            

        if (!isset($cova_products['CatalogItems'])) {
            return [];
        }

        $cova_products = $cova_products['CatalogItems'];
        $wc_products = $this->get_product_ids_by_catalog_ids($catalog_ids);            

        $update_products = [];

        foreach ($wc_products as $product_id => $catalog_id) {
            $product_details = $cova_products[$catalog_id];

            $wc_terms = [];
            $categories = [];

            if (isset($product_details['CanonicalClassification']['Name'])) {
                $categories['classification'] = $product_details['CanonicalClassification']['Name'];
            }

            if (isset($product_details['Specifications']) && !empty($product_details['Specifications'])) {
                foreach ($product_details['Specifications'] as $key => $spec) {

                    foreach ($spec['Fields'] as $field) {
                        if ($field['DisplayName'] === 'Online Menu Category') {
                            $categories['online-menu'] = $field['Value'];
                        }

                        if ($field['DisplayName'] === 'Strain') {
                            $categories['strain'] = $field['Value'];
                        }
                    }

                    // if ($spec['Name'] === 'Online Menu') {
                    //     foreach ($spec['Fields'] as $field) {
                    //         if ($field['DisplayName'] === 'Online Menu Category') {
                    //             $categories['online-menu'] = $field['Value'];
                    //         }
                    //     }
                    // }

                    // if ($spec['Name'] === 'Details') {
                    //     foreach ($spec['Fields'] as $details) {
                    //         if ($details['DisplayName'] === 'Strain') {
                    //             $categories['strain'] = $details['Value'];
                    //         }
                    //     }
                    // }
                }
            }

            $update_products[] = [
            'product_id' => $product_id,
            'catalog_id' => $catalog_id,
            'categories' => $categories
            ];        
        }

        $page += 1;
        App::save_sync_transient_data('category_mapping_current_index_page', $page);

        return $update_products;
    }

    public function save_classification_data()
    {
        $classification_id = trim(get_option('cova_classification_tree_id'));

        if (!$classification_id) {
            return;
        }

        $classifications = new \CovaAPI\ClassificationTree();

        $items = $classifications->get_classifications($classification_id);
        $items = json_decode($items, true);

        $categories = [];

        //        if (!empty($items['Categories'])) {
        ////            foreach ($items['Categories'])
        //        }
    }

    public static function get_all_cova_categories($classification_tree_id)
    {
        $classifications = new \CovaAPI\ClassificationTree();
        $items = $classifications->get_classifications($classification_tree_id);
        $items = json_decode($items, true);  // cova classification items

        $categories = [];
        $classifications = [];

        // get items from categories
        if (isset($items['Categories'])) {
            $categories = self::get_cova_categories_classifications_recursive($items['Categories']);

            foreach ($items['Categories'] as $category) {
                $categories[][] = [
                    'Id' => $category['Id'],
                    'Name' => $category['Name']
                ];
            }

            $categories = call_user_func_array('array_merge', $categories);
        }

        if (isset($items['Classifications'])) {
            $classifications = $items['Classifications'];
        }

        $merged_categories = array_merge($categories, $classifications);
        $merged_categories = array_filter($merged_categories);

        $cat_items = [];

        foreach ($merged_categories as $cat_item) {
            $cat_items[$cat_item['Id']] = dabber_sanitize_slug($cat_item['Name']);
        }

        update_option('dabber_classifications', $cat_items);

        return $merged_categories;
    }

    public static function get_cova_categories_classifications_recursive($top_categories)
    {
        $classifications = [];

        foreach ($top_categories as $key => $top_category) {
            foreach ($top_category as $tkey => $cat_items) {

                if ($tkey === 'Classifications' && !empty($cat_items)) {
                    $classifications[] = $cat_items;
                }

                if ($tkey === 'Categories' && !empty($cat_items)) {
                    $cat_items2 = self::get_cova_categories_classifications_recursive($cat_items);
                    $cat_items2 = call_user_func_array('array_merge', $cat_items2);
                    $classifications[] = $cat_items2;
                }
            }
        }

        return $classifications;
    }

    public function get_all_cova_products_paginated()
    {    
        $page = App::get_sync_transient_data('category_mapping_current_index_page', 1);

        if ($page === 1) {
            Cova_Data_Manager::store_data('cova-all-products', []); // always clear data on first load to get the latest result.
        }

        $saved_data = Cova_Data_Manager::get_stored_data('cova-all-products');
        
        if ($saved_data !== false && !empty($saved_data)) {
            return $saved_data;
        }

        $all_items = $this->cova_api['catalog']->items();
        $grouped_items = [];

        foreach ($all_items as $key => $item) {
            $grouped_items[] = $item['CatalogItemId'];
        }

        $grouped_items = array_chunk($grouped_items, 50);

        array_unshift($grouped_items, "");
        unset($grouped_items[0]);

        Cova_Data_Manager::store_data('cova-all-products', $grouped_items);

        return $grouped_items;
    }

    public function get_product_ids_by_catalog_ids($catalog_ids)
    {
        global $wpdb;

        $catalog_ids = implode("','", $catalog_ids);
        $sql = "SELECT * FROM {$wpdb->prefix}postmeta WHERE meta_key='cova_catalog_id' && meta_value IN('$catalog_ids')";

        $result = $wpdb->get_results($sql);

        if (empty($result)) {
            return [];
        }

        $product_ids = [];

        foreach ($result as $key => $item) {
            $product_ids[$item->post_id] = $item->meta_value;
        }

        return $product_ids;
    }

    // public function is_online_menu_category_parent($parent_category, $sub_cat)
    // {
    //     $parent_category = dabber_sanitize_slug($parent_category);
    //     $sub_cat = dabber_sanitize_slug($sub_cat);

    //     return ($parent_category === $sub_cat);
    // }

    // public function get_plain_categories_array()
    // {
    //     $categories = explode(' - ', $this->get_categories());
    //     $last_slug = '';
    //     $new_category_struct = [];

    //     if (!empty($categories)) {
    //         $slug = [];
    //         foreach ($categories as $category) 
    //         {
    //             $item_slug = dabber_sanitize_slug($category);
    //             $slug[] = $item_slug;
    //             $slug_key = implode('-', $slug);

    //             $new_category_struct[$slug_key] = [
    //                 'slug' => $item_slug,
    //                 'name' => sanitize_text_field($category),
    //                 'parent_slug' => $last_slug
    //             ];

    //             $last_slug = $slug_key;
    //         }
    //     }    

    //     return $new_category_struct;    
    // }

    public function create()
    {
        $this->update_product_category(
            [
            'product_id' => $this->get_product_id(),
            'catalog_id' => $this->get_product_catalog_id(),
            'categories' => $this->get_categories()
            ]
        );
        // $new_category_struct = $this->get_plain_categories_array();

        // foreach ($new_category_struct as $item_slug => $category) {
        //     $term = get_term_by('slug', $item_slug, 'product_cat');            

        //     if (isset($term->term_id)) { 
        //         wp_set_object_terms($this->product_id, $term->term_id, 'product_cat', true);
        //         continue; 
        //     }

        //     $parent_id = 0;
        //     $new_cat_id = false;

        //     if ($item_slug !== $category['slug']) {
        //         $parent = get_term_by('slug', $category['parent_slug'], 'product_cat');

        //         if (isset($parent->term_id)) {
        //             $parent_id = $parent->term_id;
        //         }
        //     }
            
        //     $new_cat = wp_insert_term($category['name'], 'product_cat', [
        //         'parent' => $parent_id,
        //         'slug' => $item_slug
        //     ]);

        //     if ( ! is_wp_error( $new_cat ) ){
        //         $new_cat_id = $new_cat['term_id'];
        //     }

        //     if ($new_cat_id !== false) {
        //         wp_set_object_terms($this->product_id, $new_cat_id, 'product_cat', true);
        //     }                
        // }        
    }
}

$cova_category = new Cova_Product_Category();
$cova_category->run();
