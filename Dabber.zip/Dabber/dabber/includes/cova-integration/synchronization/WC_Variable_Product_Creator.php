<?php

namespace Cova_Integration;

class WC_Variable_Product_Creator
{
    public $data;
    public $api;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    /**
     * Check and remove if the current variation to be imported has a
     * sibling variation that is set as simple product.
     */
    public function remove_simple_variations()
    {
        $products = new \WP_Query(
            [
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_query' => [
            'relation' => 'AND',
            [
            'key' => 'cova_slug',
            'value' => cova_truncate_slug($this->data['Id']) .'-',
            'compare' => 'LIKE'
            ]
            ]
            ]
        );

        if (empty($products->posts)) {
            return;
        }

        foreach ($products->posts as $key => $post) {
            wp_delete_post($post->ID, true);
        }
    }

    public function create()
    {
        $this->remove_simple_variations();

        $parent_id = $this->get_wc_parent_product();

        do_action('dabber_sync_variable_before_variable_create', $this->data, $parent_id);

        if ($parent_id === false) {
            $parent_id = $this->create_wc_parent_product();
        }

        do_action('dabber_sync_variable_product_after_create', $this->data, $parent_id);

        $is_create_variation = apply_filters('dabber_sync_variable_is_create_variation', true, $parent_id);
        $imported_products = [];

        if ($is_create_variation === true) {
            $is_synced = $this->api['catalog']->is_product_synced($this->data['catalog_id']);

            if ($is_synced === false) {
                $imported_products[] = $this->create_variation_product($parent_id);
            }
        }

        return apply_filters('dabber_imported_products_details', $imported_products);
    }

    public function create_variation_product($parent_id)
    {
        $variation_creator = new WC_Variation_Product_Creator($this->api);

        $this->data['parent_id'] = $parent_id;

        $variation_creator->set_data($this->data);
        $variation_creator->set_cova_global_data($this->get_cova_global_data());

        //@test
        $variation = $variation_creator->create();

        return $variation;
    }

    public function get_wc_parent_product()
    {
        $product = new \WP_Query(
            [
            'post_type' => 'product',
            'post_status' => 'any',
            'posts_per_page' => 1,
            'meta_query' => [
            'relation' => 'AND',
            [
            'key' => 'cova_slug',
            'value' => $this->api['catalog']->truncate_slug($this->data['Id']),
            'compare' => '='
            ]
            ]
            ]
        );

        if (!isset($product->posts[0])) {
            return false;
        }

        return $product->posts[0]->ID;
    }

    public function create_wc_parent_product()
    {
        $details_manager = new Variable_Product_Details_Manager($this->api);
        $details_manager->set_additional_data(
            apply_filters(
                'dabber_sync_variable_product_additional_data', [
                'product_type'  => $this->data['product_type'],
                'catalog_id'    => $this->data['catalog_id'],
                'cova_data'     => $this->data
                ]
            )
        );

        $details_manager->set_slug_id($this->api['catalog']->truncate_slug($this->data['Id']));
        $details_manager->set_cova_global_data($this->get_cova_global_data());
        $details_manager->generate_cova_details();

        $details = $details_manager->get_wc_product_details();

        $product = new \WC_Product_Variable();
        $details['product'] = $product;

        $update_product = new WC_Variable_Product_Updater();
        $update_product->set_data($details);

        //@test
        $updated_product = $update_product->update();

        return $updated_product;
    }
}
