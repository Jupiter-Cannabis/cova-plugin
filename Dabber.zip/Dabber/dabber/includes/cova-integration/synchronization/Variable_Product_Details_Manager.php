<?php

namespace Cova_Integration;

class Variable_Product_Details_Manager
{
    public $api;
    public $data;
    public $slug_id;
    public $additional_data = [];
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;    
    }

    public function set_slug_id($slug_id)
    {
        $this->slug_id = $slug_id;
    }

    public function set_additional_data($additional_data)
    {
        $this->additional_data = $additional_data;
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function get_slug_id()
    {
        return $this->slug_id;
    }    

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    public function generate_cova_details()
    {
        $this->data = $this->api['catalog']->product_manager($this->get_slug_id());
        $this->data = array_merge($this->data, $this->additional_data);

        $this->generate_general_details();
        $this->generate_variation_details();
    }

    public function generate_variation_details()
    {
        $variation_catalog_ids = [];

        foreach ($this->cova_global_data['catalog'][$this->get_cova_slug()] as $key => $item) {
            $variation_catalog_ids[] = $item['CatalogItemId'];
        }

        $variations = $this->api['catalog']->bulk(
            [
            'CatalogItemIds' => $variation_catalog_ids
            ]
        );

        $this->variations = [];

        foreach ($variations['CatalogItems'] as $catalog_id => $data) {
            $details_manager = new Variation_Product_Details_Manager($this->api);
            $details_manager->set_data($data);
            $details_manager->generate_product_details();

            $this->variations[$catalog_id] = $details_manager;
        }
    }

    public function generate_general_details()
    {
        foreach ($this->data['general'] as $key => $detail) {
            switch ($detail['displayName']) {
            case 'Product Name':
                $this->data['title'] = $detail['value'];
                break;
            case 'Short Description':
                $this->data['short_description'] = $detail['value'];
                break;
            case 'Long Description':
                   $this->data['long_description'] = $detail['value'];
                break;
            default:
                break;
            }
        }
    }

    public function get_title()
    {
        return $this->data['title'];
    }

    public function get_cova_slug()
    {
        return $this->get_slug_id();
    }

    public function get_sku()
    {
        return $this->get_slug_id();
    }

    public function get_short_description()
    {
        return $this->data['short_description'];
    }

    public function get_long_description()
    {
        return $this->data['long_description'];
    }

    public function get_date_added()
    {
        $dates = [];

        if (!isset($this->cova_global_data['catalog'][$this->get_slug_id()])) {
            return current_time('Y-m-d H:i:s');
        }

        foreach ($this->cova_global_data['catalog'][$this->get_slug_id()] as $key => $value) {
            $dates[] = strtotime($value['DateAddedUtc']);
        }

        $latest_date = max($dates);
        $date_added  = date('Y-m-d H:i:s', $latest_date);
        $currentDate = strtotime(date('Y-m-d'));

        if (strtotime($date_added) > $currentDate) {
            return current_time('Y-m-d H:i:s');
        }

        return $date_added;
    }

    public function get_locations_total_stock()
    {
        $stocks = [];

        if (!isset($this->cova_global_data['catalog'][$this->get_slug_id()])) {
            return [];
        }

        foreach ($this->cova_global_data['inventory'] as $location_id => $inventory_items) {
            foreach ($this->cova_global_data['catalog'][$this->get_slug_id()] as $key => $catalog_item) {
                $catalog_id = $catalog_item['CatalogItemId'];
                if (isset($inventory_items[$catalog_id])) {
                    $stocks[$location_id][] = $inventory_items[$catalog_id]['Quantity'];
                }                
            }
        }

        $default_location_stocks = [];

        foreach ($this->cova_global_data['locations'] as $loc_id => $loc_data) {
            $default_location_stocks[$loc_id] = 0;
        }

        $location_stocks = [];

        foreach ($stocks as $location_id => $items) {
            $location_stocks[$location_id] = array_sum($items);
        }

        $location_stocks = array_replace($default_location_stocks, $location_stocks);

        return [
        'total_stock' => array_sum($location_stocks),
        'location_stocks' => $location_stocks
        ];
    }

    public function get_featured_image()
    {
        if (!isset($this->data['heroShot'])) {
            return false;
        }

        if (!$this->data['heroShot']) {
            return false;
        }

        $cova_image = cova_get_image($this->data['heroShot'], $this->get_title());
        //        $cova_image['full']['cova_url'] = $cova_image['full']['url'];
        //        $img_id = cova_upload_image($cova_image['full']);

        return $cova_image;
    }

    public function get_variations()
    {
        $variation_names = [];

        foreach ($this->data['variations'] as $key => $item) {
            $variation_names[] = $item['name'];
        }

        return $variation_names;
    }

    public function get_category()
    {
        $category = $this->data['classification']['name'];

        if ($category === '') {
            return false;
        }

        return $category;
    }

    public function get_categories()
    {
        $categories = [];

        foreach ($this->variations as $catalog_id => $item) {
            $categories[$catalog_id] = $item->get_categories();
        }

        return $categories;
    }

    public function get_brands()
    {
        $brands = [];

        foreach ($this->variations as $catalog_id => $item) {
            $brands[] = $item->get_brand();
        }

        $brands = array_unique($brands);

        return $brands;
    }

    public function get_wc_product_details()
    {
        $details['product_type'] = $this->data['product_type'];
        $details['catalog_id']   = $this->data['catalog_id'];
        $details['cova_data']    = $this->data['cova_data'];

        $details['sku'] = $this->get_sku();
        $details['cova_slug'] = $this->get_cova_slug();
        $details['get_slug'] = sanitize_title_with_dashes($this->get_title());

        $details['title'] = $this->get_title();
        $details['short_description'] = $this->get_short_description();
        $details['long_description'] = $this->get_long_description();

        $details['date_added'] = $this->get_date_added();
        $details['stocks'] = $this->get_locations_total_stock();

        $details['featured_image'] = $this->get_featured_image();
        $details['attributes'] = [
        'Brand' => $this->get_variations()
        ];

        $details['categories'] = $this->get_categories();
        $details['brands'] = $this->get_brands();

        return apply_filters('dabber_sync_variable_product_details', $details, $this);
    }
}
