<?php

namespace Cova_Integration;

class WC_Tiered_Pricing_Product_Creator
{
    public $data;
    public $api;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    public function create()
    {
        $product = dabber_get_base_bulk_product($this->data['catalog_id']);

        if ($product && $this->data['is_base_bulk'] === true) {
            return false;
        }

        $details_manager = new Simple_Product_Details_Manager($this->api);
        $this->data['is_bulk_product'] = true;

        $details_manager->set_data($this->data);
        $details_manager->set_cova_global_data($this->get_cova_global_data());

        $details = $details_manager->get_wc_product_details();

        $details['wc_product'] = new \WC_Product_Simple();

        $update_product = new WC_Simple_Product_Updater();
        $update_product->set_data($details);

        $product = $update_product->update();

        return $product;
    }
}
