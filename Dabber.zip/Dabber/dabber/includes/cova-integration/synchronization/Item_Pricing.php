<?php

namespace Cova_Integration\Sync;

use CovaAPI\ItemPricing as API_ItemPricing;

class Item_Pricing
{
    public $pricing;

    public function run()
    {
        $this->pricing = new API_ItemPricing();
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->pricing, $name], $param);

        return json_decode($data, true);
    }    

    public function get_location_pricing($location_id)
    {
        // $final_products = [];
        $product_handler = [];

        $pdata = $this->byLocation($location_id);
        
        foreach ($pdata as $key => $item) {
            $product_handler[$location_id][$item['CatalogItemId']][$item['Id']] = [
            'RegularPrice'  => $item['RegularPrice'],
            'OverridePrice' => $item['OverridePrice'],
            'PricingTierId' => $item['PricingTierId'],
            'LastModifiedDateUtc' => $item['LastModifiedDateUtc']
            ];
            // if (isset($product_handler[$location_id][$item['CatalogItemId']])) {
            //     $product_handler[$location_id][$item['CatalogItemId']][$item['Id']] = $price_data;
            // } else {
            //     $product_handler[$location_id][$item['CatalogItemId']] = $price_data;
            // }
        }

        // d($product_handler);
        // die();
        // foreach ($product_handler[$location_id] as $catalog_id => $prices) {
        //     krsort($prices);
        //     $final_products[$location_id][$catalog_id] = $prices[array_key_first($prices)];
        // }

        return $product_handler;
    }

    public function get_price_tiers()
    {
        $tiers = $this->pricing_tiers();
        $price_tiers = [];

        if (!is_array($tiers)) {
            return [];
        }

        if (empty($tiers)) {
            return [];
        }

        foreach ($tiers as $key => $value) {
            $price_tiers[$value['Id']] = $value;
        }

        return $price_tiers;
    }

    public function get_all_pricing_by_locations($locations)
    {
        $final_products = [];

        foreach ($locations as $i => $location) {
            $product_handler = [];
            $pdata = $this->byLocation($location['Id']);
            foreach ($pdata as $key => $item) {
                $modified_date_key = strtotime($item['LastModifiedDateUtc']);
                $product_handler[$location['Id']][$item['CatalogItemId']][$modified_date_key] = [
                 'RegularPrice'  => $item['RegularPrice'],
                 'OverridePrice' => $item['OverridePrice'],
                 'PricingTierId' => $item['PricingTierId'],
                 'LastModifiedDateUtc' => $item['LastModifiedDateUtc']
                ];
            }

            foreach ($product_handler[$location['Id']] as $catalog_id => $prices) {
                 krsort($prices);
                 $final_products[$location['Id']][$catalog_id] = $prices[array_key_first($prices)];
            }
        }
         
        return $final_products;
    }

    //    public function get_product_prices($catalog_id, $locations_data, $pricing_source = 'import')
    //    {
    //        $prices = [];
    //        $pricing = [];
    //        $location_ids = [];
    //        $default_pricing = 0;
    //
    //        foreach ($locations_data as $location) {
    //
    //            $pricing_file = 'pricing-'. $location['Id'] .'-sync';
    //
    //            if ($pricing_source === 'update') {
    //                $pricing_file = 'update-products-sync/pricing-'. $location['Id'];
    //            }
    //
    //            $pricing_data = Sync::get_stored_data($pricing_file);
    //
    //            if ($pricing_data !== false) {
    //                $pricing[$location['Id']] = [
    //                    'regular' => $pricing_data[$catalog_id]['RegularPrice'],
    //                    'sale'       => $pricing_data[$catalog_id]['OverridePrice']
    //                ];
    //
    //                $prices[] = $pricing_data[$catalog_id]['RegularPrice'];
    //            }
    //        }
    //
    //        if (!empty($prices)) {
    //            $default_pricing = max($prices);
    //        }
    //
    //        return [
    //            'default_pricing' => $default_pricing,
    //            'location_pricing' => $pricing
    //        ];
    //    }
}
