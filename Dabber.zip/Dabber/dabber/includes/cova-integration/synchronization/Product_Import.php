<?php

namespace Cova_Integration;

/**
 * @todo for import with existing SKU, add a checker if the product is imported completely/properly.
 * @todo add an import complete status on product import.
 * @todo prioritize import products with stock and price.
 */
class Product_Import
{
    private $api;
    public $import_batch_num = 1;
    public $cova_global_data;
    public $products_to_import;
    public $products_to_remove;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {
        add_filter('dabber_sync_variable_product_attribute_term', [$this, 'set_default_product_attribute_term'], 10, 2);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_cova_import_sync_import_products', [$this, 'ajax_run_sync']);
        add_action('init', [$this, 'run_manual_sync']);
        add_action('cova_import_products', [$this, 'import_products_init']);
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {        
            wp_enqueue_script('cova-import-products-sync', COVA_INTEGRATION_URI .'/assets/js/import-products.js', [], null, true);
        }
    }    

    public function run_manual_sync()
    {
        if (!isset($_GET['_dabber_run_import_sync'])) {
            return;
        }

        do_action('cova_import_products', 'manual');

        die();
    }

    public function ajax_run_sync()
    {
        dabber_set_sync_on();

        do_action('cova_import_products');

        update_option('dabber_disable_all_cron', 'yes');

        if (!empty($this->imported_products)) {            

            wp_send_json_success(
                [
                'status' => 'ok',
                'message' => 'Successfully imported '. count($this->imported_products) .' product(s)',
                'data' => $this->imported_products,                
                'total_import' => $this->total_import_num,
                'total_synced' => count($this->imported_products),
                'message_type' => 'output'
                ], 200
            );
        }

        update_option('dabber_disable_all_cron', 'no');

        wp_send_json_success(
            [
            'status' => 'complete',
            'message' => 'No more products to import',
            'message_type' => 'success'
            ], 200
        );
    }

    public function import_products_init($sync_type)
    {
        include_once ABSPATH .'wp-load.php';
        
        $iterationId = md5(microtime());
        if ($sync_type === 'manual') {
            dabber_cron_logger('EVENT - import products');
        }
        else
        {
            $start = microtime(true);
            dabber_cron_logger2('EVENT - import products', $iterationId);
        }
        
        try
        {
            $this->generate_cova_global_data();
            $this->get_products_to_import();

            if (isset($this->products_to_import) && !empty($this->products_to_import)) {
                $import_products = $this->api['catalog']->bulk(
                    [
                    'CatalogItemIds' => $this->products_to_import
                    ]
                );

                if (isset($import_products['CatalogItems']) && !empty($import_products['CatalogItems'])) {
                    $this->import_products($import_products['CatalogItems']);
                }    
            }

            if (isset($this->products_to_remove) && !empty($this->products_to_remove)) {
                $this->remove_products($this->products_to_remove);
            }

            if ($sync_type === 'manual') {
                d(['imported_products' => $this->imported_products]);
            }
        }
        catch(\Exception $e)
        {
            if (!($sync_type === 'manual')) {
                $duration = microtime(true) - $start;
                dabber_cron_logger2('EVENT - import products failed. ' . $e->getMessage(), $iterationId, $duration, false);
            }
            
            throw $e;
        }

        if (!($sync_type === 'manual')) {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - import products', $iterationId, $duration);
        }
    }

    public function generate_cova_global_data()
    {
        $catalog_data   = Cova_Data_Manager::get_global_data('catalog');
        $inventory_data = Cova_Data_Manager::get_global_data('inventory');
        $locations_data = Cova_Data_Manager::get_global_data('locations');

        $this->cova_global_data = [
        'catalog'   => $catalog_data,
        'inventory' => $inventory_data,
        'locations' => $locations_data
        ];

        $prices = [];

        foreach ($this->cova_global_data['locations'] as $location_id => $location) {
            $price_data = Cova_Data_Manager::get_global_data('pricing-'. $location_id);
            $prices[$location_id] = $price_data[$location_id];
        }

        $this->cova_global_data['pricing'] = $prices;
    }

    public function import_products($cova_products)
    {
        $this->imported_products = [];

        do_action('dabber_before_product_import_process', $cova_products);

        foreach ($cova_products as $catalog_id => $cova_product) {

            $cova_product['catalog_id'] = $catalog_id;
            $product_type = apply_filters('dabber_import_product_type_identifier', $this->get_cova_product_type($cova_product['Id']), $cova_product);
            $cova_product['product_type'] = $product_type;

            if ($product_type === 'variable' || $product_type === 'tiered_variable') {
                $variable_product = new WC_Variable_Product_Creator($this->api);
                $variable_product->set_data($cova_product);
                $variable_product->set_cova_global_data($this->cova_global_data);
                $product = $variable_product->create();
                $this->imported_products[] = $product;

            } else {
                $simple_product = new WC_Simple_Product_Creator($this->api);
                $simple_product->set_data($cova_product);
                $simple_product->set_cova_global_data($this->cova_global_data);
                $product = $simple_product->create();
                $this->imported_products[] = $product;
            }
        }

        error_log(
            print_r(
                [
                'import_products' => $this->imported_products
                ], true
            )
        );

        do_action('dabber_after_product_import_process', $this->imported_products);
    }

    public function remove_products($catalog_ids)
    {

    }

    public function get_products_to_import()
    {        
        $cova_ids = $this->get_all_cova_catalog_ids();
        $wc_ids = $this->get_all_imported_products();

        $to_import = array_diff($cova_ids, $wc_ids);
        $to_import = apply_filters('dabber_import_process_catalog_ids', array_values($to_import));

        $this->total_import_num = count($to_import);
        $this->products_to_import = array_slice($to_import, 0, $this->import_batch_num);

        $to_remove = array_diff($wc_ids, $cova_ids);

        $this->total_remove_num = count($to_remove);
        $this->products_to_remove = array_slice($to_remove, 0, $this->import_batch_num);
    }

    public function get_all_cova_catalog_ids()
    {
        $cova_catalog_ids = [];
        //        $catalog_with_stock = $this->get_catalog_ids_with_stock();
        $catalog_with_price = $this->get_catalog_ids_with_price();  // Only import products with correct price.
        //        $import_catalog_ids = array_intersect($catalog_with_stock, $catalog_with_price);
        //        $import_catalog_ids = array_filter($import_catalog_ids);

        foreach ($this->cova_global_data['catalog'] as $slug => $items) {
            foreach ($items as $key => $data) {
                if ($data['LifeCycle'] !== 'Active' || !in_array($data['CatalogItemId'], $catalog_with_price)) {
                    continue;
                }
                $cova_catalog_ids[] = $data['CatalogItemId'];
            }
        }

        return $cova_catalog_ids;
    }

    public function get_catalog_ids_with_price()
    {
        $catalog_ids = [];

        foreach ($this->cova_global_data['pricing'] as $location_id => $items) {
            foreach ($items as $catalog_id => $data) {
                $info = array_values($data);
                if (!$info[0]['RegularPrice'] || in_array($catalog_id, $catalog_ids)) {
                    continue;
                }
                $catalog_ids[] = $catalog_id;
            }
        }

        return $catalog_ids;
    }

    public function get_catalog_ids_with_stock()
    {
        $catalog_ids = [];

        foreach ($this->cova_global_data['inventory'] as $items) {
            foreach ($items as $catalog_id => $data) {
                if (!in_array($catalog_id, $catalog_ids) && $data['Quantity'] > 0) {
                    $catalog_ids[] = $catalog_id;
                }
            }
        }

        return $catalog_ids;
    }

    public function get_all_imported_products()
    {
        global $wpdb;

        $sql = "SELECT meta.meta_value
				FROM {$wpdb->prefix}postmeta as meta
				LEFT JOIN {$wpdb->prefix}posts as products
				ON products.ID = meta.post_id
				WHERE meta.meta_key = 'cova_catalog_id'
				AND (
					products.post_status = 'publish' OR
					products.post_status = 'private' OR
					products.post_status = 'draft'
				)";

        $catalog_ids = $wpdb->get_results($sql);

        if (empty($catalog_ids)) {
            return [];
        }

        $ids = [];
        foreach ($catalog_ids as $key => $item) {
            $ids[] = $item->meta_value;
        }

        return $ids;
    }

    public function get_cova_product_type($slug)
    {
        // breakdown all variable products to simple
        $is_breakdown_variables = apply_filters('dabber_breakdown_variable_products', get_option('cova_sync_settings_breakdown_all'));
        $is_breakdown_variables = (!$is_breakdown_variables)? 'yes' : $is_breakdown_variables;

        if ($is_breakdown_variables === 'yes') {
            return 'simple';
        }

        $truncated_slug = cova_truncate_slug($slug);
        $catalog = $this->cova_global_data['catalog'][$truncated_slug];

        if (count($catalog) > 1) {
            return 'variable';
        }

        return 'simple';
    }

    public function set_default_product_attribute_term($term, $data)
    {
        return 'brand';
    }
}
