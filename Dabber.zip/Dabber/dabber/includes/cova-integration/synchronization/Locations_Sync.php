<?php

namespace Cova_Integration;

class Locations_Sync
{
    private $api = [];
    public $wc_locations;
    public $cova_locations;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);

        add_action('wp_ajax_cova_location_sync_initialize_sync_locations', [$this, 'ajax_initialize_sync_locations']);
        // add_action('wp_ajax_cova_location_sync_fetch_cova_locations', [$this, 'ajax_fetch_cova_locations']);
        // add_action('wp_ajax_cova_location_sync_clean_unused_locations', [$this, 'ajax_clean_unused_locations']);
        // add_action('wp_ajax_cova_location_sync_sync_locations', [$this, 'ajax_sync_locations']);

        add_action('init', [$this, 'run_sync']);
        add_action('cova_sync_locations', [$this, 'sync_locations']);
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {        
            wp_enqueue_script('cova-locations-sync', COVA_INTEGRATION_URI .'/assets/js/locations-sync.js', [], null, true);
        }
    }

    public function run_sync()
    {
        if (!isset($_POST['cova-sync-location'])) {
            return;
        }

        do_action('cova_sync_locations');
    }

    public function sync_locations()
    {
        global $cova_updated_locations;

        $this->generate_cova_locations();
        $this->generate_wc_locations();
        
        $cova_updated_locations = $this->import_locations();

        //This is a bit of a hack. If product import is inturrupted or accidently started and not finished, the system will be in a state
        //whereby cron's wont work. We can use the location import as an easter egg in that if we know a location sync has been run, then
        //currently a product import is not running. Therefore, it is safe to turn this to "no".
        //We may choose to keep this, or, create a UI element in the plugin to reset it.
        //update_option('dabber_disable_all_cron', 'no');

        return $cova_updated_locations;
    }

    public function generate_cova_locations()
    {
        $this->cova_locations = $this->api['locations']->get_active_locations();        
    }

    public function generate_wc_locations()
    {
        $this->wc_locations = cova_get_all_wc_locations();
    }

    public function import_locations()
    {
        $this->clean_locations();

        $updated_locations = [];

        foreach ($this->cova_locations as $location) {
            $updated_locations[] = $this->update_location($location);            
        }

        return $updated_locations;
    }

    public function clean_locations()
    {
        $cova_location_slugs = [];

        foreach ($this->cova_locations as $cova_location) {
            $cova_location_slugs[] = $cova_location['slug'];
        }

        foreach ($this->wc_locations as $wc_location) {
            if (!in_array($wc_location['slug'], $cova_location_slugs)) {
                wp_delete_term($wc_location['term_id'], 'locations');
            }
        }
    }

    public function update_location($location)
    {
        $location_slug = $location['slug'];
        $location_term = get_term_by('slug', $location_slug, 'locations');


        if (!$location_term) {
            $location_term = (array) wp_insert_term(
                $location['name'], 'locations', [
                'slug' => $location_slug
                ]
            );    

            $term_id = $location_term['term_id'];
        } else {
            $term_id = $location_term->term_id;
        }
        
        $address    = $location['address']['AddressLine1'] .' '. $location['address']['AddressLine2'];
        $city       = $location['address']['City'];
        $state      = $location['address']['StateName'];
        $zip        = $location['address']['Zip'];
        $country    = $location['address']['CountryName'];
        $phone         = '';

        if(isset($location['phone']) && count($location['phone']) > 0) {
            $phone = $location['phone'][0]['Number'];
        }
        
        if(!isset($location['name'])) {
            return;
        }

        return cova_update_wc_location_meta(
            $term_id, [
            'phone'      => $phone,
            'address' => $address,
            'street'  => $location['name'],
            'city'      => $city,
            'state'      => $state,
            'postal'  => $zip,
            'country' => $country,
            'entity_id' => 'locations_' .$term_id,
            'location_id' => $location['id']
            ]
        );        
    }

    public function ajax_initialize_sync_locations()
    {
        global $cova_updated_locations;

        do_action('cova_sync_locations');

        wp_send_json_success(
            [
            //            'data' => $cova_updated_locations,
            'message'     => 'Done syncing cova locations.',
            'message_type' => 'success'
            ], 200
        );
    }

    // public function ajax_fetch_cova_locations()
    // {
    //     $locations = $this->api['locations']->get_active_locations();

    //     wp_send_json_success([
    //         'data' => $locations,
    //         'message'    => 'Found '. count($locations) .' active Cova locations.'
    //     ], 200);
    // }

    // public function ajax_clean_unused_locations()
    // {
    //     $unused_locations = [];
    //     $cova_location_slugs = [];

    //     $wc_locations = (is_array($_POST['params']['wc_locations']) && !empty($_POST['params']['wc_locations']))? $_POST['params']['wc_locations'] : [];
    //     $cova_locations = (is_array($_POST['params']['cova_locations']) && !empty($_POST['params']['cova_locations']))? $_POST['params']['cova_locations'] : [];

    //     foreach ($cova_locations as $cova_location) {
    //         $cova_location_slugs[] = $cova_location['slug'];
    //     }

    //     foreach ($wc_locations as $wc_location) {
    //         if (!in_array($wc_location['slug'], $cova_location_slugs)) {
    //             $unused_locations[] = $wc_location;
    //             wp_delete_term($wc_location['term_id'], 'locations');
    //         }
    //     }        

    //     wp_send_json_success([
    //         'data' => $unused_locations,
    //         'message' => 'Removed '. count($unused_locations) .' WC location(s).'
    //     ], 200);
    // }

    // public function ajax_sync_locations()
    // {
    //     $cova_locations = (is_array($_POST['params']['cova_locations']) && !empty($_POST['params']['cova_locations']))? $_POST['params']['cova_locations'] : [];

    //     foreach ($cova_locations as $location) {
    //         $this->sync_wc_location($location);            
    //     }

    //     wp_send_json_success([
    //         'data' => $cova_locations,
    //         'message' => 'Successfully synced Cova locations.',
    //         'message_type' => 'success'
    //     ], 200);
    // }



}
