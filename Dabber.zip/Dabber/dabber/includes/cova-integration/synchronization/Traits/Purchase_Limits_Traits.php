<?php

namespace Cova_Integration\Sync\Traits;

trait Purchase_Limits_Traits
{
    public $overLimitMessage = "Sorry! You've reached the purchase limit for cannabis due to federal regulations.";

    public function getOverLimitsMessage() {
        return $this->overLimitMessage;
    }
}
