<?php

namespace Cova_Integration;

class Attribute_Stock_Creator
{
    public $data;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    // public function create($product_id, $attributes, $stock_qty)
    // {
    //     $product = wc_get_product($product_id);

    //     $post_title   = str_replace(' - 1g', '', $product->get_name()) .' - Weight';
    //     $post_name    = get_post_meta($product_id, 'cova_catalog_id', true);
    //     $attribute_id = $this->is_attribute_stock_exists('attr-stock-'. $post_name);

    //     if ($attribute_id === false) {

    //         $attribute_id = wp_insert_post([
    //             'post_title'  => $post_title,
    //             'post_status' => 'publish',
    //             'post_name'   => $post_name,
    //             'post_type'   => 'mewz_attribute_stock'
    //         ]);

    //         if (is_wp_error($attribute_id)) {
    //             return false;
    //         }
            
    //         update_post_meta($attribute_id, '_quantity', $stock_qty);
    //         update_post_meta($attribute_id, '_match_all', 1);
    //         update_post_meta($attribute_id, '_limit_products', 1);
    //         update_post_meta($attribute_id, 'attr_stock_catalog_id', 'attr-stock-'. $post_name);
    //     }

    //     $connected_product_ids = $this->get_bulk_product_ids($this->data['catalog_id']);
    //     update_post_meta($attribute_id, '_products', $connected_product_ids);

    //     $attr_rows = [];

    //     foreach ($connected_product_ids as $key => $prdct_id) {

    //         $product_item = wc_get_product($prdct_id);
    //         $weight_attr = get_term_by('slug', sanitize_title_with_dashes($product_item->get_weight() . 'g'), 'pa_weight');

    //         $attr_rows[] = [
    //             'rows' => [
    //                 [
    //                     'attribute' => wc_attribute_taxonomy_id_by_name('pa_weight'),
    //                     'term' => $weight_attr->term_id
    //                 ]
    //             ],
    //             'multiplier' => $product_item->get_weight()
    //         ];
    //     }

    //     \Mewz\WCAS\Util\Matches::save_sets($attribute_id, $attr_rows);
    // }

    // public function is_attribute_stock_exists($catalog_id)
    // {
    //     $args_posts = [
    //         'post_type'      => 'mewz_attribute_stock',
    //         'posts_per_page' => 1,
    //         'meta_query' => [
    //             'relation' => 'AND',
    //             [
    //                 'key' => 'attr_stock_catalog_id',
    //                 'value' => $catalog_id,
    //                 'compare' => '='
    //             ]
    //         ]
    //     ];

    //     $loop_posts = new \WP_Query( $args_posts );

    //     if ( ! $loop_posts->have_posts() ) {
    //         return false;
    //     } else {
    //         $loop_posts->the_post();
    //         return $loop_posts->post->ID;
    //     }
    // }    
}
