<?php

namespace Cova_Integration;

class WC_Variation_Product_Creator
{
    public $data;
    public $api;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    public function is_variation_exists($variation_slug)
    {
        return false;
    }

    public function create_variation_post($parent)
    {
        $variation_post = [
            'post_title'  => $parent->get_name(),
            'post_name'   => 'product-'. $parent->get_id() .'-variation',
            'post_status' => 'publish',
            'post_parent' => $parent->get_id(),
            'post_type'   => 'product_variation',
            'guid'        => $parent->get_permalink()
        ];

        return wp_insert_post($variation_post);
    }

    public function create()
    {
        $details_manager = new Variation_Product_Details_Manager($this->api);
        $details_manager->set_data($this->data);
        $details_manager->set_cova_global_data($this->get_cova_global_data());

        $details = $details_manager->get_wc_product_details();
        $parent = wc_get_product($this->data['parent_id']);
        $variation_id = $this->is_variation_exists('');

        if (!$variation_id) {
            $variation_id = $this->create_variation_post($parent);
        }

        // Get an instance of the WC_Product_Variation object
        $variation = new \WC_Product_Variation($variation_id);        

        $details['wc_product'] = $variation;
        $details['parent']  = $parent;

        $update_variation = new WC_Variation_Product_Updater();
        $update_variation->set_data($details);

        //@test
        $updated_variation = $update_variation->update();

        return $updated_variation;
    }

}
