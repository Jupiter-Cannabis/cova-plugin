<?php

namespace Cova_Integration;

class Sync_Scheduler
{
    public function run()
    {
        add_action('plugins_loaded', [$this, 'run_cron_jobs'], 110);
    }

    public function run_cron_jobs()
    {
        add_filter('cron_schedules', [$this, 'add_cron_schedules']);
        add_action('wp', [$this, 'add_scheduled_event']);

        add_action('dabber_cron_update_catalog_global_data',   [$this, 'update_catalog_global_data_callback']);
        add_action('dabber_cron_update_inventory_global_data', [$this, 'update_inventory_global_data_callback']);

        add_action('dabber_cron_update_inventory_sync', [$this, 'update_inventory_sync_callback']);
        add_action('dabber_cron_update_product_sync',   [$this, 'update_product_sync_callback']);
        add_action('dabber_cron_import_products_sync',  [$this, 'import_products_sync_callback']);
        add_action('dabber_cron_update_pricing_sync',   [$this, 'update_pricing_sync_callback']);
    }

    public static function add_scheduled_event()
    {
        if (!wp_next_scheduled('dabber_cron_update_inventory_global_data')) {
            wp_schedule_event(time(), 'every_2_minutes', 'dabber_cron_update_inventory_global_data');
        }

        if (!wp_next_scheduled('dabber_cron_update_catalog_global_data')) {
            wp_schedule_event(time(), 'every_7_minutes', 'dabber_cron_update_catalog_global_data');
        }

        if (!wp_next_scheduled('dabber_cron_update_inventory_sync')) {
            wp_schedule_event(time(), 'every_munite', 'dabber_cron_update_inventory_sync');
        }

        if (!wp_next_scheduled('dabber_cron_update_pricing_sync')) {
            wp_schedule_event(time(), 'every_7_minutes', 'dabber_cron_update_pricing_sync');
        }

        if (!wp_next_scheduled('dabber_cron_update_product_sync')) {
            wp_schedule_event(time(), 'every_13_minutes', 'dabber_cron_update_product_sync');
        }
        
        if (!wp_next_scheduled('dabber_cron_import_products_sync')) {
            wp_schedule_event(time(), 'every_15_minutes', 'dabber_cron_import_products_sync');
        }
    }
    
    public function add_cron_schedules($schedules)
    {
        $schedules['every_munite'] = [
            'interval' => 60,
            'display'  => __('Every minute', 'dabber'),
        ];

        $schedules['every_2_minutes'] = [
            'interval' => 120,
            'display'  => __('Every 2 minutes', 'dabber'),
        ];        

        $schedules['every_3_minutes'] = [
            'interval' => 180,
            'display'  => __('Every 3 minutes', 'dabber'),
        ];

        $schedules['every_5_minutes'] = [
            'interval' => 300,
            'display'  => __('Every 5 minutes', 'dabber'),
        ];

        $schedules['every_7_minutes'] = [
            'interval' => 420,
            'display'  => __('Every 7 minutes', 'dabber'),
        ];

        $schedules['every_9_minutes'] = [
            'interval' => 540,
            'display'  => __('Every 9 minutes', 'dabber'),
        ];

        $schedules['every_11_minutes'] = [
            'interval' => 660,
            'display'  => __('Every 11 minutes', 'dabber'),
        ];

        $schedules['every_13_minutes'] = [
            'interval' => 780,
            'display'  => __('Every 13 minutes', 'dabber'),
        ];

        $schedules['every_15_minutes'] = [
            'interval' => 900,
            'display'  => __('Every 15 minutes', 'dabber'),
        ];

        return $schedules;        
    }

    public function update_catalog_global_data_callback()
    {
        if (!$this->is_job_enabled('cova_global_data')) {
            return;
        }
        $iterationId = md5(microtime());
        $start = microtime(true);
        dabber_cron_logger2('EVENT - catalog global data', $iterationId);

        try
        {
            Cova_Data_Manager::store_catalog_data('catalog');
        }
        catch(\Exception $e)
        {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - catalog global data failed. ' . $e->getMessage(), $iterationId, $duration, false);
            throw $e;
        }
        
        $duration = microtime(true) - $start;
        dabber_cron_logger2('EVENT - catalog global data', $iterationId, $duration);
    }

    public function update_inventory_global_data_callback()
    {
        if (!$this->is_job_enabled('cova_global_data')) {
            return;
        }      
        $iterationId = md5(microtime());
        $start = microtime(true);
        dabber_cron_logger2('EVENT - inventory global data', $iterationId);

        try
        {
            Cova_Data_Manager::store_inventory_data('inventory');
        }
        catch(\Exception $e)
        {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - inventory global data failed. ' . $e->getMessage(), $iterationId, $duration, false);
            throw $e;
        }
        
        $duration = microtime(true) - $start;
        dabber_cron_logger2('EVENT - inventory global data', $iterationId, $duration);
    }

    public function update_inventory_sync_callback() 
    {
        if (!$this->is_job_enabled('cova_update_inventory')) {
            return;
        }

        do_action('cova_update_inventory');
    }

    public function update_product_sync_callback()
    {
        if (!$this->is_job_enabled('cova_update_products')) {
            return;
        }

        do_action('cova_update_products');
    }

    public function import_products_sync_callback()
    {
        if (!$this->is_job_enabled('cova_import_products')) {
            return;
        }

        do_action('cova_import_products');
    }

    public function update_pricing_sync_callback()
    {
        if (!$this->is_job_enabled('cova_update_pricing')) {
            return; 
        }

        do_action('cova_update_pricing');
    }

    public function is_job_enabled($job)
    {
        if (get_option('dabber_disable_all_cron') === 'yes') {
            return false;
        }

        $enabled_jobs = (array) get_option('dabber_enabled_crons');

        return array_key_exists($job, $enabled_jobs);
    }
}

$dabber_sync_scheduler = new Sync_Scheduler();
$dabber_sync_scheduler->run();
