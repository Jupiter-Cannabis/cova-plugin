<?php

namespace Cova_Integration;

class Product_Update_V2
{
    private $api;
    private $update_batch_limit = 5;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {
        add_action('cova_update_products_v2', [$this, 'initiate_update_products']);
    }

    public function initiate_update_products()
    {
        $iterationId = md5(microtime());
        $start = microtime(true);
        dabber_cron_logger2('EVENT - product updateV2', $iterationId);
        try
        {
            include_once ABSPATH .'wp-load.php';

            $wc_products = $this->get_products_to_update();
            //        $wc_products = [
            //            (object) [
            //                'product_id' => 211348,
            //                'catalog_id' => '1ad01ea9-12a3-4d0b-b44b-43dee304ff88'
            //            ]
            //        ];

            $catalog_ids = [];

            foreach ($wc_products as $item) {
                $catalog_ids[$item->product_id] = $item->catalog_id;
            }

            $cova_products = $this->api['catalog']->bulk(
                [
                'CatalogItemIds' => array_values($catalog_ids)
                ]
            );

            foreach ($wc_products as $product) {
                if (isset($cova_products['CatalogItems'][$product->catalog_id])) {
                    $this->update($product->product_id, $cova_products['CatalogItems'][$product->catalog_id]);
                }
            }
        }
        catch(\Exception $e)
        {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - product updateV2 failed. ' . $e->getMessage(), $iterationId, $duration, false);
            throw $e;
        }
        $duration = microtime(true) - $start;
        dabber_cron_logger2('EVENT - product updateV2', $iterationId, $duration);
    }

    public function update($wc_product_id, $cova_product)
    {
        $wc_product     = wc_get_product($wc_product_id);
        $product_type   = $wc_product->get_type();
        $global_data    = Cova_Data_Manager::generate_global_data();

        $cova_product['catalog_id'] = $wc_product->get_meta('cova_catalog_id');
        $details_manager = new Simple_Product_Details_Manager($this->api);
        $details_manager->set_data($cova_product);
        $details_manager->set_cova_global_data($global_data);

        $details = $details_manager->get_wc_product_details();

        $details['wc_product'] = $wc_product;

        // update product basic info like title, desc, attachments, specifications etc.
        $this->update_product_general_info($details);

        if ($product_type === 'variation') {
            // do update variations
        }

        if ($product_type === 'simple') {
            $is_bulk_product = get_post_meta($wc_product->get_id(), 'dabber_is_bulk_product', true);

            if ($is_bulk_product === true) {
                // update bulk products
            }
        }
    }

    public function update_product_general_info($details)
    {
        $updater = new WC_Simple_Product_Updater();
        $updater->set_data($details);

        $updater->update_images();
        $updater->update_categories();
        $updater->update_product();
        //        $updater->update_info([
        //            'images',
        //            'categories',
        ////            'title',
        ////            'date_created',
        ////            'sku',
        ////            'description',
        ////            'short_description',
        ////            'is_featured',
        ////            'backorders',
        ////            'catalog_visibility',
        ////            'publish_status',
        ////            'stock_status',
        ////            'manage_stock',
        ////            'stock_quantity',
        ////            'price',
        ////            'weight',
        ////            'metadata',
        ////            'brands',
        ////            'tags',
        ////            'field_mapping'
        //        ]);
    }

    public function get_products_to_update()
    {
        global $wpdb;

        $last_queried_item = (int) get_option('cova_product_update_last_queried_item');
        $wc_products = $wpdb->get_results(
            "
            SELECT DISTINCT meta.meta_value as catalog_id, product.ID as product_id
            FROM {$wpdb->prefix}posts as product
            LEFT JOIN {$wpdb->prefix}postmeta as meta
            ON product.ID = meta.post_id
            WHERE meta.meta_key = 'cova_catalog_id'
            AND meta.meta_value != ''
            AND product.post_status = 'publish'
            AND product.ID > {$last_queried_item}
            ORDER BY product.ID
            ASC
            LIMIT {$this->update_batch_limit}
        "
        );

        if (empty($wc_products)) {
            update_option('cova_product_update_last_queried_item', 0);
            return $this->get_products_to_update();
        }

        $last_queried_item = end($wc_products);
        update_option('cova_product_update_last_queried_item', $last_queried_item->product_id);

        return $wc_products;
    }
}
