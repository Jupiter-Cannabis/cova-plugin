<?php

namespace Cova_Integration;

class Simple_Product_Details_Manager
{
    public $api;
    public $data;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;    
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    public function get_title()
    {
        //        if ($this->is_bulk_product() === true) {
        //            $title = $this->data['Name'];
        //            $weight = $this->get_stock_weight();
        //
        //            return $title .' - '. $weight['value'] . $weight['unit'];
        //        }

        return $this->data['Name'];
    }

    public function get_slug()
    {
        return $this->data['Id'];
    }

    public function get_sku()
    {
        $grouped_sku = $this->api['catalog']->truncate_slug($this->get_slug());

        $sku = $this->get_slug();
    
        foreach ($this->cova_global_data['catalog'][$grouped_sku] as $key => $item) {
            if ($item['CatalogItemId'] === $this->data['catalog_id']) {
                $sku = $item['CatalogSku'];
                break;
            }
        }

        //        if ($this->is_bulk_product() === true) {
        //            $weight = $this->get_stock_weight();
        //            return $sku .'-'. sanitize_title_with_dashes($weight['value']);
        //        }

        return $sku;
    }

    public function get_short_description()
    {
        return $this->data['ShortDescription'];
    }

    public function get_long_description()
    {
        return $this->data['LongDescription'];
    }

    public function get_date_added()
    {
        $date = strtotime($this->data['DateAddedUtc']);
        $currentDate = strtotime(date('Y-m-d'));

        if ($date > $currentDate) {
            return current_time('Y-m-d H:i:s');
        }

        return date('Y-m-d H:i:s', $date);
    }
    
    public function get_lifecycle_status()
    {
        return strtolower($this->data['LifeCycle']);
    }

    public function get_weights()
    {
        // for new mexico
        if (isset($this->specifications['details']['retail-marijuana-product-type-new-mexico']['Value'])) {
            $retail_type = $this->specifications['details']['retail-marijuana-product-type-new-mexico']['Value'];

            if ($retail_type === 'Edible' && isset($this->specifications['details']['thc-content']['Value'])) {

                $value = $this->specifications['details']['thc-content']['Value'];
                $unit = $this->specifications['details']['thc-content']['Unit'];

                if ($unit === 'mg') {
                    $value = $value / 1000;
                }

                if ($value > 0) {
                    return [
                     'value' => $value,
                     'unit'  => $unit
                    ];
                }
            }    
        }
        //---

        if (isset($this->specifications['details']['equivalent-to']['Value'])) {

            $value = $this->specifications['details']['equivalent-to']['Value'];
            $unit = $this->specifications['details']['equivalent-to']['Unit'];

            if ($unit === 'mg') {
                $value = $value / 1000;
            }

            if ($value > 0) {
                return [
                 'value' => $value,
                 'unit'  => $unit
                ];
            }
        }

        if (isset($this->specifications['details']['net-weight']['Value'])) {

            $value = $this->specifications['details']['net-weight']['Value'];
            $unit = $this->specifications['details']['net-weight']['Unit'];

            if ($unit === 'mg') {
                $value = $value / 1000;
            }

            if ($value > 0) {
                return [
                 'value' => $value,
                 'unit'  => $unit
                ];
            }
        }

        return [
            'value' => 0,
            'unit'  => ''
        ];

        //        return [
        //            'equivalency' => $equivalent_to,
        //            'net_weight' => $net_weight
        //        ];
    }

    //    public function get_stock_weight()
    //    {
    //        $weights = $this->get_weights();
    //
    ////        if ($this->is_base_bulk() === false && $this->is_bulk_product() === true) {
    ////
    ////            $tiered_price = $this->get_tiered_price();
    ////
    ////            if ($tiered_price !== false) {
    ////                return [
    ////                    'value' => $tiered_price['QuantityLowerBound'],
    ////                    'unit' => 'g'
    ////                ];
    ////            }
    ////
    ////            return [
    ////                'value' => $this->data['']
    ////            ];
    ////
    ////        }
    //
    //        if (isset($weights['equivalency']['value']) && $weights['equivalency']['value'] > 0) {
    //            return [
    //                'value' => $weights['equivalency']['value'],
    //                'unit'    => $weights['equivalency']['unit']
    //            ];
    //        }
    //
    //        if (isset($weights['net_weight']['value']) && $weights['net_weight']['value'] > 0) {
    //            return [
    //                'value' => $weights['net_weight']['value'],
    //                'unit'    => $weights['net_weight']['unit']
    //            ];
    //        }
    //
    //        return [
    //            'value' => 0,
    //            'unit'    => 'g'
    //        ];
    //    }

    //    public function generate_default_details()
    //    {
    //        if (!isset($this->data['is_bulk_product'])) {
    //            $this->data['is_bulk_product'] = false;
    //        }
    //
    //        if (!isset($this->data['bulk_tiered_price'])) {
    //            $this->data['bulk_tiered_price'] = false;
    //        }
    //
    //        if (!isset($this->data['is_base_bulk'])) {
    //            $this->data['is_base_bulk'] = false;
    //        }
    //    }

    public function generate_product_details()
    {
        if (!isset($this->data['Specifications'])) {
            return;
        }

        $specifications = [];

        foreach ($this->data['Specifications'] as $spec) {    
            foreach ($spec['Fields'] as $field) {
                $specifications[sanitize_title($spec['Name'])][sanitize_title($field['DisplayName'])] = (array) $field;
            }
        }

        $this->specifications = $specifications;
    }

    public function get_prices_by_location()
    {
        $location_pricing     = [];
        $regular_prices     = [];
        //        $tiered_prices         = [];
        $base_tiered_prices = [];

        foreach ($this->cova_global_data['pricing'] as $location_id => $prices) {            
            if (isset($prices[$this->data['catalog_id']])) {
                foreach ($prices[$this->data['catalog_id']] as $price_id => $price) {
                    //                    if (!$price['PricingTierId']) {
                    $regular_prices[] = $price['RegularPrice'];        
                    //                        $base_tiered_prices[$location_id] = $price['RegularPrice'];
                    $location_pricing[$location_id] = $price;
                    //                    } else {
                    //                        $tiered_prices[$location_id][$price_id] = $price;
                    //                    }
                    break;
                }
            }
        }

        $default_pricing = max($regular_prices);
        
        //        if ($this->is_bulk_product() === true && $this->is_base_bulk() === false) {
        //            foreach ($tiered_prices as $location_id => $prices) {
        //                foreach ($prices as $pkey => $pitem) {
        //                    if ($pitem['PricingTierId'] === $this->get_tiered_price_id()) {
        //
        //                        $stock_weight = $this->get_stock_weight();
        //                        $regular_price = ((float) $pitem['RegularPrice'] * (float) $stock_weight['value']);
        //                        $regular_price = number_format(floor($regular_price*100)/100, 2);
        //
        //                        $pitem['RegularPrice'] = $regular_price;
        //
        //                        $default_pricing = $pitem['RegularPrice'];
        //                        $location_pricing[$location_id] = $pitem;
        //                        $base_tiered_prices[$location_id] = $pitem['RegularPrice'];
        //                    }
        //                }
        //            }
        //        }

        return [
        'default_pricing'      => $default_pricing,            
        'location_pricing'      => $location_pricing,
        //            'base_tiered_prices' => $base_tiered_prices,
        //            'tiered_prices'      => $tiered_prices
        ];
    }

    public function get_locations_stock()
    {
        $location_stocks = [];

        foreach ($this->cova_global_data['locations'] as $location_id => $location_item) {

            if (!isset($this->cova_global_data['inventory'][$location_id])) {
                $location_stocks[$location_id] = 0;
                continue;
            }

            $location_inventory = $this->cova_global_data['inventory'][$location_id];
            if (isset($location_inventory[$this->data['catalog_id']])) {
                //                if ($this->is_bulk_product() === true) {
                //                    $location_stocks[$location_id] = (float) ($location_inventory[$this->data['catalog_id']]['Quantity'] / 1000);
                //                } else {
                $location_stocks[$location_id] = $location_inventory[$this->data['catalog_id']]['Quantity'];
                //                }
                
            } else {
                $location_stocks[$location_id] = 0;
            }
        }

        return [
        'total_stock' => array_sum($location_stocks),
        'location_stocks' => $location_stocks
        ];
    }

    public function get_specifications()
    {
        return $this->specifications;
    }

    public function get_individual_specifications()
    {
        $specifications = [];

        foreach ($this->get_specifications() as $key => $specs) {
            foreach ($specs as $spec_key => $item) {
                $specifications[$spec_key] = $item['Value'];
            }
        }

        return $specifications;
    }

    public function get_details()
    {
        $data = $this->get_specifications();

        if (!isset($data['details'])) {
            return [];
        }

        return $data['details'];
    }

    public function get_additional_details()
    {
        $data = $this->get_specifications();

        if (!isset($data['additional-details'])) {
            return [];
        }

        return $data['additional-details'];
    }

    public function get_product_online_menu()
    {
        if (!isset($this->specifications['online-menu'])) {
            return [];
        }

        return $this->specifications['online-menu'];
    }

    public function get_brand()
    {
        $details = $this->get_specifications();

        if (isset($details['online-menu']['online-menu-brand'])) {
            return $details['online-menu']['online-menu-brand']['Value'];
        }

        $details = $this->get_additional_details();

        if (isset($details['brand-name'])) {
            return $details['brand-name']['Value'];
        }

        return false;
    }

    public function get_categories()
    {
        $details = $this->get_specifications();

        $categories = [];

        if (isset($this->data['CanonicalClassification']['Name'])) {
            $categories['classification'] = $this->data['CanonicalClassification']['Name'];
        }

        if (isset($details['online-menu']['online-menu-category'])) {
            $categories['online-menu'] = $details['online-menu']['online-menu-category']['Value'];
        }                

        if (isset($details['details']['strain'])) {
            $categories['strain'] = $details['details']['strain']['Value'];
        }

        return $categories;
    }

    public function get_cbd_details()    
    {
        $cbd = null;
        $cbd_max = null;
        $cbd_min = null;

        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {

                // Save cbd only
                if (stripos($key, 'cbd') !== false) {
                    $cbd = $item['Value'];
                }

                // Save cbd max
                if (stripos($key, 'cbd') !== false && stripos($key, 'max') !== false) {
                    $cbd_max = $item['Value'];
                }

                // Save cbd min
                if (stripos($key, 'cbd') !== false && stripos($key, 'min') !== false) {
                    $cbd_min = $item['Value'];
                }
            }
        }

        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {

                // Save cbd only
                if ($cbd_max === null) {
                    if (stripos($key, 'cbd') !== false) {
                        $cbd = $item['Value'];
                    }
                }

                // Save cbd max
                if ($cbd_max === null) {
                    if (stripos($key, 'cbd') !== false && stripos($key, 'max') !== false) {
                        $cbd_max = $item['Value'];
                    }
                }
                
                // Save cbd min
                if ($cbd_min === null) {
                    if (stripos($key, 'cbd') !== false && stripos($key, 'min') !== false) {
                        $cbd_min = $item['Value'];
                    }
                }
            }
        }

        return [
        'cbd' => $cbd,
        'min' => $cbd_min,
        'max' => $cbd_max
        ];
    }

    public function get_thc_details()
    {
        $thc = null;
        $thc_max = null;
        $thc_min = null;

        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {

                // Save thc only
                if (stripos($key, 'thc') !== false) {
                    $thc = $item['Value'];
                }

                // Save thc max
                if (stripos($key, 'thc') !== false && stripos($key, 'max') !== false) {
                    $thc_max = $item['Value'];
                }

                // Save thc min
                if (stripos($key, 'thc') !== false && stripos($key, 'min') !== false) {
                    $thc_min = $item['Value'];
                }
            }
        }

        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {

                // Save thc only
                if ($thc_max === null) {
                    if (stripos($key, 'thc') !== false) {
                        $thc = $item['Value'];
                    }
                }

                // Save thc max
                if ($thc_max === null) {
                    if (stripos($key, 'thc') !== false && stripos($key, 'max') !== false) {
                        $thc_max = $item['Value'];
                    }
                }
                
                // Save thc min
                if ($thc_min === null) {
                    if (stripos($key, 'thc') !== false && stripos($key, 'min') !== false) {
                        $thc_min = $item['Value'];
                    }
                }
            }
        }

        return [
        'thc' => $thc,
        'min' => $thc_min,
        'max' => $thc_max
        ];
    }

    public function get_terpenes_details()
    {
        $details_terpenes = [];
        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {
                if (stripos($key, 'terpene') !== false && !is_numeric($item['Value'])) {
                    $details_terpenes[] = $item['Value'];
                }
            }
        }

        if (!empty($details_terpenes)) {
            return $details_terpenes;
        }

        $additional_details_terpenes = [];
        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {
                if (stripos($key, 'terpene') !== false && !is_numeric($item['Value'])) {
                    $additional_details_terpenes[] = $item['Value'];
                }
            }
        }

        return $additional_details_terpenes;
    }

    //    public function get_cova_fields()
    //    {
    //        $fields = [];
    //
    //        foreach ($this->get_specifications() as $key => $specs) {
    //            foreach ($specs as $item) {
    //                $fields[$item['Id']] = $item['DisplayName'];
    //            }
    //        }
    //
    //        return $fields;
    //    }

    public function get_strain_details()
    {
        $details = $this->get_details();

        if (isset($details['strain']['Value'])) {
            return $details['strain']['Value'];
        }

        return null;
    }

    public function get_featured_image_id()
    {
        if (!isset($this->data['HeroShotId']) || !$this->data['HeroShotId']) {
            return false;
        }

        return $this->data['HeroShotId'];
    }

    public function get_images(): array
    {
        if (!isset($this->data['Assets'])) {
            return [];
        }

        $images = [];
        $img_ext = [
            'png',
            'jpeg',
            'jpg'
        ];

        foreach ($this->data['Assets'] as $item) {
            if ($item['Type'] !== 'Image') {
                continue;
            }

            $extension = pathinfo($item['Name'], PATHINFO_EXTENSION);
            if (!in_array($extension, $img_ext)) {
                $extension = false;
            }
            $cova_url = 'https://amsprod.blob.core.windows.net/assets/'. $item['Id'] .'.'. $extension;

            if (!$extension) {
                $image_result = cova_get_image($item['Id'], $item['Name']);
                $cova_url = $image_result['full']['url'];
            }

            $images[] = [
                'cova_id'    => $item['Id'],
                'cova_url'   => $cova_url
            ];
        }

        return $images;
    }

    //    public function is_bulk_product()
    //    {
    //        if (!isset($this->data['is_bulk_product'])) {
    //            return false;
    //        }
    //
    //        return $this->data['is_bulk_product'];
    //    }
    //
    //    public function is_base_bulk()
    //    {
    //        if (!isset($this->data['is_base_bulk'])) {
    //            return false;
    //        }
    //
    //        return $this->data['is_base_bulk'];
    //    }

    //    public function get_tiered_price()
    //    {
    //        if (!isset($this->data['bulk_tiered_price'])) {
    //            return false;
    //        }
    //
    //        return $this->data['bulk_tiered_price'];
    //    }

    //    public function get_tiered_price_id()
    //    {
    //        if (!isset($this->data['bulk_tiered_price'])) {
    //            return false;
    //        }
    //
    //        return $this->data['bulk_tiered_price']['Id'];
    //    }

    public function get_attributes()
    {
        //        if ($this->is_bulk_product() === true) {
        //
        //            if ($this->is_base_bulk() === true) {
        //
        //                $weights = $this->get_weights();
        //
        //                if (isset($weights['equivalency']['value']) && $weights['equivalency']['value'] > 0) {
        //                    return [
        //                        'Weight' => [$weights['equivalency']['value'] . $weights['equivalency']['unit']]
        //                    ];
        //                }
        //
        //                if (isset($weights['net_weight']['value']) && $weights['net_weight']['value'] > 0) {
        //                    return [
        //                        'Weight' => [$weights['net_weight']['value'] . $weights['net_weight']['unit']]
        //                    ];
        //                }
        //            } else {
        //                return [
        //                    'Weight' => [$this->get_tiered_price()['QuantityLowerBound'] .'g']
        //                ];
        //            }
        //        }

        return [];
    }

    public function get_wc_product_details()
    {
        //        $this->generate_default_details();
        $this->generate_product_details();

        $details['title'] = $this->get_title();
        $details['slug']  = $this->get_slug();
        $details['sku']   = $this->get_sku();
        $details['catalog_id'] = $this->data['catalog_id'];

        $details['date_added'] = $this->get_date_added();

        $details['long_description'] = $this->get_long_description();
        $details['short_description'] = $this->get_short_description();

        $details['life_cycle'] = $this->get_lifecycle_status();

        $details['pricing'] = $this->get_prices_by_location();
        $details['stocks'] = $this->get_locations_stock();

        $details['weight'] = $this->get_weights();

        $details['additional_details'] = $this->get_additional_details();
        $details['details'] = $this->get_details();

        $details['specifications'] = $this->get_specifications();
        $details['individual_specifications'] = $this->get_individual_specifications();
        //        $details['product_field_mapping'] = $this->get_cova_fields();

        $details['images'] = $this->get_images();
        $details['featured_image'] = $this->get_featured_image_id();

        $details['brand'] = $this->get_brand();
        $details['categories'] = $this->get_categories();

        $details['thc_details'] = $this->get_thc_details();
        $details['cbd_details'] = $this->get_cbd_details();
        $details['strain_details'] = $this->get_strain_details();
        $details['terpenes_details'] = $this->get_terpenes_details();

        $details['attributes'] = $this->get_attributes();
        //        $details['stock_weight'] = $this->get_stock_weight();
        //        $details['is_bulk_product'] = $this->is_bulk_product();
        //        $details['is_base_bulk'] = $this->is_base_bulk();
        //
        //        $details['bulk_tiered_price'] = $this->get_tiered_price();
        //        $details['bulk_tiered_price_id'] = $this->get_tiered_price_id();

        return apply_filters('cova_sync_product_details', $details, $this);
    }


}
