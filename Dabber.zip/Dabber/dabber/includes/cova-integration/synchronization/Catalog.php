<?php

namespace Cova_Integration\Sync;

use CovaAPI\Catalog as API_Catalog;

class Catalog
{
    public $catalog;    
    public $stored_data;
    public $log_file_path;    
    public $current_product_slug;

    public function run()
    {
        $catalog = new API_Catalog();
        $this->catalog = $catalog;
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->catalog, $name], $param);

        return json_decode($data, true);
    }

    public function get_all_items()
    {
        $catalog_data  = $this->items();    
        $catalog_data  = $this->group_products_by_slug($catalog_data);        

        return $catalog_data;        
    }

    public function get_product_short_details($catalog_id)
    {
        $product = $this->structure($catalog_id);

        if (!$product) {
            return false;
        }

        $cova_url = 'https://hub.covasoft.net/#CatalogManager/products/'. $catalog_id .'/'. $product['Id'];

        return [
        'Name'             => $product['Name'],
        'Id'             => $product['Id'],
        'CatalogItemId' => $catalog_id,
        'LifeCycle'     => $product['LifeCycle'],
        'cova_hub_url'    => '<a href="'. $cova_url .'" target="_blank">'. $cova_url .'</a>'
        ];        
    }

    public function is_product_synced($catalog_id)
    {
        $products = new \WP_Query(
            [
            'post_type'         => ['product', 'product_variation'],
            'posts_per_page'     => -1,
            'post_status'         => 'any',
            'meta_query'         => [
            'relation' => 'AND',
            [
            'key'         => 'cova_catalog_id',
            'value'        => $catalog_id,
            'compare'    => '='
            ]
            ]
            ]
        );

        if (!isset($products->posts[0])) {
            return false;
        }

        return $products->posts[0];
    }

    public function group_products_by_slug($data)
    {
        if (!is_array($data)) { return []; 
        }
        if (empty($data)) { return []; 
        }

        $grouped_items = [];

        foreach ($data as $key => $item) {
            $slug = $this->truncate_slug($item['Slug']);
            $grouped_items[$slug][] = [
            'Slug'                 => $item['Slug'],
            'CatalogItemId'     => $item['CatalogItemId'],
            'DateAddedUtc'         => $item['DateAddedUtc'],
            'DateUpdatedUtc'     => $item['DateUpdatedUtc'],
            'CatalogSku'        => $item['CatalogSku'],
                'LifeCycle'         => $item['LifeCycle']
            ];
        }

        return $grouped_items;
    }

    public function get_last_updated_products($from = '', $to = '')
    {
        $products = \Cova_Integration\Cova_Data_Manager::get_global_data('catalog', true);
        $updated_items = [];

        $from = strtotime($from);
        $to = strtotime($to);

        if ($from === false) {
            $from = strtotime(date('Y-m-d', strtotime('-2 day', strtotime(gmdate('Y-m-d')))));
        }

        if ($to === false) {
            $to = strtotime('+2 day', strtotime(gmdate('Y-m-d')));
        }

        foreach ($products as $group_slug => $group_items) {
            foreach ($group_items as $item) {
                $updated_date = date("Y-m-d H:i:s", strtotime($item['DateUpdatedUtc']));
                $updated_date = strtotime($updated_date);

                if ($updated_date >= $from && $updated_date <= $to) {
                    $updated_items[] = [
                     'catalog_id' => $item['CatalogItemId'],
                     'date_updated' => $updated_date
                    ];
                }
            }
        }

        return $updated_items;
    }

    public function truncate_slug($slug = false)
    {
        preg_match('/(.*?)-V[0-9a-z]+/i', $slug, $new_slug);

        if (!isset($new_slug[1])) {
            return $slug;
        }

        return trim($new_slug[1]);
    }
}
