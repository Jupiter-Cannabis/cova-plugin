<?php

namespace Cova_Integration;

class WC_Variation_Product_Updater
{
    public $data;
    public $product;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function update()
    {
        $parent = $this->data['parent'];

        $this->product = $this->data['wc_product'];

        $this->product->set_date_created($this->data['date_added']);

        $this->product->set_sku($this->data['sku']);
        $this->product->set_price($this->data['pricing']['default_pricing']);
        $this->product->set_regular_price($this->data['pricing']['default_pricing']);

        $this->product->set_description($this->data['long_description']);
        $this->product->set_short_description($this->data['short_description']);

        $this->product->set_manage_stock('yes');
        $this->product->set_stock_quantity($this->data['stocks']['total_stock']);
        $this->product->set_backorders('no');

        if ($this->data['stocks']['total_stock'] > 0) {
            $this->product->set_stock_status('instock');
        } else {
            $this->product->set_stock_status('outofstock');
        }

        if ($this->data['weights']['equivalency']['value'] > 0) {
            $this->product->set_weight($this->data['weights']['equivalency']['value']);
        } else {
            $this->product->set_weight($this->data['weights']['net_weight']['value']);
        }

        $this->product->set_catalog_visibility('visible');

        if ($this->data['life_cycle'] === 'active') {
            $this->product->set_status('publish');
        } else {
            $this->product->set_status('private');
        }

        $this->product->save();

        $this->hack_product_visibility($this->product);

        if ($this->data['featured_image'] !== false) {
            set_post_thumbnail($this->product->get_id(), $this->data['featured_image']);
        }

        $attr_name = apply_filters('dabber_sync_variable_product_attribute_term', '', $this->data);
        $attr_term = get_term_by('slug', dabber_sanitize_slug($this->data['title']), 'pa_'. $attr_name);

        if (isset($attr_term->slug)) {
            update_post_meta($this->product->get_id(), 'attribute_pa_'. $attr_name, $attr_term->slug);
        }

        $this->save_wcmlim_data($this->product->get_id(), $this->data);
        $this->save_meta_data($this->product->get_id(), $this->data);

        do_action('dabber_sync_variation_product_after_update', $this);

        return $this->get_updated_product_info($this->product->get_id());
    }

    //    public function update_master_product()
    //    {
    //        $updater = new WC_Variable_Product_Updater;
    //        $updater->set_product($this->product);
    //        $updater->set_data($this->data);
    //        $updater->set_api_instances($this->api);
    //
    //        $updater->update_variation_stock();
    //    }

    /**
     * Hack to fix bug where sometimes synced products visibility
     * is not working properly.
     */
    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }

    public function get_updated_product_info($product_id)
    {
        $cova_catalog_id = get_post_meta($product_id, 'cova_catalog_id', true);
        $cova_slug = get_post_meta($product_id, 'cova_slug', true);
        $cova_url = 'https://hub.covasoft.net/#CatalogManager/products/'. $cova_catalog_id .'/'. $cova_slug;
        $wc_url = get_the_permalink($product_id);

        return [
        'name' => get_the_title($product_id),
        'url'  => '<a href="'. $wc_url .'" target="_blank">'. $wc_url .'</a>',
        'type' => get_post_type($product_id),
        'cova_details' => [
        'catalog_id' => $cova_catalog_id,
        'slug_id'     => $cova_slug,
        'url'          => '<a href="'. $cova_url .'" target="_blank">'. $cova_url .'</a>'
        ]
        ];
    }

    public function save_wcmlim_data($product_id, $data)
    {
        foreach ($data['pricing']['location_pricing'] as $location_id => $price) {
            $location = cova_get_wc_location_by_cova_location_id($location_id);
            cova_update_product_location_regular_price($product_id, $location->term_id, $price['RegularPrice']);

            if ($price['OverridePrice'] > 0) {
                cova_update_product_location_sale_price($product_id, $location->term_id, $price['OverridePrice']);
            }            
        }

        foreach ($data['stocks']['location_stocks'] as $location_id => $quantity) {
            $location = cova_get_wc_location_by_cova_location_id($location_id);
            cova_update_product_location_stock($product_id, $location->term_id, $quantity);
        }        
    }

    public function save_meta_data($product_id, $data)
    {
        $meta_args = [
            'cova_catalog_id'       => $data['catalog_id'],
            'cova_slug'             => $data['slug'],
            'cova_specifications'   => $data['specifications']
        ];

        foreach ($data['individual_specifications'] as $key => $value) {
            $meta_args['cova_'. $key] = $value;
        }

        $metadata = apply_filters('dabber_sync_variation_product_update_metadata', $meta_args, $product_id, $data, $this);

        foreach ($metadata as $meta_key => $meta_val) {
            update_post_meta($product_id, $meta_key, $meta_val);
        }
    }
}
