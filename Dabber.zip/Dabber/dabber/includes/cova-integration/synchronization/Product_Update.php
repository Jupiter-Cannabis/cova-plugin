<?php

namespace Cova_Integration;

class Product_Update
{
    private $api;
    private $update_batch_num = 5;
    private $total_update_num;
    public  $cova_global_data;
    public  $to_update_catalog_ids;
    public  $update_products;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);

        /**
         * Manual operations
         */
        add_action('init', [$this, 'breakdown_products']);
        add_action('init', [$this, 'group_products']);
        add_action('init', [$this, 'run_manual_sync']);

        add_action('wp_ajax_cova_update_sync_update_products', [$this, 'ajax_update_products']);

        add_action('cova_breakdown_products', [$this, 'initiate_breakdown_products']);
        add_action('cova_group_products', [$this, 'initiate_group_products']);
        add_action('cova_update_products', [$this, 'initiate_product_update']);
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {
            wp_enqueue_script('cova-update-products-sync', COVA_INTEGRATION_URI .'/assets/js/update-products.js', [], null, true);
        }
    }

    public function run_manual_sync()
    {
        if (!isset($_GET['_dabber_run_update_sync'])) {
            return;
        }

        do_action('cova_update_products', 'manual');

        die();
    }

    public function ajax_update_products()
    {
        dabber_set_sync_on();

        if (isset($_POST['params']['clear_log_files']) && $_POST['params']['clear_log_files'] == 'yes') {
            Cova_Data_Manager::remove_stored_data('updated-product-items');
        }

        $sync_all = (isset($_POST['params']['sync_all']) && $_POST['params']['sync_all'] === 'yes')? 'all-products' : $_POST['params']['sync_all'];
        do_action('cova_update_products', $sync_all);

        if ($this->update_products === false) {
            wp_send_json_success(
                [
                'status' => 'complete',
                'message' => 'No more products to update',
                'message_type' => 'success'
                ], 200
            );
        }

        if (empty($this->update_products)) {
            wp_send_json_success(
                [
                'status' => 'ok',
                'message' => 'No products found on the following catalog_ids batch',
                'data' => $this->to_update_catalog_ids,
                'total_update' => $this->total_update_num,
                'total_synced' => count($this->update_products),
                'message_type' => 'output'
                ], 200
            );
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'message' => 'Successfully updated '. count($this->update_products) .' product(s)',
            'data' => $this->update_products,
            'total_update' => $this->total_update_num,
            'total_synced' => count($this->update_products),
            'message_type' => 'output'
            ], 200
        );
    }

    public function initiate_product_update($sync_type)
    {
        global $cova_current_sync_running;

        $iterationId = md5(microtime());
        $start = microtime(true);
        dabber_cron_logger2('EVENT - product update', $iterationId);
        try
        {
            $cova_current_sync_running = 'product_update';

            include_once ABSPATH .'wp-load.php';
    
            $this->generate_cova_global_data();

            if ($sync_type === 'all-products') {
                $products_to_update = $this->get_all_wc_products_to_update();
            } else {
                $products_to_update = $this->get_products_to_update();
            }

            $catalog_ids = apply_filters('dabber_sync_product_update_process_catalog_ids', $products_to_update);
    
            if (empty($catalog_ids)) {
                Cova_Data_Manager::remove_stored_data('to-update');
                Cova_Data_Manager::remove_stored_data('wc-products-to-update');

                $this->update_products = false;
                $duration = microtime(true) - $start;
                dabber_cron_logger2('EVENT - product update', $iterationId, $duration);
    
                return [];
            }
    
            $cova_products = $this->api['catalog']->bulk(
                [
                'CatalogItemIds' => $catalog_ids[0]
                ]
            );
    
            $this->update_products = [];
            $this->to_update_catalog_ids = $catalog_ids[0];
    
            if (empty($cova_products['CatalogItems'])) {
                $this->remove_not_exist_catalog_ids_products($catalog_ids[0]);
            } else {
    
                do_action('dabber_before_product_update_process', $cova_products['CatalogItems']);
    
                foreach ($cova_products['CatalogItems'] as $catalog_id => $item) {
                    $item['catalog_id'] = $catalog_id;
                    $updated_product = $this->update_product($item);
    
                    if ($updated_product !== false) {
                        $this->update_products[] = $updated_product;
                    }
                }
    
                do_action('dabber_after_product_update_process', $this->update_products);
            }
    
            $this->reset_to_update_items($catalog_ids);
    
            
        }
        catch(\Exception $e)
        {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - product update failed. ' . $e->getMessage(), $iterationId, $duration, false);
            throw $e;
        }

        $duration = microtime(true) - $start;
        dabber_cron_logger2('EVENT - product update', $iterationId, $duration);
        return $this->update_products;
        
    }

    public function remove_not_exist_catalog_ids_products($catalog_ids)
    {
        $products = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'post_status' => 'any',
            'posts_per_page' => -1,
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_catalog_id',
                    'value' => $catalog_ids,
                    'compare' => 'IN'
                ]
            ],
            'fields' => 'ids'
            ]
        );

        if($products->found_posts < 1) {
            return;
        }

        foreach($products->posts as $id) {
            wp_delete_post($id, true);
        }
    }

    public function get_all_wc_products_to_update()
    {
        global $wpdb;

        $catalog_ids = Cova_Data_Manager::get_stored_data('wc-products-to-update');

        if ($catalog_ids !== false) {
            return $catalog_ids;
        }

        $catalog_ids = $wpdb->get_results(
            "
            SELECT meta.meta_value as catalog_id
            FROM {$wpdb->prefix}posts as product
            LEFT JOIN {$wpdb->prefix}postmeta as meta
            ON product.ID = meta.post_id
            WHERE meta.meta_key = 'cova_catalog_id'
            AND meta.meta_value != ''
            AND product.post_status = 'publish'
            ORDER BY product.ID
            ASC
        ", ARRAY_N
        );

        $catalog_ids_arr = [];

        foreach ($catalog_ids as $item) {
            $catalog_ids_arr[] = $item[0];
        }

        $catalog_ids_arr = array_chunk($catalog_ids_arr, $this->update_batch_num);

        Cova_Data_Manager::store_data('wc-products-to-update', $catalog_ids_arr);

        return $catalog_ids_arr;
    }

    public function get_products_to_update()
    {
        $catalog_ids = Cova_Data_Manager::get_stored_data('to-update');

        if ($catalog_ids !== false) {
            return $catalog_ids;
        }

        $prev_days          = date('Y-m-d', strtotime('-5 day', strtotime(gmdate('Y-m-d')))); // default to previous 1 day
        $cova_updated_items = $this->api['catalog']->get_last_updated_products($prev_days);
        $wc_updated_items   = $this->get_updated_items();
        $wc_imported_items  = dabber_get_all_imported_products();

        $catalog_ids = [];
        $update_keys = [];

        foreach ($cova_updated_items as $key => $item) {
            $update_key = $item['date_updated'] .'-'. $item['catalog_id'];

            // do not update products with catalog ID if already updated or if not yet imported.
            if (in_array($update_key, $wc_updated_items) || !in_array($item['catalog_id'], $wc_imported_items)) {
                continue;
            }

            $catalog_ids[] = $item['catalog_id'];
            $update_keys[] = $update_key;
        }

        $this->total_update_num = count($catalog_ids);

        $catalog_ids = array_chunk($catalog_ids, $this->update_batch_num);

        $this->insert_updated_product_items($update_keys);

        Cova_Data_Manager::store_data('to-update', $catalog_ids);

        return $catalog_ids;
    }

    public function insert_updated_product_items($items)
    {
        $updated_items = Cova_Data_Manager::get_stored_data('updated-product-items');
        /**
         * @todo, investigate why $items sometimes gets null value
         */
        $new_data = array_merge($updated_items, $items);

        Cova_Data_Manager::store_data('updated-product-items', $new_data);
        Cova_Data_Manager::save_storage_timestamp('updated-product-items');
    }

    public function get_updated_items()
    {
        $updated_items = Cova_Data_Manager::get_stored_data('updated-product-items');

        if ($updated_items === false) {
            return [];
        }

        $saved_date = Cova_Data_Manager::get_storage_timestamp('updated-product-items');

        if (strtotime($saved_date) > strtotime('-2 day')) {
            return $updated_items;
        }

        Cova_Data_Manager::remove_stored_data('updated-product-items');

        return [];
    }

    /**
     * Unset previously updated batch
     */
    public function reset_to_update_items($catalog_ids): void
    {
        if (empty($catalog_ids)) {
            return;
        }

        unset($catalog_ids[0]);

        Cova_Data_Manager::store_data('to-update', array_values($catalog_ids));
    }

    public function update_product($cova_product)
    {
        $wc_product = dabber_get_product_by_catalog_id($cova_product['catalog_id']);

        if (!$wc_product) {
            return false;
        }

        $update_short_circuit = apply_filters('dabber_sync_before_product_update', false, $cova_product, $wc_product);

        if ($update_short_circuit !== false ) {
            return $update_short_circuit;
        }

        $product_type = $wc_product->get_type();

        if ($product_type === 'simple') {
            return $this->update_simple_product($cova_product, $wc_product);
        }

        if ($product_type === 'variation') {
            return $this->update_variation_product($cova_product, $wc_product);
        }

        return false;
    }

    public function update_variation_product($cova_product, $wc_product)
    {
        $details_manager = new Variation_Product_Details_Manager($this->api);
        $details_manager->set_data($cova_product);
        $details_manager->set_cova_global_data($this->cova_global_data);

        $details = $details_manager->get_wc_product_details();

        $details['wc_product'] = $wc_product;
        $details['parent'] = wc_get_product($wc_product->get_parent_id());

        $product = new WC_Variation_Product_Updater();
        $product->set_data($details);

        return $product->update();
    }

    public function update_simple_product($cova_product, $wc_product)
    {
        $details_manager = new Simple_Product_Details_Manager($this->api);
        $details_manager->set_data($cova_product);
        $details_manager->set_cova_global_data($this->cova_global_data);

        $details = $details_manager->get_wc_product_details();

        $details['is_update']  = true;
        $details['wc_product'] = $wc_product;

        $product = new WC_Simple_Product_Updater();
        $product->set_data($details);

        return $product->update();
    }

    //    public function get_base_bulk_product($catalog_id)
    //    {
    //        $product = new \WP_Query([
    //            'post_type'  => 'product',
    //            'publish'    => 'publish'
    //        ]);
    //    }

    //    public function update_bulk_product($cova_product, $wc_product)
    //    {
    //        $catalog_id = get_post_meta($wc_product->get_id(), 'cova_catalog_id', true);
    //
    //        //
    //        $simple_product_creator = new WC_Simple_Product_Creator($this->api);
    //        $tiered_prices = $simple_product_creator->get_price_tiers();
    //
    //        foreach ($tiered_prices as $price_key => $price) {
    //            $tiered_product = new WC_Tiered_Pricing_Product_Creator($this->api);
    //            $product_data['is_base_bulk'] = false;
    //            $product_data['bulk_tiered_price'] = $price;
    //
    //            $tiered_product->set_data($product_data);
    //            $tiered_product->set_cova_global_data($this->cova_global_data);
    //            $product = $tiered_product->create();
    //
    //            $products[] = $product;
    //        }
    //
    ////        $bulk_products = dabber_get_bulk_products_by_catalog_id($catalog_id);
    ////
    ////        if ($bulk_products === false) {
    ////            return false;
    ////        }
    ////
    ////        $updated_bulk_products = [];
    ////
    ////        foreach ($bulk_products as $bkey => $bulk_item) {
    ////
    ////            $is_base_bulk = get_post_meta($bulk_item->ID, 'dabber_is_base_bulk_product', true);
    ////
    ////            $cova_product['is_bulk_product'] = true;
    ////
    ////            if ($is_base_bulk == true) {
    ////                $cova_product['is_base_bulk'] = true;
    ////            } else {
    ////                $cova_product['bulk_tiered_price'] = get_post_meta($bulk_item->ID, 'dabber_bulk_tiered_price', true);
    ////            }
    ////
    ////            $details_manager = new Simple_Product_Details_Manager($this->api);
    ////            $details_manager->set_data($cova_product);
    ////            $details_manager->set_cova_global_data($this->cova_global_data);
    ////
    ////            $details = $details_manager->get_wc_product_details();
    ////
    ////            $details['wc_product'] = wc_get_product($bulk_item->ID);
    ////
    ////            $product = new WC_Simple_Product_Updater();
    ////            $product->set_data($details);
    ////
    ////            $updated_bulk_products[] = $product->update();
    ////        }
    //
    //        return $updated_bulk_products;
    //    }

    public function breakdown_products()
    {
        if (!isset($_POST['cova-breakdown-existing-prdct-ids'])) {
            return;
        }

        if (trim($_POST['cova-breakdown-existing-prdct-ids']) === '') {
            return;
        }

        $product_slugs = array_map('trim', explode(',', $_POST['cova-breakdown-existing-prdct-ids']));

        do_action('cova_breakdown_products', $product_slugs);
    }

    public function group_products()
    {
        if (!isset($_POST['cova-regroup-prdct-ids'])) {
            return;
        }

        if (trim($_POST['cova-regroup-prdct-ids']) === '') {
            return;
        }

        $product_slugs = array_map('trim', explode(',', $_POST['cova-regroup-prdct-ids']));

        do_action('cova_group_products', $product_slugs);
    }

    public function initiate_breakdown_products($slugs)
    {
        $this->generate_cova_global_data();

        $slugs = array_unique($slugs);
        $variation_ids = [];
        $variable_product_ids = [];
        $product_catalog_ids = [];

        foreach ($slugs as $key => $slug) {
            $products = $this->get_product_by_slug_id($slug);

            if ($products !== false) {
                foreach ($products as $pkey => $product) {
                    $variation_ids[] = $product->ID;
                    $product_catalog_ids[] = get_post_meta($product->ID, 'cova_catalog_id', true);

                    if ($product->post_parent) {
                        $variable_product_ids[] = $product->post_parent;
                    }
                }
            }
        }

        if (empty($variable_product_ids)) {
            return;
        }

        $variable_product_ids = array_unique($variable_product_ids);
        $product_catalog_ids  = array_filter($product_catalog_ids);

        $this->remove_products_by_ids($variable_product_ids);

        $import_products = $this->api['catalog']->bulk(
            [
            'CatalogItemIds' => $product_catalog_ids
            ]
        );

        $brokendown_products = [];

        if (isset($import_products['CatalogItems']) && !empty($import_products['CatalogItems'])) {
            $brokendown_products = $this->import_simple_products($import_products['CatalogItems']);
        }
    }

    public function initiate_group_products($slugs)
    {
        $this->generate_cova_global_data();

        $slugs = array_unique($slugs);
        $variation_ids = [];
        $product_catalog_ids = [];

        foreach ($slugs as $slug) {
            $products = $this->get_product_by_slug_id($slug);

            foreach ($products as $product) {
                $variation_ids[] = $product->ID;
                $product_catalog_ids[] = get_post_meta($product->ID, 'cova_catalog_id', true);
            }
        }

        $this->remove_products_by_ids($variation_ids);

        $import_products = $this->api['catalog']->bulk(
            [
            'CatalogItemIds' => $product_catalog_ids
            ]
        );

        $grouped_products = [];

        if (isset($import_products['CatalogItems']) && !empty($import_products['CatalogItems'])) {
            $grouped_products = $this->import_variation_products($import_products['CatalogItems']);
        }
    }

    public function generate_cova_global_data()
    {
        $catalog_data   = Cova_Data_Manager::get_global_data('catalog');
        $inventory_data = Cova_Data_Manager::get_global_data('inventory');
        $locations_data = Cova_Data_Manager::get_global_data('locations');

        $this->cova_global_data = [
            'catalog'   => $catalog_data,
            'inventory' => $inventory_data,
            'locations' => $locations_data
        ];

        $prices = [];

        foreach ($this->cova_global_data['locations'] as $location_id => $location) {
            $price_data = Cova_Data_Manager::get_global_data('pricing-'. $location_id);
            $prices[$location_id] = $price_data[$location_id];
        }

        $this->cova_global_data['pricing'] = $prices;
    }

    public function import_simple_products($cova_products)
    {
        $imported_products = [];

        foreach ($cova_products as $catalog_id => $cova_product) {
            $cova_product['catalog_id'] = $catalog_id;
            $simple_product = new WC_Simple_Product_Creator($this->api);
            $simple_product->set_data($cova_product);
            $simple_product->set_cova_global_data($this->cova_global_data);
            $imported_products[] = $simple_product->create();
        }

        return $imported_products;
    }

    public function import_variation_products($cova_products)
    {
        $imported_products = [];

        foreach ($cova_products as $catalog_id => $cova_product) {

            $cova_product['catalog_id'] = $catalog_id;

            $variable_product = new WC_Variable_Product_Creator($this->api);
            $variable_product->set_data($cova_product);
            $variable_product->set_cova_global_data($this->cova_global_data);
            $imported_products[] = $variable_product->create();
        }

        return $imported_products;
    }

    public function remove_products_by_ids($product_ids)
    {
        foreach ($product_ids as $key => $id) {
            wp_delete_post($id, true);
        }
    }

    public function get_product_by_slug_id($slug)
    {
        $products = new \WP_Query(
            [
            'post_type' => ['product', 'product_variation'],
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => 'cova_slug',
                    'value' => $slug,
                    'compare' => 'LIKE'
                ]
            ]
            ]
        );

        if (empty($products->posts)) {
            return false;
        }

        return $products->posts;
    }
}
