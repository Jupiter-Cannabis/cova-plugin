<?php

namespace Cova_Integration;

class WC_Simple_Product_Updater
{
    public $data;
    private $product;

    public function set_data($data)
    {
        $this->data = $data;
        $this->product = $this->data['wc_product'];
    }

    public function get_data()
    {
        return $this->data;
    }

    public function __call($name, $param)
    {
        return call_user_func_array([$this, $name], $param);
    }

    //    public function update_info($details)
    //    {
    //        $this->product = $this->data['wc_product'];
    //
    //        foreach ($details as $detail) {
    //            $callback = 'update_'. $detail;
    //            $this->$callback();
    //        }
    //
    //        $this->product->save();
    //        $this->hack_product_visibility($this->product);
    //    }

    public function update_product()
    {
        $this->product->save();
        $this->hack_product_visibility($this->product);
    }

    public function update_images()
    {
        $wp_attachment_ids = $this->upload_attachments($this->data['images']);

        if (!isset($wp_attachment_ids[$this->data['featured_image']])) {
            return;
        }

        $this->product->set_image_id($wp_attachment_ids[$this->data['featured_image']]);

        if (count($wp_attachment_ids) > 1) {
            unset($wp_attachment_ids[$this->data['featured_image']]);
            $this->product->set_gallery_image_ids(array_values($wp_attachment_ids));
        } else {
            $this->product->set_gallery_image_ids([0]); // remove gallery image if there's only one image available.
        }
    }

    public function update_title()
    {
        $this->product->set_name($this->data['title']);
    }

    public function update_date_created()
    {
        $this->product->set_date_created($this->data['date_added']);
    }

    public function update_sku()
    {
        $this->product->set_sku($this->data['sku']);
    }

    public function update_description()
    {
        $this->product->set_description($this->data['long_description']);
    }

    public function update_short_description()
    {
        $this->product->set_short_description($this->data['short_description']);
    }

    public function update_is_featured()
    {
        $this->product->set_featured(false);
    }

    public function update_backorders()
    {
        $this->product->set_backorders('no');
    }

    public function update_catalog_visibility()
    {
        $this->product->set_catalog_visibility('visible');
    }

    public function update_publish_status()
    {
        if ($this->data['life_cycle'] === 'active') {
            $this->product->set_status('publish');
        } else {
            $this->product->set_status('private');
        }
    }

    public function update_stock_status()
    {
        if ($this->data['stocks']['total_stock'] > 0) {
            $this->product->set_stock_status('instock');
        } else {
            $this->product->set_stock_status('outofstock');
        }
    }

    public function update_manage_stock()
    {
        $this->product->set_manage_stock('yes');
    }

    public function update_stock_quantity()
    {
        $this->product->set_stock_quantity($this->data['stocks']['total_stock']);
    }

    public function update_price()
    {
        $this->product->set_price($this->data['pricing']['default_pricing']);
        $this->product->set_regular_price($this->data['pricing']['default_pricing']);
    }

    public function update_weight()
    {
        $this->product->set_weight($this->data['weight']['value']);
        //        if ($this->data['weights']['equivalency']['value'] > 0) {
        //            $this->product->set_weight($this->data['weights']['equivalency']['value']);
        //        } else {
        //            $this->product->set_weight($this->data['weights']['net_weight']['value']);
        //        }
    }

    /**
     * @todo   use update_meta_data()
     * @return void
     */
    public function update_metadata()
    {
        $this->save_meta_data($this->product->get_id(), $this->data);
    }

    /**
     * @todo   use set_category_ids()
     * @return void
     */
    public function update_categories()
    {
        if (!empty($this->data['categories'])) {
            $this->create_category($this->product->get_id(), $this->data['categories']);
        }
    }

    /**
     * @todo   use set_attributes()
     * @return void
     */
    public function update_brands()
    {
        if ($this->data['brand'] !== false) {
            $this->create_brand($this->product->get_id(), $this->data['brand']);
        }
    }

    /**
     * @todo   use set_tag_ids()
     * @return void
     */
    public function update_tags()
    {
        if (!empty($this->data['terpenes_details'])) {
            $this->add_tags($this->product->get_id(), $this->data['terpenes_details']);
        }
    }

    //    public function update_field_mapping()
    //    {
    //        $this->save_field_mapping($this->data['product_field_mapping']);
    //    }

    public function update()
    {
        $product = $this->data['wc_product'];

        $product_props = [
            'name'                  => $this->data['title'],
            'sku'                   => $this->data['sku'],
            'description'           => $this->data['long_description'],
            'short_description'     => $this->data['short_description'],
            'backorders'            => 'no',
            'featured'              => false,
            'catalog_visibility'    => 'visible',
            'status'                => ($this->data['life_cycle'] === 'active')? 'publish' : 'private',
            'manage_stock'          => 'yes',
            'stock_status'          => ($this->data['stocks']['total_stock'] > 0)? 'instock' : 'outofstock',
            'stock_quantity'        => $this->data['stocks']['total_stock'],
            'price'                 => $this->data['pricing']['default_pricing'],
            'regular_price'         => $this->data['pricing']['default_pricing'],
            'weight'                => $this->data['weight']['value']
        ];

        $current_sku_prod = wc_get_product_id_by_sku($this->data['sku']);

        if ($product->get_id() !== $current_sku_prod) {
            wp_delete_post($current_sku_prod, true);
        }

        if (!isset($this->data['is_update'])) {
            $product_props['date_created'] = $this->data['date_added'];
        }

        $wp_attachment_ids = $this->upload_attachments($this->data['images']);

        if (isset($wp_attachment_ids[$this->data['featured_image']])) {
            $product_props['image_id'] = $wp_attachment_ids[$this->data['featured_image']];
        }

        if (count($wp_attachment_ids) > 1) {
            unset($wp_attachment_ids[$this->data['featured_image']]);
            $product_props['gallery_image_ids'] = array_values($wp_attachment_ids);
        } else {
            $product_props['gallery_image_ids'] = [0]; // remove gallery image if there's only one image available.
        }

        $product_props = apply_filters('cova_sync_product_update_product_props', $product_props, $product, $this->data, $this);

        foreach ($product_props as $prop_key => $prop_val) {
            $prop_name = 'set_'. $prop_key;
            $product->$prop_name($prop_val);
        }

        do_action('cova_before_simple_product_update', $product, $this);

        $product_id = $product->save();

        $this->hack_product_visibility($product);
        $this->save_meta_data($product_id);
        $this->save_wcmlim_data($product_id);

        $this->create_category($product_id);
        $this->create_brand($product_id);
        $this->add_tags($product_id);

        $product = wc_get_product($product_id);

        do_action('cova_after_simple_product_update', $product, $this);

        return apply_filters('cova_get_update_product_info', $this->get_updated_product_info($product_id));
    }

    /**
     * Hack to fix bug where sometimes synced products visibility
     * is not working properly.
     */
    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }

    //    public function is_attribute_stock_exists($catalog_id)
    //    {
    //        $args_posts = [
    //            'post_type'      => 'mewz_attribute_stock',
    //            'posts_per_page' => 1,
    //            'meta_query' => [
    //                'relation' => 'AND',
    //                [
    //                    'key' => 'attr_stock_catalog_id',
    //                    'value' => $catalog_id,
    //                    'compare' => '='
    //                ]
    //            ]
    //        ];
    //
    //        $loop_posts = new \WP_Query( $args_posts );
    //
    //        if ( ! $loop_posts->have_posts() ) {
    //            return false;
    //        } else {
    //            $loop_posts->the_post();
    //            return $loop_posts->post->ID;
    //        }
    //    }

    //    public function get_bulk_product_ids($catalog_id)
    //    {
    //        $product = new \WP_Query([
    //            'post_type' => 'product',
    //            'posts_per_page' => -1,
    //            'meta_query' => [
    //                'relation' => 'AND',
    //                [
    //                    'key' => 'cova_catalog_id',
    //                    'value' => $catalog_id,
    //                    'compare' => '='
    //                ]
    //            ]
    //        ]);
    //
    //        if ($product->found_posts > 0) {
    //            return wp_list_pluck( $product->posts, 'ID' );
    //        }
    //
    //        return [];
    //    }

    //    public function create_attribute_stock($product_id, $attributes, $stock_qty)
    //    {
    //        $product = wc_get_product($product_id);
    //
    //        $post_title   = str_replace(' - 1g', '', $product->get_name()) .' - Weight';
    //        $post_name    = get_post_meta($product_id, 'cova_catalog_id', true);
    //        $attribute_id = $this->is_attribute_stock_exists('attr-stock-'. $post_name);
    //
    //        if ($attribute_id === false) {
    //
    //            $attribute_id = wp_insert_post([
    //                'post_title'  => $post_title,
    //                'post_status' => 'publish',
    //                'post_name'   => $post_name,
    //                'post_type'   => 'mewz_attribute_stock'
    //            ]);
    //
    //            if (is_wp_error($attribute_id)) {
    //                return false;
    //            }
    //
    //            update_post_meta($attribute_id, '_quantity', $stock_qty);
    //            update_post_meta($attribute_id, '_match_all', 1);
    //            update_post_meta($attribute_id, '_limit_products', 1);
    //            update_post_meta($attribute_id, 'attr_stock_catalog_id', 'attr-stock-'. $post_name);
    //        }
    //
    //        $connected_product_ids = $this->get_bulk_product_ids($this->data['catalog_id']);
    //        update_post_meta($attribute_id, '_products', $connected_product_ids);
    //
    //        $attr_rows = [];
    //
    //        foreach ($connected_product_ids as $key => $prdct_id) {
    //
    //            $product_item = wc_get_product($prdct_id);
    //            $weight_attr = get_term_by('slug', sanitize_title_with_dashes($product_item->get_weight() . 'g'), 'pa_weight');
    //
    //            $attr_rows[] = [
    //                'rows' => [
    //                    [
    //                        'attribute' => wc_attribute_taxonomy_id_by_name('pa_weight'),
    //                        'term' => $weight_attr->term_id
    //                    ]
    //                ],
    //                'multiplier' => $product_item->get_weight()
    //            ];
    //        }
    //
    //        \Mewz\WCAS\Util\Matches::save_sets($attribute_id, $attr_rows);
    //
    //        return true;
    //    }

    public function create_variation_attributes($product_id, $attributes)
    {
        $product_attributes = [];

        foreach( $attributes as $key => $terms ) {
            $taxonomy   = wc_attribute_taxonomy_name($key);
            $attr_label = ucfirst($key);
            $attr_name  = ( wc_sanitize_taxonomy_name($key));

            $product_attributes[$taxonomy] = [
                'name'         => $taxonomy,
                'value'        => '',
                'position'     => '',
                'is_visible'   => 1,
                'is_variation' => 0,
                'is_taxonomy'  => 1
            ];

            foreach( $terms as $value ){
                $term_name = ucfirst($value);
                $term_slug = sanitize_title($value);

                if(! term_exists($value, $taxonomy) ) {
                    $insert_term = wp_insert_term($term_name, $taxonomy, ['slug' => $term_slug]);
                }

                $set_post_term = wp_set_post_terms($product_id, $term_name, $taxonomy, true);
            }
        }

        update_post_meta($product_id, '_product_attributes', $product_attributes);
    }

    public function create_brand($product_id)
    {
        $brand = apply_filters('cova_sync_product_update_brands', $this->data['brand'], $product_id, $this);

        if ($brand === false) {
            return;
        }

        $brand_slug = sanitize_title_with_dashes($brand);
        $brand_term = get_term_by('slug', $brand_slug, 'product_brand');

        wp_set_object_terms($product_id, "", 'product_brand'); // remove existing attached brand

        if (isset($brand_term->term_id)) {
            wp_set_object_terms($product_id, $brand_term->term_id, 'product_brand', true);
            return;
        }

        $brand_cat = wp_insert_term(
            $brand, 'product_brand', [
            'slug' => $brand_slug
            ]
        );

        if (!is_wp_error($brand_cat)) {
            wp_set_object_terms($product_id, $brand_cat['term_id'], 'product_brand', true);
        }
    }

    public function add_tags($product_id)
    {
        $tags = apply_filters('cova_sync_product_update_tags', $this->data['terpenes_details'], $product_id, $this);

        if (empty($tags)) {
            return;
        }

        wp_set_object_terms($product_id, "", 'product_tag'); // remove existing attached brand

        foreach ($tags as $tag) {
            $tag_slug = sanitize_title_with_dashes($tag);
            $tag_term = get_term_by('slug', $tag_slug, 'product_tag');

            if (isset($tag_term->term_id)) {
                wp_set_object_terms($product_id, $tag_term->term_id, 'product_tag', true);
            }

            $tag_cat = wp_insert_term(
                $tag, 'product_tag', [
                'slug' => $tag_slug
                ]
            );

            if (!is_wp_error($tag_cat)) {
                wp_set_object_terms($product_id, $tag_cat['term_id'], 'product_tag', true);
            }
        }
    }

    public function create_category($product_id)
    {
        $categories = (!empty($this->data['categories']))? $this->data['categories'] : [];
        $cats = apply_filters('cova_sync_product_update_categories', $categories, $product_id, $this);

        if (empty($cats)) {
            return;
        }

        $product_category = new Cova_Product_Category();
        $product_category->update_product_category(
            [
            'product_id' => $product_id,
            'categories' => $cats
            ]
        );
    }

    public function save_wcmlim_data($product_id)
    {
        $wcmlim_data = apply_filters(
            'cova_sync_product_update_wcmlim', [
            'location_pricing'  => $this->data['pricing']['location_pricing'],
            'location_stocks'   => $this->data['stocks']['location_stocks']
            ], $product_id, $this->data, $this
        );

        foreach ($wcmlim_data as $meta_key => $meta_value) {
            if ($meta_key === 'location_pricing') {
                foreach ($meta_value as $location_id => $price) {
                    $location = cova_get_wc_location_by_cova_location_id($location_id);
                    cova_update_product_location_regular_price($product_id, $location->term_id, $price['RegularPrice']);
                    cova_update_product_location_sale_price($product_id, $location->term_id, $price['OverridePrice']);
                }
            }

            if ($meta_key === 'location_stocks') {
                foreach ($meta_value as $location_id => $quantity) {
                    $location = cova_get_wc_location_by_cova_location_id($location_id);
                    cova_update_product_location_stock($product_id, $location->term_id, $quantity);
                }
            }
        }
    }

    public function get_updated_product_info($product_id)
    {
        $cova_catalog_id = get_post_meta($product_id, 'cova_catalog_id', true);
        $cova_slug = get_post_meta($product_id, 'cova_slug', true);
        $cova_url = 'https://hub.covasoft.net/#CatalogManager/products/'. $cova_catalog_id .'/'. $cova_slug;
        $wc_url = get_the_permalink($product_id);

        return [
            'name' => get_the_title($product_id),
            'url'  => '<a href="'. $wc_url .'" target="_blank">'. $wc_url .'</a>',
            'type' => get_post_type($product_id),
            'cova_details' => [
                'catalog_id' => $cova_catalog_id,
                'slug_id'     => $cova_slug,
                'url'          => '<a href="'. $cova_url .'" target="_blank">'. $cova_url .'</a>'
            ]
        ];
    }

    public function upload_attachments($images): array
    {
        $wp_images = [];

        foreach ($images as $image)
        {
            $wp_images[$image['cova_id']] = cova_upload_image($image);
        }

        return $wp_images;
    }

    /**
     * @todo add tiered price id product meta
     */
    public function save_meta_data($product_id)
    {
        $meta_args = [
            'cova_catalog_id'   => $this->data['catalog_id'],
            'cova_slug'         => $this->data['slug'],
        //            'net_weight'        => sanitize_text_field($this->data['weight']['value'])
        ];

        //        if ($this->data['cbd_details']['min'] !== null) {
        //            $meta_args['minimum_cbd_content_percent'] = sanitize_text_field($this->data['cbd_details']['min']);
        //        }
        //        if ($this->data['cbd_details']['max'] !== null) {
        //            $meta_args['maximum_cbd_content_percent'] = sanitize_text_field($this->data['cbd_details']['max']);
        //        }
        //
        //        if ($this->data['thc_details']['min'] !== null) {
        //            $meta_args['minimum_thc_content_percent'] = sanitize_text_field($this->data['thc_details']['min']);
        //        }
        //        if ($this->data['thc_details']['max'] !== null) {
        //            $meta_args['minimum_thc_content_percent'] = sanitize_text_field($this->data['thc_details']['max']);
        //        }
        //
        //        if ($this->data['strain_details'] !== null) {
        //            $meta_args['plant_type'] = sanitize_text_field($this->data['strain_details']);
        //        }

        $meta_args['cova_specifications'] = $this->data['specifications'];

        $metadata = apply_filters('cova_sync_product_update_metadata', $meta_args, $product_id, $this->data, $this);

        foreach ($metadata as $meta_key => $meta_val) {
            update_post_meta($product_id, $meta_key, $meta_val);
        }
    }

    //    public function save_field_mapping($fields)
    //    {
    //        $existing_fields = get_option('cova_product_field_mapping');
    //        $existing_fields = (is_array($existing_fields))? $existing_fields : [];
    //
    //        foreach ($fields as $key => $field_name) {
    //            $existing_fields[$key] = $field_name;
    //        }
    //
    //        update_option('cova_product_field_mapping', $existing_fields);
    //    }
}
