<?php

namespace Cova_Integration\Sync;

use CovaAPI\Location as API_Location;

class Locations
{
    public $locations;

    public function run()
    {
        $locations = new API_Location();
        $this->locations = $locations;
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->locations, $name], $param);

        return json_decode($data, true);
    }

    public function get_all_locations()
    {
        $location_data = $this->all();
        $location_data = $this->group_locations_by_id($location_data);        

        return $location_data;
    }

    public function group_locations_by_id($data)
    {
        $new_items = [];

        foreach ($data as $location) {
            $new_items[$location['Id']] = $location;
        }

        return $new_items;
    }

    public function get_active_locations()
    {
        $locations_data = $this->all();

        $locations = [];

        foreach ($locations_data as $location) {
            if ($location['LocationStatus'] === 'Active') {
                $locations[] = [
                 'id' => $location['Id'],
                 'slug' => sanitize_title_with_dashes($location['Id'] .'-'. $location['Address']['City']),
                 'name' => $location['Name'],
                 'address' => $location['Address'],
                 'phone' => $location['StorePhoneNumbers']
                ];
            }            
        }

        return $locations;        
    }

    public function get_active_location_ids()
    {
        $locations_data = $this->all();

        $locations = [];

        foreach ($locations_data as $location) {
            if ($location['LocationStatus'] === 'Active') {
                $locations[] = $location['Id'];
            }            
        }

        return $locations;        
    }

    // public function get_term_location_by_slug($location_slug)
    // {
    //     $location = new \WP_Term_Query([
            
    //     ]);
    // }
}
