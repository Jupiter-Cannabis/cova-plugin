<?php

namespace Cova_Integration\Sync;

use CovaAPI\PurchaseLimits as API;

class Purchase_Limits
{
    public $api;

    public $locationId;

    public $body;

    public $customerType = 'Recreational'; // Recreational/Medical

    public static $weightUnits = ['mg', 'kg', 'lbs', 'oz'];

    public $gauges;

    public $errors;

    public function run()
    {
        $this->api = new API();
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->api, $name], $param);

        return json_decode($data, true);
    }

    /**
     * Get transaction limits by calling API
     */
    public function getTransactionLimits($locationId, $product = null, $quantity = null)
    {
        $this->locationId = $locationId;

        $this->setCustomerType();
        $this->createBody($product, $quantity);

        return $this->byLocationId($this->locationId, $this->body);
    }

    /**
     * Create API call request body
     */
    public function createBody($newProduct = null, $newQuantity = null)
    {
        $this->body = [
            'customer' => [
                'customerType' => [
                    'type' => $this->customerType
                ]
            ],
            'lineItems' => []
        ];

        if ($newProduct) {
            $this->addLineItem($newProduct, $newQuantity);
        }

        $cart_items = WC()->cart->get_cart();

        foreach($cart_items as $cart_item) {
            $product  = $cart_item['data'];
            $quantity = $cart_item['quantity'];

            $this->addLineItem($product, $quantity);
        }
    }

    /**
     * Set customer type
     */
    public function setCustomerType()
    {
        $dabber_cart_limits = get_option('dabber_cart_limits');

        if (isset($dabber_cart_limits['customer_type'])) {
            $this->customerType = $dabber_cart_limits['customer_type'];
        }
    }

    /**
     * Add product into line items in request's body
     */
    private function addLineItem($product, $quantity)
    {
        $product_id   = $product->get_id();
        $product_name = $product->get_name();

        // Get COVA product ID and specifications
        $cova_catalog_id     = get_post_meta($product_id, 'cova_catalog_id', true);
        $cova_specifications = get_post_meta($product_id, 'cova_specifications', true);

        // Get retail marijuana product type
        $rmpt = self::getRMPT($cova_specifications);

        if (!$rmpt) {
            return;
        }

        // Create product specifications
        $specifications = [];

        $product_net_weight = self::getNetWeight($cova_specifications);
        if ($product_net_weight) {
            $specifications[] = [
                'field'             => $product_net_weight['DisplayName'],
                'value'             => $product_net_weight['Value'],
                'specificationUnit' => $product_net_weight['Unit']
            ];
        }

        $product_thc_content = self::getTHCContent($cova_specifications);
        if ($product_thc_content) {
            $specifications[] = [
                'field'             => $product_thc_content['DisplayName'],
                'value'             => $product_thc_content['Value'],
                'specificationUnit' => $product_thc_content['Unit']
            ];
        }

        // Create product quantity
        $product_equivalent_to = self::getEquivalentTo($cova_specifications);
        if ($product_equivalent_to) {
            $quantity = [
                'type'         => 'Gram',
                'gramQuantity' => $product_equivalent_to['Value'] * $quantity
            ];
        } else {
            $quantity = [
                'type'         => 'Each',
                'eachQuantity' => $quantity
            ];
        }

        // Create product details body
        $body_item = [
            'catalogId'      => $cova_catalog_id,
            'rmpt'           => $rmpt,
            'specifications' => $specifications,
            'quantity'       => $quantity,
            'productName'    => $product_name
        ];

        $this->body['lineItems'][] = $body_item;
    }

    /**
     * Get product specifications
     */
    private static function getSpecificationDetails($specifications)
    {
        $details = false;

        if (isset($specifications['other']) && !empty($specifications['other'])) {
            $details = $specifications['other'];
        }

        if (isset($specifications['details']) && !empty($specifications['details'])) {
            $details = $specifications['details'];
        }

        if (!$details) {
            return false;
        }

        return $details;
    }

    /**
     * Get retail marijuana product type from product specifications
     */
    private static function getRMPT($specifications)
    {
        $details = self::getSpecificationDetails($specifications);

        if (!$details) {
            return false;
        }

        $rmpt      = 'retail-marijuana-product-type';
        $keys      = array_keys($details);
        $rmpt_keys = preg_grep('/'.$rmpt.'/i', $keys);

        if (empty($rmpt_keys)) {
            return false;
        }

        $rmpt_key = reset($rmpt_keys);

        if (!isset($details[$rmpt_key]['Value'])) {
            return false;
        }

        return $details[$rmpt_key]['Value'];
    }

    /**
     * Get product net weight from specifications
     */
    private static function getNetWeight($specifications)
    {
        $details = self::getSpecificationDetails($specifications);

        if (!$details) {
            return false;
        }

        foreach (self::$weightUnits as $unit) {
            if (isset($details['net-weight-'.$unit])) {
                return $details['net-weight-'.$unit];
            }
        }

        if (isset($details['net-weight'])) {
            return $details['net-weight'];
        }

        return false;
    }

    /**
     * Get product equivalency from specifications
     */
    private static function getEquivalentTo($specifications)
    {
        $details = self::getSpecificationDetails($specifications);

        if (!$details) {
            return false;
        }

        if (!isset($details['equivalent-to'])) {
            return false;
        }

        return $details['equivalent-to'];
    }

    /**
     * Get product THC content from specifications
     */
    private static function getTHCContent($specifications)
    {
        $details = self::getSpecificationDetails($specifications);

        if (!$details) {
            return false;
        }

        if (!isset($details['thc-content'])) {
            return false;
        }

        return $details['thc-content'];
    }
}
