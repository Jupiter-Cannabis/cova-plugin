<?php

namespace Cova_Integration;

class Inventory_Updater
{
    private $api;
    private $prev_days_sync = 2;
    private $items_to_update = [];
    private $total_update_num = 0;
    private $update_batch_num = 100;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_cova_inventory_sync_update_inventory', [$this, 'ajax_update_inventory']);
        add_action('wp_ajax_cova_inventory_sync_full_update_inventory', [$this, 'ajax_full_update_inventory']);
        
        add_action('init', [$this, 'run_manual_sync']);
        add_action('init', [$this, 'validate_inventory_sync']);
        add_action('cova_update_inventory', [$this, 'initialize_update_inventory']);
        add_action('cova_full_update_inventory', [$this, 'initialize_full_update_inventory']);
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {        
//            wp_enqueue_script('cova-inventory-sync', COVA_INTEGRATION_URI .'/assets/js/inventory-sync.js', [], null, true);
        }
    }

    public function run_manual_sync()
    {
        if (!isset($_GET['_dabber_run_inventory_sync'])) {
            return;
        }

        do_action('cova_update_inventory', 'manual');

        die();
    }

    public function validate_inventory_sync()
    {
        if (!is_user_logged_in() || !is_admin()) {
            return;
        }

        if (!isset($_GET['_dabber_validate_inventory_sync'])) {
            return;
        }

        $update_items = [];

        $from = strtotime(date('Y-m-d', strtotime('-'. $this->prev_days_sync .' day', strtotime(gmdate('Y-m-d')))));
        $to = strtotime('+1 day', strtotime(gmdate('Y-m-d')));
        $inventory = Cova_Data_Manager::get_global_data('inventory');

        foreach ($inventory as $location_id => $items) {
            foreach ($items as $catalog_id => $item) {
                $updated_date = date("Y-m-d", strtotime($item['UpdatedDateUtc']));
                $updated_date = strtotime($updated_date);
                $update_key = $updated_date .'-'. $location_id .'-'. $catalog_id;

                if ($updated_date >= $from && $updated_date <= $to) {

                    $product = dabber_get_product_by_catalog_id($catalog_id);

                    if (!$product) {
                        continue;
                    }

                    $location_term = cova_get_wc_location_by_cova_location_id($location_id);
                    $wc_quantity = dabber_get_product_location_stock_quantity($product->get_id(), $location_term->term_id);
                    
                    $update_items[$update_key] = [
                     'catalog_id' => $catalog_id,
                     'location_id' => $location_id,
                     'quantity' => $item['Quantity'],
                     'woocommerce' => [
                      'product_id' => $product->get_id(),
                      'name' => $product->get_name(),
                      'quantity' => $wc_quantity,
                      'is_cova_qty_matched' => ($item['Quantity'] == $wc_quantity)
                     ],
                     'update_key' => $update_key
                    ];
                }
            }
        }

        !d($update_items);

        die();
    }

    public function ajax_update_inventory()
    {
        // force reset log files to get the latest data.
        // Cova_Data_Manager::store_inventory_data('inventory');
        // Cova_Data_Manager::remove_stored_data('inventory-sync');
        // Cova_Data_Manager::remove_stored_data('updated-inventory-items');

        dabber_set_sync_on();

        if (isset($_POST['params']['clear_log_files']) && $_POST['params']['clear_log_files'] == 'yes') {
            Cova_Data_Manager::remove_stored_data('updated-inventory-items');
        }

        do_action('cova_update_inventory');

        if (empty($this->items_to_update)) {
            wp_send_json_success(
                [
                'status' => 'complete',
                'message' => 'No more items to update',
                'message_type' => 'success'
                ], 200
            );
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'message' => 'Successfully updated '. count($this->items_to_update) .' product(s)',
            'data' => $this->items_to_update,                
            'total_update' => $this->total_update_num,
            'total_synced' => count($this->items_to_update),
            'message_type' => 'output'
            ], 200
        );
    }

    public function ajax_full_update_inventory()
    {
        dabber_set_sync_on();

        if (isset($_POST['params']['clear_log_files']) && $_POST['params']['clear_log_files'] == 'yes') {            
            Cova_Data_Manager::remove_stored_data('full-updated-inventory-items');
        }

        update_option('dabber_disable_cova_update_inventory', 'yes');

        do_action('cova_full_update_inventory');

        if (!empty($this->items_to_update)) {

            wp_send_json_success(
                [
                'status' => 'ok',
                'message' => 'Successfully updated '. count($this->items_to_update) .' product(s)',
                'data' => $this->items_to_update,                
                'total_update' => $this->total_update_num,
                'total_synced' => count($this->items_to_update),
                'message_type' => 'output'
                ], 200
            );
        }    

        update_option('dabber_disable_cova_update_inventory', 'no');

        wp_send_json_success(
            [
            'status' => 'complete',
            'message' => 'No more items to update',
            'message_type' => 'success'
            ], 200
        );
    }

    public function initialize_full_update_inventory()
    {
        include_once ABSPATH .'wp-load.php';

        $items_to_update = $this->get_items_to_update_full_method();

        // Sync complete, remove data files.
        if (empty($items_to_update)) {
            Cova_Data_Manager::remove_stored_data('full-inventory-sync'); 
            $this->items_to_update = [];
            return [];
        }

        $this->do_update_inventory($items_to_update);
    }

    public function initialize_update_inventory($sync_type)
    {
        global $cova_current_sync_running;

        $iterationId = md5(microtime());
        $start = microtime(true);
        dabber_cron_logger2('EVENT - inventory update', $iterationId);

        try
        {
            $cova_current_sync_running = 'inventory_update';
            include_once ABSPATH .'wp-load.php';
            
            $items_to_update = $this->get_items_to_update();

            // Sync complete, remove data files.
            if (empty($items_to_update)) {
                Cova_Data_Manager::remove_stored_data('inventory-sync'); 
                $this->items_to_update = [];
                $duration = microtime(true) - $start;
                dabber_cron_logger2('EVENT - inventory update', $iterationId, $duration);
                return [];
            }

            $this->do_update_inventory($items_to_update);
        }
        catch(\Exception $e)
        {
            $duration = microtime(true) - $start;
            dabber_cron_logger2('EVENT - inventory update failed. ' . $e->getMessage(), $iterationId, $duration, false);
            throw $e;
        }
        $duration = microtime(true) - $start;
        dabber_cron_logger2('EVENT - inventory update', $iterationId, $duration);
        
    }

    public function do_update_inventory($items_to_update)
    {
        $updated_items = [];

        foreach ($items_to_update[0] as $key => $item) {

            $product = dabber_get_product_by_catalog_id($item['catalog_id']);

            if (!$product) {
                continue;
            }

            do_action('cova_sync_before_inventory_update', $product, $this);

            $product_id = $product->get_id();
            $available_locations = cova_get_available_locations();
            $location_ids = [];        

            foreach ($available_locations as $term) {
                $cova_location_id = get_term_meta($term['term_id'], 'location_id', true);
                $location_ids[$cova_location_id] = $term['term_id'];
            }

            cova_update_product_location_stock($product_id, $location_ids[$item['location_id']], $item['quantity']);

            $total_stock = 0;

            foreach ($location_ids as $loc_id => $term_id) {
                $loc_qty = dabber_get_product_location_stock_quantity($product_id, $term_id);
                $total_stock += $loc_qty;
            }

            //$oos_threshold = (int) get_option('woocommerce_notify_no_stock_amount');
            $oos_threshold = 0;

            if ($total_stock > $oos_threshold) {
                $product->set_stock_status('instock');
            } else {
                $product->set_stock_status('outofstock');
            }

            $filtered_total_stock = apply_filters('dabber_set_product_total_stock', $total_stock, $product, $item);
            $product->set_stock_quantity($filtered_total_stock);
            $product->save();

            $this->hack_product_visibility($product);

            $parent_id = $product->get_parent_id();

            if ($parent_id > 0) {
                $this->update_parent_stock_qty($parent_id);
            }

            $updated_location_quantity = dabber_get_product_location_stock_quantity($product_id, $location_ids[$item['location_id']]);

            if ($updated_location_quantity == $item['quantity']) {
                $updated_items[] = $item['update_key'];
            }

            do_action('cova_sync_after_inventory_update', $product, $item, $this);
        }

        $this->items_to_update = $items_to_update[0];

        //        if ($sync_type === 'manual') {
        //            d(['update_inventory' => $items_to_update[0]]);
        //        }

        $this->insert_updated_inventory_items($updated_items);
        $this->reset_to_update_items($items_to_update);
    }

    public function update_variation_stock_quantity()
    {

    }

    /**
     * Hack to fix bug where sometimes synced products visibility
     * is not working properly.
     */
    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }

    /**
     * Unset previously updated batch
     */
    public function reset_to_update_items($items)
    {
        if (empty($items)) {
            return false;
        }

        unset($items[0]);

        Cova_Data_Manager::store_data('inventory-sync', array_values($items));
    }

    public function update_parent_stock_qty($parent_id)
    {
        $parent = wc_get_product($parent_id);
        $variations = $parent->get_children();        
        $locations = cova_get_all_wc_locations();        

        $total_stock = 0;
        $location_total_qty_arr = [];

        foreach ($variations as $key => $variation_id) {
            
            $location_total_qty = 0;

            foreach ($locations as $termkey => $term) {                
                $loc_qty = (int) get_post_meta($variation_id, 'wcmlim_stock_at_'. $term['term_id'], true);

                if (isset($location_total_qty_arr[$term['term_id']])) {
                    $location_total_qty_arr[$term['term_id']] += $loc_qty;
                } else {
                    $location_total_qty_arr[$term['term_id']] = $loc_qty;
                }
                
                $location_total_qty += $loc_qty;
            }

            $total_stock += $location_total_qty;
        }

        foreach ($locations as $termkey2 => $term2) {
            cova_update_product_location_stock($parent->get_id(), $term2['term_id'], $location_total_qty_arr[$term2['term_id']]);
        }

        //        $oos_threshold = get_option('woocommerce_notify_no_stock_amount');
        $oos_threshold = 0;

        if ($total_stock > $oos_threshold) {
            $parent->set_stock_status('instock');
        } else {
            $parent->set_stock_status('outofstock');
        }

        $parent->set_stock_quantity($total_stock);
        $parent->set_catalog_visibility('visible');
        $parent->save();
    }

    public function get_items_to_update_full_method()
    {
        $items_to_update = Cova_Data_Manager::get_stored_data('full-inventory-sync');

        if (is_array($items_to_update) && !empty($items_to_update)) {
            return $items_to_update;
        }

        $updated_items = $this->get_updated_inventory_items('updated-inventory-items-full-method');
        $inventory = Cova_Data_Manager::get_global_data('inventory');

        foreach ($inventory as $location_id => $items) {
            foreach ($items as $catalog_id => $item) {

                $updated_date = date("Y-m-d H:i:s", strtotime($item['UpdatedDateUtc']));
                $updated_date = strtotime($updated_date);
                $update_key = $updated_date .'-'. $location_id .'-'. $catalog_id;

                if (in_array($update_key, $updated_items)) {
                    continue;
                }
                
                $update_items[$update_key] = [
                'catalog_id' => $catalog_id,
                'location_id' => $location_id,
                'quantity' => $item['Quantity'],
                'update_key' => $update_key
                ];
            }
        }

        $this->total_update_num = count($update_items);

        $update_items = array_chunk($update_items, $this->update_batch_num);

        Cova_Data_Manager::store_data('full-inventory-sync', $update_items);
        Cova_Data_Manager::save_storage_timestamp('updated-inventory-items-full-method');

        return $update_items;                
    }    

    public function get_items_to_update()
    {        
        $items_to_update = Cova_Data_Manager::get_stored_data('inventory-sync');

        if (is_array($items_to_update) && !empty($items_to_update)) {
            return apply_filters('dabber_inventory_sync_process_update_items', $items_to_update);
        }

        $updated_items = $this->get_updated_inventory_items('updated-inventory-items');
        $update_items = [];

        $from = strtotime(date('Y-m-d', strtotime('-'. $this->prev_days_sync .' day', strtotime(gmdate('Y-m-d')))));
        $to = strtotime('+1 day', strtotime(gmdate('Y-m-d')));
        $inventory = Cova_Data_Manager::get_global_data('inventory');

        foreach ($inventory as $location_id => $items) {
            foreach ($items as $catalog_id => $item) {
                $updated_date = date("Y-m-d H:i:s", strtotime($item['UpdatedDateUtc']));
                $updated_date = strtotime($updated_date);
                $update_key = $updated_date .'-'. $location_id .'-'. $catalog_id;

                if (in_array($update_key, $updated_items)) {
                    continue;
                }

                if ($updated_date >= $from && $updated_date <= $to) {
                    $update_items[$update_key] = [
                    'catalog_id' => $catalog_id,
                    'location_id' => $location_id,
                    'quantity' => $item['Quantity'],
                    'update_key' => $update_key
                    ];
                }
            }
        }

        $this->total_update_num = count($update_items);

        $update_items = array_chunk($update_items, $this->update_batch_num);

        Cova_Data_Manager::store_data('inventory-sync', $update_items);
        Cova_Data_Manager::save_storage_timestamp('updated-inventory-items');

        return apply_filters('dabber_inventory_sync_process_update_items', $update_items);
    }

    public function insert_updated_inventory_items($items)
    {
        $updated_items = Cova_Data_Manager::get_stored_data('updated-inventory-items');
        $updated_items = (is_array($updated_items))? $updated_items : [];
        $new_data = array_merge($updated_items, $items);

        Cova_Data_Manager::store_data('updated-inventory-items', $new_data);
    }

    public function get_updated_inventory_items($log_file)
    {
        $updated_items = Cova_Data_Manager::get_stored_data($log_file);

        if ($updated_items === false) {
            return []; 
        }

        $saved_date = Cova_Data_Manager::get_storage_timestamp($log_file);
        $saved_date = strtotime($saved_date);

        if ($saved_date > strtotime('-3 day')) {
            return $updated_items;
        }

        Cova_Data_Manager::remove_stored_data($log_file);

        return [];
    }
}
