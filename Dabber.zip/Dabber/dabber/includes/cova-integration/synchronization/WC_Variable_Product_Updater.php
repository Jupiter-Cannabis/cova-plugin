<?php

namespace Cova_Integration;

class WC_Variable_Product_Updater
{
    public $data;
    public $product;

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function update()
    {
        $this->product = $this->data['product'];

        $this->product->set_date_created($this->data['date_added']);
        $this->product->set_name($this->data['title']);
        $this->product->set_sku($this->data['sku']);
        $this->product->set_description($this->data['long_description']);
        $this->product->set_short_description($this->data['short_description']);
        $this->product->set_status('publish');
        $this->product->set_catalog_visibility('visible');
        $this->product->set_featured(false);

        $this->product->set_manage_stock('yes');

        $stock_qty = (int) $this->data['stocks']['total_stock'];        
        $this->product->set_stock_quantity($stock_qty);

        $stock_status = 'outofstock';
        if ($stock_qty > 0) {
            $stock_status = 'instock';
        }

        $this->product->set_stock_status($stock_status);

        $this->upload_attachments();

        $product_id = $this->product->save();

        $this->hack_product_visibility($this->product);

        //        if ($this->data['featured_image'] !== false) {
        //            set_post_thumbnail( $product_id, $this->data['featured_image'] );
        //        }

        update_post_meta($product_id, 'cova_slug', $this->data['cova_slug']);

        foreach ($this->data['stocks']['location_stocks'] as $location_id => $quantity) {
            $location_term = cova_get_wc_location_by_cova_location_id($location_id);
            cova_update_product_location_stock($product_id, $location_term->term_id, $quantity);
        }

        $this->create_variation_attributes($this->data['attributes'], $product_id);

        if (!empty($this->data['categories'])) {
            $this->create_category($product_id, $this->data['categories']);
        }

        if (!empty($this->data['brands'])) {
            $this->create_brand($product_id, $this->data['brands']);
        }

        do_action('dabber_sync_variable_product_after_update', $this);

        return $product_id;       
    }

    public function upload_attachments()
    {
        if ($this->data['featured_image'] !== false) {
            $attachment_id = cova_upload_image(
                [
                'cova_id' => $this->data['featured_image']['full']['cova_id'],
                'cova_url' => $this->data['featured_image']['full']['url']
                ]
            );

            $this->product->set_image_id($attachment_id);
        }
    }

    public function create_variation_attributes($attributes, $product_id)
    {        
        $product_attributes = [];

        foreach( $attributes as $key => $terms ) {
            $taxonomy = wc_attribute_taxonomy_name($key);

            if (!taxonomy_exists($taxonomy)) {
                if($this->create_custom_product_attribute($key) !== true) {
                    return;
                }
            }

            $product_attributes[$taxonomy] = [
                'name'         => $taxonomy,
                'value'        => '',
                'position'     => '',
                'is_visible'   => 1,
                'is_variation' => 1,
                'is_taxonomy'  => 1
            ];

            foreach( $terms as $value ){
                $term_name = ucfirst($value);
                $term_slug = sanitize_title($value);

                if(! term_exists($value, $taxonomy) ) {          
                    wp_insert_term($term_name, $taxonomy, ['slug' => $term_slug]);
                }

                wp_set_post_terms($product_id, $term_name, $taxonomy, true);
            }
        }

        update_post_meta($product_id, '_product_attributes', $product_attributes);        
    }

    public function create_custom_product_attribute($label_name)
    {
        global $wpdb;

        $slug = sanitize_title($label_name);

        if (strlen($slug) >= 28 ) {
            return new \WP_Error('invalid_product_attribute_slug_too_long', sprintf(__('Name "%s" is too long (28 characters max). Shorten it, please.', 'woocommerce'), $slug), array( 'status' => 400 ));
        } elseif (wc_check_if_attribute_name_is_reserved($slug) ) {
            return new \WP_Error('invalid_product_attribute_slug_reserved_name', sprintf(__('Name "%s" is not allowed because it is a reserved term. Change it, please.', 'woocommerce'), $slug), array( 'status' => 400 ));
        } elseif (taxonomy_exists(wc_attribute_taxonomy_name($label_name)) ) {
            return new \WP_Error('invalid_product_attribute_slug_already_exists', sprintf(__('Name "%s" is already in use. Change it, please.', 'woocommerce'), $label_name), array( 'status' => 400 ));
        }

        $data = array(
            'attribute_label'   => $label_name,
            'attribute_name'    => $slug,
            'attribute_type'    => 'select',
            'attribute_orderby' => 'menu_order',
            'attribute_public'  => 0, // Enable archives ==> true (or 1)
        );

        $results = $wpdb->insert("{$wpdb->prefix}woocommerce_attribute_taxonomies", $data);

        if (is_wp_error($results) ) {
            return new \WP_Error('cannot_create_attribute', $results->get_error_message(), array( 'status' => 400 ));
        }

        $id = $wpdb->insert_id;

        do_action('woocommerce_attribute_added', $id, $data);

        wp_schedule_single_event(time(), 'woocommerce_flush_rewrite_rules');

        delete_transient('wc_attribute_taxonomies');

        return true;
    }
    
    /**
     * Hack to fix bug where sometimes synced products visibility
     * is not working properly.
     */
    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }

    public function create_category($product_id, $categories)
    {        
        foreach ($categories as $catalog_id => $data) {
            $product_category = new Cova_Product_Category();
            $product_category->update_product_category(
                [
                'product_id' => $product_id,
                'categories' => $data
                ]
            );
        }
    }

    public function create_brand($product_id, $brands)
    {
        foreach ($brands as $key => $brand) {
            
            $brand_slug = sanitize_title_with_dashes($brand);
            $brand_term = get_term_by('slug', $brand_slug, 'product_brand');

            if (isset($brand_term->term_id)) {
                wp_set_object_terms($product_id, $brand_term->term_id, 'product_brand', true);
                return;
            }

            $brand_cat = wp_insert_term(
                $brand, 'product_brand', [
                'slug' => $brand_slug
                ]
            );

            if (!is_wp_error($brand_cat)) {
                      wp_set_object_terms($product_id, $brand_cat['term_id'], 'product_brand', true);
            }
        }
    }

}
