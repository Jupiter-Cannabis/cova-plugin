<?php

namespace Cova_Integration;

class WC_Cova_Category_Mapping
{
    public function run()
    {
        if (!is_admin()) {
            return;
        }

        if (isset($_GET['regenerate_product_categories'])) {
            add_action('init', [$this, 'regenerate_product_categories']);
        }            

        if (isset($_GET['set_cova_wc_category_mapping'])) {
            add_action('init', [$this, 'set_cova_wc_category_mapping']);
        }
    }

    public function get_cova_possible_categories()
    {        
        $data = Sync::get_stored_data('grouped_catalog_items');

        if ($data !== false && !empty($data)) {
            return $data;
        }

        $all_items = $this->catalog->items();
        $catalog_ids = [];

        foreach ($all_items as $key => $item) {
            $catalog_ids[] = $item['CatalogItemId'];
        }

        $grouped_catalog_ids = array_chunk($catalog_ids, 450, false);
        $cova_categories = [];


        foreach ($grouped_catalog_ids as $key => $catalog_id_items) {

            $grouped_products = $this->catalog->bulk(
                [
                'CatalogItemIds' => $catalog_id_items
                ]
            );            

            foreach ($grouped_products['CatalogItems'] as $catalog_id => $catalog_item) {

                $grouped_cats = [];

                if (isset($catalog_item['CanonicalClassification']['Name'])) {
                    $grouped_cats[] = $catalog_item['CanonicalClassification']['Name'];
                }

                if (isset($catalog_item['Specifications']) && !empty($catalog_item['Specifications'])) {
                    foreach ($catalog_item['Specifications'] as $key => $spec) {
                        if ($spec['Name'] === 'Online Menu') {
                            foreach ($spec['Fields'] as $field) {
                                if ($field['DisplayName'] === 'Online Menu Category') {
                                          $grouped_cats[] = $field['Value'];
                                }
                            }
                        }
                    }
                }

                if (count($grouped_cats) > 1) { // only include items with sub category
                    $cova_categories[] = implode(' >>> ', $grouped_cats);
                }                
            }        
        }

        $cova_categories = array_unique($cova_categories);

        Sync::store_data('grouped_catalog_items', $cova_categories);

        return $cova_categories;
    }

    public function set_cova_wc_category_mapping()
    {
        $this->initialize_sync_classes();

        $classifications = new CovaAPI\ClassificationTree();

        $classification_tree_id = (isset($_GET['classification_tree_id']) && $_GET['classification_tree_id'] !== '')? $_GET['classification_tree_id'] : false;

        if ($classification_tree_id === false) {
            die('No Classification Tree ID is set!');
        }

        $items = $classifications->get_classifications($classification_tree_id);
        $items = json_decode($items, true);  // cova classification items

        if (!isset($items['Classifications']) || empty($items['Classifications'])) {
            die('No existing cova categories to map.');
        }

        $mapping = $this->save_cova_wc_mapping();

        echo '<form method="post" action="">';

        echo '<h5>Top Level Categories</h5>';
        foreach ($items['Classifications'] as $key => $item) {

            $item_key = sanitize_title_with_dashes($item['Name']);

            echo '<div>';                
            echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item['Name'] .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 0) .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 1) .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 2) .'">';
            echo '</div>';
        }

        $cova_categories = $this->get_cova_possible_categories();

        echo '<h5>Online Menu Categories</h5>';
        foreach ($cova_categories as $key => $item) {

            $item_key = str_replace(' >>> ', '-', $item);
            $item_key = sanitize_title_with_dashes($item_key);

            echo '<div>';                
            echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 0) .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 1) .'">';
            echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 2) .'">';
            echo '</div>';
        }        
        
        echo '<p><input type="submit" name="save_cova_wc_mapping" value="Save Mapping"></p>';
        echo '</form>';

        die();
    }

    public function get_cova_mapping_value($mapping, $id, $index)
    {
        if (!isset($mapping[$id][$index])) {
            return '';
        }

        return $mapping[$id][$index];
    }

    public function save_cova_wc_mapping()
    {
        if (isset($_POST['save_cova_wc_mapping'])) {
            update_option('cova_category_mapping', $_POST['cova_classification']);
        }

        return get_option('cova_category_mapping');
    }

    public function get_all_cova_products_paginated()
    {    
        $page = (isset($_GET['num']))? $_GET['num'] : 1;

        if ($page === 1) {
            Sync::store_data('cova-all-products', []); // always clear data on first load to get the latest result.
        }

        $saved_data = Sync::get_stored_data('cova-all-products');
        
        if ($saved_data !== false && !empty($saved_data)) {
            return $saved_data;
        }

        $all_items = $this->catalog->items();
        $grouped_items = [];

        foreach ($all_items as $key => $item) {
            $grouped_items[] = $item['CatalogItemId'];
        }

        $grouped_items = array_chunk($grouped_items, 50);

        array_unshift($grouped_items, "");
        unset($grouped_items[0]);

        Sync::store_data('cova-all-products', $grouped_items);

        return $grouped_items;
    }

    public function get_product_ids_by_catalog_ids($catalog_ids)
    {
        global $wpdb;

        $catalog_ids = implode("','", $catalog_ids);
        $sql = "SELECT * FROM {$wpdb->prefix}postmeta WHERE meta_key='cova_catalog_id' && meta_value IN('$catalog_ids')";

        $result = $wpdb->get_results($sql);

        if (empty($result)) {
            return [];
        }

        $product_ids = [];

        foreach ($result as $key => $item) {
            $product_ids[$item->post_id] = $item->meta_value;
        }

        return $product_ids;
    }

    public function get_wc_categories_structure($categories)
    {
        $last_slug = '';
        $new_category_struct = [];

        if (!empty($categories)) {
            $slug = [];
            foreach ($categories as $category) 
            {
                $category = trim($category);
                $item_slug = sanitize_title_with_dashes($category);
                $slug[] = $item_slug;
                $slug_key = implode('-', $slug);

                $new_category_struct[$slug_key] = [
                 'slug' => $item_slug,
                 'name' => sanitize_text_field($category),
                 'parent_slug' => $last_slug
                ];

                $last_slug = $slug_key;
            }
        }    

        return $new_category_struct;    
    }

    public function clear_product_category_sync_storage()
    {
        if (!isset($_GET['clear_product_category_sync_storage'])) {
            return;
        }

        Sync::store_data('cova-all-products', []);
    }

    public function get_products_and_categories()
    {
        $page = (isset($_GET['num']))? $_GET['num'] : 1;
        $catalog_ids = $this->get_all_cova_products_paginated();

        echo "<h3>Number of pages: ". count($catalog_ids) ."</h3>";

        if ($page >= count($catalog_ids)) {
            echo "Sync complete!";            
        }

        if ($page > count($catalog_ids)) {
            die();
        }        

        $catalog_ids = $catalog_ids[$page];

        echo "<h4>Updated page: ". $page ."</h4>";

        $cova_products = $this->catalog->bulk(
            [
            'CatalogItemIds' => $catalog_ids
            ]
        );            

        if (!isset($cova_products['CatalogItems'])) {
            return [];
        }

        $cova_products = $cova_products['CatalogItems'];
        $wc_products = $this->get_product_ids_by_catalog_ids($catalog_ids);            

        $update_products = [];

        foreach ($wc_products as $product_id => $catalog_id) {
            $product_details = $cova_products[$catalog_id];

            $wc_terms = [];
            $categories = [];

            if (isset($product_details['CanonicalClassification']['Name'])) {
                $categories['classification'] = $product_details['CanonicalClassification']['Name'];
            }

            if (isset($product_details['Specifications']) && !empty($product_details['Specifications'])) {
                foreach ($product_details['Specifications'] as $key => $spec) {

                    if ($spec['Name'] === 'Online Menu') {
                        foreach ($spec['Fields'] as $field) {
                            if ($field['DisplayName'] === 'Online Menu Category') {
                                $categories['online-menu'] = $field['Value'];
                            }
                        }
                    }

                    if ($spec['Name'] === 'Details') {
                        foreach ($spec['Fields'] as $details) {
                            if ($details['DisplayName'] === 'Strain') {
                                $categories['strain'] = $details['Value'];
                            }
                        }
                    }
                }
            }

            $update_products[] = [
            'product_id' => $product_id,
            'catalog_id' => $catalog_id,
            'categories' => $categories
            ];        
        }

        return $update_products;
    }

    public function pre_roll_fix($terms)
    {
        $sub_terms = array_map('trim', explode('-', $terms));
        $new_terms = [];
        foreach ($sub_terms as $key => $term) {
            if ($term === 'Pre Roll') {
                $new_terms[] = 'Pre-Roll';
            } else {
                $new_terms[] = $term;
            }
        }

        return $new_terms;
    }

    public function map_parent_category($product_id, $parent_cat)
    {
        $mapped_categories = get_option('cova_category_mapping');
        $parent_cat = sanitize_title_with_dashes($parent_cat);

        if (!isset($mapped_categories[$parent_cat])) {
            return;
        }

        $category_ids = $this->create_term_array_hierarchy($mapped_categories[$parent_cat]);
        $product = wc_get_product($product_id);
        $parent_id = $product->get_parent_id();

        if ($parent_id > 0) {
            wp_set_object_terms($parent_id, $category_ids, 'product_cat');    
        }

        wp_set_object_terms($product_id, $category_ids, 'product_cat');
    }

    public function map_sub_categories($product_id, $categories)
    {
        $mapped_categories = get_option('cova_category_mapping');
        $submenu_arr = array_map('trim', explode(' - ', $categories['online-menu']));
        $mapped_key  = $categories['classification'] .'-'. implode('-', $submenu_arr);
        $mapped_key  = sanitize_title_with_dashes($mapped_key);

        if (!isset($mapped_categories[$mapped_key])) {
            return;
        }

        $remap_categories = [];

        foreach ($mapped_categories[$mapped_key] as $key => $category) {
            switch ($category) {
            case '{strain}':
                $remap_categories[] = $categories['strain'];
                break;                
            default:
                $remap_categories[] = $category;
                break;
            }
        }

        $remap_categories = array_unique($remap_categories);
        $remap_categories = array_filter($remap_categories);

        $category_ids = $this->create_term_array_hierarchy($remap_categories);
        $product = wc_get_product($product_id);
        $parent_id = $product->get_parent_id();

        if ($parent_id > 0) {
            wp_set_object_terms($parent_id, $category_ids, 'product_cat');    
        }

        wp_set_object_terms($product_id, $category_ids, 'product_cat');
    }

    public function create_term_array_hierarchy($terms)
    {
        $last_term_slug = [];
        $category_ids = [];

        foreach ($terms as $key => $term) {
            
            if ($term === '') {
                continue;
            }
            
            $parent_slug = implode('-', $last_term_slug);
            $prefix_slug = ($parent_slug !== '')? $parent_slug .'-' : '';
            $term_slug   = $prefix_slug . sanitize_title_with_dashes($term);
            $term_name   = sanitize_text_field($term);

            $last_term_slug[] = sanitize_title_with_dashes($term);
            $is_term = get_term_by('slug', $term_slug, 'product_cat');

            if (isset($is_term->term_id)) {
                $category_ids[] = $is_term->term_id;
                continue;
            }

            $parent_id = 0;

            if ($parent_slug !== '') {
                $parent_cat = get_term_by('slug', $parent_slug, 'product_cat');
                if (isset($parent_cat->term_id)) {
                    $parent_id = $parent_cat->term_id;
                }
            }            

            $new_cat = wp_insert_term(
                $term_name, 'product_cat', [
                'parent' => $parent_id,
                'slug' => $term_slug
                ]
            );

            if (! is_wp_error($new_cat) ) {
                      $category_ids[] = $new_cat['term_id'];
            }
        }

        return $category_ids;
    }

    public function regenerate_product_categories()
    {
        $this->initialize_sync_classes();
                
        $update_products = $this->get_products_and_categories();

        foreach ($update_products as $key => $product_item) {

            wp_set_object_terms($product_item['product_id'], "", 'product_cat'); // remove existing attached categories

            if ($product_item['categories']['classification'] !== '') {
                $this->map_parent_category($product_item['product_id'], $product_item['categories']['classification']);
            }
            if ($product_item['categories']['online-menu'] !== '') {
                $this->map_sub_categories($product_item['product_id'], $product_item['categories']);
            }
        }

        $next_page = $_GET['num'] + 1;
        ?>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
            <script type="text/javascript">
                jQuery(document).ready(function()
                {
                    var site_url = '<?php echo get_admin_url() ?>?regenerate_product_categories=1&num=';
                    var page = '<?php echo $next_page ?>';

                    setTimeout(function() {
                        window.location.href = site_url + page;
                    }, 1000);                    
                });
            </script>
        <?php

        die();
    }    
}

// $regenerate = new WC_Cova_Category_Mapping;
// $regenerate->run();
