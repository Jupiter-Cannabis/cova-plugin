<?php

namespace Cova_Integration\Sync;

use CovaAPI\Inventory as API_Inventory;

class Inventory
{
    public $inventory;

    public function run()
    {
        $inventory = new API_Inventory();
        $this->inventory = $inventory;
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->inventory, $name], $param);

        return json_decode($data, true);
    }

    public function get_data()
    {
        return json_decode($this->all(), true);
    }

    public function get_inventory_by_locations($locations)
    {
        $inventory = [];

        foreach ($locations as $key => $location) {
            $inventory[$location['Id']] = $this->all($location['Id']);
        }

        $items_inventory = [];

        foreach ($inventory as $location_id => $items) {
            foreach ($items as $item) {
                $items_inventory[$location_id][$item['Id']] = [
                'Quantity' => $item['Quantity'],
                'UpdatedDateUtc' => $item['UpdatedDateUtc']
                ];
            }            
        }

        return $items_inventory;
    }
}
