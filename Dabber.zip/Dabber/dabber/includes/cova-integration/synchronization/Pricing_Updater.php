<?php

namespace Cova_Integration;


class Pricing_Updater
{
    private $api;
    private $sync_batch_num = 100;
    private $total_update_num;
    private $items_to_update;
    private $prev_days = 2;

    public function __construct($api)
    {
        $this->api = $api;
    }

    public function run()
    {    
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_cova_pricing_sync_update_pricing', [$this, 'ajax_run_sync']);
        add_action('init', [$this, 'run_manual_sync']);
        add_action('cova_update_pricing', [$this, 'update_pricing_init']);

        add_action('admin_init', [$this, 'validate_pricing']);
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {
            wp_enqueue_script('dabber-product-pricing-sync', COVA_INTEGRATION_URI .'/assets/js/pricing-sync.js', [], null, true);
        }
    }

    public function run_manual_sync()
    {
        if (!isset($_GET['_dabber_run_pricing_sync'])) {
            return;
        }

        do_action('cova_update_pricing', 'manual');

        die();
    }

    public function ajax_run_sync()
    {
        dabber_set_sync_on();

        if (isset($_POST['params']['clear_log_files']) && $_POST['params']['clear_log_files'] == 'yes') {
            Cova_Data_Manager::remove_stored_data('updated-pricing-items');
        }

        do_action('cova_update_pricing');

        if (empty($this->items_to_update)) {
            wp_send_json_success(
                [
                'status' => 'complete',
                'message' => 'No more items to update',
                'message_type' => 'success'
                ], 200
            );
        }

        wp_send_json_success(
            [
            'status' => 'ok',
            'message' => 'Successfully updated '. count($this->items_to_update) .' product(s)',
            'data' => $this->items_to_update,                
            'total_update' => $this->total_update_num,
            'total_synced' => count($this->items_to_update),
            'message_type' => 'output'
            ], 200
        );
    }

    public function update_pricing_init($sync_type)
    {
        
        $iterationId = md5(microtime());
        $start = microtime(true);

        try
        {
            //Only record the stats for automatic
            if (!($sync_type === 'manual')) {    
                dabber_cron_logger2('EVENT - pricing update', $iterationId);
            }
            else 
            {
                dabber_cron_logger('EVENT - pricing update');
            }


            include_once ABSPATH .'wp-load.php';

            $items_to_update = $this->get_items_to_update();

            // Sync complete, remove data files.
            if (empty($items_to_update)) {
                Cova_Data_Manager::remove_stored_data('pricing-sync'); 
                $this->items_to_update = [];
                if (!($sync_type === 'manual')) {    
                    $duration = microtime(true) - $start;
                    dabber_cron_logger2('EVENT - pricing update', $iterationId, $duration);
                }
                return [];
            }

            $updated_items = [];
            $sale_product_ids = [];
            $sale_products_handler = [];
            $updated_products_handler = [];

            foreach ($items_to_update[0] as $key => $item) {
                $product = dabber_get_product_by_catalog_id($item['catalog_id']);

                if (!$product) {
                    continue;
                }

                $is_bulk_product = $product->get_meta('is_bulk_product');

                if ($is_bulk_product === 'yes') {
                    continue;
                }

                $product_id    = $product->get_id();
                $location_term = cova_get_wc_location_by_cova_location_id($item['location_id']);
                $regular_price = ($item['prices']['RegularPrice'] !== null)? (float) $item['prices']['RegularPrice'] : 0;
                $sale_price    = ($item['prices']['OverridePrice'] !== null)? (float) $item['prices']['OverridePrice'] : 0;

                $product->set_price($regular_price);
                $product->set_regular_price($regular_price);            

                cova_update_product_location_regular_price($product_id, $location_term->term_id, $regular_price);            
                cova_update_product_location_sale_price($product_id, $location_term->term_id, $sale_price);        

                $is_sale = false;

                // check if sale
                if ($sale_price > 0 && $sale_price < $regular_price) {
                    if ($product->get_type() === 'variation') {
                        $sale_product_ids[$location_term->term_id][] = $product->get_parent_id();
                    } else {
                        $sale_product_ids[$location_term->term_id][] = $product_id;
                    }

                    $product->set_sale_price($sale_price);
                    
                    $is_sale = true;
                } else {
                    $product->set_sale_price('');
                }

                $product->save();

                $this->hack_product_visibility($product);

                $data = [
                'catalog_id' => $item['catalog_id'],
                'product' => $product
                ];

                if ($is_sale === true) {
                    $data['on_sale'] = true;
                }

                $updated_products_handler[] = $data;    

                $wc_regular_price = cova_get_product_location_regular_price($product_id, $location_term->term_id);
                $wc_sale_price = cova_get_product_location_sale_price($product_id, $location_term->term_id);

                if ($wc_regular_price == $regular_price && $wc_sale_price == $sale_price) {
                    $updated_items[] = $item['update_key'];    
                }            
            }

            if ($sync_type === 'manual') {
                d(['update_inventory' => $items_to_update[0]]);
            }

            //        error_log(print_r([
            //            'update_pricing_init' => $updated_products_handler
            //        ], true));

            $this->items_to_update = $this->list_updated_products_details($updated_products_handler);

            $this->insert_updated_pricing_items($updated_items);
            $this->reset_to_update_items($items_to_update);


            //Only record the stats for automatic
            if (!($sync_type === 'manual')) {
                $duration = microtime(true) - $start;
                dabber_cron_logger2('EVENT - pricing update', $iterationId, $duration);
            }

            return $updated_products_handler;        
        }
        catch (\Exception $e) 
        {
            //Call the logger to ensure the exception is logged.
            //Only record the logs for automatic
            if (!($sync_type === 'manual')) {
                $duration = microtime(true) - $start;
                dabber_cron_logger2('EVENT - pricing update failed. ' . $e->getMessage(), $iterationId, $duration, false);
            }

            // Rethrow exception to propagate it up the call stack
            throw $e;
        }


        
    }

    /**
     * Hack to fix bug where sometimes synced products visibility
     * is not working properly.
     */
    public function hack_product_visibility($product)
    {
        // temporarily update visibility
        $product->set_catalog_visibility('catalog');
        $product->save();

        // reset visibility
        $product->set_catalog_visibility('visible');
        $product->save();
    }
    
    /**
     * Unset previously updated batch
     */
    public function reset_to_update_items($items)
    {
        if (empty($items)) {
            return false;
        }

        unset($items[0]);

        Cova_Data_Manager::store_data('pricing-sync', array_values($items));
    }

    public function validate_pricing()
    {
        if (!is_admin()) {
            return;
        }

        if (!isset($_GET['_dabber_validate_products_pricing'])) {
            return;
        }

        $locations = Cova_Data_Manager::get_global_data('locations');
        $products = [];

        foreach ($locations as $location_id => $location) {
            $location_items = Cova_Data_Manager::get_global_data('pricing-' . $location_id, true);
            $wc_location = cova_get_wc_location_by_cova_location_id($location_id);
            foreach ($location_items as $items) {
                foreach ($items as $catalog_id => $item) {
                    $product = dabber_get_product_by_catalog_id($catalog_id);
                    if (!$product) {
                        continue;
                    }

                    $item = array_values($item);
                    $is_prices_matched = false;

                    $wc_reg_price = (float) get_post_meta($product->get_id(), 'wcmlim_regular_price_at_'. $wc_location->term_id, true);
                    $wc_sale_price = (float) get_post_meta($product->get_id(), 'wcmlim_sale_price_at_'. $wc_location->term_id, true);
                    $cova_reg_price = (float) $item[0]['RegularPrice'];
                    $cova_sale_price = (float) $item[0]['OverridePrice'];

                    if ($wc_reg_price == $cova_reg_price && $wc_sale_price == $cova_sale_price) {
                        $is_prices_matched = true;
                    }

                    $products[$location_id][$product->get_id()] = [
                        'catalog_id' => $catalog_id,
                        'product_name' => $product->get_title(),
                        'wc_regular_price' => $wc_reg_price,
                        'wc_sale_price' => $wc_sale_price,
                        'cova_regular_price' => $cova_reg_price,
                        'cova_sale_price' => $cova_sale_price,
                        'is_prices_matched' => $is_prices_matched
                    ];
                }
            }
        }

        echo '<pre>';
            var_dump($products);
        echo '</pre>';

        die();
    }

    public function get_items_to_update()
    {
        $items_to_update = Cova_Data_Manager::get_stored_data('pricing-sync');

        if ($items_to_update !== false) {
            return $items_to_update;
        }    

        $updated_items = $this->get_updated_pricing_items();
        $locations = Cova_Data_Manager::get_global_data('locations');
        $last_modified_prices = [];
        $on_sale_products = [];
        // $new_update_items = [];

        $from_date  = strtotime(date('Y-m-d', strtotime('-'. $this->prev_days .' day', strtotime(gmdate('Y-m-d')))));
        $to_date    = strtotime('+1 day', strtotime(gmdate('Y-m-d')));

        foreach ($locations as $location_id => $location) {
            $location_items = Cova_Data_Manager::get_global_data('pricing-'. $location_id);

            foreach ($location_items as $items) {

                foreach ($items as $catalog_id => $prices) {

                     //                    $prices = array_merge(...$prices);
                    $price_handler = $prices;
                    foreach ($price_handler as $price) {
                        $prices = $price;
                        break;
                    }

                    $modified   = strtotime(date('Y-m-d H:i:s', strtotime($prices['LastModifiedDateUtc'])));
                    $update_key = $modified .'-'. $location_id .'-'. $catalog_id;

                    if ($prices['OverridePrice'] > 0 && $prices['OverridePrice'] < $prices['RegularPrice']) {
                        $on_sale_products[$location_id][] = $catalog_id;

                        $last_modified_prices[$catalog_id .'-'. $location_id] = [
                        'catalog_id' => $catalog_id,
                        'location_id' => $location_id,
                        'prices' => $prices,
                        'update_key' => $update_key
                        ];                        
                    }

                    if (in_array($update_key, $updated_items)) {
                        continue;
                    }

                    if (($modified >= $from_date) && ($modified <= $to_date)) {
                        $last_modified_prices[$catalog_id .'-'. $location_id] = [
                            'catalog_id' => $catalog_id,
                            'location_id' => $location_id,
                            'prices' => $prices,
                            'update_key' => $update_key
                        ];
                    }
                }
            }
        }

        $last_modified_prices     = array_values($last_modified_prices);
        $this->total_update_num = count($last_modified_prices);
        $last_modified_prices   = array_chunk($last_modified_prices, $this->sync_batch_num);

        $this->update_on_sale_products($on_sale_products);

        Cova_Data_Manager::store_data('pricing-sync', $last_modified_prices);
        Cova_Data_Manager::save_storage_timestamp('updated-pricing-items');

        return $last_modified_prices;
    }

    public function clear_onsale_products_transient()
    {
        $locations  = cova_get_all_wc_locations();

        foreach ($locations as $wc_loc) {
            delete_option('dabber_product_on_sale_'. $wc_loc['term_id']);
        }
    }

    public function update_on_sale_products($items)
    {
        $this->clear_onsale_products_transient();

        error_log(
            print_r(
                [
                'update_on_sale_products' => $items
                ], true
            )
        );

        if (empty($items)) { return; 
        }

        // Override WC sale transient by location term id.
        foreach ($items as $loc_id => $ids) {

            $product_ids = [];
            
            foreach ($ids as $catalog_id) {
                $product = dabber_get_product_by_catalog_id($catalog_id);

                if ($product) {
                    $product_ids[] = $product->get_id();
                }
            }

            $location_term = cova_get_wc_location_by_cova_location_id($loc_id);
            $option_name = 'dabber_product_on_sale_'. $location_term->term_id;
            delete_option($option_name);
            update_option($option_name, $product_ids);
        }
    }

    public function insert_updated_pricing_items($items)
    {
        $updated_items = Cova_Data_Manager::get_stored_data('updated-pricing-items');
        $updated_items = (!$updated_items)? [] : $updated_items;
        $new_data = array_merge($updated_items, $items);

        Cova_Data_Manager::store_data('updated-pricing-items', $new_data);
    }

    public function get_updated_pricing_items()
    {
        $updated_items = Cova_Data_Manager::get_stored_data('updated-pricing-items');

        if ($updated_items === false) {
            return []; 
        }

        $saved_date = Cova_Data_Manager::get_storage_timestamp('updated-pricing-items');
        $saved_date = strtotime($saved_date);

        if ($saved_date > strtotime('-3 day')) {
            return $updated_items;
        }

        Cova_Data_Manager::remove_stored_data('updated-pricing-items');

        return [];
    }

    public function list_updated_products_details($products)
    {
        if (empty($products)) {
            return [];
        }

        $products_handler = [];

        foreach ($products as $catalog_id => $product) {

            $data = [
            'name' => $product['product']->get_name(),    
            'catalog_id' => $product['catalog_id'],
            'woocommerce_product_link' => '<a href="'. get_the_permalink($product['product']->get_id()) .'" target="_blank">'. get_the_permalink($product['product']->get_id()) .'</a>'
            ];

            if (isset($product['on_sale'])) {
                $data['on_sale'] = true;
            }

            $products_handler[] = $data;
        }

        return $products_handler;
    }
}
