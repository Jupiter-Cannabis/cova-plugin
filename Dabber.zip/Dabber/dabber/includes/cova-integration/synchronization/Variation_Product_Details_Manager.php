<?php

namespace Cova_Integration;

class Variation_Product_Details_Manager
{
    public $api;
    public $data;
    public $cova_global_data;

    public function __construct($api)
    {
        $this->api = $api;    
    }

    public function set_cova_global_data($global_data)
    {
        $this->cova_global_data = $global_data;
    }

    public function set_data($data)
    {
        $this->data = $data;
    }

    public function get_data()
    {
        return $this->data;
    }

    public function get_cova_global_data()
    {
        return $this->cova_global_data;
    }

    public function get_title()
    {
        return $this->data['Name'];
    }

    public function get_slug()
    {
        return $this->data['Id'];
    }

    public function get_sku()
    {
        $grouped_sku = $this->api['catalog']->truncate_slug($this->get_slug());

        $sku = $this->get_slug();
    
        foreach ($this->cova_global_data['catalog'][$grouped_sku] as $key => $item) {
            if ($item['CatalogItemId'] === $this->data['catalog_id']) {
                $sku = $item['CatalogSku'];
                break;
            }
        }

        return $sku;
    }

    public function get_short_description()
    {
        return $this->data['ShortDescription'];
    }

    public function get_long_description()
    {
        return $this->data['LongDescription'];
    }

    public function get_date_added()
    {
        $date = strtotime($this->data['DateAddedUtc']);
        $currentDate = strtotime(date('Y-m-d'));

        if ($date > $currentDate) {
            return current_time('Y-m-d H:i:s');
        }

        return date('Y-m-d H:i:s', $date);
    }

    public function get_lifecycle_status()
    {
        return strtolower($this->data['LifeCycle']);
    }

    public function get_weights()
    {
        $equivalent_to = [
        'value' => 0,
        'unit' => ''
        ];

        $net_weight = [
        'value' => 0,
        'unit' => ''
        ];

        if (isset($this->specifications['details']['equivalent-to']['Value'])) {
            $equivalent_to = [
            'value' => $this->specifications['details']['equivalent-to']['Value'],
            'unit' => $this->specifications['details']['equivalent-to']['Unit']
            ];
        }

        if (isset($this->specifications['details']['net-weight']['Value'])) {
            $net_weight = [
            'value' => $this->specifications['details']['net-weight']['Value'],
            'unit' => $this->specifications['details']['net-weight']['Unit']
            ];
        }

        return [
        'equivalency' => $equivalent_to,
        'net_weight' => $net_weight
        ];
    }

    public function generate_product_details()
    {
        if (!isset($this->data['Specifications'])) {
            return;
        }

        $specifications = [];

        foreach ($this->data['Specifications'] as $spec) {    
            foreach ($spec['Fields'] as $field) {
                $specifications[sanitize_title($spec['Name'])][sanitize_title($field['DisplayName'])] = (array) $field;
            }
        }

        $this->specifications = $specifications;
    }

    public function get_prices_by_location()
    {
        $location_pricing = [];
        $regular_prices = [];

        foreach ($this->cova_global_data['pricing'] as $location_id => $prices) {
            if (isset($prices[$this->data['catalog_id']])) {
                $location_pricing[$location_id] = $prices[$this->data['catalog_id']];
                if (isset($prices[$this->data['catalog_id']]['RegularPrice'])) {
                    $regular_prices[] = $prices[$this->data['catalog_id']]['RegularPrice'];
                }
            }    
        }

        $default_pricing = (!empty($regular_prices))? max($regular_prices) : [];

        return [
        'default_pricing' => $default_pricing,
        'location_pricing' => $location_pricing
        ];
    }

    public function get_locations_stock()
    {
        $location_stocks = [];

        foreach ($this->cova_global_data['locations'] as $location_id => $location_item) {

            if (!isset($this->cova_global_data['inventory'][$location_id])) {
                $location_stocks[$location_id] = 0;
                continue;
            }

            $location_inventory = $this->cova_global_data['inventory'][$location_id];
            if (isset($location_inventory[$this->data['catalog_id']])) {
                $location_stocks[$location_id] = $location_inventory[$this->data['catalog_id']]['Quantity'];
            } else {
                $location_stocks[$location_id] = 0;
            }
        }

        return [
        'total_stock' => array_sum($location_stocks),
        'location_stocks' => $location_stocks
        ];
    }

    public function get_specifications()
    {
        return $this->specifications;
    }

    public function get_individual_specifications()
    {
        $specifications = [];

        foreach ($this->get_specifications() as $key => $specs) {
            foreach ($specs as $spec_key => $item) {
                $specifications[$spec_key] = $item;
            }
        }

        return $specifications;
    }

    public function get_details()
    {
        $data = $this->get_specifications();

        if (!isset($data['details'])) {
            return [];
        }

        return $data['details'];
    }

    public function get_additional_details()
    {
        $data = $this->get_specifications();

        if (!isset($data['additional-details'])) {
            return [];
        }

        return $data['additional-details'];
    }

    public function get_product_online_menu()
    {
        if (!isset($this->specifications['online-menu'])) {
            return [];
        }

        return $this->specifications['online-menu'];
    }

    public function get_brand()
    {
        $details = $this->get_specifications();

        if (isset($details['online-menu']['online-menu-brand'])) {
            return $details['online-menu']['online-menu-brand']['Value'];
        }

        $details = $this->get_additional_details();

        if (isset($details['brand-name'])) {
            return $details['brand-name']['Value'];
        }

        return false;
    }

    public function get_categories()
    {
        $details = $this->get_specifications();

        $categories = [];

        if (isset($this->data['CanonicalClassification']['Name'])) {
            $categories['classification'] = $this->data['CanonicalClassification']['Name'];
        }

        if (isset($details['online-menu']['online-menu-category'])) {
            $categories['online-menu'] = $details['online-menu']['online-menu-category']['Value'];
        }                

        if (isset($details['details']['strain'])) {
            $categories['strain'] = $details['details']['strain']['Value'];
        }

        return $categories;
    }

    public function get_cbd_details()    
    {
        $cbd = null;
        $cbd_max = null;
        $cbd_min = null;

        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {

                // Save cbd only
                if (stripos($key, 'cbd') !== false) {
                    $cbd = $item['Value'];
                }

                // Save cbd max
                if (stripos($key, 'cbd') !== false && stripos($key, 'max') !== false) {
                    $cbd_max = $item['Value'];
                }

                // Save cbd min
                if (stripos($key, 'cbd') !== false && stripos($key, 'min') !== false) {
                    $cbd_min = $item['Value'];
                }
            }
        }

        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {

                // Save cbd only
                if ($cbd_max === null) {
                    if (stripos($key, 'cbd') !== false) {
                        $cbd = $item['Value'];
                    }
                }

                // Save cbd max
                if ($cbd_max === null) {
                    if (stripos($key, 'cbd') !== false && stripos($key, 'max') !== false) {
                        $cbd_max = $item['Value'];
                    }
                }
                
                // Save cbd min
                if ($cbd_min === null) {
                    if (stripos($key, 'cbd') !== false && stripos($key, 'min') !== false) {
                        $cbd_min = $item['Value'];
                    }
                }
            }
        }

        return [
        'cbd' => $cbd,
        'min' => $cbd_min,
        'max' => $cbd_max
        ];
    }

    public function get_thc_details()
    {
        $thc = null;
        $thc_max = null;
        $thc_min = null;

        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {

                // Save thc only
                if (stripos($key, 'thc') !== false) {
                    $thc = $item['Value'];
                }

                // Save thc max
                if (stripos($key, 'thc') !== false && stripos($key, 'max') !== false) {
                    $thc_max = $item['Value'];
                }

                // Save thc min
                if (stripos($key, 'thc') !== false && stripos($key, 'min') !== false) {
                    $thc_min = $item['Value'];
                }
            }
        }

        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {

                // Save thc only
                if ($thc_max === null) {
                    if (stripos($key, 'thc') !== false) {
                        $thc = $item['Value'];
                    }
                }

                // Save thc max
                if ($thc_max === null) {
                    if (stripos($key, 'thc') !== false && stripos($key, 'max') !== false) {
                        $thc_max = $item['Value'];
                    }
                }
                
                // Save thc min
                if ($thc_min === null) {
                    if (stripos($key, 'thc') !== false && stripos($key, 'min') !== false) {
                        $thc_min = $item['Value'];
                    }
                }
            }
        }

        return [
        'thc' => $thc,
        'min' => $thc_min,
        'max' => $thc_max
        ];
    }

    public function get_terpenes_details()
    {
        $details_terpenes = [];
        $details = $this->get_details();

        if (!empty($details)) {
            foreach ($details as $key => $item) {
                if (stripos($key, 'terpene') !== false) {
                    $details_terpenes[] = $item['Value'];
                }
            }
        }

        if (!empty($details_terpenes)) {
            return implode(', ', $details_terpenes);
        }

        $additional_details_terpenes = [];
        $additional_details = $this->get_additional_details();

        if (!empty($additional_details)) {
            foreach ($additional_details as $key => $item) {
                if (stripos($key, 'terpene') !== false) {
                    $additional_details_terpenes[] = $item['Value'];
                }
            }
        }

        if (!empty($additional_details_terpenes)) {
            return implode(', ', $additional_details_terpenes);
        }        

        return null;
    }

    public function get_strain_details()
    {
        $details = $this->get_details();

        if (isset($details['strain']['Value'])) {
            return $details['strain']['Value'];
        }

        return null;
    }

    public function get_featured_image()
    {
        if (!isset($this->data['HeroShotId'])) {
            return false;
        }

        if (!$this->data['HeroShotId']) {
            return false;
        }

        $cova_image = cova_get_image($this->data['HeroShotId'], $this->get_title());
        $img_id = cova_upload_image($cova_image['full']);

        return $img_id;
    }

    public function get_wc_product_details()
    {
        $this->generate_product_details();

        $details['title'] = $this->get_title();
        $details['slug']  = $this->get_slug();
        $details['sku']   = $this->get_sku();
        $details['catalog_id'] = $this->data['catalog_id'];

        $details['date_added'] = $this->get_date_added();

        $details['long_description'] = $this->get_long_description();
        $details['short_description'] = $this->get_short_description();

        $details['life_cycle'] = $this->get_lifecycle_status();

        $details['pricing'] = $this->get_prices_by_location();
        $details['stocks'] = $this->get_locations_stock();

        $details['weights'] = $this->get_weights();

        $details['additional_details'] = $this->get_additional_details();
        $details['details'] = $this->get_details();

        $details['specifications'] = $this->get_specifications();
        $details['individual_specifications'] = $this->get_individual_specifications();
        $details['featured_image'] = $this->get_featured_image();

        $details['brand'] = $this->get_brand();
        $details['categories'] = $this->get_categories();

        $details['thc_details'] = $this->get_thc_details();
        $details['cbd_details'] = $this->get_cbd_details();
        $details['strain_details'] = $this->get_strain_details();
        $details['terpenes_details'] = $this->get_terpenes_details();
        $details['cova_data'] = $this->data;

        return apply_filters('dabber_sync_variation_product_details', $details, $this);
    }


}
