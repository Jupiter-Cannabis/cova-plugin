<?php

namespace Cova_Integration;

class Console_Commands
{
    public function run()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);

        add_action('wp_ajax_cova_sync_command_execute', [$this, 'execute']);
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script('cova-sync-commands', MGC_PLUGIN_URI .'includes/cova-product-sync/assets/js/console-commands.js', [], null, true);
    }

    public function execute()
    {
        $this->parse_command();

        $commands = $this->get_available_commands();

        wp_send_json_success(
            [
            'message' => 'Test'
            ], 200
        );
    }

    // public function find_command()
    // {

    // }

    public function parse_command()
    {
        $command = sanitize_text_field($_POST['params']['cmd']);
        $cmd_arr = explode(':', $command);

        dd($cmd_arr);
    }

    public function get_available_commands()
    {
        $commands = [
        'sync' => [
        'clear'
        ]
        ];
    }

    public function sync_clear($args)
    {
        wp_send_json_success(
            [
            'message' => 'test',
            'data' => $args
            ], 200
        );
    }
}
