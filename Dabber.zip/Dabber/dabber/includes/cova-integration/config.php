<?php

namespace Cova_Integration;

/**
 * Sync configs
 */
Config_Manager::set_config(
    'cova_sync', [
    'sync_permissions' => [                        // Limit sync functionalities based on allowed user roles.
        'product' => [
            'administrator'
        ]
    ],
    'log_path' => WP_CONTENT_DIR .'/uploads/cova-sync/',
    'product_sync' => [
        'page' => 1,
        'page_size' => 5000
    ],
    'global_data_storage_interval' => 60*28        // Set time interval in seconds to save global data.
    ]
);

/**
 * Product configs
 */
Config_Manager::set_config(
    'product', [
    'use_location_specific_price' => true,         // Enabling this option will override the master product price with the location price.
    'show_additional_details' => [                // Set true to show additional details in single product page additional information tab.
        'terpenes' => true
    ],                
    'hide_outofstock_by_location' => true         // Hide out of stock products on a location basis
    ]
);

/**
 * Payment configs
 */
Config_Manager::set_config(
    'payment', [
    'disable_cova_sale' => false                 // Setting false will prevent cova sales api request.
    ]
);
