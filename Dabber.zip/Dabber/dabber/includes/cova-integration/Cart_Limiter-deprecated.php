<?php

namespace Cova_Integration;

class Cart_Limiter
{
    private $product;
    private $quantity;

    public function set_product(\WC_Product $product)
    {
        $this->product = $product;
    }

    public function set_quantity($quantity)
    {
        $this->quantity = $quantity;
    }

    /**
     * Check if total cart weight is in limit.
     */
    public function is_cart_weight_full(): bool
    {        
        $total_weight  = $this->get_cart_total_weight();
        $weight_limits = $this->get_weight_limits();

        if ($total_weight > $weight_limits['cart_total']) {
            return true;
        }

        $cart_category_weights = $this->get_cart_total_weight_by_categories();

        foreach ($cart_category_weights as $category => $weight) {
            if (!array_key_exists($category, $weight_limits)) {
                continue;
            }    

            if ($weight > $weight_limits[$category]) {
                return true;
            }
        }

        return false;
    }

    public function get_weight_limits()
    {
        // $weight_limits = get_option('dabber_weight_limits');

        $weight_limits = [
        'cart_total' => 30,
            'concentrates' => 30,
            'topicals' => 30,
            'beverages' => 30,
            'flower' => 30,
            'pre-roll' => 30,
            'edibles' => 30
        ];

        if (!$weight_limits) {
            return [];
        }

        return $weight_limits;
    }

    public function get_cart_total_weight_by_categories()
    {
        $category_weights = [];

        if ($this->product->get_type() === 'simple') {
            $current_product_terms  = get_the_terms($this->product->get_id(), 'product_cat');
            $current_product_weight = $this->product->get_weight();
        }

        if ($this->product->get_type() === 'variation') {
            $parent = wc_get_product($this->product->get_parent_id());
            $current_product_terms  = get_the_terms($parent->get_id(), 'product_cat');
            $current_product_weight = $parent->get_weight();
        }

        foreach ($current_product_terms as $tkey1 => $current_p_term) {
            if ($current_product_weight > 0) {
                $category_weights[$current_p_term->slug] = ($current_product_weight * $this->quantity);
            }
        }

        foreach( WC()->cart->get_cart() as $cart_item ) {            
            $terms         = get_the_terms($cart_item['product_id'], 'product_cat');       
            $weight     = $cart_item['data']->get_weight();
            $quantity     = $cart_item['quantity'];

            foreach ($terms as $tkey => $term) {
                $category_weights[$term->slug] = ($weight * $quantity);
            }         
        }

        return $category_weights;
    }

    public function get_cart_total_weight()
    {
        $current_product_total_weight = 0;
        $product_weight = $this->product->get_weight();

        if ($product_weight > 0) {
            $current_product_total_weight = ($this->get_weight_in_grams($product_weight) * $this->quantity);
        }

        $cart_total_weight = ($current_product_total_weight + WC()->cart->cart_contents_weight);

        return $cart_total_weight;
    }

    public function get_weight_in_grams($weight)
    {
        $weight_unit = get_option('woocommerce_weight_unit');

        if ($weight_unit === 'kg') {
            return $weight / 1000;
        }

        if ($weight_unit === 'lbs') {
            return $weight / 453.59237;
        }

        if ($weight_unit === 'oz') {
            return $weight / 28.3495;
        }

        return $weight;
    }    

} // end class
