<?php

function CovaAPI($version = '')
{
    return CovaAPI::instance($version);
}
