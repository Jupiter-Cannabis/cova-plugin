<?php

namespace CovaAPI_V2;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class Catalog
{
    function __construct()
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
        $this->env          = $cova_api_auth->credentials['environment'];
    }

    public function get_update_as_of($date_time, $data)
    {
        try {
            $endpoint = dabber_api_endpoint_v2('covaapiaggregator', 'Companies/'. $this->company_id .'/DetailedProductData/UpdatedAsOf/'. $date_time, 'v1', 'iqmetrix2', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token
                ],
                'json'          => $data,
                'verify'        => false,
                'http_errors'   => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_all_catalog_ids($search = [])
    {
        try {
            $params = dabber_urldecode_build_query($search);
            $endpoint = dabber_api_endpoint_v2('catalogs', 'companies('.$this->company_id.')/Catalog/Items?'.$params, 'v1', 'iqmetrix', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_products_by_catalog_ids($catalog_ids)
    {
        try {
            $endpoint = dabber_api_endpoint_v2('covaapiaggregator', 'Companies/'. $this->company_id .'/Products/ByProductIdList', 'v1', 'iqmetrix2', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token
                ],
                'json' => [
                    'IncludeSkusAndUpcs' => true,
                    'IncludeSpecifications' => true,
                    'IncludeAssets' => true,
                    'ProductIds' => $catalog_ids
                ],
                'verify' => false,
                'http_errors' => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_detailed_products_by_catalog_ids($data)
    {
        try {
            $endpoint = dabber_api_endpoint_v2('covaapiaggregator', 'Companies/'. $this->company_id .'/DetailedProductData/ByProductIdList', 'v1', 'iqmetrix2', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token
                ],
                'json'          => $data,
                'verify'        => false,
                'http_errors'   => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }

    public function get_detailed_products_data($data)
    {
        try {
            $endpoint = dabber_api_endpoint_v2('covaapiaggregator', 'Companies/'. $this->company_id .'/DetailedProductData', 'v1', 'iqmetrix2', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'POST', $endpoint, [
                    'headers' => [
                        'Accept'        => 'application/json',
                        'Authorization' => 'Bearer '.$this->access_token
                    ],
                    'json'          => $data,
                    'verify'        => false,
                    'http_errors'   => false
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
}
