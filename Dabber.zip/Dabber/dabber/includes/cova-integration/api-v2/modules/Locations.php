<?php

namespace CovaAPI_V2;
use GuzzleHttp\Client as Guzzle;
use CovaAPI\Auth;
use CovaAPI\InstrumentedHttp;

class Locations
{
    function __construct()
    {
        global $cova_api_auth;

        $guzzle = new Guzzle();
        $this->InstrumentedHttpClient = new InstrumentedHttp($guzzle);
        $this->access_token = $cova_api_auth->auth['access_token'];
        $this->company_id   = $cova_api_auth->credentials['company_id'];
        $this->env          = $cova_api_auth->credentials['environment'];
    }

    function get_all_locations()
    {
        try {
            $endpoint = dabber_api_endpoint_v2('entitymanager', 'companies('.$this->company_id.')/Locations', 'v1', 'iqmetrix', $this->env);

            $res = $this->InstrumentedHttpClient->request(
                'GET', $endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer '.$this->access_token,
                ]
                ]
            );

        } catch(\Exception $e) {
            $res = $e->getResponse();
        }

        if (!is_object($res)) {
            cova_debugger($res);

            $auth = new Auth();
            $auth->refresh_access_token();
            return $res;
        }

        return $res->getBody()->getContents();
    }
}
