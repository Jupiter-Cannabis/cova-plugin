<?php

require_once plugin_dir_path(__FILE__) .'CovaAPI.php';
require_once plugin_dir_path(__FILE__) .'helpers.php';

$modules = array_filter(
    glob(plugin_dir_path(__FILE__) .'modules/*.php'), function ($v) {
        return false === strpos($v, 'index.php');
    }
);

asort($modules);

foreach( $modules as $module ) {
    include_once $module;
}
