<?php

class CovaAPI
{
    private $api;
    public static $api_version;

    protected static $_instance = null;

    public static function instance($version)
    {
        if (is_null(self::$_instance) ) {
            self::$_instance = new self();
        }
        self::$api_version = $version;
        return self::$_instance;
    }

    public function __get( $key )
    {
        $method_name = $key . self::$api_version;
        $this->$method_name();

        return $this;
    }

    public function __call($name, $param)
    {
        $data = call_user_func_array([$this->api, $name], $param);

        return json_decode($data, true);
    }

    public function catalog()
    {
        $this->api = new \CovaAPI\Catalog();
    }

    public function inventory()
    {
        $this->api = new \CovaAPI\Inventory();
    }

    public function catalogv2()
    {
        $this->api = new \CovaAPI_V2\Catalog();
    }

    public function locationsv2()
    {
        $this->api = new \CovaAPI_V2\Locations();
    }
}
