<?php

namespace Cova_Integration;

class Cova_Product_Query
{
    public $meta_query;

    public function run()
    {            
        add_action('woocommerce_product_related_posts_query', [$this, 'remove_related_oos_by_location'], 999, 3);
        add_filter('pre_transient_wc_products_onsale', [$this, 'override_onsale_products_transient'], 100, 2);

        $this->set_meta_query();


        add_filter('woocommerce_product_query_meta_query', [$this, 'update_meta_query'], 100);
        add_filter('prdctfltr_meta_query', [$this, 'update_meta_query'], 100);
        add_filter('woocommerce_product_is_visible', [$this, 'modify_product_visibility'], 99999, 2);
    }

    public function modify_product_visibility($is_visible, $product_id)
    {
        global $dabber_current_location_data;

        $stock = (float) get_post_meta($product_id, 'wcmlim_stock_at_'. $dabber_current_location_data['wc_location_id'], true);

        return $stock > 0;
    }

    public function set_meta_query()
    {
        $current_location = cova_get_current_location();

        $this->meta_query = [
            'relation' => 'AND',
            [
                'key' => 'wcmlim_regular_price_at_'. $current_location,
                'value' => '1000',
                'compare' => '!='
            ],
            [
                'key' => 'wcmlim_regular_price_at_'. $current_location,
                'value' => '0',
                'compare' => '!='
            ],
            [
                'key' => 'wcmlim_stock_at_'. $current_location,
                'value' => '0',
                'compare' => '>',
                'type' => 'NUMERIC'
            ],
            [
                'key' => '_stock',
                'value' => '0',
                'compare' => '>',
                'type' => 'NUMERIC'
            ],
        ];
    }

    public function update_meta_query($meta_query)
    {
        if (is_admin()) {
            return $meta_query;
        }

        $meta_query[] = $this->meta_query;

        return $meta_query;
    }

    public function override_onsale_products_transient($value, $transient)
    {
        if ($transient !== 'wc_products_onsale') {
            return $value;
        }

        $value = $this->get_sale_products_by_location_transient();

        return $value;
    }

    public function get_sale_products_by_location_transient()
    {
        global $dabber_enabled_modules;

        $current_location = cova_get_current_location();
        $on_sale_products = get_option('dabber_product_on_sale_'. $current_location);
        $on_sale_products = (is_array($on_sale_products))? $on_sale_products : [];

        $promo_products = (in_array('\Dabber\Modules\Promotions\Promotions', $dabber_enabled_modules))? get_option('dabber_product_on_promo_'. $current_location) : [];
        $promo_products = (is_array($promo_products) && isset($promo_products[$current_location]))? $promo_products[$current_location] : [];

        $products = array_merge($on_sale_products, $promo_products);
        $products = array_unique($products);
        $products = array_slice($products, 0, 1000);

        return $products;
    }


    /**
     * Remove related product items with 1k and 0 price.
     */
    public function remove_related_oos_by_location($query, $product_id, $args)
    {
        global $wpdb, $dabber_current_location_data;

        $query['join'] = $query['join'] . " INNER JOIN $wpdb->postmeta AS cova_postmeta ON ( p.ID = cova_postmeta.post_id )
                                            INNER JOIN $wpdb->postmeta AS cova_postmeta2 ON ( p.ID = cova_postmeta2.post_id )
                                            INNER JOIN $wpdb->postmeta AS cova_postmeta3 ON ( p.ID = cova_postmeta3.post_id )";
        $query['where'] = $query['where'] . " AND ( ( ( ( cova_postmeta.meta_key = 'wcmlim_regular_price_at_". $dabber_current_location_data['wc_location_id'] ."'
                                              AND cova_postmeta.meta_value != '1000' )
                                              AND ( cova_postmeta.meta_key = 'wcmlim_regular_price_at_". $dabber_current_location_data['wc_location_id'] ."'
                                              AND cova_postmeta.meta_value != '0' ) 
                                              AND ( cova_postmeta2.meta_key = 'wcmlim_stock_at_". $dabber_current_location_data['wc_location_id'] ."'
                                              AND CAST(cova_postmeta2.meta_value AS SIGNED) > '0' )
                                              AND ( cova_postmeta3.meta_key = '_stock'
                                              AND CAST(cova_postmeta3.meta_value AS SIGNED) > '0' ) ) ) )";

        return $query;
    }

}

add_action(
    'plugins_loaded', function () {
        if (!class_exists('WooCommerce')) { return; 
        }

        $cova_product_query = new Cova_Product_Query;
        $cova_product_query->run();    
    }, 9999
);
