<?php

namespace Cova_Integration;

use function Dabber\Cova_Integration\Promotions\cova_get_promo_formatted_details;

class Admin_UI
{
    private $current_tab;
    private $tab_navs;
    private $current_section;

    public function run()
    {
        //        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('cova_admin_before_body', [$this, 'render_admin_messages']);
    }

    public function enqueue_scripts()
    {
        wp_enqueue_style('cova-sync', COVA_INTEGRATION_URI .'/assets/css/style.css', [], null);
        wp_enqueue_style('cova-font-awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', [], '4.7.0');

        wp_enqueue_script('cova-category-mapping', COVA_INTEGRATION_URI .'/assets/js/category-mapping.js', [], null, true);
    }

    public function register_admin_menu()
    {
        add_menu_page('Cova E-Commerce Integration', 'Integration V1', 'manage_options', 'cova_integration', [$this, 'page_callback']);
    }

    public function render_admin_messages()
    {
        global $cova_admin_messages;

        if (empty($cova_admin_messages)) {
            return;
        }

        foreach ($cova_admin_messages as $item) {
            if ($item['type'] === 'error') {
                echo '<div class="cova-admin-error"><p>'. $item['message'] .'</p></div>';
            }
        }
    }

    public function page_callback()
    {
        $this->current_tab = (isset($_GET['tab']) && $_GET['tab'] !== '')? $_GET['tab'] : 'sync';
        $page_name = 'render_'. $this->current_tab . '_page';

        echo '<div class="wrap">';

        $this->render_page_tabs();
        // $this->render_page_header();

        if (method_exists($this, $page_name)) {
            call_user_func([$this, $page_name]);
        }

        do_action('cova_'. $page_name);

        echo '</div>';
    }

    public function render_page_header()
    {

    }

    public function render_page_tabs()
    {
        $this->tab_navs = apply_filters(
            'cova_admin_nav_items', [
            'sync' => __('Product Sync'),
            'sync_settings' => __('Sync Settings'),
            'general_settings' => __('General Settings'),
            'integration' => __('API Integration')
            // 'settings' => __('Settings')
            ]
        );

        echo '<h1>Cova E-Commerce Integration</h1>';

        echo '<nav class="nav-tab-wrapper cova-nav-tab-wrapper">';
        foreach ($this->tab_navs as $tab => $name) {
            $is_active = ($tab === $this->current_tab)? 'nav-tab-active' : '';
            echo '<a href="'. get_admin_url() .'/admin.php?page=cova_integration&tab='. $tab .'" class="nav-tab '. $is_active .'">'. $name .'</a>';
        }
        echo '</nav>';
    }

    public function render_sync_settings_page()
    {
        $this->current_section = (isset($_GET['section']) && $_GET['section'] !== '')? $_GET['section'] : 'products';

        $sub_menus = apply_filters(
            'dabber_admin_sync_settings_nav_sub_items', [
            'products'      => __('Products', 'cova'),
            'categories'    => __('Categories', 'cova'),
            'cron_jobs'     => __('Cron Jobs', 'dabber'),
            'promotions'    => __('Promotions', 'dabber')
            ]
        );

        $sub_settings = [];

        foreach ($sub_menus as $sub_menu_key => $sub_menu_name ) {
            $sub_settings[] = '<li><a href="?page=cova_integration&tab=sync_settings&section='. $sub_menu_key .'" class="'. (($this->current_section === $sub_menu_key)? 'current' : '') .'">'. $sub_menu_name .'</a></li>';
        }

        echo '<div class="cova-sync-wrap">';
        echo '<ul class="subsubsub">';
        echo implode(' | ', $sub_settings);
        echo '</ul>';
        echo '<br class="clear">';
        $this->render_sync_products_section();
        $this->render_sync_categories_section();
        $this->render_sync_cron_jobs_section();
        $this->render_sync_promotions_section();
        //        $this->render_sync_product_fields_mapping();

        do_action('dabber_admin_sync_settings_render_section', $this->current_section);

        echo '</div>';
    }

    public function render_integration_page()
    {
        $this->save_api_settings();

        $api = get_option('dabber_api_details');
        $is_connected = get_option('dabber_is_api_connected');

        $is_client_secret  = (isset($api['live']['credentials']['client_secret']) && trim($api['live']['credentials']['client_secret']) !== '')? __('Client Secret is set') : '';
        $is_password        = (isset($api['live']['credentials']['password']) && trim($api['live']['credentials']['password']) !== '')? __('Password is set') : '';
        $is_live_connected = ($is_connected === 'yes')? '<span style="color: #21b921;">('.__('Connected', 'dabber').')</span>' : '';

        $is_sandbox_client_secret = (isset($api['sandbox']['credentials']['client_secret']) && trim($api['sandbox']['credentials']['client_secret']) !== '')? __('Sandbox Client Secret is set') : '';
        $is_sandbox_password       = (isset($api['sandbox']['credentials']['password']) && trim($api['sandbox']['credentials']['password']) !== '')? __('Sandbox Password is set') : '';
        $is_sandbox_connected       = ($api['mode'] === 'sandbox')? '<span style="color: #21b921;">('.__('Connected', 'dabber').')</span>' : '';

        $is_sandbox = ($api['mode'] === 'sandbox')? true : false;
        ?>
        <div class="cova-sync-wrap">
            <form action="" method="post">
                <h3><?php _e('Live Credentials', 'cova') ?> <?php echo $is_live_connected ?></h3>
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row"><?php _e('Company ID', 'cova') ?></th>
                        <td>
                            <input type="text" name="cova_api_company_id" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $api['live']['credentials']['company_id'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Client ID', 'cova') ?></th>
                        <td>
                            <input type="text" name="cova_api_client_id" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $api['live']['credentials']['client_id'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Client Secret', 'cova') ?></th>
                        <td>
                            <input type="password" name="cova_api_client_secret" placeholder="<?php echo $is_client_secret ?>" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Username', 'cova') ?></th>
                        <td>
                            <input type="text" name="cova_api_username" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="<?php echo $api['live']['credentials']['username'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Password', 'cova') ?></th>
                        <td>
                            <input type="password" name="cova_api_password" placeholder="<?php echo $is_password ?>" class="dabber-live-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                        </td>
                    </tr>
                    </tbody>
                </table>
                <p></p>
                <hr>
                <div style="display:none !important;">
                    <h3><?php _e('Sandbox Credentials', 'dabber') ?> <?php echo $is_sandbox_connected ?></h3>
                    <table class="form-table">
                        <tbody>
                        <tr>
                            <th scope="row"><?php _e('Enable Sandbox Mode', 'cova') ?></th>
                            <td>
                                <fieldset>
                                    <label for="cova_api_enable_sandbox">
                                        <input name="cova_api_enable_sandbox" <?php echo (($is_sandbox === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="cova_api_enable_sandbox" value="1">
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Company ID', 'cova') ?></th>
                            <td>
                                <input type="text" name="cova_api_sandbox_company_id" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Client ID', 'cova') ?></th>
                            <td>
                                <input type="text" name="cova_api_sandbox_client_id" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Client Secret', 'cova') ?></th>
                            <td>
                                <input type="password" name="cova_api_sandbox_client_secret" placeholder="<?php echo $is_sandbox_client_secret ?>" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Username', 'cova') ?></th>
                            <td>
                                <input type="text" name="cova_api_sandbox_username" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Password', 'cova') ?></th>
                            <td>
                                <input type="password" name="cova_api_sandbox_password" placeholder="<?php echo $is_sandbox_password ?>" class="dabber-sandbox-credentials regular-text ltr" autocomplete="off" data-lpignore="true" value="">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <p></p>
                <input type="hidden" id="dabber_update_live_credentials" name="dabber_update_live_credentials" value="">
                <input type="hidden" id="dabber_update_sandbox_credentials" name="dabber_update_sandbox_credentials" value="">
                <input type="submit" id="submit" name="cova-save-api-credentials" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">
            </form>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function()
            {
                jQuery('.dabber-live-credentials').change(function()
                {
                    jQuery('#dabber_update_live_credentials').val(1);
                });

                jQuery('.dabber-sandbox-credentials').change(function()
                {
                    jQuery('#dabber_update_sandbox_credentials').val(1);
                });
            });
        </script>
        <?php
    }

    public function render_sync_products_section()
    {
        if (isset($_POST['cova-products-sync-settings'])) {

            $is_breakdown_all = (isset($_POST['cova-breakdown-all']))? 'yes' : 'no';
            $is_convert_tiered = (isset($_POST['convert-tierd-pricing']))? 'yes' : 'no';
            $breadkown_ids = sanitize_text_field($_POST['cova-breakdown-prdct-ids']);

            update_option('cova_sync_settings_breakdown_all', $is_breakdown_all);
            update_option('dabber_sync_settings_convert_tiered_pricing', $is_convert_tiered);
            update_option('cova_sync_settings_breakdown_ids', $breadkown_ids);
        }

        $is_breakdown_all = get_option('cova_sync_settings_breakdown_all');
        $is_convert_tiered = get_option('dabber_sync_settings_convert_tiered_pricing');
        $breadkown_ids = get_option('cova_sync_settings_breakdown_ids');

        if($this->current_section === 'products') : ?>
            <h2><?php _e('Product Sync', 'cova') ?></h2>
            <form action="" method="post">
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row"><?php _e('Breakdown All Variable Products', 'cova') ?></th>
                        <td>
                            <fieldset>
                                <label for="cova-breakdown-all">
                                    <input name="cova-breakdown-all" <?php echo (($is_breakdown_all === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="cova-breakdown-all" value="1">
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Convert Tiered Prices to Simple Product', 'dabber') ?></th>
                        <td>
                            <fieldset>
                                <label for="convert-tierd-pricing">
                                    <input name="convert-tierd-pricing" <?php echo (($is_convert_tiered === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="convert-tierd-pricing" value="1">
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <input type="submit" id="submit" name="cova-products-sync-settings" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">
            </form>
            <p></p>
            <hr>
            <form action="" method="post">
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row">
                            <label for="cova-breakdown-existing-prdct-ids"><?php _e('Breakdown existing variable products', 'cova') ?></label>
                        </th>
                        <td>
                            <input name="cova-breakdown-existing-prdct-ids" type="text" id="cova-breakdown-existing-prdct-ids" value="" class="regular-text ltr" autocomplete="off">
                            <p class="description"><?php _e('List of cova master product slug Ids to be broken down as individual products separated by comma.', 'cova') ?></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Breakdown Products', 'cova') ?>">
            </form>
            <p></p>
            <hr>
            <form action="" method="post">
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row">
                            <label for="cova-regroup-prdct-ids"><?php _e('Regroup products', 'cova') ?></label>
                        </th>
                        <td>
                            <input name="cova-regroup-prdct-ids" type="text" id="cova-regroup-prdct-ids" value="" class="regular-text ltr" autocomplete="off">
                            <p class="description"><?php _e('List of cova master product slug Ids to be grouped as variable products separated by comma.', 'cova') ?></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Regroup Products', 'cova') ?>">
            </form>
        <?php endif;
    }

    public function render_sync_categories_section()
    {
        if($this->current_section === 'categories') :

            $this->save_cova_wc_mapping();

            echo '<h2>Category Mapping</h2>';

            $classification_tree_id = trim(get_option('cova_classification_tree_id'));

            echo '<form method="post" action="">';
            echo '<table class="form-table">';
            echo '<tbody>';
            echo '<tr>';
            echo '<th scope="row">';
            echo '<label for="cova-classification-tree-id">'. __('Cova Classification Tree ID', 'cova') .'</label>';
            echo '</th>';
            echo '<td>';
            echo '<input name="cova-classification-tree-id" type="text" id="cova-classification-tree-id" value="'. $classification_tree_id .'" class="regular-text ltr" autocomplete="off">';
            echo '</td>';
            echo '</tr>';
            echo '</tbody>';
            echo '</table>';


            if (!$classification_tree_id) {
                echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';
                return;
            }

            //            $items = $classifications->get_classifications($classification_tree_id);
            //            $items = json_decode($items, true);  // cova classification items
            //
            //            $categories = [];
            //            $classifications = [];
            //
            //            // get items from categories
            //            if (isset($items['Categories'])) {
            //                $categories = self::get_cova_categories_classifications_recursive($items['Categories']);
            //
            //                foreach ($items['Categories'] as $category) {
            //                    $categories[][] = [
            //                        'Id' => $category['Id'],
            //                        'Name' => $category['Name']
            //                    ];
            //                }
            //
            //                $categories = call_user_func_array('array_merge', $categories);
            //            }
            //
            //            if (isset($items['Classifications'])) {
            //                $classifications = $items['Classifications'];
            //            }
            //
            //            $merged_categories = array_merge($categories, $classifications);
            //            $merged_categories = array_filter($merged_categories);

            $merged_categories = Cova_Product_Category::get_all_cova_categories($classification_tree_id);

            if (empty($merged_categories)) {
                echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';
                return;
            }

            $mapping = get_option('cova_category_mapping');

            echo '<p></p>';
            echo '<hr>';

            echo '<h4>Top Level Categories</h4>';
            foreach ($merged_categories as $key => $item) {

                $item_key = sanitize_title_with_dashes($item['Name']);

                echo '<div class="cova-cat-mapping-wrap">';
                echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item['Name'] .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 0) .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 1) .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 2) .'">';
                echo '</div>';
            }

            $cova_categories = $this->get_cova_possible_categories();

            echo '<p style="margin-bottom:20px;"></p>';
            echo '<hr>';

            echo '<h4>Online Menu Categories</h4>';
            foreach ($cova_categories as $key => $item) {

                $item_key = str_replace(' >>> ', '-', $item);
                $item_key = sanitize_title_with_dashes($item_key);
                $item = str_replace(' >>> ', ' → ', $item);

                echo '<div class="cova-cat-mapping-wrap">';
                echo '<input type="text" style="min-width: 290px" readonly="readonly" name="cova_classification['. $item_key .']" value="'. $item .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 0) .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 1) .'">';
                echo '<input type="text" name="cova_classification['. $item_key .'][]" value="'. $this->get_cova_mapping_value($mapping, $item_key, 2) .'">';
                echo '</div>';
            }

            echo '<p><input type="submit" class="cova-sync-btn button button-primary button-large" name="save_cova_wc_mapping" value="Save Mapping"></p>';
            echo '</form>';

            echo '<p style="margin: 30px 0;"></p>';
            echo '<hr>';

            echo '<h3>Regenerate Product Categories</h3>';

            echo '<p><input type="submit" id="cova-regenerate-categories" class="cova-sync-btn button button-primary button-large" value="Regenerate"></p>';
        endif;
    }

    public function render_sync_cron_jobs_section()
    {
        if($this->current_section === 'cron_jobs') {

            $this->save_cron_settings();

            $cron_jobs = [
                'cova_update_pricing'   => __('Pricing Sync', 'dabber'),
                'cova_update_inventory' => __('Inventory Sync', 'dabber'),
                'cova_update_products'  => __('Products Sync', 'dabber'),
                'cova_import_products'  => __('Product Import', 'dabber'),
                'cova_global_data'        => __('Bulk cova data', 'dabber')
            ];

            $enabled_jobs = (array) get_option('dabber_enabled_crons');
            ?>
            <form action="" method="post">
                <h3>Enable/Disable Jobs</h3>
                <table class="form-table">
                    <tbody>
                    <?php foreach($cron_jobs as $key => $name) : ?>
                        <tr>
                            <th scope="row"><?php echo $name ?></th>
                            <td>
                                <fieldset>
                                    <label for="dabber_enable_<?php echo $key ?>">
                                        <input name="dabber_enabled_crons[<?php echo $key ?>]" <?php echo ((array_key_exists($key, $enabled_jobs))? 'checked="checked"' : '') ?> type="checkbox" id="dabber_enable_<?php echo $key ?>" value="1">
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <input type="submit" id="submit" name="dabber-cron-jobs-settings" class="button button-primary" value="Save Changes">
            </form>
            <?php
        }
    }

    public function render_sync_promotions_section()
    {
        if($this->current_section !== 'promotions') {
            return;
        }

        $this->save_promo_settings();

        $promotions = get_option('dabber_promotions');
        $enabled_promos = (array) get_option('dabber_enabled_promos');
        $override_sale_prices = get_option('dabber_override_sale_prices');

        if (empty($promotions)) {
            echo '<p>No available promotions.</p>';
            return;
        }

        $promos_arr = [];

        foreach ($promotions as $location_id => $promos) {
            foreach ($promos as $promo) {
                $promos_arr[$promo['Id']] = $promo;
            }
        }

        ?>
        <form action="" method="post">
            <h3>Enable/Disable Promotions</h3>
            <table class="form-table">
                <tbody>
                <?php foreach ($promos_arr as $promo_id => $promo) :
                        $promo_details = cova_get_promo_formatted_details($promo);
                    ?>
                    <tr>
                        <th scope="row">
                            <?php echo $promo_details['name'] .' - '. $promo_details['discount']; ?>
                            <div class="promo-details">
                                <?php if (is_array($promo_details['schedule'])) : ?>
                                    <?php foreach ($promo_details['schedule'] as $sched) : ?>
                                        <p><?php echo $sched['start'] .' to '. $sched['end']  ?></p>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <p><?php echo $promo_details['schedule'] ?></p>
                                <?php endif; ?>
                            </div>
                        </th>
                        <td>
                            <fieldset>
                                <label for="dabber_enable_<?php echo $promo_id ?>">
                                    <input name="dabber_enabled_promotions[<?php echo $promo_id ?>]" <?php echo ((in_array($promo_id, $enabled_promos))? 'checked="checked"' : '') ?> type="checkbox" id="dabber_enable_<?php echo $promo_id ?>" value="1">
                                    <input type="hidden" name="dabber_promos[]" value="<?php echo $promo_id; ?>">
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <hr/>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">Override product on sale price</th>
                        <td>
                            <fieldset>
                                <label for="dabber_override_sale_prices">
                                    <input name="dabber_override_sale_prices" <?php echo (($override_sale_prices === 'on')? 'checked="checked"' : '') ?> type="checkbox" id="dabber_override_sale_prices" value="1">
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                </tbody>
            </table>
            <input type="submit" id="submit" name="dabber-promotions-settings" class="button button-primary" value="Save Changes">
        </form>

        <style>
            .promo-details p {
                margin-bottom: 3px;
                margin-top: 0;
            }

            .promo-details {
                font-weight: normal;
            }
        </style>
        <?php
    }

    public function render_sync_product_fields_mapping()
    {
        if($this->current_section !== 'product_fields_mapping') {
            return;
        }

        $this->save_product_fields_mapping();

        $product_fields = apply_filters(
            'cova_product_fields', [
            [
               'key'        => 'terpene_percent',
               'name'       => __('Terpene %'),
               'multiple'   => false
            ],
            [
                'key'        => 'terpenes',
                'name'       => __('Terpenes'),
                'multiple'   => true
            ],
            [
                'key'        => 'cbd_percent',
                'name'       => __('CBD %'),
                'multiple'   => false
            ],
            [
                'key'        => 'cbd_min',
                'name'       => __('CBD Min'),
                'multiple'   => false
            ],
            [
                'key'        => 'cbd_max',
                'name'       => __('CBD Max'),
                'multiple'   => false
            ],
            [
                'key'        => 'thc_percent',
                'name'       => __('THC %'),
                'multiple'   => false
            ],
            [
                'key'        => 'thc_min',
                'name'       => __('THC Min'),
                'multiple'   => false
            ],
            [
                'key'        => 'thc_max',
                'name'       => __('THC Max'),
                'multiple'   => false
            ]
            ]
        );

        $cova_fields = get_option('cova_product_field_mapping');
        $wc_field_mapping = (array) get_option('cova_wc_product_field_mapping');

        if (!is_array($cova_fields) || empty($cova_fields)) {
            echo '<p>No available cova fields to map. Please sync the products.</p>';
            return;
        }
        ?>
        <div class="cova-sync-wrap">
            <form action="" method="post">
                <h3>Product Fields Mapping</h3>
                <table class="form-table cova-product-field-mapping">
                    <tbody>
                        <?php foreach($product_fields as $item) : ?>
                            <tr>
                                <td class="product-field"><?php echo $item['name']; ?></td>
                                <td class="cova-field">
                                    <?php if ($item['multiple'] === true) : ?>
                                        <select name="product_field[<?php echo $item['key'] ?>][]" multiple="multiple">
                                            <option value="">-- Choose Field --</option>
                                            <?php
                                            foreach($cova_fields as $field_key => $field_name) :
                                                $is_selected = (in_array($field_key, $wc_field_mapping[$item['key']]))? 1: 0;
                                                ?>
                                                <option value="<?php echo $field_key ?>" <?php selected($is_selected, 1, true) ?>><?php echo $field_name ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>

                                    <?php if ($item['multiple'] === false) : ?>
                                        <select name="product_field[<?php echo $item['key'] ?>]">
                                            <option value="">-- Choose Field --</option>
                                            <?php
                                            foreach($cova_fields as $field_key => $field_name) :
                                                $is_selected = (isset($wc_field_mapping[$item['key']]) && $wc_field_mapping[$item['key']] == $field_key)? 1: 0;
                                                ?>
                                                <option value="<?php echo $field_key ?>" <?php selected($is_selected, 1, true) ?>><?php echo $field_name ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <hr/>
                <input type="submit" id="submit" name="dabber-product_fields_mapping-settings" class="button button-primary" value="Save Changes">
            </form>
        </div>
        <style>
            .cova-product-field-mapping .product-field {
                width: 120px;
            }
        </style>
        <?php
    }

    public function save_product_fields_mapping()
    {
        if (!isset($_POST['dabber-product_fields_mapping-settings'])) {
            return;
        }

        update_option('cova_wc_product_field_mapping', $_POST['product_field']);
    }

    public function render_sync_page()
    {
        ?>
        <div class="cova-sync-wrap">
            <div class="cova-sync-controls">
                <div>
                    <form id="dabber-sync" class="" method="post" action="">
                        <h3>Choose Sync Action</h3>
                        <select id="sync-action" name="sync-action" required="required">
                            <option value="">-- Choose action --</option>
                            <option value="sync-pricing">Sync Pricing</option>
                            <option value="sync-inventory">Sync Inventory</option>
                            <option value="sync-details">Update Product Details</option>
                            <option value="import">Import Products</option>
                            <!-- <option value="full-sync-pricing">Full Sync Pricing</option> -->
                            <!-- <option value="full-sync-inventory">Full Sync Inventory</option> -->
                            <!-- <option value="full-sync-details">Full Sync Product Details</option>-->
                            <option value="sync-promotions">Sync Promotions</option>
                            <option value="sync-locations">Sync Location</option>
                        </select>
                        <input type="submit" name="cova-import-products" class="button button-primary cova-sync-btn button-large" value="Submit" />
                    </form>
                </div>
            </div>
            <div class="cova-sync-console">
                <div class="cova-sync-console-head">
                    <span class="sync-process"></span>
                    <span class="sync-status"></span>
                </div>
                <div class="sync-console-body">
                    <ul></ul>
                </div>
                <div class="cova-sync-console-command">
                    <form id="sync-command" method="post" action="">
                        <input type="text" data-lpignore="true" spellcheck="false" name="cmd">
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_general_settings_page()
    {
        $this->save_general_settings();

        $dabber_site_status = get_option('dabber_site_status');
        $enable_push_order = get_option('cova_enable_push_order');
        $weight_limits = get_option('dabber_weight_limits');

        ?>
        <div class="cova-sync-wrap">
            <form action="" method="post">

                <h2><?php _e('Site launching settings', 'cova') ?></h2>
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row"><?php _e('Site status', 'cova') ?></th>
                        <td>
                            <fieldset>
                                <label for="site-status-live">
                                    <input name="site-status" <?php echo ((!$dabber_site_status || $dabber_site_status === 'live')? 'checked="checked"' : '') ?> type="radio" id="site-status-live" value="live">
                                    Live
                                </label>
                                <br>
                                <label for="site-status-coming-soon">
                                    <input name="site-status" <?php echo (($dabber_site_status === 'coming-soon')? 'checked="checked"' : '') ?> type="radio" id="site-status-coming-soon" value="coming-soon">
                                    Coming soon
                                </label>
                                <br>
                                <label for="site-status-maintenance">
                                    <input name="site-status" <?php echo (($dabber_site_status === 'maintenance')? 'checked="checked"' : '') ?> type="radio" id="site-status-maintenance" value="maintenance">
                                    Maintenance
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Enable push order to cova', 'cova') ?></th>
                        <td>
                            <fieldset>
                                <label for="cova-enable-push-order">
                                    <input name="cova-enable-push-order" <?php echo (($enable_push_order === 'yes')? 'checked="checked"' : '') ?> type="checkbox" id="cova-enable-push-order" value="1">
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                    </tbody>
                </table>

                <div style="display: none;">
                    <hr>
                    <h2><?php _e('Cart limit settings (g)', 'cova') ?></h2>

                    <table class="form-table">
                        <tbody>
                        <tr>
                            <th scope="row"><?php _e('Total cart weight limit', 'dabber') ?></th>
                            <td>
                                <fieldset data-index="0">
                                    <label for="total_weight_limit">
                                        <input type="hidden" name="weight_limit[0][limit_name]" value="cart_total">
                                        <input type="number" step=".01" id="total_weight_limit" name="weight_limit[0][limit]" value="30">
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Weight limit by categories', 'dabber') ?></th>
                            <td>
                                <fieldset data-index="1">
                                    <label for="">
                                        <input type="text" name="weight_limit[1][limit_name]">
                                        <input type="number" step=".01" class="category_weight_limit" name="weight_limit[1][limit]" value="">
                                    </label>
                                    <button class="add-category-limit">Add</button>
                                </fieldset>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <input type="submit" id="submit" name="dabber_save_general_settings" class="button button-primary" value="<?php _e('Save Changes', 'cova') ?>">
            </form>
        </div>
        <?php
    }

    public function save_general_settings()
    {
        if (!isset($_POST['dabber_save_general_settings'])) {
            return;
        }

        $site_status = isset($_POST['site-status']) ? $_POST['site-status'] : 'live';
        update_option('dabber_site_status', sanitize_text_field($site_status));

        $enable_push_order = (isset($_POST['cova-enable-push-order']))? 'yes' : 'no';
        update_option('cova_enable_push_order', sanitize_text_field($enable_push_order));

        if (isset($_POST['weight_limit']) && is_array($_POST['weight_limit'])) {
            update_option('dabber_weight_limits', $_POST['weight_limit']);
        }
    }

    public function save_cron_settings()
    {
        if (!isset($_POST['dabber-cron-jobs-settings'])) {
            return;
        }

        if (isset($_POST['dabber_enabled_crons'])) {
            update_option('dabber_enabled_crons', array_map('sanitize_text_field', $_POST['dabber_enabled_crons']));
        } else {
            update_option('dabber_enabled_crons', []);
        }
    }

    public function save_promo_settings()
    {
        if (!isset($_POST['dabber-promotions-settings'])) {
            return;
        }

        $enabled_promos = [];

        if (isset($_POST['dabber_enabled_promotions'])) {
            $enabled_promos = array_map('sanitize_text_field', $_POST['dabber_enabled_promotions']);
            $enabled_promos = array_keys($enabled_promos);
            update_option('dabber_enabled_promos', $enabled_promos);
        } else {
            update_option('dabber_enabled_promos', []);
        }

        if (isset($_POST['dabber_promos']) && !empty($_POST['dabber_promos'])) {
            $disabled_promos = array_diff($_POST['dabber_promos'], $enabled_promos);
            update_option('dabber_disabled_promos', $disabled_promos);
        }

        if (isset($_POST['dabber_override_sale_prices'])) {
            update_option('dabber_override_sale_prices', 'on');
        } else {
            update_option('dabber_override_sale_prices', 'off');
        }
    }

    public function get_cova_mapping_value($mapping, $id, $index)
    {
        if (!isset($mapping[$id][$index])) {
            return '';
        }

        return $mapping[$id][$index];
    }

    public function save_cova_wc_mapping()
    {
        if (!isset($_POST['save_cova_wc_mapping'])) {
            return;
        }

        if (isset($_POST['cova_classification'])) {
            update_option('cova_category_mapping', $_POST['cova_classification']);
        }

        if (isset($_POST['cova-classification-tree-id'])) {
            update_option('cova_classification_tree_id', sanitize_text_field($_POST['cova-classification-tree-id']));
        }
    }

    public function get_cova_possible_categories()
    {
        //        $data = Cova_Data_Manager::get_stored_data('grouped_catalog_items');

        //        if ($data !== false && !empty($data)) {
        //            return $data;
        //        }

        $catalog_api = new Sync\Catalog();
        $catalog_api->run();

        $all_items = $catalog_api->items();
        $catalog_ids = [];

        foreach ($all_items as $key => $item) {
            $catalog_ids[] = $item['CatalogItemId'];
        }

        $grouped_catalog_ids = array_chunk($catalog_ids, 450, false);
        $cova_categories = [];

        foreach ($grouped_catalog_ids as $key => $catalog_id_items) {

            $grouped_products = $catalog_api->bulk(
                [
                'CatalogItemIds' => $catalog_id_items
                ]
            );

            foreach ($grouped_products['CatalogItems'] as $catalog_id => $catalog_item) {

                $grouped_cats = [];

                if (isset($catalog_item['CanonicalClassification']['Name'])) {
                    $grouped_cats[] = $catalog_item['CanonicalClassification']['Name'];
                }

                if (isset($catalog_item['Specifications']) && !empty($catalog_item['Specifications'])) {
                    foreach ($catalog_item['Specifications'] as $key => $spec) {
                        if ($spec['Name'] === 'Online Menu') {
                            foreach ($spec['Fields'] as $field) {
                                if ($field['DisplayName'] === 'Online Menu Category') {
                                    $grouped_cats[] = $field['Value'];
                                }
                            }
                        }
                    }
                }

                if (count($grouped_cats) > 1) { // only include items with sub category
                    $cova_categories[] = implode(' >>> ', $grouped_cats);
                }
            }
        }

        $cova_categories = array_unique($cova_categories);

        //        Cova_Data_Manager::store_data('grouped_catalog_items', $cova_categories);

        return $cova_categories;
    }

    public function save_api_settings()
    {
        if (!isset($_POST['cova-save-api-credentials'])) {
            return;
        }

        $api = get_option('dabber_api_details');

        if ($_POST['dabber_update_live_credentials'] == 1) {

            $this->save_api_credentials(
                [
                'company_id'    => sanitize_text_field($_POST['cova_api_company_id']),
                'client_id'        => sanitize_text_field($_POST['cova_api_client_id']),
                'client_secret'    => (trim($_POST['cova_api_client_secret']) !== '')? sanitize_text_field($_POST['cova_api_client_secret']) : $api[$api['mode']]['credentials']['client_secret'],
                'username'        => sanitize_text_field($_POST['cova_api_username']),
                'password'        => (trim($_POST['cova_api_password']) !== '')? sanitize_text_field($_POST['cova_api_password']) : $api[$api['mode']]['credentials']['password']
                ], 'live'
            );
        }

        if ($_POST['dabber_update_sandbox_credentials'] == 1) {

            $this->save_api_credentials(
                [
                'company_id'    => sanitize_text_field($_POST['cova_api_sandbox_company_id']),
                'client_id'        => sanitize_text_field($_POST['cova_api_sandbox_client_id']),
                'client_secret'    => (trim($_POST['cova_api_sandbox_client_secret']) !== '')? sanitize_text_field($_POST['cova_api_sandbox_client_secret']) : $api[$api['mode']]['credentials']['client_secret'],
                'username'        => sanitize_text_field($_POST['cova_api_sandbox_username']),
                'password'        => (trim($_POST['cova_api_sandbox_password']) !== '')? sanitize_text_field($_POST['cova_api_sandbox_password']) : $api[$api['mode']]['credentials']['password']
                ], 'sandbox'
            );
        }

        $api = get_option('dabber_api_details');

        if (isset($_POST['cova_api_enable_sandbox'])) {
            $api['mode'] = 'sandbox';
        } else {
            $api['mode'] = 'live';
        }

        update_option('dabber_api_details', $api);
    }

    public function save_api_credentials($credentials, $mode)
    {
        $api = get_option('dabber_api_details');

        $cova_api = new \CovaAPI\Auth();
        $cova_api->set_credentials($credentials);
        $response = $cova_api->generate_access_token();

        if (!isset($response['access_token'])) {
            $api_data = false;

            echo '<p style="color: red">'. __($mode .' API error', 'dabber') .': '. $response['Description'] .'</p>';

            update_option('dabber_is_api_connected', 'no');
        } else {

            $api_data = [
                'credentials' => $credentials,
                'auth' => [
                    'access_token'  => $response['access_token'],
                    'expires_in'    => $response['expires_in'],
                    'refresh_token' => $response['refresh_token'],
                    'generated_at'  => date('Y-m-d H:i:s'),
                    'expired_at'    => date('Y-m-d H:i:s', strtotime('+'. $response['expires_in'].' seconds'))
                ]
            ];

            update_option('dabber_is_api_connected', 'yes');
        }

        $api[$mode] = $api_data;

        update_option('dabber_api_details', $api);
    }
}
