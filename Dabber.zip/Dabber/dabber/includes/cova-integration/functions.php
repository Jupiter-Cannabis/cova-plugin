<?php

use Cova_Integration\Cova_Data_Manager;
use Cova_Integration\Variable_Product_Details_Manager;
use Cova_Integration\WC_Variable_Product_Creator;
use Cova_Integration\WC_Variable_Product_Updater;

define('COVA_INTEGRATION_URI', COVA_PLUGIN_URI .'includes/cova-integration');

function dabber_set_sync_on()
{
    if (!defined('DABBER_DOING_SYNC')) {
        define('DABBER_DOING_SYNC', true);
    }
}

function dabber_get_converted_attribute_stock_qty($quantity)
{
    return (float) ($quantity / 1000);
}

function dabber_get_attribute_stock_quantity_by_catalog_id($catalog_id)
{
    $attribute_stock_id = dabber_get_attribute_stock_by_catalog_id($catalog_id);

    if ($attribute_stock_id === false) {
        return 0;
    }

    return (float) get_post_meta($attribute_stock_id, '_quantity', true);
}

function dabber_get_tiered_bulk_product_item($catalog_id, $tiered_price_id)
{
    $posts = new \WP_Query(
        [
        'post_type'      => 'product',
        'posts_per_page' => 1,
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'cova_catalog_id',
                'value' => $catalog_id,
                'compare' => '='
            ],
            [
                'key' => 'dabber_is_base_bulk_product',
                'value' => false,
                'compare' => '='
            ]
        ]
        ]
    );

    if (! $posts->have_posts() ) {
        return false;
    } else {
        $posts->the_post();

        return $posts->post->ID;
    }
}

function dabber_get_base_bulk_product($catalog_id) 
{
    $posts = new \WP_Query(
        [
        'post_type'      => 'product',
        'posts_per_page' => 1,
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'cova_catalog_id',
                'value' => $catalog_id,
                'compare' => '='
            ],
            [
                'key' => 'dabber_is_base_bulk_product',
                'value' => true,
                'compare' => '='
            ]
        ]
        ]
    );

    if (! $posts->have_posts() ) {
        return false;
    } else {
        $posts->the_post();

        return $posts->post->ID;
    }    
}

function dabber_get_attribute_stock_by_catalog_id($catalog_id)
{
    $posts = new \WP_Query(
        [
        'post_type'      => 'mewz_attribute_stock',
        'posts_per_page' => 1,
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'attr_stock_catalog_id',
                'value' => 'attr-stock-'. $catalog_id,
                'compare' => '='
            ]
        ]
        ]
    );

    if (! $posts->have_posts() ) {
        return false;
    } else {
        $posts->the_post();

        return $posts->post->ID;
    }    
}

function dabber_get_products_by_catalog_ids($catalog_ids)
{
    $products = new \WP_Query(
        [
        'post_type'      => ['product', 'product_variation'],
        'post_status'      => 'publish',
        'posts_per_page' => -1,
        'meta_query' => [
            'relation' => 'AND',
            [
                'key'       => 'cova_catalog_id',
                'value'   => $catalog_ids,
                'compare' => 'IN'
            ]
        ]
        ]
    );

    if (!isset($products->posts)) {
        return [];
    }

    return $products->posts;
}

function dabber_get_bulk_products_by_catalog_id($catalog_id)
{
    $product = new \WP_Query(
        [
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'cova_catalog_id',
                'value' => $catalog_id,
                'compare' => '='
            ]
        ]
        ]
    );

    if (!$product->post_count) {
        return false;
    }

    return $product->posts;    
}

function dabber_get_product_by_catalog_id($catalog_id)
{
    $product = new \WP_Query(
        [
        'post_type' => ['product', 'product_variation'],
        'posts_per_page' => 1,
        'post_status' => 'any',
        'orderby' => 'ID',
        'order' => 'DESC',
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'cova_catalog_id',
                'value' => $catalog_id,
                'compare' => '='
            ]
        ]
        ]
    );

    if (!$product->post_count) {
        return false;
    }

    return apply_filters('cova_get_product_by_catalog_id', wc_get_product($product->post->ID));
}

function cova_get_product_catalog_id($product_id)
{
    $catalog_id = get_post_meta($product_id, 'cova_catalog_id', true);

    if (!$catalog_id) {
        $product = wc_get_product($product_id);
        $catalog_id = $product->get_sku();
    }

    return $catalog_id;
}

function cova_get_image($id, $name = '')
{
    $assets_url = 'https://amsprod.blob.core.windows.net/assets/';
    $img_ext = [
        'png',
        'jpeg',
        'jpg',
        'gif'
    ];
    $image_sizes = [
        'full' => '',
        // 'thumbnail' => '_300_150'
    ];
    $images = [];

    foreach ($image_sizes as $size_name => $size) {
        
        foreach ($img_ext as $ext) {
            $img_url = $assets_url . $id . $size . '.'. $ext;

            if (@getimagesize($img_url)) {
                $images[$size_name] = [
                    'name' => $name,
                    'url' => $img_url,
                    'cova_id' => $id
                ];
                break;
            }
        }

    }

    return $images;
}

function cova_is_image_exists($cova_img_id)
{
    $image = new \WP_Query(
        [
        'post_type' => 'attachment',
        'posts_per_page' => 1,
        'post_status' => 'any',
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => 'cova_img_id',
                'value' => $cova_img_id,
                'compare' => '='
            ]
        ]
        ]
    );

    if (!isset($image->posts[0])) {
        return false;
    }

    return $image->posts[0];
}

function cova_truncate_slug($slug = false)
{
    preg_match('/(.*?)-V[0-9a-z]+/i', $slug, $new_slug);

    if (!isset($new_slug[1])) {
        return $slug;
    }

    return trim($new_slug[1]);
}

/**
 * Upload image if not exists
 *
 * @param  $data
 * @return false|int|WP_Error
 */
function cova_upload_image($data)
{
    $image = cova_is_image_exists($data['cova_id']);

    if ($image !== false) {
        return $image->ID;
    }

    $image_data = file_get_contents($data['cova_url']);

    if (!$image_data) {
        return false;
    }

    $image_name       = basename($data['cova_url']);
    $upload_dir       = wp_upload_dir();
    $unique_file_name = wp_unique_filename($upload_dir['path'], $image_name);
    $file_title       = basename($unique_file_name);
    $file_type        = wp_check_filetype($image_name, null);

    if(wp_mkdir_p($upload_dir['path']) ) {
        $file = $upload_dir['path'] . '/' . $image_name;
    } else {
        $file = $upload_dir['basedir'] . '/' . $image_name;
    }

    $save_image = file_put_contents($file, $image_data);

    if (!$save_image) {
        return false;
    }

    $attachment = [
        'post_mime_type' => $file_type['type'],
        'post_title'     => $file_title,
        'post_content'   => '',
        'post_status'    => 'inherit'
    ];

    $attach_id = wp_insert_attachment($attachment, $file);

    if (is_wp_error($attach_id)) {
        return false;
    }

    include_once ABSPATH . 'wp-admin/includes/image.php';

    $attach_data = wp_generate_attachment_metadata($attach_id, $file);

    wp_update_attachment_metadata($attach_id, $attach_data);

    update_post_meta($attach_id, 'cova_img_id', $data['cova_id']);

    return $attach_id;
}

function dabber_get_all_imported_products()
{
    global $wpdb;

    $sql = "SELECT meta.meta_value
				FROM {$wpdb->prefix}postmeta as meta
				LEFT JOIN {$wpdb->prefix}posts as products
				ON products.ID = meta.post_id
				WHERE meta.meta_key = 'cova_catalog_id'
				AND (
					products.post_status = 'publish' OR
					products.post_status = 'private' OR
					products.post_status = 'draft'
				)";

    $catalog_ids = $wpdb->get_results($sql);

    if (empty($catalog_ids)) {
        return [];
    }

    $ids = [];
    foreach ($catalog_ids as $key => $item) {
        $ids[] = $item->meta_value;
    }

    return $ids;
}

function dabber_create_variable_product($cova_product)
{
    global $cova_api;

    $variable_product = new WC_Variable_Product_Creator($cova_api);
    $variable_product->set_data($cova_product);
    $variable_product->set_cova_global_data(Cova_Data_Manager::generate_global_data());

    return $variable_product->create();
}

function dabber_update_variable_product($data, $product)
{
    global $cova_api;

    $details_manager = new Variable_Product_Details_Manager($cova_api);
    $details_manager->set_additional_data(
        apply_filters(
            'dabber_sync_variable_product_additional_data', [
            'product_type'  => $data['product_type'],
            'catalog_id'    => $data['catalog_id'],
            'cova_data'     => $data
            ]
        )
    );

    $details_manager->set_slug_id($cova_api['catalog']->truncate_slug($data['Id']));
    $details_manager->set_cova_global_data(Cova_Data_Manager::generate_global_data());
    $details_manager->generate_cova_details();

    $details = $details_manager->get_wc_product_details();

    $details['product'] = $product;

    $update_product = new WC_Variable_Product_Updater();
    $update_product->set_data($details);

    return $update_product->update();
}
