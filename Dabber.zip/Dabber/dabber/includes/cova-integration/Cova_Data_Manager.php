<?php

namespace Cova_Integration;

class Cova_Data_Manager
{
    private static $instance = null;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new Cova_Data_Manager();
        }

        return self::$instance;
    }

    public static function generate_global_data()
    {
        $catalog_data   = self::get_global_data('catalog');
        $inventory_data = self::get_global_data('inventory');
        $locations_data = self::get_global_data('locations');

        $data = [
            'catalog'   => $catalog_data,
            'inventory' => $inventory_data,
            'locations' => $locations_data
        ];

        $prices = [];

        foreach ($data['locations'] as $location_id => $location) {
            $price_data = self::get_global_data('pricing-'. $location_id);
            $prices[$location_id] = $price_data[$location_id];
        }

        $data['pricing'] = $prices;

        return $data;
    }

    public static function get_global_data($file_path, $force_update = false)
    {
        $is_needs_update = self::is_data_needs_update($file_path);
        $stored_data = self::get_stored_data($file_path);

        if ($is_needs_update === true || empty($stored_data) || $stored_data === false || $force_update === true) {
            switch ($file_path) {
            case 'catalog':
                self::store_catalog_data($file_path);
                break;
            case 'inventory':
                self::store_inventory_data($file_path);
                break;
            case (preg_match('/pricing-[0-9]+/i', $file_path)? true : false):
                   self::store_pricing_data($file_path);
                break;
            case 'locations':
                self::store_locations_data($file_path);
                break;
            default:
                return [];
                    break;
            }            
        }

        return self::get_stored_data($file_path);
    }

    public static function store_locations_data($file_path)
    {
        $locations = new Sync\Locations;
        $locations->run();

        $locations_data = $locations->get_all_locations();        
        
        self::store_data($file_path, $locations_data);
        self::save_storage_timestamp($file_path);

        return $locations_data;        
    }

    public static function store_catalog_data($file_path)
    {
        $catalog = new Sync\Catalog;
        $catalog->run();

        $catalog_data = $catalog->get_all_items();        
        
        self::store_data($file_path, $catalog_data);
        self::save_storage_timestamp($file_path);

        return $catalog_data;
    }

    public static function store_inventory_data($file_path)
    {
        $inventory = new Sync\Inventory;
        $inventory->run();

        $locations_data = self::get_global_data('locations');
        $inventory_data = $inventory->get_inventory_by_locations($locations_data);
        
        self::store_data($file_path, $inventory_data);
        self::save_storage_timestamp($file_path);

        return $inventory_data;
    }

    public static function store_pricing_data($file_path)
    {
        $pricing = new Sync\Item_Pricing;
        $pricing->run();

        $pricing_name = explode('-', $file_path);
        $location_id = $pricing_name[1];

        $pricing_data = $pricing->get_location_pricing($location_id);

        if (empty($pricing_data)) {
            return [];

        }
        self::store_data('pricing-'. $location_id, $pricing_data);
        self::save_storage_timestamp($file_path);

        return $pricing_data;
    }

    public static function is_stored_file_exists($file)
    {
        $path_info = pathinfo($file);
        $log_dir   = rtrim(Config_Manager::get_config('cova_sync.log_path'), '/');
        $dirname   = ($path_info['dirname'] !== '.')? $path_info['dirname'] : '';
        $log_path  = rtrim($log_dir .'/'. $dirname, '/');
        $file_path = $log_path .'/'. str_replace('.json', '', $path_info['filename']) .'.json';

        return file_exists($file_path);
    }

    public static function store_data($file, $data, $save_timestamp = false)
    {
        $path_info = pathinfo($file);
        $log_dir   = rtrim(Config_Manager::get_config('cova_sync.log_path'), '/');
        $dirname   = ($path_info['dirname'] !== '.')? $path_info['dirname'] : '';
        $log_path  = rtrim($log_dir .'/'. $dirname, '/');
        $file_path = $log_path .'/'. str_replace('.json', '', $path_info['filename']) .'.json';

        if (!file_exists($file_path)) {

            if (!is_dir($log_path)) {
                mkdir($log_path, 0775, true);
            }            

            $f = fopen($file_path, 'w');
            fclose($f);
        }

        file_put_contents($file_path, json_encode($data));

        if ($save_timestamp === true) {
            Cova_Data_Manager::save_storage_timestamp($file);
        }
    }

    public static function get_stored_data($file, $last_seconds_ago = null)
    {
        $file_path = Config_Manager::get_config('cova_sync.log_path') . str_replace('.json', '', $file) .'.json';

        if (!file_exists($file_path)) {
            self::store_data($file, []);
            return false;
        }

        if ($last_seconds_ago === null || self::is_data_needs_update($file, $last_seconds_ago) !== true) {
            $data = file_get_contents($file_path);

            if (trim($data) === '') {
                return [];
            }

            return json_decode($data, true);
        }

        return [];
    }    

    public static function remove_stored_data($file)
    {
        $file_path = Config_Manager::get_config('cova_sync.log_path') . str_replace('.json', '', $file) .'.json';

        if (!file_exists($file_path)) {        
            return false;
        }        

        return unlink($file_path);
    }

    public static function is_data_needs_update($file_path, $interval = null)
    {            
        $data_key = sanitize_title_with_dashes($file_path);
        $data_log = self::get_storage_timestamp($data_key);

        if (empty($data_log)) {
            return true;
        }

        $interval        = ($interval !== null)? $interval : Config_Manager::get_config('cova_sync.global_data_storage_interval');
        $log_time        = strtotime($data_log);
        $current_time  = strtotime(date('Y-m-d h:i:s'));
        $time_diff        = abs($log_time - $current_time);

        if ($time_diff < $interval) {
            return round($time_diff / 60, 0);
        }

        return true;
    }

    public static function save_storage_timestamp($data_key)
    {
        $data = self::get_stored_data('global-data-logs');
        $data = (is_array($data))? $data : [];

        $data[$data_key] = date('Y-m-d h:i:s');

        self::store_data('global-data-logs', $data);
    }

    public static function get_storage_timestamp($data_key = '')
    {    
        $data = self::get_stored_data('global-data-logs');

        if ($data === false) {
            return [];
        }

        if ($data_key === '') {
            return $data;
        }

        if (!isset($data[$data_key])) {
            return [];
        }

        return $data[$data_key];
    }
}
