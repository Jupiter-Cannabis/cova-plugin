function sync_ajax(sync_process, action, args)
{
    let ajax_args = {
        url: cova_sync.ajax_url,
        type: 'POST',
        data: {
            action: 'cova_'+ sync_process +'_'+ action,
            params: {}
        },
        error: function (err) {
            console.log(err);
        },
        statusCode: {
            502: function () {
                console.log('Encountered 502 error. Continuing process.');
                console.log(sync_process, action, args);
                sync_ajax(sync_process, action, args);
            }
        }
    };

    if (args.hasOwnProperty('data')) {
        ajax_args.data.params = args.data;
    }
    if (args.hasOwnProperty('beforeSend')) {
        ajax_args.beforeSend = args.beforeSend;
    }
    if (args.hasOwnProperty('success')) {
        ajax_args.success = args.success;
    }
    if (args.hasOwnProperty('error')) {
        ajax_args.error = args.error;
    }

    jQuery.ajax(ajax_args);
}

function cova_sync_set_progress_number(progress_num = 0, over = false)
{
    let html = '<span class="progress-number"><span class="progress">'+ progress_num +'</span> / <span class="over">'+ over +'</span></span>';

    if (jQuery('.progress-number').length > 0) {
        jQuery('.progress-number .progress').html(progress_num);
        jQuery('.progress-number .over').html(over);
    } else {
        jQuery('.cova-sync-console-head').append(html);
    }    
}

function cova_sync_set_operation_name(operation = '')
{
    if (operation === '') {
        jQuery('.sync-process').html('');
        return;
    }

    let available_operations = {
        'sync-locations': 'Location Sync',
        'sync-inventory': 'Inventory Sync',
        'sync-pricing': 'Update Pricing',
        'update-products': 'Sync Product Details',
        'import-products': 'Import Products',
        'sync-promotions': 'Sync Promotions',
        'sync-command': 'Executing Command'
    }

    jQuery('.cova-sync-console-command').hide();
    jQuery('.cova-sync-console-command input').prop('disabled', true);    
    jQuery('.sync-process').html('Process: <span class="'+ operation +'">'+ available_operations[operation] +'</span>');
}

function cova_sync_set_operation_status(status = '')
{
    if (status === '') {
        jQuery('.sync-status').html('').attr('class', 'sync-status');
        return;
    }

    let available_statuses = {
        'processing': 'Processing',
        'complete': 'Completed',
        'stopped': 'Stopped',
        'executing': '...'
    }

    if (status === 'complete') {
        jQuery('.cova-sync-console-command').show();
        jQuery('.cova-sync-console-command input').prop('disabled', false);        
        // jQuery('.cova-sync-btn').prop('disabled', false);
    }

    if (status === 'processing') {
        // jQuery('.cova-sync-btn').prop('disabled', true);    
    }

    jQuery('.sync-status').html(available_statuses[status]).attr('class', 'sync-status').addClass(status);
}

function cova_parse_form_data(data) 
{
    const json = {};

    jQuery.each(
        data, function () {
            json[this.name] = this.value || "";
        }
    );

    return json;
}

function cova_clear_console()
{
    jQuery('.sync-console-body ul').html('');
    jQuery('.progress-number').remove();
}

function cova_print_log_message(response)
{
    let log_html = '';
    let classes = [];

    if (typeof response === 'string') {
        log_html += '<li class=""><div>'+ response + '</div>';
    } else {

        if (response.data.hasOwnProperty('data') === true) {
            classes.push('has-data');
        }

        if (response.data.hasOwnProperty('message_type') === true) {
            classes.push(response.data.message_type);
        }

        log_html += '<li class="'+ classes.join(' ') +'"><div>'+ response.data.message + '</div>';

        if (response.data.hasOwnProperty('data') === true) {
            if (typeof response.data.data === 'object') {
                let json_data = JSON.stringify(response.data.data, undefined, 2);
                log_html += '<div class="data"><pre class="data-content">'+ json_data.replace(/\\/g, "") +'</pre></div>';
            }
        }
    }

    log_html += '</li>';

    jQuery('.sync-console-body ul').append(log_html);    
    jQuery('.sync-console-body').scrollTop(jQuery(document).height());
}

(function ($) {
    $(document.body).on(
        'click', '.sync-console-body li.has-data', function (e) {
            $(this).toggleClass('open');
        }
    );

    $(document.body).on(
        'submit', '#dabber-sync', function (e) {
            let sync_action = $('#sync-action').val();
            let actions = {
                'sync-pricing': 'dabber_sync_pricing',
                'sync-inventory': 'dabber_sync_inventory',
                'sync-details': 'dabber_sync_product_details',
                'full-sync-pricing': 'dabber_sync_pricing',
                'full-sync-inventory': 'dabber_sync_inventory',
                'full-sync-details': 'dabber_sync_product_details',
                'import': 'dabber_import_products',
                'sync-locations': 'dabber_sync_locations',
                'sync-promotions': 'dabber_sync_promotions'
            }

            $(document.body).trigger(actions[sync_action]);

            e.preventDefault();
        }
    );
})(jQuery);