(function ($) {
    function run_sync_command(data)
    {
        data = cova_parse_form_data(data);

        sync_ajax(
            'sync_command', 'execute', {
                data: data,
                beforeSend: function () {
                      cova_clear_console();
                      cova_sync_set_operation_name('');
                      cova_sync_set_operation_status('');

                      cova_print_log_message('Executing command: <span class="cmd-txt">'+ data.cmd +'</span>');
                      $('.cova-sync-console-command input').val('');
                },
                success: function (response) {
                    cova_print_log_message(response);
                }
            }
        );        
    }

    $(document.body).on(
        'submit', '#sync-command', function (e) {
            e.preventDefault();
            run_sync_command($(this).serializeArray());
        }
    );
})(jQuery);