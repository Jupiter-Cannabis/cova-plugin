(function ($) {
    let total_synced = 0;
    let total_update = null;
    
    function dabber_initialize_product_update(clear_log_files)
    {
        sync_ajax(
            'update_sync', 'update_products', {
                data: {
                    clear_log_files: clear_log_files
                },            
                beforeSend: function () {                
                },
                success: function (response) {

                    cova_print_log_message(response);

                    total_synced += response.data.total_synced;

                    if (total_update === null) {
                        total_update = response.data.total_update;
                    }

                    if (response.data.total_synced > 0) {
                        //                     cova_sync_set_progress_number(total_synced, total_update);
                    }                

                    if (response.data.status === 'complete') {
                        total_update = null;
                        total_synced = 0;
                        cova_sync_set_operation_status('complete');
                        return;
                    }

                    dabber_initialize_product_update('no');
                }
            }
        );        
    }

    $(document.body).on(
        'dabber_sync_product_details', function (e) {
            e.preventDefault();

            cova_clear_console();
            cova_print_log_message('Updating products...');
            cova_sync_set_operation_name('update-products');
            cova_sync_set_operation_status('processing');

            dabber_initialize_product_update('yes');
        }
    );

})(jQuery);