(function ($) {
    function initialize_category_mapping()
    {
        sync_ajax(
            'category_mapping', 'regenerate_categories', {
                beforeSend: function () {
                      jQuery('.cova-sync-btn').prop('disabled', true);
                },
                success: function (response) {
                    if (response.data.status === 'complete') {
                        jQuery('.cova-sync-btn').prop('disabled', false);
                        return;
                    }
                    initialize_category_mapping();
                }
            }
        );
    }

    $(document).ready(
        function () {
            $('#cova-regenerate-categories').click(
                function (e) {
                    initialize_category_mapping();
                }
            );        
        }
    );
})(jQuery);