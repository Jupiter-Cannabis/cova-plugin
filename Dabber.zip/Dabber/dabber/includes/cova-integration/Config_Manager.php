<?php

namespace Cova_Integration;

/**
 * Set global site specific configuration
 */
class Config_Manager
{
    private static $config;

    public static function set_config($key, $value)
    {
        self::$config[$key] = $value;
    }

    public static function get_config($key = null)
    {
        if ($key === null) {
            return self::$config;
        }

        $key = explode('.', $key);        
        $config = self::$config;

        foreach ($key as $key_item) {
            if (!isset($config[$key_item])) {
                die('Undefined '. $key_item .' config key!');
            }

            $config = $config[$key_item];
        }

        return $config;
    }
}
