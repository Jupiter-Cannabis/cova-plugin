<?php

namespace Cova_Integration;

class App
{
    private $cova_api;

    public function run()
    {
        $this->dependency_check();
        $this->includes();        
        $this->register_hooks();
    }

    public function register_hooks()
    {        
        add_action('plugins_loaded', [$this, 'init'], 100);
        //        add_action( 'admin_enqueue_scripts', [$this, 'enqueue_sync_scripts'] );

        //        add_action('init', [$this, 'test_promo']);
        //        add_action('init', [$this, 'testcode'], 99999);
        //        add_action('init', [$this, 'test_create_bulk_product']);
    }

    /**
     * @todo Check for required plugins as dependency. Ex: Woocommerce, Multi-location plugins etc.
     */
    public function dependency_check()
    {
    }

    public function includes()
    {
        $dir_path = plugin_dir_path(__FILE__);

        include_once $dir_path .'Config_Manager.php';
        include_once $dir_path .'config.php';    

        include_once $dir_path .'api/api.php';
        include_once $dir_path .'api-v2/api.php';

        include_once $dir_path .'functions.php';        

        include_once $dir_path .'synchronization/Catalog.php';
        include_once $dir_path .'synchronization/Locations.php';
        include_once $dir_path .'synchronization/Inventory.php';        
        include_once $dir_path .'synchronization/Item_Pricing.php';

        include_once $dir_path .'Cova_Data_Manager.php';

        include_once $dir_path .'synchronization/Cova_Product_Category.php';
        //        require_once $dir_path .'synchronization/Inventory_Updater.php';
        //
        //        require_once $dir_path .'synchronization/Simple_Product_Details_Manager.php';
        //        require_once $dir_path .'synchronization/Variable_Product_Details_Manager.php';
        //        require_once $dir_path .'synchronization/Variation_Product_Details_Manager.php';
        //
        //        require_once $dir_path .'synchronization/WC_Simple_Product_Creator.php';
        //        require_once $dir_path .'synchronization/WC_Variation_Product_Creator.php';
        //        require_once $dir_path .'synchronization/WC_Variable_Product_Creator.php';
        //        require_once $dir_path .'synchronization/WC_Tiered_Pricing_Product_Creator.php';
        //
        //        require_once $dir_path .'synchronization/WC_Simple_Product_Updater.php';
        //        require_once $dir_path .'synchronization/WC_Variation_Product_Updater.php';
        //        require_once $dir_path .'synchronization/WC_Variable_Product_Updater.php';
        //        require_once $dir_path .'synchronization/Attribute_Stock_Creator.php';
        //
        //        require_once $dir_path .'synchronization/Pricing_Updater.php';
        include_once $dir_path .'synchronization/Locations_Sync.php';
        //        require_once $dir_path .'synchronization/Product_Import.php';
        //        require_once $dir_path .'synchronization/Product_Update.php';
        //        require_once $dir_path .'synchronization/Product_Update_V2.php';
        // // require_once $dir_path .'synchronization/Product_Stock_Update.php';

        // require_once $dir_path .'synchronization/Sales_Order.php';
        //        require_once $dir_path .'synchronization/Sync_Scheduler.php';

        require_once $dir_path .'synchronization/Traits/Purchase_Limits_Traits.php';
        include_once $dir_path .'synchronization/Purchase_Limits.php';

        include_once $dir_path .'Admin_UI.php';
        // require_once $dir_path .'synchronization/Console_Commands.php';

        include_once $dir_path .'Cova_Product_Query.php';
        //        require_once $dir_path .'Cart_Limiter.php';
    }

    //    public function enqueue_sync_scripts()
    ////    {
    ////        global $current_screen;
    ////
    ////        if (is_admin() && $current_screen->id === 'toplevel_page_cova_integration') {
    ////            $ajax_url = admin_url( 'admin-ajax.php' );
    ////
    ////            wp_enqueue_script('cova-sync-func', COVA_INTEGRATION_URI .'/assets/js/functions.js', [], null, true);
    ////            wp_add_inline_script('cova-sync-func', 'let cova_sync = '. json_encode([
    ////                'ajax_url' => $ajax_url
    ////            ]), 'before');
    ////        }
    ////    }

    public function initialize_sync_api_classes()
    {
        $this->initialize_catalog_api_class();
        $this->initialize_locations_api_class();
        $this->initialize_inventory_api_class();
        $this->initialize_item_pricing_api_class();
        $this->initialize_purchase_limits_api_class();
    }

    public function init()
    {        
        $this->initialize_sync_api_classes();

        global $cova_api;

        $cova_api = $this->cova_api;

        $admin_ui = new Admin_UI;
        $admin_ui->run();        

        // $console = new Console_Commands;
        // $console->run();

        // $global_sync = new Global_Data_Sync($this->cova_api);
        // $global_sync->run();

        $locations_sync = new Locations_Sync($this->cova_api);
        $locations_sync->run();

        //        $import_sync = new Product_Import($this->cova_api);
        //        $import_sync->run();

        //        $update_sync = new Product_Update($this->cova_api);
        //        $update_sync->run();
        //
        //        $update_sync = new Product_Update_V2($this->cova_api);
        //        $update_sync->run();

        // $sales_order = new Sales_Order($this->cova_api);
        // $sales_order->run();

        //        $inventory_sync = new Inventory_Updater($this->cova_api);
        //        $inventory_sync->run();
        //
        //        $pricing_sync = new Pricing_Updater($this->cova_api);
        //        $pricing_sync->run();
    }

    public function initialize_catalog_api_class()
    {
        $catalog = new \Cova_Integration\Sync\Catalog;
        $catalog->run();

        $this->cova_api['catalog'] = $catalog;
    }

    public function initialize_locations_api_class()
    {
        $locations = new \Cova_Integration\Sync\Locations();
        $locations->run();

        $this->cova_api['locations'] = $locations;
    }

    public function initialize_inventory_api_class()
    {
        $inventory = new \Cova_Integration\Sync\Inventory();
        $inventory->run();

        $this->cova_api['inventory'] = $inventory;
    }

    public function initialize_item_pricing_api_class()
    {
        $pricing = new \Cova_Integration\Sync\Item_Pricing();
        $pricing->run();

        $this->cova_api['pricing'] = $pricing;
    }

    public function initialize_purchase_limits_api_class()
    {
        $purchase_limits = new \Cova_Integration\Sync\Purchase_Limits();
        $purchase_limits->run();

        $this->cova_api['purchase_limits'] = $purchase_limits;
    }

    public static function get_sync_transient_data($key, $default_value = null)
    {
        $transient_data = get_transient('cova_sync_process_data');

        if (!isset($transient_data[$key]) && $default_value === null) {
            return $default_value;
        }

        if (!isset($transient_data[$key])) {
            self::save_sync_transient_data($key, $default_value);

            return $default_value;
        }

        return $transient_data[$key];
    }

    public static function save_sync_transient_data($key, $value)
    {
        $transient_data = get_transient('cova_sync_process_data');

        if ($transient_data === false || $transient_data === '') {
            $transient_data = [];            
        }

        $transient_data[$key] = $value;
        set_transient('cova_sync_process_data', $transient_data, DAY_IN_SECONDS);

        return $transient_data;
    }

    public static function remove_sync_transient_data($key)
    {
        $transient_data = get_transient('cova_sync_process_data');

        if ($transient_data === false || $transient_data === '') {
            return false;            
        }

        if (isset($transient_data[$key])) {
            unset($transient_data[$key]);
        }
        
        set_transient('cova_sync_process_data', $transient_data, DAY_IN_SECONDS);

        return $transient_data;        
    }
}

$cova_app = new App;
$cova_app->run();
