<?php

cova_set_default_wc_location();

function dabber_load_global_wcmlim()
{
    global $dabber_current_location, $dabber_current_cova_location_id, $dabber_current_location_data;

    $dabber_current_location = cova_get_current_location();
    $dabber_current_cova_location_id = dabber_get_current_cova_location_id();

    $dabber_current_location_data = [
        'wc_location_id' => $dabber_current_location,
        'cova_location_id' => (int) $dabber_current_cova_location_id,
        'oos_threshold' => (int) get_option('dabber_global_threshold')
    ];
}
add_action('init', 'dabber_load_global_wcmlim');

/**
 * Set default location index if there is only one available location.
 */
function cova_set_default_wc_location()
{
    $locations = cova_get_available_locations();
    $default_location_index = '0';

    if (count($locations) > 1) { // only set default location on single location
        return;
    }

    setcookie("wcmlim_selected_location", $default_location_index, time() + 36000, '/');
    $_COOKIE['wcmlim_selected_location'] = $default_location_index;
}

function cova_get_excluded_wc_locations()
{
    return get_option("wcmlim_exclude_locations_from_frontend");
}

function cova_get_wc_location_by_cova_location_id($cova_location_id)
{
    $wc_location = new WP_Term_Query(
        [
        'taxonomy' => 'locations',
        'hide_empty' => false,
        'number' => 1,
        'meta_query' => [
        'relation' => 'AND',
        [
                'key' => 'location_id',
                'value' => $cova_location_id,
                'compare' => '='
        ]
        ]
        ]
    );

    //    !d($wc_location);

    //    error_log(print_r([
    //        'cova_get_wc_location_by_cova_location_id' => [
    //            'cova_location_id' => $cova_location_id,
    //            'terms' => $wc_location->terms
    //        ]
    //    ], true));

    if (!isset($wc_location->terms[0])) {
        return false;
    }

    return $wc_location->terms[0];
}

function cova_get_cova_location_id_by_term_id($term_id)
{
    $locations = new \WP_Term_Query(
        [
        'taxonomy'      => 'locations',
        'hide_empty' => false,
        'include'      => $term_id,
        'fields'      => 'slugs'
        ]
    );

    if (isset($locations->terms[0])) {
        preg_match('/^[0-9]+/', $locations->terms[0], $location_id);
    }

    if (isset($location_id[0])) {
        return $location_id[0];
    }

    return false;
}

/**
 * Get current global selected location.
 */
function cova_get_current_location()
{
    global $dabber_current_location;

    if ($dabber_current_location) {
        return $dabber_current_location;
    }

    $locations = cova_get_available_locations();

    if (count($locations) < 1) { return 0; 
    }

    $selectedLocation = isset($_COOKIE['wcmlim_selected_location']) ? $_COOKIE['wcmlim_selected_location'] : 0;
    if (isset($_POST['action']) && $_POST['action'] == 'wcmlim_location_change') {
        $selectedLocation = isset($_POST['wcmlim_change_lc_to']) ? $_POST['wcmlim_change_lc_to'] : 0;
    }

    if (!isset($locations[$selectedLocation]['term_id'])) { return 0; 
    }

    return $locations[$selectedLocation]['term_id'];
}

function dabber_get_current_cova_location_id()
{
    global $dabber_current_cova_location_id, $dabber_current_location;

    if (!$dabber_current_location) {
        $dabber_current_location = cova_get_current_location();
    }

    if ($dabber_current_cova_location_id) {
        return $dabber_current_cova_location_id;
    }

    $cova_location_id = get_term_meta($dabber_current_location, 'location_id', true);

    if (!$cova_location_id) {
        return 0;
    }

    return $cova_location_id;
}

function cova_get_current_location_name()
{
    $locations = cova_get_available_locations();

    if (count($locations) < 1) {
        return false;
    }

    $selectedLocation = isset($_COOKIE['wcmlim_selected_location'])? $_COOKIE['wcmlim_selected_location'] : 0;

    if (!isset($locations[$selectedLocation]['name'])) {
        return false;
    }

    return $locations[$selectedLocation]['name'];
}

/**
 * Get product stock quantity by location_id
 */
function dabber_get_product_location_stock_quantity($product_id, $location_id = false)
{
    $product = wc_get_product($product_id);
    $total_stock = 0;

    if (!$product) { return $total_stock; 
    }

    if($product->has_child() ) {
        $variations = $product->get_available_variations();
        $current_location_id = ($location_id === false)? cova_get_current_location() : $location_id;

        foreach ($variations as $variation) {
            $total_stock += (int) get_post_meta($variation['variation_id'], 'wcmlim_stock_at_'. $current_location_id, true);
        }

        return $total_stock;    
    }

    $total_stock = (int) get_post_meta($product_id, 'wcmlim_stock_at_'. $location_id, true);

    return $total_stock;
}

function cova_get_available_locations($object = false)
{
    $exclude = cova_get_excluded_wc_locations();

    $args = [
        'taxonomy'      => 'locations',
        'hide_empty'    => false,
        'orderby'       => 'name',
        'order'         => 'ASC',
        'number'        => 0,
        'hierarchical'  => false
    ];

    if (!empty($exclude)) {
        $args['exclude'] = $exclude;
    }

    $terms = new \WP_Term_Query($args);
    $locations = [];

    if (is_null($terms->terms)) {
        return $locations;
    }

    foreach ($terms->terms as $location) {
        if ($object === true) {
            $locations[] = $location;
        } else {
            $locations[] = (array) $location;
        }
    }

    return $locations;
}

function dabber_get_location_ids()
{
    global $wpdb;

    $query = $wpdb->get_results(
        "SELECT terms.term_id, terms.slug FROM {$wpdb->prefix}term_taxonomy as taxonomy
            LEFT JOIN {$wpdb->prefix}terms as terms 
            ON taxonomy.term_id = terms.term_id
            WHERE taxonomy.taxonomy = 'locations'"
    );

    if (empty($query)) {
        return [];
    }

    $items = [];

    foreach ($query as $item) {
        preg_match('/^[0-9]+/', $item->slug, $location_id);
        $items[$item->term_id] = (int) $location_id[0];
    }

    return $items;
}

function cova_get_all_wc_locations()
{
    $args = [
    'taxonomy'         => 'locations',
    'hide_empty'     => false,
    'orderby'         => 'name',
    'order'         => 'ASC',
    'number'         => 0,
    'hierarchical'     => false
    ];

    $terms = new \WP_Term_Query($args);
    $locations = [];

    if (empty($terms->terms)) {
        return $locations;
    }

    foreach ($terms->terms as $location) {
        $locations[] = (array) $location;
    }

    return $locations;
}

function cova_get_product_location_sale_price($product_id, $location_term_id = false)
{
    if ($location_term_id === false) {
        $location_term_id = cova_get_current_location();
    }

    $price = get_post_meta($product_id, 'wcmlim_sale_price_at_'. $location_term_id, true);

    return apply_filters('dabber_product_sale_price', $price, $product_id, $location_term_id);
}

function cova_get_product_location_regular_price($product_id, $location_term_id = false)
{
    if ($location_term_id === false) {
        $location_term_id = cova_get_current_location();
    }

    $price = get_post_meta($product_id, 'wcmlim_regular_price_at_'. $location_term_id, true);

    return apply_filters('dabber_product_regular_price', $price, $product_id, $location_term_id);
}

// function dabber_get_product_location_quantity($product_id, $location_term_id)
// {
//     return get_post_meta($product_id, 'wcmlim_stock_at_'. $location_term_id, true);
// }

function cova_update_product_location_sale_price($product_id, $location_term_id, $price)
{
    if (!$price || $price == '0') {        
        delete_post_meta($product_id, 'wcmlim_sale_price_at_'. $location_term_id);
        return;
    }
    update_post_meta($product_id, 'wcmlim_sale_price_at_'. $location_term_id, $price);
}

function cova_update_product_location_regular_price($product_id, $location_term_id, $price)
{
    update_post_meta($product_id, 'wcmlim_regular_price_at_'. $location_term_id, $price);    
}

function cova_update_product_location_stock($product_id, $location_term_id, $stock_qty)
{
    $quantity = apply_filters('cova_update_product_location_stock_quantity', $stock_qty, $product_id, $location_term_id);
    update_post_meta($product_id, 'wcmlim_stock_at_'. $location_term_id, $quantity);
}

function cova_update_wc_location_meta($term_id, $data)
{
    update_term_meta($term_id, 'wcmlim_autocomplete_address', $data['address']);
    update_term_meta($term_id, 'wcmlim_street_number', $data['street']);
    update_term_meta($term_id, 'wcmlim_locality', $data['city']);
    update_term_meta($term_id, 'wcmlim_administrative_area_level_1', $data['state']);
    update_term_meta($term_id, 'wcmlim_postal_code', $data['postal']);
    update_term_meta($term_id, 'wcmlim_country', $data['country']);            
    update_term_meta($term_id, 'wcmlim_phone', $data['phone']);
    update_term_meta($term_id, 'location_id', $data['location_id']);
}

/**
 * B2B Pro fix: should always exclude the excluded locations in the term query.
 */

/**
 * Catch excluded locations early.
 */
add_filter('get_terms_args', 'dabber_location_exclude_handler', 0, 2);
function dabber_location_exclude_handler($args, $taxonomies)
{
    if (!in_array('locations', $taxonomies)) {
        return $args;
    }

    $args['excluded_locations'] = $args['exclude'];

    return $args;
}

/**
 * Re-include excluded locations after B2BPro modification
 */
add_filter('get_terms_args', 'dabber_location_exclude', 100, 2);
function dabber_location_exclude($args, $taxonomies)
{
    if (is_admin()) {
        return $args;
    }

    if (!in_array('locations', $taxonomies)) {
        return $args;
    }

    if (empty($args['excluded_locations'])) {
        return $args;
    }

    $args['exclude'] = $args['excluded_locations'];

    return $args;
}
