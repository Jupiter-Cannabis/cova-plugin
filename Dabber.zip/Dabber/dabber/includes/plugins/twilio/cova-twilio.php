<?php

add_action('woocommerce_checkout_process', 'custom_validate_billing_phone');
add_action('woocommerce_checkout_update_order_meta', 'toggle_twilio_sms_optin', 99);


/**
 * check if twilio plugin is activated
 *
 * @return bool
 */
function cova_twilio_activation_check()
{
    if (is_plugin_active('woocommerce-twilio-sms-notifications/woocommerce-twilio-sms-notifications.php') ) {
        return true;
    }
    return false;
}

/**
 * Lists of allowed area codes
 *
 * @return array
 */
function cova_twilio_area_codes()
{
    return [204, 226, 236, 249, 250, 263, 289, 306, 343, 354, 365, 367, 368, 403, 416, 418, 428, 431, 437, 438, 450, 468, 474, 506, 514, 519, 548, 579, 581, 584, 587, 604, 613, 639, 647, 672, 683, 705, 709, 742, 753, 778, 780, 782, 807, 819, 825, 867, 873, 902, 905];
}

/**
 * Validate phone number by type and length
 * Allowed is INT and length is 10
 *
 * @return void
 */
function custom_validate_billing_phone()
{

    $is_twilio_active = cova_twilio_activation_check();

    if ($is_twilio_active && isset($_POST['billing_phone']) ) {
        $phone = $_POST['billing_phone'];
        $phoneLength = strlen(preg_replace('/[^0-9]/', '', $phone));

        if ($phoneLength <> 10 ) {
            wc_add_notice(__('<strong>Billing Phone</strong> must be at least 10 digits long. Please include your area code + phone number without any spaces or special characters.'), 'error');
        } else if(country_code_exists($phone) ) {
            wc_add_notice(__('<strong>Billing Phone</strong> should exclude the country code `1` at the beginning. Please ONLY include your area code + phone number without any spaces or special characters.'), 'error');
        }

    }
}

/**
 * If country code exists in phone number
 *
 * @param  $phone_number
 * @return string
 */
function country_code_exists($phone_number)
{

    if (substr($phone_number, 0, 1) === "1") {
        return true;
    }

    return false;
}

/**
 * Check if billing_phone area code exists in allowed area codes list
 * Enable/Disable Twilio SMS Optin
 *
 * @param  $order_id
 * @return void
 */
function toggle_twilio_sms_optin($order_id)
{

    $is_twilio_active = cova_twilio_activation_check();

    if($is_twilio_active ) {
        $phone_number = $_POST['billing_phone'];
        $area_codes = cova_twilio_area_codes();
        $area_code = substr($phone_number, 0, 3);
        $sms_optin_value = 1;

        //If the phone number is not in the allowed lists
        if (!in_array($area_code, $area_codes)) {
            $plugin_instance = new WC_Twilio_SMS();
            // remove user from twilio sms optin
            remove_action('woocommerce_checkout_update_order_meta', array( $plugin_instance, 'process_opt_in_checkbox' ), 10);
            $sms_optin_value = 0;
        }

        update_post_meta($order_id, '_wc_twilio_sms_optin', $sms_optin_value);
    }

}
