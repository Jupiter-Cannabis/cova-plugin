<?php

/**
 * Fix min quantity and set to 0 if the full quantity of the product is already added to the cart.
 *
 * @param $quantity
 * @param $product
 * @return mixed
 */
function cova_modify_add_to_cart_quantity_input_min($quantity, $product)
{
    return $quantity;
}
//add_filter('woocommerce_quantity_input_min', 'cova_modify_add_to_cart_quantity_input_min', 100, 2);

/**
 * Limit users from adding products to cart more than the total stock quantity.
 *
 * @param $quantity
 * @param $product
 * @return mixed
 */
function cova_modify_add_to_cart_quantity_input_max($quantity, $product)
{
    $cart = WC()->cart->get_cart_item_quantities();

    if (!isset($cart[$product->get_id()])) {
        return $quantity;
    }

    global $dabber_current_location_data;

    $quantity = (float) $product->get_meta('wcmlim_stock_at_'. $dabber_current_location_data['wc_location_id']);

    return (float) $quantity - (float) $cart[$product->get_id()];
}
//add_filter('woocommerce_quantity_input_max', 'cova_modify_add_to_cart_quantity_input_max', 9999, 2);

function cova_modify_add_to_cart_quantity_min_max($args, $product)
{
    $args['max_value'] = 5;
    return $args;
}
//add_filter('woocommerce_quantity_input_args', 'cova_modify_add_to_cart_quantity_min_max', 9999, 2);