<?php

function cova_modify_product_thc_potency_filter_query($query_args, $object)
{
    if (!isset($object->query['post_type']) || $object->query['post_type'] !== 'product' || is_admin()) {
        return $query_args;
    }

    global $dabber_current_location_data;

    $thc_key = 'package_at_'. $dabber_current_location_data['wc_location_id'] .'_thc_percent';

    return str_replace('thc_potency', $thc_key, $query_args);
}
add_filter('posts_where_request', 'cova_modify_product_thc_potency_filter_query', 100, 2);

function cova_modify_product_cbd_potency_filter_query($query_args, $object)
{
    if (!isset($object->query['post_type']) || $object->query['post_type'] !== 'product' || is_admin()) {
        return $query_args;
    }

    global $dabber_current_location_data;

    $cbd_key = 'package_at_'. $dabber_current_location_data['wc_location_id'] .'_cbd_percent';

    return str_replace('cbd_potency', $cbd_key, $query_args);
}
add_filter('posts_where_request', 'cova_modify_product_cbd_potency_filter_query', 100, 2);
