<?php

namespace Dabber;

use Cova_Integration\Cova_Data_Manager;

class DabberSyncJobManager
{
    private $actions = [];
    private $is_executed = false;

    public function __construct()
    {
        $this->define_variables();

        add_action('init', [$this, 'execute_actions']);
    }

    private function define_variables()
    {
        define('DABBER_SCHEDULED_ACTIONS_LOG_FILE', 'scheduled-actions');
        define('DABBER_LAST_ACTION_EXECUTIONS_LOG_FILE', 'last-action-executions');
        define('DABBER_ACTION_DATE_FORMAT', 'Y-m-d H:i:s');
    }

    public function execute_actions()
    {
        // Prevent this action from being executed multiple times per load.
        if ($this->is_executed === true) {
            return;
        }

        $this->get_registered_actions();

        $actions = $this->get_actions_to_execute();

        if (empty($actions)) {
            return;
        }

        $last_executed_actions = Cova_Data_Manager::get_stored_data(DABBER_LAST_ACTION_EXECUTIONS_LOG_FILE);

        foreach ($actions as $action_name) {
            do_action($action_name);
            $last_executed_actions[$action_name] = strtotime(date(DABBER_ACTION_DATE_FORMAT));
        }

        Cova_Data_Manager::store_data(DABBER_LAST_ACTION_EXECUTIONS_LOG_FILE, $last_executed_actions);

        //        cova_debugger('execute-action');

        $this->is_executed = true;
    }

    public function get_registered_actions()
    {
        $actions = apply_filters('dabber_action_scheduler', []);

        foreach ($actions as $action => $frequency) {
            if (!is_numeric($frequency) || $frequency < 1) {
                unset($actions[$action]);
            }
        }

        $this->actions = $actions;
    }

    public function get_actions_to_execute()
    {
        $executed_actions = Cova_Data_Manager::get_stored_data(DABBER_LAST_ACTION_EXECUTIONS_LOG_FILE);

        $actions_to_run = [];

        foreach ($this->actions as $action => $frequency) {
            if (!isset($executed_actions[$action])) {
                $actions_to_run[] = $action;
                continue;
            }

            if ($this->get_time_diff($executed_actions[$action]) > $frequency) {
                $actions_to_run[] = $action;
            }
        }

        return $actions_to_run;
    }

    public function get_time_diff($timestamp)
    {
        $current_time = strtotime(date(DABBER_ACTION_DATE_FORMAT));

        return $current_time - $timestamp;
    }
}

$dabber_sync_job_manager = new DabberSyncJobManager();
