<?php

function dabber_sanitize_slug($slug)
{
    $new_slug = trim(preg_replace('/[^a-zA-Z0-9\-_]+/i', '-', trim($slug)), "-");

    return sanitize_title_with_dashes($new_slug);
}

/**
 * Get current global selected location.
 */
function mgc_get_current_location()
{
    $terms = get_terms(
        [
        'hide_empty' => false,
        'taxonomy' => 'locations'
        ]
    );

    $new_terms = [];

    foreach ($terms as $key => $term) {
        $new_terms[] = [
        'term_id' => $term->term_id,
        'name' => $term->name
        ];
    }

    if(count($new_terms) < 1 ) { return 0; 
    }

    $selectedLocation = isset($_COOKIE['wcmlim_selected_location'])? $_COOKIE['wcmlim_selected_location'] : 0;

    if (!isset($new_terms[$selectedLocation]['term_id'])) {return 0; 
    }

    return $new_terms[$selectedLocation]['term_id'];    
}

function dabber_hack_product_visibility($product)
{
    // temporarily update visibility
    $product->set_catalog_visibility('catalog');
    $product->save();

    // reset visibility
    $product->set_catalog_visibility('visible');
    $product->save();
}

/**
 * Handle default wc error handling and remove duplicates.
 */
function cova_add_wc_notice($message, $notice_type = 'custom_error')
{
    $notices = wc_get_notices($notice_type);
    $is_notice_exists = false;

    foreach ($notices as $key => $notice) {
        if ($notice['notice'] === $message) {
            $is_notice_exists = true;
            break;
        }
    }

    if ($is_notice_exists === false) {
        wc_add_notice($message, $notice_type);
    }
}

/**
 * Get product stock quantity by location_id
 */
function mgc_get_product_location_stock_quantity($product_id, $location_id = false)
{
    $product = wc_get_product($product_id);
    $total_stock = 0;

    if (!$product) { return $total_stock; 
    }

    if($product->has_child() ) {        
        $variations = $product->get_available_variations();
        $current_location_id = ($location_id === false)? mgc_get_current_location() : $location_id;

        foreach ($variations as $variation) {
            $total_stock += (int) get_post_meta($variation['variation_id'], 'wcmlim_stock_at_'. $current_location_id, true);
        }        
    }    

    return $total_stock;
}

/**
 * Remove password strength check.
 */
function cova_iconic_remove_password_strength()
{
    wp_dequeue_script('wc-password-strength-meter');
}
add_action('wp_print_scripts', 'cova_iconic_remove_password_strength', 10);

function cova_add_admin_messages($data)
{
    global $cova_admin_messages;

    $cova_admin_messages[] = $data;
}

function dabber_has_job_recently_executed($job_name, $seconds_ago)
{

}

function dabber_record_job_execution($job_name)
{

    //    \Cova_Integration\Cova_Data_Manager::store_data($job_name, );
}

function dabber_get_cached_post_meta($post_id, $key)
{
    return (new \Dabber\DabberCacheManager($key, 'post', $post_id, true))->get_data();
}

function dabber_get_cached_user_meta($user_id, $key)
{
    return (new \Dabber\DabberCacheManager($key, 'user', $user_id, true))->get_data();
}

function dabber_store_cache_post_meta($post_id, $key, $data, $duration = 60*60)
{
    (new \Dabber\DabberCacheManager($key, 'post', $post_id))->store($data, $duration);
}

function cova_get_product_image_size($size)
{
    if (!is_array($size)) {
        $image_size_info = wp_get_additional_image_sizes();
        if (isset($image_size_info[$size])) {
            $width = $image_size_info[$size]['width'];
            $height = ($image_size_info[$size]['height'] > 0)? $image_size_info[$size]['height'] : $image_size_info[$size]['width'];
            $img_size = [$width, $height];
        } else {
            $width = get_option($size . '_size_w');
            $width = (empty($width))? 1500 : $width;
            $height = get_option($size . '_size_h');
            $height = (empty($height))? 1500 : $height;
            $img_size = [$width, $height];
        }
    } else {
        $img_size = $size;
    }

    return $img_size;
}

function cova_get_product_image_url($cova_img_id, $size = [300,300])
{
    if (is_numeric($cova_img_id)) {

        $post_image = wp_get_attachment_url($cova_img_id);

        if (!$post_image) {
            $image_id = get_option('woocommerce_placeholder_image');

            if (!$image_id) {
                return wc_placeholder_img_src();
            }
            return wp_get_attachment_url($image_id);
        }

        return $post_image;
    }

    $img_size = cova_get_product_image_size($size);

    return [
        'url' => 'https://ams.iqmetrix.net/images/'. $cova_img_id .'/preview/'. implode('/', $img_size),
        'size' => $img_size
    ];
}
