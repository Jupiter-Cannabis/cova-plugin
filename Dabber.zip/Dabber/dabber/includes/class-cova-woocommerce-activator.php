<?php

/**
 * Fired during plugin activation
 *
 * @link  http://example.com
 * @since 1.0.0
 *
 * @package    Cova_woocommerce
 * @subpackage Cova_woocommerce/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cova_woocommerce
 * @subpackage Cova_woocommerce/includes
 * @author     Your Name <email@example.com>
 */
class Cova_woocommerce_Activator
{

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since 1.0.0
     */
    public static function activate()
    {
        //        \Cova_Integration\Sync_Scheduler::add_scheduled_event();

        self::create_index_table();
    }

    public static function create_index_table()
    {
        global $wpdb;

        $table_name = $wpdb->prefix .'dabber_index';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id BIGINT NOT NULL AUTO_INCREMENT,
            index_key varchar(255) NOT NULL,
            index_value LONGTEXT NOT NULL,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        include_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
}
