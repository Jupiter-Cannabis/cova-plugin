<?php

namespace Dabber\Cova_Integration\Promotions;

function cova_get_promo_formatted_details($promo)
{
    $details = [
        'id'            => $promo['Id'],
        'name'          => $promo['Name'],
        'location_ids'  => $promo['SelectedParentEntities']
    ];

    if (array_key_exists('Pattern', $promo['Period'])) {
        $days = [];
        $pattern = $promo['Period']['Pattern'];

        foreach ($pattern['DaysOfTheWeek'] as $day) {
            $days[] = date('D', strtotime($day));
        }

        $details['schedule']    = 'Every '. implode(', ', $days) .' at '. date('h:ia', strtotime($promo['Period']['TimeSchedule']['StartTime'])) .' to '. date('h:ia', strtotime($promo['Period']['TimeSchedule']['EndTime']));
        $details['date_start']  = (stripos($promo['Period']['EffectiveDateRange']["StartDate"], '0001') !== false)? 'Now' : date('H:i a', strtotime($promo['Period']['EffectiveDateRange']['StartDate']));
        $details['date_end']    = (stripos($promo['Period']['EffectiveDateRange']["EndDate"], '9999') !== false)? 'Indefinite' : date('H:i a', strtotime($promo['Period']['EffectiveDateRange']['EndDate']));
    }

    if (array_key_exists('DateRanges', $promo['Period'])) {
        foreach ($promo['Period']['DateRanges'] as $date) {
            $details['schedule'][] = [
                'start' => date('Y-m-d h:i a', strtotime($date['StartDate'])),
                'end' => date('Y-m-d h:i a', strtotime($date['EndDate']))
            ];
        }
    }

    $discount_tag = $promo['Rule']['Discount']['Tag'];

    if ($discount_tag === 'Percentage') {
        $details['discount'] = $promo['Rule']['Discount'][$discount_tag] .'% off';
    }

    if ($discount_tag === 'Dollar') {
        $currency = '$';
        $details['discount'] = $currency . $promo['Rule']['Discount'][$discount_tag] .' off';
    }

    return $details;
}
