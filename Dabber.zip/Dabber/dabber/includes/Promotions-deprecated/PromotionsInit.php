<?php

namespace Dabber\Cova_Integration\Promotions;

class PromotionsInit
{
    public $synced_promos;

    public function run()
    {
        add_action('init', [$this, 'init']);
        add_action('init', [$this, 'load_promotions_vars'], 0);

        add_filter('cron_schedules', [$this, 'add_cron_schedules']);
        add_action('admin_init', [$this, 'add_scheduled_event']);
        add_action('dabber_cron_sync_promotions', [$this, 'sync_promo_callback']);
        add_shortcode('cova_promotion', [$this, 'shortcode_callback']);

        add_filter('woocommerce_add_cart_item', [$this, 'apply_promo_price_on_add_to_cart']);

        include_once plugin_dir_path(__FILE__) .'functions.php';
    }

    public function init()
    {
        add_action('wp_ajax_cova_promotion_sync_sync_promotions', [$this, 'ajax_sync_promotions']);
        add_action('dabber_sync_promotions', [$this, 'initiate_promotions_sync']);
        add_filter('woocommerce_product_is_on_sale', [$this, 'set_product_on_sale'], 99999, 2);
        add_filter('get_post_metadata', [$this, 'override_wcmlim_sale_meta'], 100, 4);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function apply_promo_price_on_add_to_cart($data)
    {
        if (!$this->is_product_on_promo($data['data'])) {
            return $data;
        }

        $currency_symbol  = get_option('woocommerce_currency');
        $currency_symbol  = (!$currency_symbol)? $currency_symbol : '$';
        $promo_price = $this->get_promo_price($data['data']);

        $data['select_location']['location_cart_price'] = $currency_symbol. $promo_price;

        return $data;
    }

    public function add_cron_schedules($schedules)
    {
        $schedules['every_twelve_hours'] = [
            'interval' => 43200,
            'display'  => __('Every twelve hours', 'dabber'),
        ];

        $schedules['every_thirty_minutes'] = [
            'interval' => 1800,
            'display'  => __('Every 30 minutes', 'dabber'),
        ];

        return $schedules;
    }

    public function add_scheduled_event()
    {
        if (!wp_next_scheduled('dabber_cron_sync_promotions')) {
            wp_schedule_event(time(), 'every_thirty_minutes', 'dabber_cron_sync_promotions');
        }
    }

    public function sync_promo_callback()
    {
        do_action('dabber_sync_promotions');
    }

    public function load_promotions_vars()
    {
        global $dabber_promotions;

        $dabber_promotions = [
            'promos' => get_option('dabber_product_promos'),
            'enabled_promos' => get_option('dabber_enabled_promos')
        ];
    }

    public function enqueue_scripts()
    {
        global $current_screen;

        if (is_admin() && $current_screen->id === 'woocommerce_page_cova_integration') {
            wp_enqueue_script('cova-promotions-sync', COVA_INTEGRATION_URI .'/assets/js/promotions-sync.js', [], null, true);
        }
    }

    public function shortcode_callback($attr)
    {
        $promos = get_option('dabber_promotions');
        $current_location = cova_get_current_location();
        $wc_location_id = cova_get_cova_location_id_by_term_id($current_location);

        ob_start();

        if (!isset($promos[$wc_location_id])) {
            return 'No available promos for this location.';
        }

        foreach ($promos[$wc_location_id] as $promo) {
            $item = cova_get_promo_formatted_details($promo);
            ?>
            <h2><?php echo $item['name'] .' - '. $item['discount'] ?></h2>
            <div class="promo-details">
                <?php if (is_array($item['schedule'])) : ?>
                    <?php foreach ($item['schedule'] as $sched) : ?>
                        <p><?php echo $sched['start'] .' to '. $sched['end']  ?></p>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p><?php echo $item['schedule'] ?></p>
                <?php endif; ?>
            </div>
            <?php
        }

        return ob_get_clean();
    }

    public function ajax_sync_promotions()
    {
        dabber_set_sync_on();

        do_action('dabber_sync_promotions');

        wp_send_json_success(
            [
            'status' => 'complete',
            'message' => 'Promotions Sync complete',
            'data' => $this->synced_promos,
            'message_type' => 'output'
            ], 200
        );
    }

    public function initiate_promotions_sync()
    {
        $promotions = new \CovaAPI\Promotions();
        $locations  = cova_get_all_wc_locations();
        $locations_promos = [];

        foreach ($locations as $key => $wc_loc) {

            $cova_loc_id = cova_get_cova_location_id_by_term_id($wc_loc['term_id']);
            $loc_promo   = json_decode($promotions->get_promotions($cova_loc_id), true);

            if (!empty($loc_promo)) {
                foreach ($loc_promo as $lkey => $promo) {

                    if ($promo['Status'] !== 'Active') {
                        continue;
                    }

                    if ($this->is_promo_expired($promo['Period']) === true) {
                        continue;
                    }
                    $locations_promos[$cova_loc_id][] = $promo;
                    $this->synced_promos[$cova_loc_id][] = [
                        'promo_id' => $promo['Id'],
                        'promo_name' => $promo['Name'],
                        'status' => $promo['Status'],
                        'period' => $promo['Period'],
                        'rule' => $promo['Rule']
                    ];
                }
            }
        }

        update_option('dabber_promotions', $locations_promos);

        $promotions = new Promotions();
        $items = $promotions->generate_wc_promos();

        update_option('dabber_product_promos', $items);

        $disabled_promotions = (array) get_option('dabber_disabled_promos');
        $enabled_promotions  = get_option('dabber_enabled_promos');
        $enabled_promotions  = (is_array($enabled_promotions))? $enabled_promotions : [];

        foreach ($this->synced_promos as $location_id => $promos) {
            foreach ($promos as $promo) {
                if (!in_array($promo['promo_id'], $disabled_promotions)) {
                    $enabled_promotions[] = $promo['promo_id'];
                }
            }
        }

        update_option('dabber_enabled_promos', array_unique($enabled_promotions));

        error_log(
            print_r(
                [
                'initiate_promotions_sync' => [
                'enabled_promos' => $enabled_promotions,
                'synced_promos' => $this->synced_promos
                ]
                ], true
            )
        );
    }

    public function is_promo_expired($period): bool
    {
        if (array_key_exists('Pattern', $period)) {
            $end_date = date('Y-m-d', strtotime($period['EffectiveDateRange']['EndDate']));
            $time_end = date('H:i:s', strtotime($period['TimeSchedule']['EndTime']));
            $end_date = strtotime($end_date .' '. $time_end);

            if ($end_date < strtotime(current_time('Y-m-d G:i:s'))) {
                return true;
            }
        }

        if (array_key_exists('DateRanges', $period)) {
            foreach ($period['DateRanges'] as $date_range) {
                $end_date = strtotime($date_range['EndDate']);
                if ($end_date >= strtotime(current_time('Y-m-d G:i:s'))) {
                    return false;
                }
            }
            return true;
        }

        return false;
    }

    public function set_product_on_sale($on_sale, $product)
    {
        if ((is_admin() && ! defined('DOING_AJAX')) || defined('DABBER_DOING_SYNC')) {
            return $on_sale;
        }

        if ($this->is_product_on_promo($product) === true) {
            return true;
        }

        return $on_sale;
    }

    public function is_product_on_promo($product): bool
    {
        global $dabber_promotions;

        $current_location_id = cova_get_current_location();

        if (get_option('dabber_override_sale_prices') === 'off') {
            $current_sale_price = $product->get_meta('wcmlim_sale_price_at_'. $current_location_id);
            if (is_numeric($current_sale_price)) {
                return false;
            }
        }

        if (isset($dabber_promotions['promos'][$current_location_id]['all'])) {
            foreach ($dabber_promotions['promos'][$current_location_id]['all'] as $item) {
                if (!in_array($item['promo_id'], $dabber_promotions['enabled_promos'])) {
                    continue;
                }
                return ($this->is_current_promo_period($item['period']) === true);
            }
        }

        if (isset($dabber_promotions['promos'][$current_location_id][$product->get_id()])) {
            foreach ($dabber_promotions['promos'][$current_location_id][$product->get_id()] as $item) {
                if (!in_array($item['promo_id'], $dabber_promotions['enabled_promos'])) {
                    continue;
                }
                return ($this->is_current_promo_period($item['period']) === true);
            }
        }

        return false;
    }

    public function override_wcmlim_sale_meta($metadata, $object_id, $meta_key = '', $single = false)
    {
        if ((is_admin() && ! defined('DOING_AJAX')) || defined('DABBER_DOING_SYNC')) {
            return $metadata;
        }

        global $product;

        if (!$product instanceof \WC_Product) {
            return $metadata;
        }

        $sale_meta = 'wcmlim_sale_price_at_'. cova_get_current_location();
        if ($meta_key !== $sale_meta) {
            return $metadata;
        }

        if ($this->is_product_on_promo($product) === false) {
            return $metadata;
        }

        // unhook filter to avoid infinite loop
        remove_filter('get_post_metadata', [$this, 'override_wcmlim_sale_meta'], 100);

        $sale_price = $this->get_promo_price($product);

        // rehook filter
        add_filter('get_post_metadata', [$this, 'override_wcmlim_sale_meta'], 100, 4);

        if (get_option('dabber_override_sale_prices') === 'off') {
            $current_sale_price = $product->get_meta($sale_meta);
            if (is_numeric($current_sale_price)) {
                return $current_sale_price;
            }
        }

        return $sale_price;
    }

    public function get_promo_price($product)
    {
        global $dabber_promotions;

        $product_id             = $product->get_id();
        $current_location       = cova_get_current_location();
        $wcmlim_price_meta_key  = 'wcmlim_regular_price_at_'. $current_location;
        $base_price             = (float) $product->get_meta($wcmlim_price_meta_key);

        $sale_prices = [];

        if (isset($dabber_promotions['promos'][$current_location]['all'])) {
            foreach ($dabber_promotions['promos'][$current_location]['all'] as $all_item) {
                $dabber_promotions['promos'][$current_location][$product_id][] = $all_item;
            }
        }

        foreach ($dabber_promotions['promos'][$current_location][$product_id] as $item) {
            if ($this->is_current_promo_period($item['period']) === false || !in_array($item['promo_id'], $dabber_promotions['enabled_promos'])) {
                continue;
            }

            $discount_amount = (float) $item['discount_amount'];

            if ($discount_amount < 0) {
                $sale_prices[] = $base_price;
            }

            if ($item['discount_type'] === 'Percentage') {
                $price_off =  $base_price * ($discount_amount / 100);
                $sale_prices[] = $base_price - $price_off;
            }

            if ($item['discount_type'] === 'Dollar') {
                $sale_prices[] = $base_price - $discount_amount;
            }
        }

        if (empty($sale_prices)) {
            return false;
        }

        $sale_prices = min($sale_prices);

        return number_format($sale_prices, 2, '.', '');
    }

    public function is_current_promo_period($period): bool
    {
        $current_date = strtotime(current_time('Y-m-d G:i:s'));
        //        $current_date = strtotime('2022-06-28 08:00:00');
        $current_time = strtotime(current_time('G:i:s'));
        //        $current_time = strtotime('09:00:00');

        if (array_key_exists('Pattern', $period)) { // for recurring days.
            $start_date = strtotime($period['EffectiveDateRange']['StartDate']);
            $end_date   = strtotime($period['EffectiveDateRange']['EndDate']);

            if ($current_date < $start_date || $current_date > $end_date) {
                return false;
            }

            $current_day = current_time('l');
            //            $current_day = 'Tuesday';

            if (!in_array($current_day, $period['Pattern']['DaysOfTheWeek'])) {
                return false;
            }

            $start_time = strtotime($period['TimeSchedule']['StartTime']);
            $end_time   = strtotime($period['TimeSchedule']['EndTime']);

            if ($current_time >= $start_time && $current_time <= $end_time) {
                return true;
            }
        }

        if (array_key_exists('DateRanges', $period)) { // for specific dates or continuous days.
            foreach ($period['DateRanges'] as $range) {
                if ($current_date >= strtotime($range['StartDate']) && $current_date <= strtotime($range['EndDate'])) {
                    return true;
                }
            }
        }

        return false;
    }
}

(new PromotionsInit())->run();
