<?php

namespace Dabber;

/**
 * @todo add option cache support
 * @todo add taxonomy cache support
 * @todo add cova_sync log file support
 */
class DabberCacheManager
{
    public $key;
    public $data_type;
    public $object_id;
    public $ignore_timestamp;

    public function __construct($key, $data_type = 'post', $object_id = null, $ignore_timestamp = false)
    {
        $this->key = $key;
        $this->data_type = $data_type;
        $this->object_id = $object_id;
        $this->ignore_timestamp = $ignore_timestamp;
    }

    public function get_key()
    {
        return $this->key;
    }

    public function get_data_type()
    {
        return $this->data_type;
    }

    public function get_object_id()
    {
        return $this->object_id;
    }

    public function get_data()
    {
        $data_method_name = 'get_'. $this->get_data_type() .'_data';

        if (!method_exists($this, $data_method_name)) {
            return false;
        }

        return $this->$data_method_name();
    }

    private function get_post_data()
    {
        $cached_data = $this->get_cached_data(get_post_meta($this->get_object_id(), 'dabber_post_cache_data_'. $this->get_key(), true));

        return apply_filters(
            'dabber_post_cache_value',
            $cached_data,
            $this->get_object_id(),
            $this->get_key()
        );
    }

    private function get_user_data()
    {
        $cached_data = $this->get_cached_data(get_user_meta($this->get_object_id(), 'dabber_user_cache_data_'. $this->get_key(), true));

        return apply_filters(
            'dabber_user_cache_value',
            $cached_data,
            $this->get_object_id(),
            $this->get_key()
        );
    }

    private function get_option_data()
    {
        return apply_filters('dabber_option_cache_value', false, $this->get_key());
    }

    private function get_taxonomy_data()
    {
        return apply_filters(
            'dabber_taxonomy_cache_value',
            false,
            $this->get_object_id(),
            $this->get_key()
        );
    }

    private function store_post_data($value, $duration)
    {
        $data_value = apply_filters('dabber_post_cache_store_value', $value, $this->get_object_id());

        update_post_meta(
            $this->get_object_id(), 'dabber_post_cache_data_'. $this->get_key(), [
            'timestamp' => $duration .':'. $this->get_current_timestamp(),
            'value'     => $data_value
            ]
        );
    }

    private function store_user_data($value, $duration)
    {
        $data_value = apply_filters('dabber_user_cache_store_value', $value, $this->get_object_id());

        update_user_meta(
            $this->get_object_id(), 'dabber_user_cache_data_'. $this->get_key(), [
            'timestamp' => $duration .':'. $this->get_current_timestamp(),
            'value'     => $data_value
            ]
        );
    }

    private function get_current_timestamp()
    {
        $current_time = date('Y-m-d H:i:s');

        return strtotime($current_time);
    }

    public function get_cached_data($data)
    {
        if (empty($data['value'])) {
            return false;
        }

        if ($this->ignore_timestamp === true) {
            return $data['value'];
        }

        if (empty($data['timestamp'])) {
            return false;
        }

        $timestamp = explode(':', $data['timestamp']);

        if ($this->is_time_over($timestamp[0], $timestamp[1])) {
            return false;
        }

        return $data['value'];
    }

    /**
     * @desc Check if the cached data is over the expected storage duration.
     *
     * @param  $duration
     * @param  $timestamp
     * @return bool
     */
    private function is_time_over($duration, $timestamp)
    {
        return ($timestamp < strtotime('-'. $duration .' seconds'));
    }

    public function store($value, $duration = 60*60)
    {
        $store_method_name = 'store_'. $this->get_data_type() . '_data';

        if (!method_exists($this, $store_method_name)) {
            return;
        }

        $this->$store_method_name($value, $duration);
    }
}
