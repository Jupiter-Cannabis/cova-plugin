<?php

/**
 * @author PaulJ
 * This file contains the paysafe payment method code fixes for double order issue.
 */

function cova_paysafe_mods_init()
{
    if (is_admin()) {
        return;
    }

    $gateways = WC()->payment_gateways->get_available_payment_gateways();

    if (!isset($gateways['netbanx'])) { // bail if netbanx payment method is not enabled.
        return;
    }

    add_action('wp_head', 'cova_paysafe_custom_styles');
    add_action('wp_footer', 'cova_paysafe_fix_scripts');
    
    add_action('wp_ajax_cova_cancel_reorder', 'cova_cancel_reorder');
    add_action('wp_ajax_nopriv_cova_cancel_reorder', 'cova_cancel_reorder');    

    add_action('woocommerce_after_order_notes', 'cova_paysafe_add_custom_fields');
    add_action('woocommerce_after_checkout_validation', 'cova_validate_duplicate_orders', 100, 2);
}
add_action('init', 'cova_paysafe_mods_init', 9999);

/**
 * Add inline styling in the header
 */
function cova_paysafe_custom_styles()
{
    if (!is_checkout()) { return; 
    }
    ?>
        <style type="text/css">
            .double-order-check {
                background: #ffbc423b;
                padding: 10px 18px;
                display: inline-block;
                border-radius: 5px;
                width: 100%;
                border: 1px solid orange;
                margin-bottom: 0;
            }
            .double-order-check p {
                color: black;
                font-weight: 400;
            }            
            .double-order-check-buttons {
                margin-top: 15px;
            }
            .double-order-check-buttons a:last-child {
                margin-left: 10px;
            }
        </style>
    <?php
}

/**
 * Add inline script in the footer
 */
function cova_paysafe_fix_scripts()
{
    if (!is_checkout()) { return; 
    }
    ?>
        <script type="text/javascript">

            var cova_paysafe_success_redirect = '';

            /**
             * Disable the place order button until the payment process is complete.
             */
            jQuery(document).ajaxSend(function(event, request, settings)
            {
                var url = settings.url;

                if (url.includes('paysafe_process_payment')) {
                    jQuery('button#place_order').prop('disabled', true);
                }
            });

            jQuery(document).ajaxComplete(function(event, xhr, settings)
            {
                var url = settings.url;

                if (url.includes('wc-ajax=checkout')) {
                    var response = jQuery.parseJSON(xhr.responseText);

                    if (response.result === 'success') {
                        cova_paysafe_success_redirect = response.paymentData.urls.successRedirectPage;
                    }                    
                }

                /**
                 * Redirect to account orders page after a successful payment.
                 */
                if (url.includes('paysafe_process_payment')) {

                    var response = jQuery.parseJSON(xhr.responseText);

                    if (response.success === true) {
                        window.parent.location.href = cova_paysafe_success_redirect;                
                    } else {
                        jQuery('button#place_order').prop('disabled', false);
                    }
                }
            });

            jQuery(document.body).on('click', '.confirm-reorder', function(e)
            {
                e.preventDefault();

                jQuery('input#cova_paysafe_check_double_order').val(0);
                jQuery('#place_order').trigger('click');
            });

            jQuery(document.body).on('click', '.cancel-reorder', function(e)
            {
                e.preventDefault();

                jQuery.ajax(
                {
                    url: '<?php echo admin_url("admin-ajax.php") ?>',
                    type: 'POST',
                    data: {
                        action: 'cova_cancel_reorder'
                    },
                    beforeSend: function() {
                        jQuery('.woocommerce').block({
                            message: null,
                            overlayCSS: {
                                background: "#fff",
                                opacity: .6
                            }
                        });            
                    },
                    success: function( response ) {
                        var res = JSON.parse(response);
                        window.parent.location.href = res.redirect_url;
                    },
                    error: function() {}
                });
            });
        
        </script>
    <?php
}
  
/**
 * Clear users cart and redirect to account's order page when cancelling reorder.
 */
function cova_cancel_reorder()
{
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        WC()->cart->remove_cart_item($cart_item_key);
    }    

    echo json_encode(
        [
        'redirect_url' => wc_get_account_endpoint_url('orders'),
        'status' => 'ok'
        ]
    );

    wp_die();
}

/**
 * Add a custom hidden field as indicator if place order should check for double order or not.
 */
function cova_paysafe_add_custom_fields( $checkout ) 
{
    woocommerce_form_field(
        'cova_paysafe_check_double_order', array(        
        'type' => 'hidden',
        'default' => true,        
        ), $checkout->get_value('cova_paysafe_check_double_order') 
    ); 
}

/**
 * Validates if the user previously placed an order within an hour ago.
 */
function cova_validate_duplicate_orders($fields, $errors)
{
    if(!empty($errors->get_error_codes()) ) {
        return;
    }    

    if (!$_POST['cova_paysafe_check_double_order']) {
        return;
    }

    if (WC()->session->get('chosen_payment_method') !== 'netbanx') {
        return;
    }

    $order = get_posts(
        [
        'post_type' => 'shop_order',
        'posts_per_page' => -1,
        'post_status' => 'wc-completed',
        'meta_query' => [
        'relation' => 'AND',
        [
                'key' => '_billing_first_name',
                'value' => $fields['billing_first_name'],
                'compare' => '='
        ],
        [
                'key' => '_billing_last_name',
                'value' => $fields['billing_last_name'],
                'compare' => '='
        ],
        [
                'key' => '_billing_email',
                'value' => $fields['billing_email'],
                'compare' => '='
        ]
        ],
        'date_query' => [
        'after' => '30 minutes ago'
        ]
        ]
    );


    if (!empty($order)) {

        $item = $order[0];

        $to_time      = strtotime(current_time('Y-m-d H:i:s'));
        $from_time      = strtotime($item->post_date);
        $minutes_ago = round(abs($to_time - $from_time) / 60, 0);

        $errors->add('validation', '<div class="double-order-check"><p>'. __('It seems like you just placed an order '. $minutes_ago .' minute(s) ago. Are you sure you want to place another order?') .'</p> <div class="double-order-check-buttons"><a class="alt btn-primary button confirm-reorder" href="#">Yes, please</a> or <a href="#" class="button cancel-reorder">Cancel</a></div></div>');
    }    
}

add_action(
    'init', function () {
        add_action('wc_paysafe_checkoutjs_account_id', 'cova_set_payment_card_by_selected_location', 100, 3);
    }
);

/**
 * Dynamically set paysafe card account based on the current selected location.
 */
function cova_set_payment_card_by_selected_location($account_id, $data_source, $payment_type)
{
    if ($account_id) {

        $settings = get_option('woocommerce_netbanx_settings');
        $current_cova_loc_id = cova_get_cova_location_id_by_term_id(cova_get_current_location());

        if (isset($settings['cova_card_location_mapping_'. $current_cova_loc_id])  
            && $settings['cova_card_location_mapping_'. $current_cova_loc_id] !== ''
        ) {
            $account_id = $settings['cova_card_location_mapping_'. $current_cova_loc_id];
        }
    }

    return $account_id;
}

/**
 * Add settings for paysafe card account location mapping.
 */
function cova_paysafe_custom_settings($fields)
{
    $terms = cova_get_available_locations();

    if (is_array($terms) && !empty($terms)) {

        $fields['cova_card_location_mapping_start'] = [
        'title' => '<hr>',
        'type' => 'title'
        ];

        $fields['cova_card_location_mapping'] = [
        'title' => 'Card - Location Mapping',
        'type' => 'title'
        ];

        foreach ($terms as $term) {
            $fields['cova_card_location_mapping_'. cova_get_cova_location_id_by_term_id($term['term_id'])] = [
            'title' => $term['name'],
            'type' => 'text'
            ];            
        }
    }

    return $fields;
}
add_action('wc_paysafe_settings_form_fields', 'cova_paysafe_custom_settings', 100);
