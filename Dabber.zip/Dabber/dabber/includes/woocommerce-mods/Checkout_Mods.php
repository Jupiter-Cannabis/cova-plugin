<?php

namespace Cova_Integration;

use Cova_Integration\Sync\Catalog;
use CovaAPI\Inventory;

class Checkout_Mods
{
    public function run()
    {
        add_action('wp', [$this, 'validate_cart_checkout_page_products_availability']);
        add_action('woocommerce_after_checkout_validation', [$this, 'validate_checkout_process_products_availability'], 100, 2);
    }

    public function validate_cart_checkout_page_products_availability()
    {
        if (!is_checkout() && !is_cart()) {
            return;
        }

        $this->generate_products_availability_error_message();
    }

    public function validate_checkout_process_products_availability($fields, $errors)
    {
        $this->generate_products_availability_error_message();
    }

    public function generate_products_availability_error_message()
    {
        $wc_products = [];
        $cart_items = WC()->cart->get_cart();

        if (empty($cart_items)) {
            return;
        }

        foreach( $cart_items as $cart_item ) {
            $product = wc_get_product($cart_item['product_id']);
            $catalog_id = $product->get_meta('cova_catalog_id');
            $wc_products[$catalog_id] = [
                'slug'          => $product->get_meta('cova_slug'),
                'name'          => $product->get_name(),
                'catalog_id'    => $catalog_id,
                'product_id'    => $product->get_id()
            ];
        }

        $inactive_product = $this->get_inactive_products($wc_products);

        if (!empty($inactive_product)) {
            foreach ($inactive_product as $catalog_id) {
                cova_add_wc_notice(__("Sorry! The product <strong>". $wc_products[$catalog_id]['name'] ."</strong> is currently sold out, check back again soon!", "woocommerce"), 'error');
            }
        }

        $oos_product_ids = $this->get_oos_products($wc_products);

        if (!empty($oos_product_ids)) {
            foreach ($oos_product_ids as $catalog_id) {
                cova_add_wc_notice(__("Sorry! The product <strong>". $wc_products[$catalog_id]['name'] ."</strong> is currently sold out, check back again soon!", "woocommerce"), 'error');
            }
        }
    }

    public function get_inactive_products($wc_products)
    {
        $catalog_ids = [];
        $inactive_products = [];

        foreach ($wc_products as $item) {
            $catalog_ids[] = $item['catalog_id'];
        }

        $catalog  = new Catalog();
        $catalog->run();

        $cova_products = $catalog->bulk(
            [
            'CatalogItemIds' => $catalog_ids
            ]
        );

        if (empty($cova_products['CatalogItems'])) {
            $inactive_products = array_keys($wc_products);
        }

        foreach ($cova_products['CatalogItems'] as $catalog_id => $item) {
            if ($item['LifeCycle'] !== 'Active') {
                $inactive_products[] = $catalog_id;
            }
        }

        return $inactive_products;
    }

    public function get_oos_products($wc_products)
    {
        global $dabber_current_location_data;

        $inventory = new \Cova_Integration\Sync\Inventory();
        $inventory->run();

        $wc_location_id = cova_get_current_location();
        $cova_location_id = cova_get_cova_location_id_by_term_id($wc_location_id);
        $inventory_data = $inventory->sellingRoomOnly($cova_location_id);

        $cova_items = [];

        foreach ($inventory_data as $item) {
            $cova_items[$item['Id']] = $item['Quantity'];
        }

        $oos_items = [];

        foreach ($wc_products as $item) {
            $oos_limit = dabber_get_product_oos_limit($item['product_id'], $dabber_current_location_data['wc_location_id']);
            if ($cova_items[$item['catalog_id']] <= $oos_limit['limit']) {
                $oos_items[] = $item['catalog_id'];
            }
        }

        return $oos_items;
    }
}

$dabber_checkout_mods = new Checkout_Mods();
$dabber_checkout_mods->run();
