<?php

namespace Cova_Integration;

class Add_To_Cart_Mods
{
    public function run()
    {
        //        add_action('woocommerce_add_to_cart_validation', [$this, 'validate_products_cart_weight_limit'], 100, 5);
        //        add_action('woocommerce_update_cart_validation', [$this, 'validate_cart_items_weight_limit'], 100, 4);
    }

    /**
     * Check weight limit on single product page add to cart
     */
    public function validate_products_cart_weight_limit($passed, $product_id, $quantity, $variation_id = '', $variations = '')
    {
        if ($variation_id) {
            $product_id = $variation_id;
        }

        $product = wc_get_product($product_id);

        if ($this->is_cart_limit_reached($product, $quantity) === true) {
            if (defined('DOING_AJAX') && DOING_AJAX) {
                return false;
            }
            cova_add_wc_notice(__("Sorry! You've reached the purchase limit for cannabis due to federal regulations.", "woocommerce"), 'error');
            return false;
        }

        return $passed;
    }

    /**
     * Check weight limit on cart items
     */
    public function validate_cart_items_weight_limit($true,  $cart_item_key,  $values,  $quantity)
    {
        $product_id = ($values['variation_id'])? $values['variation_id'] : $values['product_id'];
        $product = wc_get_product($product_id);

        if ($quantity <= $values['quantity']) {
            return $true;
        }

        if ($this->is_cart_limit_reached($product, ($quantity - $values['quantity'])) === true) {
            if (defined('DOING_AJAX') && DOING_AJAX) {
                return false;
            }
            cova_add_wc_notice(__("Sorry! You've reached the purchase limit for cannabis due to federal regulations.", "woocommerce"), 'error');
            return false;
        }

        return $true;
    }

    /**
     * Check if total weight of the cart has reached the limit.
     */
    public function is_cart_limit_reached($product, $current_quantity): bool
    {
        $cart_limiter = new Cart_Limiter();
        $cart_limiter->set_product($product);
        $cart_limiter->set_quantity($current_quantity);

        return $cart_limiter->is_cart_weight_full();
    }
}

$dabber_add_to_cart_mods = new Add_To_Cart_Mods();
$dabber_add_to_cart_mods->run();
