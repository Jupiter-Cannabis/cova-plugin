# Install HTTP client  
composer require guzzlehttp/guzzle:^7.0

https://docs.guzzlephp.org/en/stable/

# Config
copy config.default.php

rename to config.php and add your configuration

# Run
php -S localhost:8000

# visit browser 
using this url http://localhost:8000/test.php

# Cova API
Documentation 
https://api.covasoft.net/Documentation

Standard eCommerce
https://api.covasoft.net/StandardEcommerce

Standard Ecommerce Plus Integration
https://api.covasoft.net/StandardEcommercePlus

Swagger
https://api.covasoft.net//swagger/ui/index

